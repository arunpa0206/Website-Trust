<?php

namespace GiveMailChimp\MailChimp\Exceptions;

use Exception;

/**
 * Class InvalidMailChimpApiKeyException
 *
 * @package GiveMailChimp\MailChimp\Exceptions
 * @since 1.5.0
 */
class InvalidMailChimpApiKeyException extends Exception {

}
