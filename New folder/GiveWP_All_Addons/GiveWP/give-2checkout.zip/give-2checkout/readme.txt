=== Give - 2Checkout Gateway ===
Contributors: givewp
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, paymill, gateway
Requires at least: 4.9
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.1.5
Requires Give: 2.4.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

2Checkout Gateway Add-on for Give

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds a payment gateway for 2checkout.com.

== Installation ==

= Minimum Requirements =

* WordPress 4.9 or greater
* PHP version 5.6 or greater
* MySQL version 5.5 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.1.5: May 18th, 2021 =
* Fix: Resolved issue preventing donations from working in test mode

= 1.1.4: June 3rd, 2019 =
* Tweak: Adjusted the plugin's settings screens code logic to work with GiveWP Core 2.5.0+ which deprecates the old methods used to register settings in previous versions of this add-on.

= 1.1.3: September 27th, 2018 =
* Fix: Ensure the donor's first and last names are properly sent to the 2Checkout gateway.
* Fix: If switching gateways ensure that 2Checkout continues to function properly if a validation error occurs.
* Tweak: Update the 2Checkout PHP SDK to the latest version.

= 1.1.2: September 26th, 2018 =
* Fix: Some donors were not being properly redirected to the Donation Confirmation page after completing the 2Checkout payment screen.
* Tweak: The plugin will no longer deactivate itself if minimum requirements are not met but rather disable itself until requirements are met.

= 1.1.1: May 3rd, 2018 =
* Fix: Resolved error when Give is not activated and 2Checkout remains active.

= 1.1 =
* New: Added the ability to process refunds directly within the payment gateway. This will be only applicable to new
* Tweak: The plugin now respects its own constants. This is useful for non-traditional WP setups where plugins may reside in a separate directory.
* Tweak: Changed the position notices display if a transaction is declined to be more noticable for donors.
* Fix: If an incorrect CVC is entered it is now properly validated.

= 1.0.2 =
* Fix: When a custom donation was given the gateway would incorrectly assign it as a donation level within the receipt despite the correct custom amount being processed.

= 1.0.1 =
* New: Plugin now checks that Give is activated and the minimum version is met to activate this plugin. The plugin will deactivate if either conditions are not met.

= 1.0 =
* Initial plugin release. Yippee!
