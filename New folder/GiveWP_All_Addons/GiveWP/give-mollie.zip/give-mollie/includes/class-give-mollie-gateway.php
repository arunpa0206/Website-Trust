<?php
/**
 * Give Mollie Gateway.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/
 */

/**
 * The Give Mollie Payment Gateway Functionality Class.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes
 * @author     GiveWP
 */
class Give_Mollie_Gateway {

	/**
	 * Give_Mollie_Gateway constructor.
	 *
	 * @since 1.0
	 */
	public function __construct() {
		global $give_mollie;

		// Process payment.
		add_action( "give_gateway_{$give_mollie->gateway_slug}", array( $this, 'process_payment' ) );

		// Process refund amount.
		add_action( 'give_update_payment_status', array( $this, 'process_refund' ), 200, 3 );

		// Removed script enqueing since 1.2.0.
		// This is because payment selection screen has been moved to be  handled by Mollie.
		// add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}


	/**
	 * Process the Donations.
	 *
	 * @since 1.0
	 *
	 * @param array $donation_data Donation Data.
	 *
	 * @return  mixed
	 */
	public function process_payment( $donation_data ) {

		// Make sure we don't have any left over errors present.
		give_clear_errors();

		// Any errors?
		$errors = give_get_errors();

		if ( ! $errors ) {

			try {
				// Donation Price & Form ID.
				$form_id  = $donation_data['post_data']['give-form-id'];
				$price_id = ! empty( $donation_data['post_data']['give-price-id'] ) ? $donation_data['post_data']['give-price-id'] : 0;

				// Setup the payment details.
				$payment_details = array(
					'price'           => $donation_data['price'],
					'give_form_title' => $donation_data['post_data']['give-form-title'],
					'give_form_id'    => $form_id,
					'give_price_id'   => $price_id,
					'date'            => $donation_data['date'],
					'user_email'      => $donation_data['user_email'],
					'purchase_key'    => $donation_data['purchase_key'],
					'currency'        => give_get_currency( $form_id ),
					'user_info'       => $donation_data['user_info'],
					'status'          => 'pending',
					'gateway'         => 'mollie',
				);

				// Record the pending payment.
				$payment_id = give_insert_payment( $payment_details );

				// If payment creation failed.
				if ( ! $payment_id ) {
					return false;
				}

				/** @var \Give_Mollie_Webhook $give_mollie_webhook */
				$give_mollie_webhook  = new Give_Mollie_Webhook();
				$additional_query_arg = '&payment_id=' . $payment_id;
				$currency             = isset( $_POST['give-cs-form-currency'] ) ? give_clean( $_POST['give-cs-form-currency'] ) : give_get_currency( $form_id );

				// Mollie expects 1000.00 format (no thousands sep, but decimal sep with 2 decimals)
				// @see https://docs.mollie.com/reference/v2/payments-api/create-payment#parameters
				$mollie_formatted_amount = give_maybe_sanitize_amount(
					$donation_data['price'],
					array(
						'number_decimals' => 2,
					)
				);

				// Payment data.
				$payment_data = array(
					'amount'      => array(
						'value'    => $mollie_formatted_amount,
						'currency' => $currency,
					),
					'description' => strip_tags( Give_Mollie_API::get_payment_description( $payment_id ) ),
					'redirectUrl' => Give_Mollie_API::get_redirect_url( $payment_id ),
					'webhookUrl'  => $give_mollie_webhook->get_webhook_endpoint( 'payments', $additional_query_arg ),
					// "localhost", ".dev" are not acceptable.
					'metadata'    => array(
						'name'            => give_get_donor_name_by( $payment_id ),
						'email'           => isset( $_POST['give_email'] ) ? give_clean( $_POST['give_email'] ) : '',
						'give_form_id'    => isset( $_POST['give-form-id'] ) ? give_clean( $_POST['give-form-id'] ) : '',
						'give_form_title' => $donation_data['post_data']['give-form-title'],
						'give_price_id'   => $price_id,
						'date'            => $donation_data['date'],
						'user_email'      => $donation_data['user_email'],
						'purchase_key'    => $donation_data['purchase_key'],
						'currency'        => give_get_currency( $form_id ),
						'user_info'       => $donation_data['user_info'],
						'donation_id'     => $payment_id,
					),
				);

				/** @var \Give_Mollie_API $give_mollie */
				$give_mollie  = new Give_Mollie_API();
				$redirect_url = $give_mollie->create_payment( $payment_data );

				// Redirect to payment page.
				wp_redirect( $redirect_url );

			} catch ( Exception $e ) {

				// Payment creation failed.
				give_record_gateway_error( __( 'Payment Creation Failed', 'give-mollie' ), sprintf( __( 'Payment creation failed while processing the donation. Error: %1$s Details: %2$s', 'give-mollie' ), $e->getMessage(), json_encode( $donation_data ) ) );

				// Give set error.
				give_set_error( 'mollie_error', $e->getMessage() );

				// Send back to checkout page.
				give_send_back_to_checkout( '?payment-mode=mollie' );
			}
		} else {
			// Send back to checkout page.
			give_send_back_to_checkout( '?payment-mode=mollie' );
		}
	}

	/**
	 * Give Mollie refund process.
	 *
	 * @since   1.0
	 *
	 * @param   int    $payment_id Donation payment id.
	 * @param   string $new_status New payment status.
	 * @param   string $old_status Old payment status.
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 *
	 * @return  bool|WP_Error
	 */
	public function process_refund( $payment_id, $new_status, $old_status ) {
		// Get all posted data.
		$payment_data = give_clean( $_POST );

		// Only move forward if refund requested.
		if ( empty( $payment_data['give_refund_in_mollie'] ) ) {
			return false;
		}

		// Check if new status is refunded.
		if ( 'refunded' !== $new_status || ! isset( $payment_data ) ) {
			return false;
		}

		// Get Mollie payment id.
		$transaction_id = give_get_payment_transaction_id( $payment_id );

		// If no charge ID, look in the payment notes.
		if ( empty( $transaction_id ) ) {
			return new WP_Error( 'missing_payment', sprintf( __( 'Unable to refund order #%s. Order does not have the Mollie payment ID attachd to it.', 'give-mollie' ), $payment_id ) );
		}

		/** @var $mollie_obj \Give_Mollie_API $mollie_obj */
		$mollie_obj     = new Give_Mollie_API();
		$mollie_payment = $mollie_obj->get_payment( $transaction_id );

		// Check if this payment can be refundable.
		if ( $mollie_payment->canBeRefunded() ) {

			try {
				/** @var $refund \Mollie\Api\Resources\Refund */
				$refund = $mollie_payment->refund( array(
					'amount' => array(
						'value'    => $mollie_payment->amount->value,
						'currency' => $mollie_payment->amount->currency
					)
				) );

				// Collect Refund data.
				$refund_meta_data = array(
					'id'               => $refund->id,
					'amount'           => $refund->amount,
					'status'           => $refund->status,
					'refund_date_time' => $refund->createdAt,
				);

				// Store refund data.
				give_update_payment_meta( $payment_id, '_give_mollie_refund_data', $refund_meta_data );
				give_insert_payment_note( $payment_id, sprintf( __( 'Refund request sent to Mollie. Refund ID: %s', 'give-mollie' ), $refund->id ) );

			} catch ( \Mollie\Api\Exceptions\ApiException $e ) {
				// Insert payment note.
				give_insert_payment_note( $payment_id, sprintf( __( 'Unable to refund via Give Mollie: %s', 'give-mollie' ), $e->getMessage() ) );

				// Change it to previous status.
				give_update_payment_status( $payment_id, $old_status );
			}
		}
	}

	/**
	 * Include frontend css and js.
	 *
	 * NOT IN USE AS OF 1.2.0
	 *
	 * @since 1.0
	 */
	public function enqueue_scripts() {

		// Include CSS.
		wp_register_script( 'give-mollie-js', GIVE_MOLLIE_PLUGIN_URL . 'assets/dist/js/give-mollie.js', array(), GIVE_MOLLIE_VERSION, 'all' );
		wp_enqueue_script( 'give-mollie-js' );

		// Include CSS.
		wp_register_style( 'give-mollie-css', GIVE_MOLLIE_PLUGIN_URL . 'assets/dist/css/give-mollie.css', array(), GIVE_MOLLIE_VERSION, 'all' );
		wp_enqueue_style( 'give-mollie-css' );
	}


}

new Give_Mollie_Gateway();
