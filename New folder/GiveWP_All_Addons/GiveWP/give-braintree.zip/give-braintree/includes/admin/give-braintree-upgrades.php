<?php
/**
 * BrainTree Upgrades
 *
 * @package     Give
 * @copyright   Copyright (c) 2017, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.2
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Perform automatic upgrades when necessary.
 *
 * @since 1.1
 *
 * @return void
 */
function give_braintree_automatic_upgrades() {
	$did_upgrade      = false;
	$previous_version = preg_replace( '/[^0-9.].*/', '', get_option( 'give_braintree_version' ) );

	// Version 1.1 upgrade.
	if ( version_compare( '1.1', $previous_version, '>' ) || empty( $previous_version ) ) {

		// Sets the default option to display Billing Details
		// as to not mess with any donation forms without consent.
		give_update_option( 'braintree_collect_billing', 'on' );
		$did_upgrade = true;
	}

	if ( $did_upgrade || version_compare( $previous_version, GIVE_BRAINTREE_VERSION, '<' ) ) {
		// Update the version # saved in DB after version checks above.
		update_option( 'give_braintree_version', GIVE_BRAINTREE_VERSION );
	}
}

add_action( 'admin_init', 'give_braintree_automatic_upgrades' );