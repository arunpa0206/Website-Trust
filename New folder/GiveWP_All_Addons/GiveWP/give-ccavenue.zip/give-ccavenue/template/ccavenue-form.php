<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php _e( 'Process Donations with the CCAvenue payment gateway', 'give-ccavenue' ); ?></title>
</head>
<body>

<?php echo give_ccavenue_get_form(); ?>

<div class="give-ccavenue-redirect-wrap">
	<p style="text-align: center;margin-top: 5%;"><?php _e( 'We are now redirecting you to CCAvenue to complete your donation payment...', 'give-ccavenue' ); ?></p>
</div>

<script language="javascript">
	// Redirect after 2.5 seconds.
	// Adjustable via filter.
	window.setTimeout(function(){

		document.redirect.submit();

	}, <?php echo apply_filters('give_ccavenue_redirect_time', 2500) ?> );

</script>
</body>
</html>
