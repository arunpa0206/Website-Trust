<?php
/**
 * Show transaction ID under donation meta.
 *
 * @since 1.0
 *
 * @param $transaction_id
 */
function give_ccavenue_link_transaction_id( $transaction_id ) {

	$payment = new Give_Payment( $transaction_id );

	$ccavenue_trans_url = '#';

	if ( 'test' === $payment->mode ) {
		$ccavenue_trans_url = '#';
	}

	$ccavenue_response = get_post_meta( absint( $_GET['id'] ), 'ccavenue_donation_response', true );
	$ccavenue_trans_url .= $ccavenue_response['tracking_id'];

	echo sprintf( '<a href="%1$s" target="_blank">%2$s</a>', $ccavenue_trans_url, $ccavenue_response['tracking_id'] );
}

// add_filter( 'give_payment_details_transaction_id-ccavenue', 'give_ccavenue_link_transaction_id', 10, 2 );


/**
 * Add ccavenue donor detail to "Donor Detail" metabox
 *
 * @since 1.0
 *
 * @param int $donation_id Donation ID.
 *
 * @return bool
 */
function give_ccavenue_display_phone_number_in_admin( $donation_id ) {

	// Bailout.
	if ( 'ccavenue' !== give_get_payment_gateway( $donation_id ) ) {
		return false;
	}

	$phone_number = give_ccavenue_get_phone_number_value( $donation_id );
	?>
	<div class="column">
		<p>
			<strong><?php _e( 'Phone:', 'give-ccavenue' ); ?></strong><br/>
			<?php echo $phone_number; ?>
		</p>
	</div>
	<?php
}

add_action( 'give_payment_view_details', 'give_ccavenue_display_phone_number_in_admin' );
