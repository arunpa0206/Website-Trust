<?php

namespace GiveMailChimp\MailChimp;

use Give\Framework\Migrations\MigrationsRegister;
use Give\Helpers\Hooks;
use GiveMailChimp\Migrations\UpdateStoredMailChimpApiResponses;

/**
 * Class ServiceProvider
 * @package GiveMailChimp\MailChimp\Marketing
 * @since 1.5.0
 */
class ServiceProvider implements \Give\ServiceProviders\ServiceProvider {

	/**
	 * @inheritDoc
	 * @since 1.5.0
	 */
	public function register() {
		give()->singleton( ApiClient::class );
	}

	/**
	 * @inheritDoc
	 * @since 1.5.0
	 */
	public function boot() {
		$this->registerMigrations();

		if (
			isset( $_POST['give_mailchimp_api'] ) &&
			\Give_Admin_Settings::is_setting_page( 'give-mailchimp' ) &&
			\Give_Admin_Settings::is_saving_settings()
		) {
			Hooks::addAction( 'admin_init', ApiKeyValidator::class, 'handle' );
			Hooks::addAction( 'admin_init', RefreshMailchimpApiData::class, 'handle' );
		}
	}

	/**
	 * @since 1.5.0
	 */
	private function registerMigrations() {
		/** @var MigrationsRegister $register */
		$register = give( MigrationsRegister::class );
		$register->addMigrations( [ UpdateStoredMailChimpApiResponses::class ] );
	}
}
