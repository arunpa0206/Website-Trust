<?php
namespace GiveManualDonations\Infrastructure\Traits;

use GiveFunds\FundsServiceProvider;

/**
 * Class HasFundAddon
 * @package GiveManualDonations\Infrastructure\Traits
 *
 * @since 1.4.8
 */
trait FundAddonTrait {
	/**
	 * check whether or not fund addon active.
	 *
	 * @since 1.4.8
	 *
	 * @return bool
	 */
	public function isFundAddonActive() {
		return class_exists( FundsServiceProvider::class );
	}
}
