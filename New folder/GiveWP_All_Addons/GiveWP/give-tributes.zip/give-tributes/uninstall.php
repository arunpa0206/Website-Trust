<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @link       https://givewp.com
 * @since      1.0.0
 * @author     GiveWP
 *
 * @package    Give_Tributes
 */

// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Get Give core settings.
$give_settings = give_get_settings();

// List of plugin Global settings.
$plugin_settings = array(
	'give_tributes_enable_disable',
	'give_tributes_mail_a_card_enable_disable',
	'give_tributes_ecards_enable_disable',
	'give_tributes_fieldset_title',
	'give_tributes_text',
	'give_tributes_prepended_label',
	'give_tributes_section_location',
	'give_tributes_display_style',
	'give_tributes_who_sends_the_card',
	'give_tributes_custom_message_enable_disable',
	'give_tributes_message_length',
	'give_tributes_card_layout',
	'give_tributes_card_sizes',
	'give_tributes_card_font',
	'give_tributes_card_graphic',
	'give_tributes_card_content',
	'give_tributes_logo_graphic',
	'give_tributes_card_footer_text',
	'give_tributes_receipt_content_for_admin',
	'give_tributes_card_mailed_email_enable_disable',
	'give_tributes_card_sent_email_subject',
	'give_tributes_card_sent_email_heading',
	'give_tributes_card_sent_body',
	'give_tributes_card_creation_enable_disable',
	'give_tributes_receipt_content_for_donor',
	'give_tributes_ecards_custom_message_enable_disable',
	'give_tributes_ecards_email_subject',
	'give_tributes_ecards_logo_graphic',
	'give_tributes_ecards_card_graphic',
	'give_tributes_ecards_content',
	'give_tributes_prepended_label_enable_disable',
);

foreach ( $give_settings as $setting_key => $setting ) {
	if ( in_array( $setting_key, $plugin_settings ) ) {
		unset( $give_settings[ $setting_key ] );
	}
}


// Update settings.
update_option( 'give_settings', $give_settings );

// List of Plugin meta settings.
$plugin_post_meta_settings = array(
	'_give_tributes_per_form_enable_disable',
	'_give_tributes_per_form__repeater',
	'_give_tributes_per_form_give_tributes_text',
	'_give_tributes_per_form_fieldset_title',
	'_give_tributes_per_form_prepended_label',
	'_give_tributes_per_form_section_location',
	'_give_tributes_per_form_display_style',
	'_give_tributes_per_form_mail_a_card_enable_disable',
	'_give_tributes_per_form_custom_message_enable_disable',
	'_give_tributes_per_form_message_length',
	'_give_tributes_per_form_who_sends_the_card',
	'_give_tributes_per_form_card_creation_enable_disable',
	'_give_tributes_per_form_card_layout',
	'_give_tributes_per_form_card_sizes',
	'_give_tributes_per_form_card_font',
	'_give_tributes_per_form_card_graphic',
	'_give_tributes_per_form_card_content',
	'_give_tributes_per_form_logo_graphic',
	'_give_tributes_per_form_card_footer_text',
	'_give_tributes_per_form_receipt_content_for_admin',
	'_give_tributes_per_form_receipt_content_for_donor',
	'_give_tributes_per_form_card_mailed_email_enable_disable',
	'_give_tributes_per_form_card_sent_email_subject',
	'_give_tributes_per_form_card_sent_email_heading',
	'_give_tributes_per_form_give_tributes_card_sent_body',
	'_give_tributes_per_form_ecards_enable_disable',
	'_give_tributes_per_form_ecards_custom_message_enable_disable',
	'_give_tributes_per_form_ecards_message_length',
	'_give_tributes_per_form_ecards_email_subject',
	'_give_tributes_per_form_ecards_logo_graphic',
	'_give_tributes_per_form_ecards_card_graphic',
	'_give_tributes_per_form_ecards_content',
	'_give_tributes_per_form_prepended_label_enable_disable',
);


$items = get_posts( array(
	'post_type'   => 'give_forms',
	'post_status' => 'any',
	'numberposts' => - 1,
	'fields'      => 'ids',
) );


if ( $items ) {
	foreach ( $items as $item ) {

		$give_post_meta_data = give_get_meta( $item, '' );

		if ( $give_post_meta_data ) {
			foreach ( $give_post_meta_data as $key => $meta_value ) {
				if ( in_array( $key, $plugin_post_meta_settings, true ) ) {
					delete_post_meta( $item, $key );
				}
			}
		}
	}
}

// List of Plugin payment meta settings.
$plugin_payment_meta_settings = array(
	'_give_tributes_accept',
	'_give_tributes_per_form_enable_disable',
	'_give_tributes_type',
	'_give_tributes_first_name',
	'_give_tributes_last_name',
	'_give_tributes_would_to',
	'_give_tributes_honoree_ecard_email',
	'_give_tributes_ecard_personalized_message',
	'_give_tributes_mail_card_personalized_message',
	'_give_tributes_mail_card_address_1',
	'_give_tributes_mail_card_address_2',
	'_give_tributes_mail_card_city',
	'_give_tributes_address_country',
	'_give_tributes_address_state',
	'_give_tributes_mail_card_zipcode',
	'_give_tributes_who_sends_the_card',
	'_give_tributes_mail_card_notify_first_name',
	'_give_tributes_mail_card_notify_last_name',
);

$payments = get_posts( array(
	'post_type'   => 'give_payment',
	'post_status' => 'any',
	'numberposts' => - 1,
	'fields'      => 'ids',
) );

if ( $payments ) {
	foreach ( $payments as $payment ) {

		$give_payment_meta_data = give_get_meta( $payment, '' );

		if ( $give_payment_meta_data ) {
			foreach ( $give_payment_meta_data as $key => $meta_value ) {
				if ( in_array( $key, $plugin_payment_meta_settings, true ) ) {
					delete_post_meta( $payment, $key );
				}
			}
		}
	}
}
