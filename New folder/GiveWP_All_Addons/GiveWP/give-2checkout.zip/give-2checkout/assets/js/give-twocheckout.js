/**
 * Give 2Checkout Gateway
 *
 * @description: Tokenizes credit card data for 2Checkout
 */

var give_twocheckout_js;

jQuery( document ).ready(
	function ($) {

		// Pull in the public key for the environment (sandbox or production).
		TCO.loadPubKey( give_twocheckout_js.env );

		// On gateway change.
		$( document ).on(
			'give_gateway_loaded', function () {

				$( '.give-form' ).each(
					function () {
						give2Checkout( $( this ) );
					}
				);

			}
		);

		// Loop through donation forms on page and initialize 2Checkout.
		$( '.give-form' ).each(
			function () {
				give2Checkout( $( this ) );
			}
		);

		/**
		 * Process gateway payments and errors upon donation button click.
		 *
		 * @param form
		 */
		function give2Checkout(form) {

			var form_submit_btn = form.find( '.give-submit' ),
				form_loader     = form.find( '.give-loading-animation' );

			/**
			 * Set per form submission
			 */
			form.submit(
				function (e) {

					// Prevent multiple requests.
					form_submit_btn.attr( 'disabled', 'disabled' );

					// Make sure the proper gateway is set.
					if ('twocheckout' === form.find( 'input[name="give-gateway"]' ).val()) {
						if (give_twocheckout_js.sellerId && give_twocheckout_js.publishableKey) {
							// Call our token request function
							tokenRequest();
							return false;
						} else {
							// Missing credentials
							give2CheckoutError( give_twocheckout_js.keys_error );
							return false;
						}
					}
				}
			);

			/**
			 * 2Checkout Error
			 *
			 * @param message
			 */
			function give2CheckoutError(message) {

				var html = '';
				html    += '<div class="give_notices give_errors">';
				html    += '<div class="give_error give_notice"';
				html    += '<p><strong>' + give_twocheckout_js.error + '</strong>: ';
				html    += message;
				html    += '</p></div></div>';

				form_loader.hide();
				form_submit_btn.attr( 'disabled', false );
				form_submit_btn.val( form_submit_btn.data( 'before-validation-label' ) );
				form_submit_btn.before( html );
			}

			/**
			 * 2Checkout Success Callback
			 *
			 * @param data
			 */
			var successCallback = function (data) {
				// Set the token as the value for the token input
				form.find( '.twocheckout-token' ).val( data.response.token.token );
				// IMPORTANT: Here we call `submit()` on the form element directly instead of using jQuery to prevent and infinite token request loop.
				form.unbind( 'submit' ).submit();
			};

			/**
			 * Error Callback
			 *
			 * Called when token creation fails.
			 *
			 * @param data
			 */
			var errorCallback = function (data) {

				var errorcode = parseInt( data.errorCode );

				if (200 === errorcode) {
					// Ajax failed
					give2CheckoutError( give_twocheckout_js.api_error );
				} else if ('Unauthorized' === data.errorMsg) {
					// Incorrect credentials
					give2CheckoutError( give_twocheckout_js.keys_error );
				} else if (401 === errorcode) {
					// Incorrect credit card details.
					give2CheckoutError( give_twocheckout_js.card_details_error );
				} else {
					// Other errors
					give2CheckoutError( data.errorMsg );
				}
			};

			/**
			 * Token Request
			 */
			var tokenRequest = function () {
				// Setup token request arguments
				var args = {
					sellerId: give_twocheckout_js.sellerId,
					publishableKey: give_twocheckout_js.publishableKey,
					ccNo: form.find( '.card-number' ).val(),
					cvv: form.find( '.card-cvc' ).val(),
					expMonth: form.find( '.card-expiry' ).val().substring( 0, 2 ),
					expYear: form.find( '.card-expiry' ).val().substring( 5, 7 )
				};
				// Make the token request
				TCO.requestToken( successCallback, errorCallback, args );
			};

		}

	}
);
