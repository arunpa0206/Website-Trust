<?php defined( 'ABSPATH' ) or exit; ?>

<div class="notice notice-error">
	<p>
		<strong><?php _e( 'Activation Error:', 'give-manual-donations' ); ?></strong>
		<?php esc_html_e( 'You must have', 'give-manual-donations' ); ?> <a href="https://givewp.com" target="_blank">Give</a>
		<?php printf( __( 'plugin installed and activated for the %s add-on to activate', 'give-manual-donations' ), GIVE_MD_ADDON_NAME ); ?>
	</p>
</div>
