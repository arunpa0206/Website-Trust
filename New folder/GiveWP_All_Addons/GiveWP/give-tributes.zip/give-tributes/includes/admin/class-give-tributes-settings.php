<?php
/**
 * Give Tributes Settings Page/Tab
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/admin
 * @author     GiveWP <https://givewp.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Give_Tributes_Settings.
 *
 * @sine 1.0.0
 */
class Give_Tributes_Settings extends Give_Settings_Page {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->id    = 'tributes';
		$this->label = __( 'Tributes', 'give-tributes' );

		$this->default_tab = 'tributes-settings';

		parent::__construct();
	}

	/**
	 * Get settings array.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return array
	 */
	public function get_settings() {
		$settings        = array();
		$current_section = give_get_current_setting_section();

		switch ( $current_section ) {
			case 'tributes-settings':
				$settings = array(
					// Section 1: Tribute Settings.
					array(
						'type' => 'title',
						'id'   => 'give_tributes_settings',
					),
					array(
						'name'          => __( 'Tributes', 'give-tributes' ),
						'desc'          => __( 'This enables the Tributes feature for all your website\'s donation forms. Note: You can enable/disable this option and customize Tributes per form as well.', 'give-tributes' ),
						'id'            => 'give_tributes_enable_disable',
						'wrapper_class' => 'give_tributes_enable_disable',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Mail a Card', 'give-tributes' ),
						'desc'          => __( 'This enables the "Mail a Card" feature for all your website\'s donation forms. Note: You can enable / disable this option and customize Tributes per form as well.', 'give-tributes' ),
						'id'            => 'give_tributes_mail_a_card_enable_disable',
						'wrapper_class' => 'give_tributes_mail_a_card_enable_disable give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'eCards', 'give-tributes' ),
						'desc'          => __( 'This enables the "eCard" feature for all your website\'s donation forms. Note: You can enable / disable this option and customize Tributes per form as well.', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_enable_disable',
						'wrapper_class' => 'give_tributes_ecards_enable_disable give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Fieldset Title', 'give-tributes' ),
						'id'            => 'give_tributes_fieldset_title',
						'wrapper_class' => 'give_tributes_fields',
						'desc'          => __( 'Customize the text that displays inviting the donor to give a tribute.', 'give-tributes' ),
						'default'       => __( 'Dedicate this Donation', 'give-tributes' ),
						'placeholder'   => __( 'Dedicate this Donation', 'give-tributes' ),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Tribute Options', 'give-tributes' ),
						'id'            => 'give_tributes_options_repeater',
						'wrapper_class' => 'give_tributes_options_repeater give_tributes_fields',
						'type'          => 'give_tributes_group_repeater',
						'description'   => __( 'Add or edit tribute options. For example, "In honor of" or "In memory of".', 'give-tributes' ),
						'options'       => array(
							'add_button'      => __( 'Add Tribute Option', 'give-tributes' ),
							'header_title'    => __( 'Group', 'give-tributes' ),
							'remove_button'   => '<span class="dashicons dashicons-no"></span>',
							'group_numbering' => true,
							'close_tabs'      => true,
						),
						'fields'        => array(
							array(
								'name'          => __( 'Tribute Text', 'give-tributes' ),
								'id'            => 'give_tributes_text',
								'type'          => 'text',
								'wrapper_class' => 'give_tributes_text',
							),
						),
					),
					array(
						'name'          => __( 'Prepended Label', 'give-tributes' ),
						'desc'          => __( 'This enables the "Tribute Prepended Label" option that allows you to set a prepended label to customize how you address the honoree.', 'give-tributes' ),
						'id'            => 'give_tributes_prepended_label_enable_disable',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'enabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Tribute Prepended Label', 'give-tributes' ),
						'id'            => 'give_tributes_prepended_label',
						'wrapper_class' => 'give_tributes_fields give_tributes_prepended_wrap',
						'desc'          => __( 'This text appears before field labels and input placeholders asking for the honoree\'s information within your donation forms.', 'give-tributes' ),
						'default'       => __( 'Honoree', 'give-tributes' ),
						'placeholder'   => __( 'Honoree', 'give-tributes' ),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Last Name Field', 'give-tributes' ),
						'desc'          => __( 'This option customizes the "Last Name" field requirement for the honoree information.', 'give-tributes' ),
						'id'            => 'give_tributes_honoree_last_name',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'not_required',
						'options'       => array(
							'required'     => __( 'Required', 'give-tributes' ),
							'not_required' => __( 'Not Required', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Notify Option', 'give-tributes' ),
						'desc'          => __( 'Control the donor\'s options for notifying the recipient of their tribute donation. Donor Chooses Method: This option will allow the donor to choose how he/she wants the recipient to be notified (most common). Admin Chooses Method: The admin (you) can choose the specific notification method "Mail a Card" or "eCard" without allowing the donor to choose. No Notification: Choose this option if the you don\'t want to provide the donor an option to notify the recipient (this is useful if you plan on handling notifications on your own).', 'give-tributes' ),
						'id'            => 'give_tributes_notify_display_option',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'donor_choice',
						'options'       => array(
							'donor_choice' => __( 'Donor chooses method', 'give-tributes' ),
							'admin_choice' => __( 'Admin chooses method', 'give-tributes' ),
							'none'         => __( 'No notification', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Notify Method', 'give-tributes' ),
						'desc'          => __( 'Choose the method to notify the recipient of the donation made in tribute. Please ensure the option chosen is enabled.', 'give-tributes' ),
						'id'            => 'give_tributes_notify_method',
						'wrapper_class' => 'give_tributes_fields give_tribute_notify_method_lists',
						'type'          => 'select',
						'default'       => 'send_mail_card',
						'options'       => array(
							'send_mail_card' => __( 'Mail a Card', 'give-tributes' ) . ' ' . ( give_is_setting_enabled( give_get_option( 'give_tributes_mail_a_card_enable_disable' ) ) ? __( '(enabled)', 'give-tributes' ) : __( '(disabled )', 'give-tributes' ) ),
							'send_eCard'     => __( 'eCards', 'give-tributes' ) . ' ' . ( give_is_setting_enabled( give_get_option( 'give_tributes_ecards_enable_disable' ) ) ? __( '(enabled)', 'give-tributes' ) : __( '(disabled)', 'give-tributes' ) ),
						),
					),
					array(
						'name'          => __( 'Tribute Section Location', 'give-tributes' ),
						'desc'          => __( 'Choose option to place tribute section in the location.', 'give-tributes' ),
						'id'            => 'give_tributes_section_location',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'select',
						'default'       => 'give_payment_mode_top',
						'options'       => array(
							'give_after_donation_levels'              => __( 'Below the donation level fields', 'give-tributes' ),
							'give_after_donation_amount'              => __( 'Below the top donation amount field', 'give-tributes' ),
							'give_payment_mode_top'                   => __( 'Above the payment options', 'give-tributes' ),
							'give_payment_mode_bottom'                => __( 'Below the payment options', 'give-tributes' ),
							'give_donation_form_before_personal_info' => __( 'Above the personal info fields', 'give-tributes' ),
							'give_donation_form_after_personal_info'  => __( 'Below the personal info fields', 'give-tributes' ),
							'give_donation_form_before_cc_form'       => __( 'Above the credit card fields', 'give-tributes' ),
							'give_donation_form_after_cc_form'        => __( 'Below the credit card fields', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Display Style', 'give-tributes' ),
						'desc'          => __( 'Customize the field that displays on the donation forms for the tributes options listed above.', 'give-tributes' ),
						'id'            => 'give_tributes_display_style',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'radios',
						'options'       => array(
							'radios'   => __( 'Radios', 'give-tributes' ),
							'dropdown' => __( 'Dropdown', 'give-tributes' ),
							'buttons'  => __( 'Buttons', 'give-tributes' ),
						),
					),
					array(
						'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
						'id'    => 'give_tributes_settings_docs_link',
						'url'   => esc_url( 'http://docs.givewp.com/addon-tributes/' ),
						'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
						'type'  => 'give_docs_link',
					),
					array(
						'type' => 'sectionend',
						'id'   => 'give_tributes_settings',
					),
				);
				break;

			case 'tributes-mail-card' :
				$settings = array(
					// Section 2: Mail a Card.
					array(
						'type' => 'title',
						'id'   => 'give_tributes_mail_a_card_settings',
					),
					array(
						'name'          => __( 'Who Sends the Card?', 'give-tributes' ),
						'desc'          => __( 'If you plan on mailing the cards yourself use "The Admin" option. If you would to donors to send the card themselves then select "The Donor". This will provide donors the ability to print and mail the card themselves.', 'give-tributes' ),
						'id'            => 'give_tributes_who_sends_the_card',
						'wrapper_class' => 'give_tributes_who_sends_the_card',
						'type'          => 'radio_inline',
						'default'       => 'the_admin',
						'options'       => array(
							'the_admin' => __( 'The Admin', 'give-tributes' ),
							'the_donor' => __( 'The Donor', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Custom  Message', 'give-tributes' ),
						'desc'          => __( 'Enable if you would like the donor to be able to provide a custom message for the mailed card.', 'give-tributes' ),
						'id'            => 'give_tributes_custom_message_enable_disable',
						'wrapper_class' => 'give_tributes_custom_message_enable_disable',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Message Length', 'give-tributes' ),
						'desc'          => __( 'Adjusts the number of allowed characters for the tributes message.', 'give-tributes' ),
						'id'            => 'give_tributes_message_length',
						'wrapper_class' => 'give_tributes_message_length',
						'type'          => 'number',
						'css'           => 'width:12em;',
						'default'       => 255,
					),
					array(
						'name'          => __( 'Card Creation', 'give-tributes' ),
						'desc'          => __( 'Enable if you would like to generate a PDF card that can be easily printed and mailed.', 'give-tributes' ),
						'id'            => 'give_tributes_card_creation_enable_disable',
						'wrapper_class' => 'give_tribute_donor_mailed',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Card Layout', 'give-tributes' ),
						'desc'          => __( 'Choose a card layout option.', 'give-tributes' ),
						'id'            => 'give_tributes_card_layout',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'select',
						'default'       => 'L',
						'options'       => array(
							'L' => __( 'Portrait Card', 'give-tributes' ),
							'P' => __( 'Landscape Card', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Card Sizes', 'give-tributes' ),
						'desc'          => __( 'Select which size of cards you would like generated.', 'give-tributes' ),
						'id'            => 'give_tributes_card_sizes',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'multicheck',
						'default'       => array(
							'letter',
						),
						'options'       => array(
							'letter' => 'Letter( 8.5 by 11 inches)',
							'a4'     => 'A4( 8.27 by 11.69 inches)',
							'a5'     => 'A5( 5.8 by 8.3 inches)',
							'a6'     => 'A6( 4.1 by 5.8 inches)',
						),
					),
					array(
						'name'          => __( 'Card Font', 'give-tributes' ),
						'desc'          => __( 'Choose a card font option for the Mail a Card content.', 'give-tributes' ),
						'id'            => 'give_tributes_card_font',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'select',
						'default'       => 'helvetica',
						'options'       => array(
							'courier'   => __( 'Courier', 'give-tributes' ),
							'helvetica' => __( 'Helvetica', 'give-tributes' ),
							'times'     => __( 'Times New Roman', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Last Name Field', 'give-tributes' ),
						'desc'          => __( 'This option customizes the "Last Name" field requirement for the card recipient.', 'give-tributes' ),
						'id'            => 'give_tributes_mail_card_last_name',
						'wrapper_class' => 'give_tributes_fields give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'radio_inline',
						'default'       => 'not_required',
						'options'       => array(
							'required'     => __( 'Required', 'give-tributes' ),
							'not_required' => __( 'Not Required', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Special Characters', 'give-tributes' ),
						'id'            => 'give_tributes_special_chars',
						'description'   => __( 'Characters not displaying correctly? Check to enable the DejaVu Sans font replacing Courier/Helvetica/Times New Roman. Enable this option if you have characters which do not display correctly (e.g. Greek characters, Japanese, Mandarin, etc.)', 'give-tributes' ),
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => 'Enabled',
							'disabled' => 'Disabled',
						),
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
					),
					array(
						'name'          => __( 'Card Graphic', 'give-tributes' ),
						'desc'          => __( 'Upload a graphic to display as the main card image.', 'give-tributes' ),
						'id'            => 'give_tributes_card_graphic',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'file',
					),
					array(
						'name'          => __( 'Preview Card', 'give-tributes' ),
						'desc'          => __( 'Click to preview the card.', 'give-tributes' ),
						'id'            => 'give_tributes_preview_mail_card_button give_tributes_card_creation_fields',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'give_tributes_preview_mail_card_button',
					),
					array(
						'name'          => __( 'Card Content', 'give-tributes' ),
						'id'            => 'give_tributes_card_content',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'desc'          => sprintf( /* translators: %s: emails tags list */
							__( 'Enter Content for the Mailable Card that is provided in addition to the donor\'s message if enabled.<br> Images and HTML are accepted. <br><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br>' . give_tribute_get_tag_list() ),
						'type'          => 'wysiwyg',
						'default'       => give_tributes_get_mail_card_default_content(),
					),
					array(
						'name'          => __( 'Card Back Graphic', 'give-tributes' ),
						'desc'          => __( 'Upload a graphic to display on the back of the card.', 'give-tributes' ),
						'id'            => 'give_tributes_logo_graphic',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'type'          => 'file',
					),
					array(
						'name'          => __( 'Card Back Text', 'give-tributes' ),
						'desc'          => __( 'Customize the content that appears on the back of the card.', 'give-tributes' ),
						'id'            => 'give_tributes_card_footer_text',
						'wrapper_class' => 'give_tributes_card_creation_fields give_tribute_admin_mailed',
						'default'       => give_tributes_get_mail_card_default_back_text(),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Receipt Content', 'give-tributes' ),
						'id'            => 'give_tributes_receipt_content_for_admin',
						'wrapper_class' => 'give_tribute_admin_mailed',
						'desc'          => sprintf( /* translators: %s: emails tags list */
							__( 'This content will appear on the donation receipt page above the receipt.<br> Images and HTML are accepted. <br><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br>' . give_tribute_get_tag_list() ),
						'type'          => 'wysiwyg',
						'default'       => give_tributes_default_mail_card_receipt_content( 'admin' ),
					),
					array(
						'name'          => __( 'Receipt Content', 'give-tributes' ),
						'id'            => 'give_tributes_receipt_content_for_donor',
						'wrapper_class' => 'give_tribute_donor_mailed give_tributes_card_creation_fields',
						'desc'          => sprintf( /* translators: %s: emails tags list */
							__( 'This content will appear on the donation receipt page above the receipt.<br> Images and HTML are accepted. <br><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br>' . give_tribute_get_tag_list() ),
						'type'          => 'wysiwyg',
						'default'       => give_tributes_default_mail_card_receipt_content( 'donor' ),
					),
					array(
						'name'          => __( 'Card Mailed Email', 'give-tributes' ),
						'desc'          => __( 'Enable if you would like to email your donors when a card has been marked as sent.', 'give-tributes' ),
						'id'            => 'give_tributes_card_mailed_email_enable_disable',
						'wrapper_class' => 'give_tribute_admin_mailed',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Card Sent Email Subject', 'give-tributes' ),
						'desc'          => __( 'Enter the subject line for the card sent notification email.', 'give-tributes' ),
						'id'            => 'give_tributes_card_sent_email_subject',
						'wrapper_class' => 'card_mailed_email_fields give_tribute_admin_mailed',
						'default'       => __( 'Dedication Card Sent Notification', 'give-tributes' ),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Card Sent Email Heading', 'give-tributes' ),
						'desc'          => __( 'Enter the email heading for the card sent notification email.', 'give-tributes' ),
						'id'            => 'give_tributes_card_sent_email_heading',
						'wrapper_class' => 'card_mailed_email_fields give_tribute_admin_mailed',
						'default'       => __( 'Dedication Card Mailed', 'give-tributes' ),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Card Sent Email Body', 'give-tributes' ),
						'id'            => 'give_tributes_card_sent_body',
						'wrapper_class' => 'card_mailed_email_fields give_tribute_admin_mailed',
						'desc'          => sprintf( __( 'Enter the Content for the Card Sent Email Body.<br> Images and HTML are accepted. <br><strong> Available template tags:</strong> %s', 'give-tributes' ), ' <br>' . give_tribute_get_tag_list() ),
						'type'          => 'wysiwyg',
						'default'       => give_tributes_get_mail_card_sent_notification_content(),
					),
					array(
						'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
						'id'    => 'give_tributes_settings_docs_link',
						'url'   => esc_url( 'http://docs.givewp.com/addon-tributes/' ),
						'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
						'type'  => 'give_docs_link',
					),
					array(
						'type' => 'sectionend',
						'id'   => 'give_tributes_mail_a_card_settings',
					),
				);
				break;

			case 'tributes-ecard':
				$settings = array(
					// Section 3: eCards.
					array(
						'id'   => 'give_tributes_ecard_settings',
						'type' => 'title',
					),
					array(
						'name'          => __( 'Custom  Message', 'give-tributes' ),
						'desc'          => __( 'Enable if you would like the donor to be able to provide a custom message within the eCard.', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_custom_message_enable_disable',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Message Length', 'give-tributes' ),
						'desc'          => __( 'Adjusts the number of allowed characters for the tributes message.', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_message_length',
						'wrapper_class' => 'give_tributes_ecards_message_length give_tributes_ecard_fields',
						'type'          => 'number',
						'css'           => 'width:12em;',
						'default'       => 255,
					),
					array(
						'name'          => __( 'eCard Email Subject', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_email_subject',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'desc'          => __( 'Enter the subject line for the eCard email. The template tags found below will work in this field.', 'give-tributes' ),
						'default'       => give_tributes_get_default_ecard_subject(),
						'placeholder'   => give_tributes_get_default_ecard_subject(),
						'type'          => 'text',
					),
					array(
						'name'          => __( 'Multiple eCard Recipients', 'give-tributes' ),
						'desc'          => __( 'Allow your donors to provide multiple notification names and emails for their dedicated donation. This will send a dedication email to each notification recipient the donor provides.', 'give-tributes' ),
						'id'            => 'give_ecards_multiple_recipients',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'type'          => 'radio_inline',
						'default'       => 'disabled',
						'options'       => array(
							'enabled'  => __( 'Enabled', 'give-tributes' ),
							'disabled' => __( 'Disabled', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Last Name Field', 'give-tributes' ),
						'desc'          => __( 'This option customizes the "Last Name" field requirement for the card recipient.', 'give-tributes' ),
						'id'            => 'give_tributes_ecard_last_name',
						'wrapper_class' => 'give_tributes_fields',
						'type'          => 'radio_inline',
						'default'       => 'not_required',
						'options'       => array(
							'required'     => __( 'Required', 'give-tributes' ),
							'not_required' => __( 'Not Required', 'give-tributes' ),
						),
					),
					array(
						'name'          => __( 'Logo Graphic', 'give-tributes' ),
						'desc'          => __( 'Upload a graphic to display at the top of the eCard.', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_logo_graphic',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'type'          => 'file',
					),
					array(
						'name'          => __( 'eCard Header Graphic', 'give-tributes' ),
						'desc'          => __( 'Upload a graphic to display at the top of the eCard.', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_card_graphic',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'type'          => 'file',
					),
					array(
						'name'          => __( 'eCard Content', 'give-tributes' ),
						'id'            => 'give_tributes_ecards_content',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'desc'          => sprintf( /* translators: %s: emails tags list */
							__( 'Enter Content for the eCard that is provided in addition to the donor\'s message if enabled. <br>Images and HTML are accepted. <br><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br>' . give_tribute_get_tag_list() ),
						'type'          => 'wysiwyg',
						'default'       => give_tributes_get_ecard_default_content(),
					),
					array(
						'name'          => __( 'Preview eCard', 'give-tributes' ),
						'desc'          => __( 'Click the buttons to preview eCard and send eCard.', 'give-tributes' ),
						'id'            => 'give_tributes_preview_ecard_button',
						'wrapper_class' => 'give_tributes_ecard_fields',
						'type'          => 'give_tributes_preview_ecard_button',
					),
					array(
						'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
						'id'    => 'give_tributes_settings_docs_link',
						'url'   => esc_url( 'http://docs.givewp.com/addon-tributes/' ),
						'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
						'type'  => 'give_docs_link',
					),
					array(
						'id'   => 'give_tributes_ecard_settings',
						'type' => 'sectionend',
					),
				);
				break;
		}// End switch().

		/**
		 * Filter the Give - Tributes settings.
		 *
		 * @since  1.0.0
		 *
		 * @param  array $settings
		 */
		$settings = apply_filters( 'give_tributes_get_settings_' . $this->id, $settings );

		// Output.
		return $settings;
	}

	/**
	 * Get sections.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return array
	 */
	public function get_sections() {
		$sections = array(
			'tributes-settings' => __( 'General Options', 'give-tributes' ),
		);

		// Get the value of global Tribute enable/disable.
		$give_tributes_enable_disable = give_get_option( 'give_tributes_enable_disable', 'disabled' );

		// Get the value of Mail a Card enabled/disabled.
		$give_tributes_mail_a_card_enable_disable = give_get_option( 'give_tributes_mail_a_card_enable_disable', 'disabled' );

		// Get the value of Mail a Card enabled/disabled.
		$give_tributes_ecards_enable_disable = give_get_option( 'give_tributes_ecards_enable_disable', 'disabled' );

		// Show Mail a Card section if it's enabled.
		if ( 'disabled' !== $give_tributes_mail_a_card_enable_disable && 'disabled' !== $give_tributes_enable_disable ) {
			$sections['tributes-mail-card'] = __( 'Mail a Card', 'give-tributes' );
		}// End if().

		// Show eCard section if it's enabled.
		if ( 'disabled' !== $give_tributes_ecards_enable_disable && 'disabled' !== $give_tributes_enable_disable ) {
			$sections['tributes-ecard'] = __( 'eCards', 'give-tributes' );
		}// End if().

		return apply_filters( 'give_get_sections_' . $this->id, $sections );
	}
}


return new Give_Tributes_Settings();
