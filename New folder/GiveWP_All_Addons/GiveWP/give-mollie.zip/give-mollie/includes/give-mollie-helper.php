<?php
/**
 * Give - Mollie Helper functions
 */

/**
 * Collect Billing details or not?
 *
 * @since 1.0
 */
function give_mollie_show_billing_address() {

	global $give_mollie;

	// Give Mollie does not need a CC form, so remove it.
	add_action( "give_{$give_mollie->gateway_slug}_cc_form", '__return_false' );

	// Get value of billing details.
	$collect_billing_details = give_get_option( "_give_{$give_mollie->gateway_slug}_collect_billing_details", false );

	if (
		false !== $collect_billing_details
		&& 'off' !== $collect_billing_details
	) {

		// Add Billing address section after the Personal Info. section.
		add_action( "give_{$give_mollie->gateway_slug}_cc_form", 'give_default_cc_address_fields' );
	}
}

// Show/hide billing details.
add_action( 'init', 'give_mollie_show_billing_address', 10 );

/**
 * Add checkbox and JS for charge refund in merchant account.
 *
 * @since 1.0
 *
 * @param $payment_id
 */
function give_mollie_admin_payment_js( $payment_id ) {
	// Return, if gateway is not mollie.
	if ( 'mollie' !== give_get_payment_gateway( $payment_id ) ) {
		return;
	}
	?>
	<script type="text/javascript">
		// On page loaded.
		document.addEventListener( 'DOMContentLoaded', event => {

			// Get the status drop-down.
			const status_dropdown = document.querySelector( 'select[name=give-payment-status]' );

			// On change of the payment status drop-down.
			status_dropdown.addEventListener( 'change', function( event ) {

				// Get the refund checkbox.
				const refund_checkbox = document.querySelector( 'p.give-mollie-refund' );

				// If we have refund checkbox.
				if ( null != refund_checkbox ) {

					// Remove checkbox.
					refund_checkbox.remove();
				}

				// If refund option was selected.
				if ( 'refunded' === this.value ) {

					var refund_charge_checkbox = '<p class="give-mollie-refund"><input type="checkbox" id="give_refund_in_mollie" name="give_refund_in_mollie" value="1"/><label for="give_refund_in_mollie"><?php _e('Refund Charge in Mollie?', 'give-mollie'); ?></label></p>';

					document.querySelector( 'div.give-admin-box-inside' ).insertAdjacentHTML( 'beforeend', refund_charge_checkbox );
				}
			} );
		} );
	</script>
	<?php

}

add_action( 'give_view_donation_details_before', 'give_mollie_admin_payment_js', 100 );


/**
 * Displays the Mollie customer ID linked to profile on the donation details screen.
 *
 * @param $payment_id
 *
 * @return mixed
 */
function give_mollie_display_customer_id_on_donation_details( $payment_id ) {

	$gateway = give_get_payment_gateway( $payment_id );

	if ( 'mollie' !== $gateway ) {
		return $payment_id;
	}

	$donor = new Give_Donor( give_get_payment_donor_id( $payment_id ) );
	/** @var \Give_Mollie_API $give_mollie_api */
	$give_mollie_api = new Give_Mollie_API();
	$customer_key    = $donor->get_meta( $give_mollie_api->get_customer_meta_key() );

	if ( ! empty( $customer_key ) ) {
		echo '<div class="give-mollie-customer-id give-admin-box-inside"><p><strong>' . __( 'Mollie Customer ID', 'give-mollie' ) . '</strong>:&nbsp;<a href="https://www.mollie.com/dashboard/customers/' . $customer_key . '" target="_blank">' . $customer_key . '</a></p></div>';
	}

}


add_filter( 'give_view_donation_details_payment_meta_after', 'give_mollie_display_customer_id_on_donation_details', 10, 1 );


/**
 * Link transaction ID.
 *
 * Links the transaction ID in the donation details using the ID to the Mollie payment details page.
 *
 * @since 1.3.0
 *
 * @param $transaction_id
 * @param $payment_id
 *
 * @return string
 */
function give_mollie_link_transaction_id( $transaction_id, $payment_id ) {

	if ( intval( $transaction_id ) === intval( $payment_id ) ) {
		return $transaction_id;
	}

	// Link to payment in Mollie.
	if ( ! empty( $transaction_id ) ) {
		$transaction_id = '<a href="https://www.mollie.com/dashboard/payments/' . $transaction_id . '" target="_blank">' . $transaction_id . '</a>';
	}

	return $transaction_id;

}

add_filter( 'give_payment_details_transaction_id-mollie', 'give_mollie_link_transaction_id', 10, 2 );
