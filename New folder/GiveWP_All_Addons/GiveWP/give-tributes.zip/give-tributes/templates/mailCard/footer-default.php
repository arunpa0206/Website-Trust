<?php
/**
 * Give Tributes Mail a Card Email Footer.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/templates/mailCard
 * @author     GiveWP <https://givewp.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$personalized_message_container = "
	box-shadow: 0 0 0 1px #f3f3f3 !important;
    border-radius: 3px !important;
    background-color: rgb(246, 246, 246);
    border: 1px solid #f6f6f6;
    box-sizing: border-box;
    margin-right:50px;
";
?>
</td>
</tr>
</table>
<!-- End Content -->
<?php
// @TODO: eventually remove as plugin matures.
give_tributes_v11_mail_card_donor_message_compat($payment_id); ?>
</td>
</tr>
</table>
<!-- End Body -->
</td>
</tr>
</table>
</td>

</tr>
</table>
</body>
</html>