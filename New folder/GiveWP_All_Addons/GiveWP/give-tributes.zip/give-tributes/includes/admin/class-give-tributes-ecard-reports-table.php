<?php
/**
 * Give Tribute eCards Report Table Class.
 *
 * @package     Give_Tributes
 * @subpackage  Give_Tributes/admin
 * @since       1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded.
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Give_Tributes_ECard_Reports_Table Class
 *
 * Renders the eCard Report table.
 *
 * @since 1.0
 */
class Give_Tributes_ECard_Reports_Table extends WP_List_Table {

	/**
	 * Number of items per page.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $per_page = 30;

	/**
	 * Number of items found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $count = 0;

	/**
	 * Total items.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $total = 0;

	/**
	 * Get things started
	 *
	 * @since 1.0.0
	 * @see   WP_List_Table::__construct()
	 */
	public function __construct() {
		// Set parent defaults.
		parent::__construct( array(
			'singular' => __( 'eCard', 'give-tributes' ),     // Singular name of the listed records.
			'plural'   => __( 'eCards', 'give-tributes' ),    // Plural name of the listed records.
			'ajax'     => false,// Does this table support ajax?
		) );
	}

	/**
	 * Remove default search field in favor for repositioned location.
	 *
	 * Reposition the search field.
	 *
	 * @since       1.0.0
	 * @access      public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return false
	 */
	public function search_box( $text, $input_id ) {
		return false;
	}

	/**
	 * Show the search field.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return void
	 */
	public function give_search_box( $text, $input_id ) {
		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['order'] ) ) {
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
		}
		?>
		<p class="search-box donor-search" role="search">
			<label class="screen-reader-text" for="<?php echo $input_id ?>"><?php echo $text; ?>:</label>
			<input type="search" id="<?php echo $input_id ?>" name="s" value="<?php _admin_search_query(); ?>" />
			<?php submit_button( $text, 'button', false, false, array( 'ID' => 'search-submit' ) ); ?>
		</p>
		<?php
	}

	/**
	 * This function renders most of the columns in the list table.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param array  $tributes_data Contains all the data of the tribute payment.
	 * @param string $column_name   The name of the column.
	 *
	 * @return string Column Name
	 */
	public function column_default( $tributes_data, $column_name ) {
		$single_donation_url = esc_url( add_query_arg( 'id', $tributes_data['id'], admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details' ) ) );
		switch ( $column_name ) {
			case 'donations' :
				$value = sprintf( '<a href="%1$s" data-tooltip="%2$s">%3$s</a>&nbsp;%4$s&nbsp;%5$s<br>', $single_donation_url, sprintf( esc_attr__( 'View Donation %s', 'give-tributes' ), $tributes_data['id'] ), $tributes_data['id'], __( 'by', 'give-tributes' ), $this->get_donor( $tributes_data ) );
				$value .= $this->get_donor_email( $tributes_data );
				break;
			case 'notify_name' :
				$value = $tributes_data['notify_name'];
				break;
			case 'notification_email' :
				$value = $tributes_data['notification_email'];
				break;
			case 'notification_email_subject' :
				$value = $tributes_data['honoree_ecard_email_subject'];
				break;
			case 'notification_email_date_sent' :
				$value = $tributes_data['honoree_ecard_email_sent_date'];
				break;
			case 'ecard_options' :

				// eCard Options.
				$value = give_tributes_prepare_ecard_actions( $tributes_data['id'] );

				// Get the HTML for resend eCard popup.
				$value .= give_tributes_generate_popup_html( $tributes_data['id'] );
				// Get the HTML for preview eCard popup.
				$value .= give_tributes_generate_popup_html( $tributes_data['id'], 'preview' );

				break;
			default:
				$value = isset( $tributes_data[ $column_name ] ) ? $tributes_data[ $column_name ] : null;
				break;
		}// End switch().

		return apply_filters( "give_tributes_ecard_report_column_{$column_name}", $value, $tributes_data['id'] );
	}

	/**
	 * Retrieve the table columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array $columns Array of all the list table columns.
	 */
	public function get_columns() {
		$columns = array(
			'donations'                    => __( 'Donation', 'give-tributes' ),
			'notify_name'                  => __( 'Notification Names', 'give-tributes' ),
			'notification_email'           => __( 'Notification Recipients', 'give-tributes' ),
			'notification_email_subject'   => __( 'Email Subject', 'give-tributes' ),
			'notification_email_date_sent' => __( 'Date Sent', 'give-tributes' ),
			'ecard_options'                => __( 'Options', 'give-tributes' ),
		);

		return apply_filters( 'give_tributes_ecard_report_columns', $columns );

	}

	/**
	 * Get the sortable columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array Array of all the sortable columns.
	 */
	public function get_sortable_columns() {
		return array(
			'donations'                    => array( 'id', true ),
			'notification_email_date_sent' => array( 'honoree_ecard_email_sent_date', true ),
		);
	}

	/**
	 * Retrieve the current page number.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return int Current page number.
	 */
	public function get_paged() {
		return isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : null;
	}

	/**
	 * Retrieves the search query string.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return mixed string If search is present, false otherwise.
	 */
	public function get_search() {
		return ! empty( $_GET['s'] ) ? urldecode( give_clean( $_GET['s'] ) ) : false;
	}

	/**
	 * Retrieve all the data for all the payments.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array  objects in array containing all the data for the payments.
	 */
	public function payments_data() {

		$per_page = $this->per_page;
		$order    = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby  = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => $per_page,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_eCard',
					'compare' => '=',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();
	}

	/**
	 * Setup the final data for the table
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @uses   Give_Donor_Reports_Table::get_columns()
	 * @uses   WP_List_Table::get_sortable_columns()
	 *
	 * @return void
	 */
	public function prepare_items() {

		$columns  = $this->get_columns();
		$hidden   = array(); // No hidden columns.
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );

		$this->items = $this->reports_data();
		$donations   = $this->give_tribute_ecard_query();

		$this->total = count( $donations );

		$this->set_pagination_args( array(
			'total_items' => $this->total,
			'per_page'    => $this->per_page,
			'total_pages' => ceil( $this->total / $this->per_page ),
		) );
	}

	/**
	 * Retrieve all the data for eCard.
	 *
	 * @access public
	 * @since  1.0.0
	 * @return array  objects in array containing all the data for the payments
	 */
	public function give_tribute_ecard_query() {

		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => - 1,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_eCard',
					'compare' => '=',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();
	}

	/**
	 * Build all the reports data.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array $reports_data All the data for donor reports
	 */
	public function reports_data() {
		$data = array();

		$payments = $this->payments_data();

		if ( $payments ) {

			$this->count = count( $payments );

			foreach ( $payments as $payment ) {

				$form_id = give_get_payment_form_id( $payment->ID );

				// Get the receipt names.
				$ecard_notify_names = give_tributes_ecards_notify_fields( $payment->ID, 'full_name' );

				// Get the emails.
				$ecard_notify_emails = give_tributes_ecards_notify_fields( $payment->ID, 'emails' );

				// Give Tribute eCard Email Subject.
				if ( give_tributes_is_per_form_customized( $form_id ) ) {
					$ecard_email_subject = give_get_meta( $form_id, '_give_tributes_per_form_ecards_email_subject', true );
				} else {
					$ecard_email_subject = give_get_option( 'give_tributes_ecards_email_subject', give_tributes_get_default_ecard_subject() );
				}

				// Ensure tags work in subject.
				$ecard_email_subject = give_tribute_do_tags( $ecard_email_subject, $payment->ID );

				// eCard Email sent date.
				$give_ecard_email_sent_date = give_get_meta( $payment->ID, '_give_tributes_ecard_email_sent_date', true );
				$give_ecard_donation_date   = $payment->date;
				$give_ecard_email_sent_date = ! empty( $give_ecard_email_sent_date ) ? $give_ecard_email_sent_date : $give_ecard_donation_date;
				$give_ecard_email_sent_date = date( 'F j, Y, g:i a', strtotime( $give_ecard_email_sent_date ) );

				$data[] = array(
					'id'                            => $payment->ID,
					'user_id'                       => give_get_payment_donor_id( $payment->ID ),
					'notify_name'                   => $ecard_notify_names,
					'email'                         => $payment->email,
					'notification_email'            => $ecard_notify_emails,
					'honoree_ecard_email_subject'   => $ecard_email_subject,
					'honoree_ecard_email_sent_date' => $give_ecard_email_sent_date,
				);
			}// End foreach().
		}// End if().

		return $data;
	}

	/**
	 * Get donor html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string Data shown in the User column
	 */
	public function get_donor( $payment ) {

		$donor_id           = give_get_payment_donor_id( $payment['id'] );
		$donor_billing_name = give_get_donor_name_by( $payment['id'], 'donation' );
		$donor_name         = give_get_donor_name_by( $donor_id, 'donor' );

		$value = '';
		if ( ! empty( $donor_id ) ) {

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= $donor_billing_name . ' (';
			}

			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-donors&view=overview&id=$donor_id" ) ) . '">' . $donor_name . '</a>';

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= ')';
			}
		} else {
			$email = give_get_payment_user_email( $payment['id'] );
			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-payment-history&s=$email" ) ) . '">' . __( '(donor missing)', 'give-tributes' ) . '</a>';
		}

		return apply_filters( 'give_tributes_ecard_donation_table_column', $value, $payment['id'], 'tributes' );
	}

	/**
	 * Get donor email html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string                Data shown in the Email column
	 */
	public function get_donor_email( $payment ) {

		$email = give_get_payment_user_email( $payment['id'] );

		if ( empty( $email ) ) {
			$email = __( '(unknown)', 'give-tributes' );
		}

		$value = '<a href="mailto:' . $email . '" data-tooltip="' . esc_attr__( 'Email donor', 'give-tributes' ) . '">' . $email . '</a>';

		return apply_filters( 'give_payments_ecard_table_column', $value, $payment['id'], 'email' );
	}
}
