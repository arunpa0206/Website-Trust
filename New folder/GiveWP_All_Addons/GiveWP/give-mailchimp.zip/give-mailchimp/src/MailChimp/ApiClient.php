<?php

namespace GiveMailChimp\MailChimp;

use GiveMailChimp\Infrastructure\Log;
use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;
use WP_Error;
use WP_Http;

use function wp_remote_get;

/**
 * Class ApiClient
 * @package GiveMailChimp\MailChimp\Marketing
 * @since 1.5.0
 */
class ApiClient {
	/**
	 * @var Configuration
	 */
	private $configuration;

	/**
	 * @var array|WP_Error
	 */
	private $response;

	/**
	 * @var string
	 */
	private $apiUrl;

	/**
	 * @var array
	 */
	private $bodyArguments = [];

	/**
	 * ApiClient constructor.
	 *
	 * @since 1.5.0
	 *
	 * @param  Configuration  $configuration
	 */
	public function __construct( Configuration $configuration ) {
		$this->configuration = $configuration;
	}

	/**
	 * Execute api request.
	 *
	 * @since 1.5.0
	 *
	 * @param  string  $requestPath
	 * @param  array  $bodyArguments
	 *
	 * @return self
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function get( $requestPath, $bodyArguments = [] ) {
		$this->apiUrl        = trailingslashit( $this->configuration->getApiUrl() ) . $requestPath;
		$this->bodyArguments = $bodyArguments;
		$this->executeQuery( 'GET' );

		return $this;
	}

	/**
	 * Execute api request.
	 *
	 * @since 1.5.0
	 *
	 * @param  string  $requestPath
	 * @param  array  $bodyArguments
	 *
	 * @return self
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function post( $requestPath, $bodyArguments ) {
		$this->apiUrl        = trailingslashit( $this->configuration->getApiUrl() ) . $requestPath;
		$this->bodyArguments = $bodyArguments;
		$this->executeQuery( 'POST' );

		return $this;
	}

	/**
	 * Execute api request.
	 *
	 * @since 1.5.0
	 *
	 * @param  string  $requestPath
	 * @param  array  $bodyArguments
	 *
	 * @return self
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function put( $requestPath, $bodyArguments ) {
		$this->apiUrl        = trailingslashit( $this->configuration->getApiUrl() ) . $requestPath;
		$this->bodyArguments = $bodyArguments;
		$this->executeQuery( 'PUT' );

		return $this;
	}

	/**
	 * Execute api request.
	 *
	 * @param  string  $requestPath
	 *
	 * @return self
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function delete( $requestPath ) {
		$this->apiUrl = trailingslashit( $this->configuration->getApiUrl() ) . $requestPath;
		$this->executeQuery( 'DELETE' );

		return $this;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $type
	 *
	 * @return array|WP_Error
	 * @throws ApiException|MailchimpApiKeyDoesNotExistException|RequestException
	 */
	private function executeQuery( $type ) {
		$this->apiKeyValidator();

		/* @var WP_Http $http */
		$http = _wp_http_get_object();

		switch ( $type ) {
			case 'DELETE':
				$this->response = $http->request(
					$this->apiUrl,
					$this->getHttpQuery(
						[
							'method'      => 'DELETE',
							'data_format' => 'body',
							'body'        => wp_json_encode( $this->bodyArguments ),
						]
					)
				);
				break;

			case 'PUT':
				$this->response = $http->request(
					$this->apiUrl,
					$this->getHttpQuery(
						[
							'method'      => 'PUT',
							'data_format' => 'body',
							'body'        => wp_json_encode( $this->bodyArguments ),
						]
					)
				);
				break;

			case 'POST':
				$this->response = wp_remote_post(
					$this->apiUrl,
					$this->getHttpQuery(
						[
							'data_format' => 'body',
							'body'        => wp_json_encode( $this->bodyArguments ),
						]
					)
				);
				break;

			case 'GET':
				$this->response = wp_remote_get( $this->apiUrl, $this->getHttpQuery() );
				break;
		}

		$this->responseValidator();

		return $this->response;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  array  $httpQuery
	 *
	 * @return array
	 */
	public function getHttpQuery( $httpQuery = [] ) {
		$default = [
			'timeout'     => $this->configuration->requestTimeout,
			'blocking'    => true,
			'httpversion' => '1.1',
			'sslverify'   => false,
			'headers'     => [
				'content-type'  => 'application/json',
				'Authorization' => 'Basic ' . $this->configuration->getStringForBasicAuthorization(),
			],
			'body'        => $this->bodyArguments,
		];

		return wp_parse_args( $httpQuery, $default );
	}

	/**
	 * @return array|WP_Error
	 */
	public function getResponseObject() {
		return $this->response;
	}

	/**
	 * @return mixed
	 */
	public function getResponseBody() {
		return json_decode( wp_remote_retrieve_body( $this->response ) );
	}

	/**
	 * Validate response
	 * @since 1.5.0
	 * @throws RequestException|ApiException
	 */
	public function responseValidator() {
		if ( is_wp_error( $this->response ) ) {
			$this->logRequestError( $this->response->get_error_code() );

			throw new RequestException(
				$this->response->get_error_message(),
				$this->response->get_error_code(),
				$this->response->get_error_data()
			);
		}

		$statusCode = wp_remote_retrieve_response_code( $this->response );

		if ( $statusCode < 200 || $statusCode > 299 ) {
			$this->logRequestError( $statusCode );

			throw new ApiException(
				sprintf(
					'[%1$d] Error connecting to the API (%2$s)',
					$statusCode,
					$this->apiUrl
				),
				$statusCode,
				wp_remote_retrieve_headers( $this->response ),
				$this->getResponseBody()
			);
		}
	}

	/**
	 * @since 1.5.0
	 * @throws MailchimpApiKeyDoesNotExistException
	 */
	public function apiKeyValidator() {
		if ( ! $this->configuration->hasValidApiKey() ) {
			throw new MailchimpApiKeyDoesNotExistException(
				sprintf(
					'Please provide a valid mailchimp api key to execute api request for %1$s',
					$this->configuration->getApiUrl()
				)
			);
		}
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  int  $statusCode
	 */
	private function logRequestError( $statusCode ) {
		Log::http(
			esc_html__( 'Something went wrong', 'give-mailchimp' ),
			[
				'category'               => 'Give Mailchimp Api Error',
				'Error'                  => sprintf(
					'[%1$d] Error connecting to the API (%2$s)',
					$statusCode,
					$this->apiUrl
				),
				'Response'               => $this->getResponseBody(),
				'Request Body Arguments' => $this->bodyArguments,
			]
		);
	}
}
