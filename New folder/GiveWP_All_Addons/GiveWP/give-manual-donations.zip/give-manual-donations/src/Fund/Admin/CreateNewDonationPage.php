<?php
namespace GiveManualDonations\Fund\Admin;

use GiveFunds\Repositories\Funds;
use GiveManualDonations\Infrastructure\View;

/**
 * Class CreateNewDonationPage
 * @package GiveManualDonation\Fund\Admin
 *
 * @since 1.4.8
 */
class CreateNewDonationPage {
	/**
	 * Add select fund options field on new donation(insert) page.
	 *
	 * @since 1.4.8
	 */
	public function addSelectFundOption() {
		/* @var Funds $fundRepository */
		$fundRepository = give( Funds::class );
		View::render(
			'admin/create-new-donation-select-fund',
			[
				'funds' => $fundRepository->getFunds(),
			]
		);
	}
}
