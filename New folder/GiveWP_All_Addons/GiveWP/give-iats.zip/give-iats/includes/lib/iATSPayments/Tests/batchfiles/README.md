ProcessLinkTest Batch Files
---------------------------

This directory contains temporary batch files when ProcessLinkTest.php is run by PHPUnit.
