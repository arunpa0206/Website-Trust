<?php
/**
 * Functions to trigger payment processing using PayFast Gateway.
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Listen PayFast IPN
 *
 * @since 1.0
 */
function give_payfast_listen_itn() {

	if ( isset( $_GET['give-listener'] ) && 'ITN' === $_GET['give-listener'] ) {

		/**
		 * Action Hook to verify PayFast ITN.
		 *
		 * @since 1.0
		 */
		do_action( 'give_verify_payfast_itn' );
	}

}

add_action( 'init', 'give_payfast_listen_itn' );


/**
 * Process PayFast IPN
 *
 * @since 1.0
 * @since 1.0.3 Remove ip check from PayFast itn validation.
 *             https://feedback.givewp.com/feature-requests/p/remove-ip-check-from-payfast
 */
function give_payfast_process_itn() {

	// Verify that data received using POST Method only.
	if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
		return false;
	}

	// Let PayFast Know that ITN is received.
	header( 'HTTP/1.0 200 OK' );
	flush();

	// Define Required Variables.
	$payfast_error         = false;
	$payfast_done          = false;
	$processed_data        = array();
	$payfast_error_message = '';

	// Posted variables from ITN.
	$processed_data = wp_parse_args( give_clean( $_POST ), $processed_data );

	// Bail Out, if there is no processed data from PayFast.
	if ( false === $processed_data ) {
		$payfast_error         = true;
		$payfast_error_message = __( 'PayFast Response is empty.', 'give-payfast' );
	}

	// Verify security signature.
	if (
		! $payfast_error &&
		! $payfast_done
	) {
		$signature = md5( give_payfast_generate_parameter_string( $processed_data, false, false ) ); // false not to sort data

		// If signature doesn't match, Set PayFast Error.
		if ( ! give_payfast_validate_signature( $processed_data, $signature ) ) {
			$payfast_error         = true;
			$payfast_error_message = __( 'Unable to verify PayFast Signature.', 'give-payfast' );
		}
	}

	// Verify data received.
	if ( ! $payfast_error ) {
		$validation_data = $processed_data;
		unset( $validation_data['signature'] );
		$has_valid_response_data = give_payfast_validate_response_data( $validation_data );

		if ( ! $has_valid_response_data ) {
			$payfast_error         = true;
			$payfast_error_message = __( 'Invalid Response Data from PayFast', 'give-payfast' );
		}
	}

	// Bail Out, if amount doesn't match.
	$donation = new Give_Payment( $processed_data['m_payment_id'] );
	if ( abs( floatval( $donation->total ) - floatval( $processed_data['amount_gross'] ) ) > 0.01 ) {
		$payfast_error         = true;
		$payfast_error_message = __( 'Actual Donation Amount and PayFast Response Amount doesn\'t match', 'give-payfast' );
	}

	if ( $payfast_error ) {

		give_record_gateway_error(
			__( 'PayFast Error', 'give-payfast' ),
			$payfast_error_message,
			absint( $processed_data['m_payment_id'] )
		);

	} elseif ( ! $payfast_done ) {

		$donation_id    = absint( $processed_data['m_payment_id'] );
		$transaction_id = $processed_data['pf_payment_id'];
		$status         = strtolower( $processed_data['payment_status'] );

		// Process response.
		switch ( $status ) {

			case 'complete':

				// Insert Donation Note.
				give_insert_payment_note(
					$donation_id,
					sprintf(
						__( 'Transaction Successful. PayFast Transaction ID: %s', 'give-payfast' ),
						$transaction_id
					)
				);

				// Set Transaction ID to Processed Donation.
				give_set_payment_transaction_id( $donation_id, $transaction_id );

				// Set Donation Status to Complete.
				give_update_payment_status( $donation_id, 'complete' );

				// Remove Scheduled Cron Hook, when donation is complete.
				wp_clear_scheduled_hook( 'give_payfast_set_donation_abandoned', array( $donation_id ) );

				// Send Donor to Success Page.
				give_send_to_success_page();
				break;

			case 'failed':

				// Record Payment Gateway Error.
				give_record_gateway_error(
					__( 'PayFast Error. Transaction Failed for donation %s.', 'give-payfast' ),
					$donation_id
				);

				// Set Donation Status to Failed.
				give_update_payment_status( $donation_id, 'failed' );

				// Remove Scheduled Cron Hook, when donation is failed.
				wp_clear_scheduled_hook( 'give_payfast_set_donation_abandoned', array( $donation_id ) );

				// Send Donor to Failed Donation Page.
				wp_redirect( give_get_failed_transaction_uri() );
				break;

			case 'pending':

				// Record Payment Gateway Error.
				give_record_gateway_error(
					__( 'PayFast Error. Transaction Pending for donation %s', 'give-payfast' ),
					$donation_id
				);

				// Remove Scheduled Cron Hook, when donation is pending.
				wp_clear_scheduled_hook( 'give_payfast_set_donation_abandoned', array( $donation_id ) );

				// Send Donor to Failed Donation Page.
				wp_redirect( give_get_failed_transaction_uri() );
				break;

			case 'cancelled':

				// Record Payment Gateway Error.
				give_record_gateway_error(
					__( 'Donor cancelled the donation %s', 'give-payfast' ),
					$donation_id
				);

				// Set Donation Status to Cancelled.
				give_update_payment_status( $donation_id, 'cancelled' );

				// Remove Scheduled Cron Hook, when donation is cancelled.
				wp_clear_scheduled_hook( 'give_payfast_set_donation_abandoned', array( $donation_id ) );

				// Send Donor to Failed Donation Page.
				wp_redirect( give_get_failed_transaction_uri() );
				break;

			default:
				break;
		}

	}

	wp_redirect( home_url() );
	exit;
}

add_action( 'give_verify_payfast_itn', 'give_payfast_process_itn' );


/**
 * Processes the payment
 *
 * @param array $data List of Donation Data.
 *
 * @since  1.0
 */
function give_payfast_process_donation( $data ) {

	// Check for any stored errors.
	$errors = give_get_errors();
	if ( ! $errors ) {

		// Setup the donation details which need to send to PayFast.
		$data_to_send = array(
			'price'           => $data['price'],
			'give_form_title' => $data['post_data']['give-form-title'],
			'give_form_id'    => intval( $data['post_data']['give-form-id'] ),
			'give_price_id'   => isset( $data['post_data']['give-price-id'] ) ? $data['post_data']['give-price-id'] : '',
			'date'            => $data['date'],
			'user_email'      => $data['user_email'],
			'purchase_key'    => $data['purchase_key'],
			'currency'        => give_get_currency(),
			'user_info'       => $data['user_info'],
			'status'          => 'pending',
			'gateway'         => $data['gateway'],
		);

		// Record the pending payment.
		$donation = give_insert_payment( $data_to_send );

		// Verify donation payment.
		if ( ! $donation ) {

			// Record the error.
			give_record_gateway_error(
				__( 'Payment Error', 'give-payfast' ),
				/* translators: %s: payment data */
				sprintf( __( 'Payment creation failed before process Payfast. Payment data: %s', 'give-payfast' ), wp_json_encode( $data ) ),
				$donation
			);

			// Problems? Send back.
			give_send_back_to_checkout( '?payment-mode=' . $data['post_data']['give-payfast'] );
		}

		// Auto set payment to abandoned in one hour if donor is not able to donate in that time.
		wp_schedule_single_event( current_time( 'timestamp', 1 ) + HOUR_IN_SECONDS, 'give_payfast_set_donation_abandoned', array( $donation ) );

		// Get Merchant Details.
		$merchant = give_payfast_get_merchant_credentials();

		// Set PayFast Query Parameters.
		$params = array(
			'merchant_id'      => $merchant['merchant_id'],
			'merchant_key'     => $merchant['merchant_key'],
			'return_url'       => give_get_success_page_uri(),
			'cancel_url'       => give_get_failed_transaction_uri(),
			'notify_url'       => get_site_url() . '/?give-listener=ITN',
			'name_first'       => $data['post_data']['give_first'],
			'name_last'        => $data['post_data']['give_last'],
			'email_address'    => $data['post_data']['give_email'],
			'm_payment_id'     => $donation,
			'amount'           => $data['price'],
			'item_name'        => $data_to_send['give_form_title'],
			'item_description' => sprintf( __( 'This is a donation payment for %s', 'give-payfast' ), $donation ),

		);

		/**
		 * Filter the PayFast transaction request params
		 *
		 * @param array $params PayFast Query Parameters.
		 *
		 * @since 1.0
		 */
		$params = apply_filters( 'give_payfast_transaction_request_params', $params );

		$request = add_query_arg( $params, give_payfast_get_api_url() );

		wp_redirect( $request );
		exit();
	}

	// If errors are present, send the user back to the purchase page so they can be corrected.
	give_send_back_to_checkout( "?payment-mode={$data['gateway']}&form-id={$data['post_data']['give-form-id']}" );
}

add_action( 'give_gateway_payfast', 'give_payfast_process_donation' );
