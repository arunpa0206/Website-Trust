<?php
/**
 * General Filter Hooks
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Show PayFast transaction error.
 *
 * @since 1.0
 *
 * @return bool
 */
function give_payfast_show_error($content ) {
	if (
		! isset( $_GET['give-payfast-payment'] )
		|| 'failed' !== $_GET['give-payfast-payment']
		|| ! isset( $_GET['give-payfast-error-message'] )
		|| empty( $_GET['give-payfast-error-message'] )
		|| ! give_is_failed_transaction_page()
	) {
		return $content;
	}

	return give_output_error( sprintf( 'Payment Error: %s', base64_decode( $_GET['give-payfast-error-message'] ) ), false, 'error' ) . $content;
}

add_filter( 'the_content', 'give_payfast_show_error');
