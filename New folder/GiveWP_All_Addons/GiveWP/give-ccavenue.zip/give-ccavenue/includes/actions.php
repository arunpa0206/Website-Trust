<?php

/**
 * Add phone field.
 *
 * @since 1.0
 *
 * @param int $form_id Donation Form ID.
 *
 * @return bool|mixed
 */
function give_ccavenue_add_phone_field( $form_id ) {

	// Bail out, if CCAVENUE gateway is not selected
	if ( 'ccavenue' !== give_get_chosen_gateway( $form_id ) ) {
		return false;
	}

	$give_user_info = _give_get_prefill_form_field_values( $form_id );
	?>
	<p id="give-phone-wrap" class="form-row form-row-wide">
		<label class="give-label" for="give-phone">
			<?php esc_html_e( 'Phone', 'give-ccavenue' ); ?>
			<span class="give-required-indicator">*</span>
			<span class="give-tooltip give-icon give-icon-question"
					data-tooltip="<?php esc_attr_e( 'Please enter your phone number.', 'give-ccavenue' ); ?>"></span>

		</label>

		<input
				class="give-input required"
				type="tel"
				name="give_ccavenue_phone"
				id="give-phone"
				value="<?php echo isset( $give_user_info['give_phone'] ) ? $give_user_info['give_phone'] : ''; ?>"
				required
				aria-required="true"
				maxlength="10"
				pattern="\d{10}"
		/>
	</p>
	<?php
}

add_action( 'give_donation_form_after_email', 'give_ccavenue_add_phone_field' );

/**
 * Do not print cc field in donation form.
 *
 * Note: We do not need credit card field in donation form but we need billing detail fields.
 *
 * @since 1.0
 *
 * @param $form_id
 */
function give_ccavenue_cc_form_callback( $form_id ) {
	give_default_cc_address_fields( $form_id );
}

add_action( 'give_ccavenue_cc_form', 'give_ccavenue_cc_form_callback' );
