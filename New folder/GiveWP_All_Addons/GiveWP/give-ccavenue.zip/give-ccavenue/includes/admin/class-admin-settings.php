<?php
// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Give_CCAvenue_Gateway_Settings
 *
 * @since 1.0
 */
class Give_CCAvenue_Gateway_Settings {
	/**
	 * @since  1.0
	 * @access static
	 * @var Give_CCAvenue_Gateway_Settings $instance
	 */
	static private $instance;

	/**
	 * @since  1.0
	 * @access private
	 * @var string $section_id
	 */
	private $section_id;

	/**
	 * @since  1.0
	 * @access private
	 * @var string $section_label
	 */
	private $section_label;

	/**
	 * Give_CCAvenue_Gateway_Settings constructor.
	 */
	private function __construct() {
	}

	/**
	 * get class object.
	 *
	 * @since  1.0
	 * @access static
	 * @return Give_CCAvenue_Gateway_Settings
	 */
	static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @since  1.0
	 * @access public
	 */
	public function setup_hooks() {
		$this->section_id    = 'ccavenue';
		$this->section_label = __( 'CCAvenue', 'give-ccavenue' );

		// Add payment gateway to payment gateways list.
		add_filter( 'give_payment_gateways', array( $this, 'add_gateways' ) );

		if ( is_admin() ) {

			// Add section to payment gateways tab.
			add_filter( 'give_get_sections_gateways', array( $this, 'add_section' ) );

			// Add section settings.
			add_filter( 'give_get_settings_gateways', array( $this, 'add_settings' ) );
		}
	}

	/**
	 * Add payment gateways to gateways list.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $gateways array of payment gateways.
	 *
	 * @return array
	 */
	public function add_gateways( $gateways ) {
		$gateways[ $this->section_id ] = array(
			'admin_label'    => $this->section_label,
			'checkout_label' => __( 'CCAvenue', 'give-ccavenue' ),
		);

		return $gateways;
	}

	/**
	 * Add setting section.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $sections Array of section.
	 *
	 * @return array
	 */
	public function add_section( $sections ) {
		$sections[ $this->section_id ] = $this->section_label;

		return $sections;
	}

	/**
	 * Add plugin settings.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $settings Array of setting fields.
	 *
	 * @return array
	 */
	public function add_settings( $settings ) {
		$current_section = give_get_current_setting_section();

		if ( $this->section_id == $current_section ) {
			$settings = array(
				array(
					'id'   => 'give_ccavenue_payments_setting',
					'type' => 'title',
				),
				array(
					'title' => __( 'Merchant ID', 'give-ccavenue' ),
					'id'    => 'ccavenue_live_merchant_id',
					'type'  => 'api_key',
					'desc'  => __( 'The Merchant ID provided by CCAvenue.', 'give-ccavenue' ),
				),
				array(
					'title' => __( 'Working Key', 'give-ccavenue' ),
					'id'    => 'ccavenue_live_working_key',
					'type'  => 'api_key',
					'desc'  => __( 'The Working Key provided by CCAvenue.', 'give-ccavenue' ),
				),
				array(
					'title' => __( 'Access Code', 'give-ccavenue' ),
					'id'    => 'ccavenue_live_access_code',
					'type'  => 'api_key',
					'desc'  => __( 'The Access Code provided by CCAvenue.', 'give-ccavenue' ),
				),
				array(
					'id'   => 'give_ccavenue_payments_setting',
					'type' => 'sectionend',
				),
			);
		}// End if().

		return $settings;
	}
}

Give_CCAvenue_Gateway_Settings::get_instance()->setup_hooks();
