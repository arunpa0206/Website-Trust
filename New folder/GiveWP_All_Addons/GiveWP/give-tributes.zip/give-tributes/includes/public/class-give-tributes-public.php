<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://givewp.com
 * @since      1.0.0
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/public
 */

use Give\Receipt\AdditionalDetailsGroup\AdditionalDetailsGroup;
use Give\Receipt\DetailGroup;
use Give\Receipt\DonationReceipt;
use GiveTributes\Receipt\TributeDetailsGroup\Details\Tribute;
use GiveTributes\Receipt\UpdateDonationReceipt;

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/includes/public
 * @author     GiveWP <https://givewp.com>
 */
class Give_Tributes_Public {


	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 *
	 */
	public function __construct() {

		// Enqueue Script and Style for Front-end.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		// Output Tribute Section based on settings.
		add_action( 'give_pre_form_output', array( $this, 'section_output' ), 10, 1 );

		// Add Tribute data into the payment meta.
		add_action( 'give_insert_payment', array( $this, 'insert_tribute_data' ), 10, 1 );
		add_action( 'give_manual_insert_payment', array( $this, 'insert_tribute_data' ), 10, 1 );

		// eCard Default Header.
		add_action( 'give_tribute_ecard_email_header', array( $this, 'ecard_email_header_call_back' ), 10, 2 );

		// eCard Default Body.
		add_action( 'give_tribute_ecard_email_body', array( $this, 'ecard_email_body_call_back' ), 10, 1 );

		// eCard Default Footer.
		add_action( 'give_tribute_ecard_email_footer', array( $this, 'ecard_email_footer_call_back' ), 10, 1 );

		// Global Mail a Card PDF Default Header.
		add_action( 'give_tribute_mail_card_email_header', array( $this, 'mail_card_email_header_call_back' ), 10, 1 );

		// Global Mail a Card PDF Default Body.
		add_action( 'give_tribute_mail_card_email_body', array( $this, 'mail_card_email_body_call_back' ), 10, 1 );

		// Global Mail a Card PDF Default Footer.
		add_action( 'give_tribute_mail_card_email_footer', array( $this, 'mail_card_email_footer_call_back' ), 10, 1 );

		// Show Mail a Card confirmation message on donation receipt.
		add_action( 'give_payment_receipt_before_table', array( $this, 'before_payment_table' ), 10, 2 );

		// Give load gateway callback hook.
		add_action( 'wp_ajax_give_load_gateway', array( $this, 'load_gateway_callback' ), 0 );
		add_action( 'wp_ajax_nopriv_give_load_gateway', array( $this, 'load_gateway_callback' ), 0 );

		// Show Dedication information.
		add_action( 'give_payment_receipt_after', array( $this, 'donation_receipt_after' ), 10, 2 );
		add_action( 'give_new_receipt', array( $this, 'addTributeDetailItem' ), 10, 1 );

		// Add Tribute Information tag.
		add_action( 'give_add_email_tags', array( $this, 'tribute_info_tag' ), 999 );

		// Preview Default Download Declaration tag.
		add_action( 'give_email_preview_template_tags', array( $this, 'email_preview_tribute_info_tag' ), 10, 1 );

		// Required fields.
		add_filter( 'give_donation_form_required_fields', array( $this, 'maybe_require_fields' ), 0, 2 );

		// Remove required fields for manual donation.
		add_filter( 'give_tribute_required_fields', array( $this, 'manual_donation_remove_required_fields' ), 10, 1 );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function enqueue_styles() {
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		wp_register_style( GIVE_TRIBUTES_SLUG, GIVE_TRIBUTES_PLUGIN_URL . 'assets/css/give-tributes-public' . $suffix . '.css', array(), GIVE_TRIBUTES_VERSION, 'all' );
		wp_enqueue_style( GIVE_TRIBUTES_SLUG );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function enqueue_scripts() {
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		wp_enqueue_script( GIVE_TRIBUTES_SLUG, GIVE_TRIBUTES_PLUGIN_URL . 'assets/js/give-tributes-public' . $suffix . '.js', array( 'jquery' ), GIVE_TRIBUTES_VERSION, false );
	}

	/**
	 * Call hook based on tribute settings and display tribute section.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param integer $form_id form id.
	 */
	public function section_output( $form_id ) {

		// Get Tribute Section Location hook.
		$location_hook = give_tributes_get_section_location_hook( $form_id );

		// Dynamic hook based on Global/Per-Form settings.
		add_action( $location_hook, array(
			$this,
			'dedicate_donation',
		), 10, 1 );

	}

	/**
	 * Call Tribute Section after load gateway ajax callback.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function load_gateway_callback() {
		// Get Form id from the ajax callback.
		$form_id = ! empty( $_POST['give_form_id'] ) ? $_POST['give_form_id'] : 0;

		if ( ! empty( $form_id ) ) {

			// Get Tribute Section Location hook.
			$location_hook = give_tributes_get_section_location_hook( $form_id );

			// Dynamic hook based on Global/Per-Form settings.
			add_action( $location_hook, array(
				$this,
				'dedicate_donation',
			), 10, 1 );

		}// End if().
	}

	/**
	 * Display Dedicate donation field below Personal information fields.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int    $form_id Donation form id.
	 * @param string $display Display.
	 *
	 * @return mixed
	 */
	public function dedicate_donation( $form_id, $display = '' ) {

		// It will remove previous hook location and execute new hook location based on 'Tribute Section Location' option from the Backend.
		remove_action( current_action(), array(
			$this,
			'dedicate_donation',
		), 10 );

		do_action( 'give_tributes_form_before_dedicate_donation', $form_id );

		$prepended_label = '';

		// Check if global tribute settings is enabled.
		if ( give_tributes_is_per_form_global( $form_id ) ) {

			// Get the value of fieldset title.
			$dedicate_donation = give_get_option( 'give_tributes_fieldset_title', __( 'Dedicate this Donation', 'give-tributes' ) );

			// Get the value of Mail a Card enabled/disabled.
			$mail_a_card_enable_disable = give_get_option( 'give_tributes_mail_a_card_enable_disable', 'disabled' );

			// Get the value of eCards enabled/disabled.
			$ecards_enable_disable = give_get_option( 'give_tributes_ecards_enable_disable', 'disabled' );

			// Get global eCard custom message enable/disable.
			$ecards_custom_message_enable_disable = give_get_option( 'give_tributes_ecards_custom_message_enable_disable', 'disabled' );

			// Get global eCard custom message length.
			$ecards_message_length = give_get_option( 'give_tributes_ecards_message_length', 255 );

			if ( give_is_setting_enabled( give_get_option( 'give_tributes_prepended_label_enable_disable', 'enabled' ) ) ) {
				// Get global Tribute Prepended Label.
				$prepended_label = give_get_option( 'give_tributes_prepended_label', __( 'Honoree', 'give-tributes' ) );
			}
		} elseif ( give_tributes_is_per_form_customized( $form_id ) ) {

			// Get the value of fieldset title.
			$dedicate_donation = give_get_meta( $form_id, '_give_tributes_per_form_fieldset_title', true );
			$dedicate_donation = ! empty( $dedicate_donation ) ? $dedicate_donation : __( 'Dedicate this Donation', 'give-tributes' );

			// Get the value of Mail a Card enabled/disabled.
			$mail_a_card_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_mail_a_card_enable_disable', true );
			$mail_a_card_enable_disable = ! empty( $mail_a_card_enable_disable ) ? $mail_a_card_enable_disable : 'disabled';

			// Get the value of eCard enabled/disabled.
			$ecards_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_ecards_enable_disable', true );
			$ecards_enable_disable = ! empty( $ecards_enable_disable ) ? $ecards_enable_disable : 'disabled';

			// Get Per-form eCard custom message enable/disable.
			$ecards_custom_message_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_ecards_custom_message_enable_disable', true );
			$ecards_custom_message_enable_disable = ! empty( $ecards_custom_message_enable_disable ) ? $ecards_custom_message_enable_disable : 'disabled';

			// Get Per-form eCard custom message length.
			$ecards_message_length = give_get_meta( $form_id, '_give_tributes_per_form_ecards_message_length', true );
			$ecards_message_length = ! empty( $ecards_message_length ) ? $ecards_message_length : 255;

			// Get Per-form Mail a Card.
			$per_form_prepended_label_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_prepended_label_enable_disable', true );
			$per_form_prepended_label_enable_disable = ! empty( $per_form_prepended_label_enable_disable ) ? $per_form_prepended_label_enable_disable : 'enabled';

			if ( give_is_setting_enabled( $per_form_prepended_label_enable_disable ) ) {
				// Get Per-form Tribute Prepended Label.
				$prepended_label = give_get_meta( $form_id, '_give_tributes_per_form_prepended_label', true );
				$prepended_label = ! empty( $prepended_label ) ? $prepended_label : __( 'Honoree', 'give-tributes' );
			}
		} else {
			return '';
		}// End if().

		// Get the honoree notification method.
		$notify_choice = give_tributes_get_notify_display_option( $form_id );
		$default_type  = get_default_tribute_type( $form_id );

		$tribute_field_vars = array(
			'form_id'                              => $form_id,
			'prepended_label'                      => $prepended_label,
			'mail_a_card_enable_disable'           => $mail_a_card_enable_disable,
			'ecards_enable_disable'                => $ecards_enable_disable,
			'notify_choice'                        => $notify_choice,
			'ecards_custom_message_enable_disable' => $ecards_custom_message_enable_disable,
			'ecards_message_length'                => $ecards_message_length,
		);

		ob_start();

		// Show tribute fields if we are on manual donation page in backend.
		if ( give_tribute_is_manual_donation_page() ) {

			?>
			<tr class="form-field give-tributes-row give-tributes-dedicate-donation">
				<th scope="row" valign="top">
					<label><?php echo esc_html( $dedicate_donation ); ?></label>
				</th>
				<td>
					<input type="hidden" class="give-tributes-type" name="give_tributes_type" value="<?php echo $default_type; ?>" />
					<?php echo give_tribute_options_fields( $form_id ); ?>
				</td>
			</tr>
			<?php

			// Output Tribute type based on Global and Per-Form based settings.
			echo give_tributes_type_output( $form_id, true );

			// Output Tribute Honoree fields: First Name and Last Name.
			echo give_tribute_honoree_detail_fields( $tribute_field_vars, true );

			// Notify choices.
			if (
				'donor_choice' === $notify_choice
				&& ( 'disabled' !== $mail_a_card_enable_disable || 'disabled' !== $ecards_enable_disable )
			) {
				// Output Tribute Grab Info fields.
				echo give_tribute_grab_info_wrap_fields( $tribute_field_vars, true );
			}

			if (
				( 'disabled' !== $ecards_enable_disable && ( 'send_eCard' === $notify_choice || 'donor_choice' === $notify_choice ) )
				|| ( 'disabled' !== $mail_a_card_enable_disable && ( 'send_mail_card' === $notify_choice || 'donor_choice' === $notify_choice ) )
			) {
				// eCard and Mail a Card field(s).
				?>
				<tr class="form-field give-tributes-row">
					<th scope="row" valign="top">
						<label><?php echo __( 'Recipient(s)', 'give-tributes' ); ?></label>
					</th>
					<td>
						<?php
						// eCard.
						if (
							'disabled' !== $ecards_enable_disable
							&& ( 'send_eCard' === $notify_choice || 'donor_choice' === $notify_choice )
						) {
							echo give_tribute_ecard_notification_fields( $tribute_field_vars );
						}

						// Mail a Card.
						if (
							$mail_a_card_enable_disable !== 'disabled'
							&& ( 'send_mail_card' === $notify_choice || 'donor_choice' === $notify_choice )
						) {
							echo give_tributes_get_address_fields( $form_id );
						}
						?>
					</td>
				</tr>
				<?php
				// eCard.
				if (
					'disabled' !== $ecards_enable_disable
					&& ( 'send_eCard' === $notify_choice || 'donor_choice' === $notify_choice )
				) {
					?>
					<tr class="form-field give-tributes-row give-tributes-email-option">
						<th scope="row" valign="top">
							<?php _e( 'Tribute Email', 'give-tributes' ); ?>
						</th>
						<td class="give-tribute-receipt">
							<label for="give-tribute-receipt">
								<input type="checkbox" id="give-tribute-receipt" name="give-tribute-send-email" style="width: auto;"
								       value="yes" />
								<?php _e( 'Send the tribute eCard notification?', 'give-tributes' ); ?>
							</label>
							<p class="description"><?php _e( 'When this option is enabled the recipient  will receive an tribute eCard notification email.', 'give-tributes' );
								?></p>
						</td>
					</tr>
					<?php
				}
			}
		} else {
			?>
			<fieldset id="give-tributes-dedicate-donation-<?php echo $form_id; ?>" class="give-tributes-dedicate-donation"> <!-- Give - Tributes Start -->
				<input type="hidden" class="give-tributes-type" name="give_tributes_type" value="<?php echo $default_type; ?>" />
				<legend><?php echo $dedicate_donation; ?></legend>
				<?php

				// Output Tribute Options fields.
				echo give_tribute_options_fields( $form_id );

				// Output Tribute type based on Global and Per-Form based settings.
				echo give_tributes_type_output( $form_id );

				// Output Tribute Honoree fields: First Name and Last Name.
				echo give_tribute_honoree_detail_fields( $tribute_field_vars );

				// Notify choices.
				if (
					'donor_choice' === $notify_choice
					&& ( 'disabled' !== $mail_a_card_enable_disable || 'disabled' !== $ecards_enable_disable )
				) {
					// Output Tribute Grab Info fields.
					echo give_tribute_grab_info_wrap_fields( $tribute_field_vars );
				}

				// eCard.
				if (
					'disabled' !== $ecards_enable_disable
					&& ( 'send_eCard' === $notify_choice || 'donor_choice' === $notify_choice )
				) {
					echo give_tribute_ecard_notification_fields( $tribute_field_vars );
				}

				// Mail a Card.
				if (
					$mail_a_card_enable_disable !== 'disabled'
					&& ( 'send_mail_card' === $notify_choice || 'donor_choice' === $notify_choice )
				) {
					echo give_tributes_get_address_fields( $form_id );
				}
				?>
			</fieldset> <!-- Give - Tributes End -->
			<?php
		}
		// Output.
		echo apply_filters( 'give_tributes_front_fields', ob_get_clean(), $form_id );

		do_action( 'give_tributes_form_after_dedicate_donation', $form_id );
	}

	/**
	 * Maybe require the last name for Honoree Name, eCard Recipient, Mail a Card
	 *
	 * @since 1.2.1
	 *
	 * @param $required_fields array
	 * @param $form_id
	 *
	 * @return array
	 */
	public function maybe_require_fields( $required_fields, $form_id ) {
		// Honoree req. First name.
		$required_fields['give_tributes_first_name'] = array(
			'error_id'      => 'give_tributes_first_name_invalid',
			'error_message' => __( 'Please enter the honoree\'s first name.', 'give-tributes' ),
		);

		// Mail a card basic req. fields.
		$required_fields['give_tributes_mail_card_notify_first_name'] = array(
			'error_id'      => 'give_tributes_mail_card_notify_first_name_invalid',
			'error_message' => __( 'Please enter the recipient\'s first name.', 'give-tributes' ),
		);

		// eCard req. First name.
		$required_fields['give_tributes_ecard_notify_first_name'] = array(
			'error_id'      => 'give_tributes_ecard_notify_first_name_invalid',
			'error_message' => __( 'Please enter the recipient\'s first name.', 'give-tributes' ),
		);

		// Per form customized?
		if ( give_tributes_is_per_form_customized( $form_id ) ) {

			if ( 'required' === give_get_meta( $form_id, '_give_tributes_per_form_tributes_honoree_last_name', true ) ) {
				$required_fields['give_tributes_last_name'] = array(
					'error_id'      => 'give_tributes_last_name_invalid',
					'error_message' => __( 'Please enter the honoree\'s last name.', 'give-tributes' ),
				);
			}
			if ( 'required' === give_get_meta( $form_id, '_give_tributes_per_form_mail_card_last_name', true ) ) {
				$required_fields['give_tributes_mail_card_notify_last_name'] = array(
					'error_id'      => 'give_tributes_mail_card_last_name_invalid',
					'error_message' => __( 'Please enter the recipient\'s last name.', 'give-tributes' ),
				);
			}
			if ( 'required' === give_get_meta( $form_id, '_give_tributes_per_form_ecard_last_name', true ) ) {
				$required_fields['give_tributes_ecard_last_name'] = array(
					'error_id'      => 'give_tributes_ecard_notify_last_name_invalid',
					'error_message' => __( 'Please enter the recipient\'s last name.', 'give-tributes' ),
				);
			}

		} else {

			if ( 'required' === give_get_option( 'give_tributes_honoree_last_name', 'required' ) ) {
				$required_fields['give_tributes_last_name'] = array(
					'error_id'      => 'give_tributes_last_name_invalid',
					'error_message' => __( 'Please enter the honoree\'s last name.', 'give-tributes' ),
				);
			}
			if ( 'required' === give_get_option( 'give_tributes_mail_card_last_name', 'required' ) ) {
				$required_fields['give_tributes_mail_card_notify_last_name'] = array(
					'error_id'      => 'give_tributes_mail_card_last_name_invalid',
					'error_message' => __( 'Please enter the recipient\'s last name.', 'give-tributes' ),
				);
			}
			if ( 'required' === give_get_option( 'give_tributes_ecard_last_name', 'required' ) ) {
				$required_fields['give_tributes_ecard_last_name'] = array(
					'error_id'      => 'give_tributes_ecard_notify_last_name_invalid',
					'error_message' => __( 'Please enter the recipient\'s last name.', 'give-tributes' ),
				);
			}
		}// End if().

		// Mail a Card Personalized Message.
		$required_fields['give-tributes-mail-card-personalized-message'] = array(
			'error_id'      => 'give_tributes_personalized_message_invalid',
			'error_message' => __( 'Please enter the personalized message.', 'give-tributes' ),
		);

		// Mail a Card Address1.
		$required_fields['give_tributes_mail_card_address_1'] = array(
			'error_id'      => 'give_tributes_address_1_invalid',
			'error_message' => __( 'Please enter the recipient\'s address.', 'give-tributes' ),
		);

		// Mail a Card Country.
		$required_fields['give_tributes_address_country'] = array(
			'error_id'      => 'give_tributes_country_invalid',
			'error_message' => __( 'Please select the recipient\'s country.', 'give-tributes' ),
		);

		// Mail a Card City.
		$required_fields['give_tributes_mail_card_city'] = array(
			'error_id'      => 'give_tributes_city_invalid',
			'error_message' => __( 'Please enter the recipient\'s city.', 'give-tributes' ),
		);

		// Mail a Card State.
		$required_fields['give_tributes_address_state'] = array(
			'error_id'      => 'give_tributes_state_invalid',
			'error_message' => __( 'Please enter the recipient\'s state.', 'give-tributes' ),
		);

		// Mail a Card ZipCode.
		$required_fields['give_tributes_mail_card_zipcode'] = array(
			'error_id'      => 'give_tributes_zipcode_invalid',
			'error_message' => __( 'Please enter the recipient\'s zip/postal code.', 'give-tributes' ),
		);

		// eCard email notification.
		$required_fields['give_tributes_ecard_email'] = array(
			'error_id'      => 'give_tributes_ecard_email_invalid',
			'error_message' => __( 'Please enter a valid email address for the recipient.', 'give-tributes' ),
		);

		// eCard Personalized Message.
		$required_fields['give_tributes_ecard_notify_personalized_message'] = array(
			'error_id'      => 'give_tributes_ecard_personalized_message_invalid',
			'error_message' => __( 'Please enter the personalized message.', 'give-tributes' ),
		);

		// Only mark fields as required when not submitting since many fields are conditionally required.
		if ( isset( $_POST['give-form-id'] ) ) {
			$required_fields = $this->give_tributes_verified_processed_data( $required_fields );
		}

		/**
		 * Give Tribute required fields.
		 *
		 * @since 1.5
		 *
		 * @param array $required_fields
		 */
		return apply_filters( 'give_tribute_required_fields', $required_fields );
	}

	/**
	 * Verified Processed data.
	 *
	 * @since 1.5
	 *
	 * @param array $required_fields
	 *
	 * @return array $required_fields
	 */
	public function give_tributes_verified_processed_data( $required_fields ) {
		// Store posted fields to variable.
		$posted_field = give_clean( $_POST ); // WPCS: input var ok, sanitization ok, CSRF ok.
		$form_id      = 0;

		// Check whether Tribute is enabled/disabled.
		$enabled_disabled = ! empty( $posted_field['give_tributes_show_dedication'] ) ? $posted_field['give_tributes_show_dedication'] : '';

		// Get the form id.
		$form_id = ! empty( $posted_field['give-form-id'] ) ? intval( $posted_field['give-form-id'] ) : $form_id;

		$tribute_mail_card_required_fields = __give_tribute_mail_card_required_fields();
		$tribute_ecard_required_fields     = __give_tribute_ecard_required_fields();

		// If Tribute not enabled then unset all required fields.
		if ( 'yes' !== $enabled_disabled ) {

			// Unset Mail a Card required fields.
			foreach ( $tribute_mail_card_required_fields as $key => $mail_card_required_field ) {
				unset( $required_fields[ $mail_card_required_field ] );
			}// End foreach().

			// Unset eCard required fields.
			foreach ( $tribute_ecard_required_fields as $key => $ecard_required_field ) {
				unset( $required_fields[ $ecard_required_field ] );
			}// End foreach().

			return $required_fields;
		}// End if().

		// Validate Honoree First name.
		if ( ! array_key_exists( 'give_tributes_first_name', $required_fields ) ) {
			unset( $required_fields['give_tributes_first_name'] );
		}

		// Validate Honoree Last name.
		if ( ! array_key_exists( 'give_tributes_last_name', $required_fields ) ) {
			unset( $required_fields['give_tributes_last_name'] );
		}

		// Get Tribute type. e.g. Mail a Card, eCard, No thanks.
		$posted_method = ( isset( $posted_field['give_tributes_would_to'] ) && ! empty( $posted_field['give_tributes_would_to'] ) ) ? give_clean( $posted_field['give_tributes_would_to'] ) : 'none';

		// Honoree Information.
		$honoree_information = array( 'give_tributes_first_name', 'give_tributes_last_name' );

		// Tribute type option like : 'send_eCard', "send_mail_card" or 'none'.
		$ecard_or_mailed = give_tributes_get_notify_display_option( $form_id, $posted_method );

		if ( 'send_eCard' === $ecard_or_mailed ) {
			// Unset Mail a Card required fields.
			foreach ( $tribute_mail_card_required_fields as $key => $mail_card_required_field ) {
				if ( ! in_array( $mail_card_required_field, $honoree_information, true ) ) {
					unset( $required_fields[ $mail_card_required_field ] );
				}
			}// End foreach().

			// Get the notification recipient data.
			$notify_data = $posted_field['give_tributes_ecard_notify']['recipient'];

			// Check notification recipient data.
			$required_fields = $this->maybe_required_ecard_notification_data( $required_fields, $notify_data, $form_id );

		} elseif ( 'send_mail_card' === $ecard_or_mailed ) {

			// Unset eCard required fields.
			foreach ( $tribute_ecard_required_fields as $key => $ecard_required_field ) {
				if ( ! in_array( $ecard_required_field, $honoree_information, true ) ) {
					unset( $required_fields[ $ecard_required_field ] );
				}
			}// End foreach().

			$required_fields = $this->maybe_required_mail_card_notification_data( $required_fields, $posted_field, $form_id );

		} else {

			$all_required_fields = array_merge( $tribute_mail_card_required_fields, $tribute_ecard_required_fields );
			// Unset Mail a Card and eCard required fields.
			foreach ( $all_required_fields as $key => $required_field ) {
				if ( ! in_array( $required_field, $honoree_information, true ) ) {
					unset( $required_fields[ $required_field ] );
				}
			}// End foreach().

		}// End if().

		return $required_fields;
	}

	/**
	 * Give Checkout error Mail a Card Notification data.
	 *
	 * @since  1.5
	 * @access public
	 *
	 * @param array $required_fields
	 * @param array $posted_field
	 * @param int   $form_id
	 *
	 * @return array $required_fields
	 */
	public function maybe_required_mail_card_notification_data( $required_fields, $posted_field, $form_id ) {
		// Mail card Honoree Country.
		$address_country = ! empty( $posted_field['give_tributes_address_country'] ) ? $posted_field['give_tributes_address_country'] : '';

		// Get state list whose have no required country.
		$state_list = give_states_not_required_country_list();

		// Unset Mail a Card state.
		if (
			! array_key_exists( $address_country, $state_list )
			&& ! array_key_exists( 'give_tributes_address_state', $required_fields )
		) {
			unset( $required_fields['give_tributes_address_state'] );
		}

		// Mail card Honoree Zip/Postal Code.
		$mail_card_zipcode = ! empty( $posted_field['give_tributes_mail_card_zipcode'] ) ? give_clean( $posted_field['give_tributes_mail_card_zipcode'] ) : '';

		// Validate, if Zip code is valid or not.
		$is_valid = give_donation_form_validate_cc_zip( $mail_card_zipcode, $address_country );

		// Validate Honoree City.
		if ( ! array_key_exists( 'give_tributes_mail_card_zipcode', $required_fields ) ) {
			unset( $required_fields['give_tributes_mail_card_zipcode'] );
		} else {

			// Check Mail a Card Zip Valid or not.
			if (
				false === $is_valid
				&& ! empty( $mail_card_zipcode )
			) {
				$required_fields['give_tributes_invalid_zip_code'] = array(
					'error_id'      => 'give_tributes_invalid_zip_code',
					'error_message' => __( 'Please enter the recipient\'s correct zip code.', 'give-tributes' ),
				);
			}
		}

		// Validate Honoree First name.
		if ( ! array_key_exists( 'give_tributes_mail_card_notify_first_name', $required_fields ) ) {
			unset( $required_fields['give_tributes_mail_card_notify_first_name'] );
		}

		// Validate Honoree Address 1.
		if ( ! array_key_exists( 'give_tributes_mail_card_address_1', $required_fields ) ) {
			unset( $required_fields['give_tributes_mail_card_address_1'] );
		}

		// Validate Honoree City.
		if ( ! array_key_exists( 'give_tributes_mail_card_city', $required_fields ) ) {
			unset( $required_fields['give_tributes_mail_card_city'] );
		}

		// Validate Honoree Country.
		if ( ! array_key_exists( 'give_tributes_address_country', $required_fields ) ) {
			unset( $required_fields['give_tributes_address_country'] );
		}

		// Check if global tribute settings is enabled.
		$custom_message_enable_disable = 'disabled';
		if ( ! give_tributes_is_per_form_customized( $form_id ) && give_is_setting_enabled( give_get_option( 'give_tributes_enable_disable' ) ) ) {

			// Get global Mail a Card custom message enable/disable.
			$custom_message_enable_disable = give_get_option( 'give_tributes_custom_message_enable_disable', 'disabled' );

		} elseif ( give_tributes_is_per_form_customized( $form_id ) ) {

			// Get Per-form Mail a Card custom message enable/disable.
			$custom_message_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_custom_message_enable_disable', true );
			$custom_message_enable_disable = ! empty( $custom_message_enable_disable ) ? $custom_message_enable_disable : 'disabled';
		}

		// Unset Mail a card Personalized message.
		if (
			! give_is_setting_enabled( $custom_message_enable_disable )
			|| ! array_key_exists( 'give-tributes-mail-card-personalized-message', $required_fields )
		) {
			unset( $required_fields['give-tributes-mail-card-personalized-message'] );
		}

		return $required_fields;
	}

	/**
	 * Check eCard multiple notification data.
	 *
	 * @access public
	 * @since  1.4.0
	 * @since  1.5.0 Conditional required fields.
	 *
	 * @param array $required_fields
	 * @param array $notify_data
	 * @param int   $form_id
	 *
	 * @return array
	 */
	public function maybe_required_ecard_notification_data( $required_fields, $notify_data, $form_id ) {
		// Check all recipient data for validation.
		foreach ( $notify_data as $key => $recipient ) {
			$is_required           = true;
			$recipient_value_count = count( $recipient );
			$filtered_count        = count( array_filter( $recipient ) );

			// Check mismatch count then all fields are not filled.
			if ( $recipient_value_count !== $filtered_count ) {
				$is_required = false;
			}

			// Check key.
			switch ( $key ) {
				case 'first_name':
					if (
						$is_required
						&& array_key_exists( 'give_tributes_ecard_notify_first_name', $required_fields )
					) {
						unset( $required_fields['give_tributes_ecard_notify_first_name'] );
					}
					break;
				case 'last_name' :
					// Validate if required either globally or per form.
					if (
						$is_required
						&& array_key_exists( 'give_tributes_ecard_last_name', $required_fields )
					) {
						unset( $required_fields['give_tributes_ecard_last_name'] );
					}
					break;
				case 'personalized' :
					// Validate if required either globally or per form.
					// Check if global tribute settings is enabled.
					$custom_message_enable_disable = 'disabled';
					if ( ! give_tributes_is_per_form_customized( $form_id ) && give_is_setting_enabled( give_get_option( 'give_tributes_enable_disable' ) ) ) {

						// Get global Mail a Card custom message enable/disable.
						$custom_message_enable_disable = give_get_option( 'give_tributes_ecards_custom_message_enable_disable', 'disabled' );

					} elseif ( give_tributes_is_per_form_customized( $form_id ) ) {

						// Get Per-form Mail a Card custom message enable/disable.
						$custom_message_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_ecards_custom_message_enable_disable', true );
						$custom_message_enable_disable = ! empty( $custom_message_enable_disable ) ? $custom_message_enable_disable : 'disabled';
					}

					if (
						(
							$is_required
							&& array_key_exists( 'give_tributes_ecard_notify_personalized_message', $required_fields )
						) ||
						! give_is_setting_enabled( $custom_message_enable_disable )
					) {
						unset( $required_fields['give_tributes_ecard_notify_personalized_message'] );
					}

					break;
				case 'email':
					$is_valid_email = true;
					if( is_array( $recipient ) ) {
						foreach( $recipient as $notify_email ) {
							if( ! empty( $notify_email ) && ! is_email( $notify_email ) ) {
								$is_valid_email = false;
								break;
							}
						}// End foreach().
					}// End if().

					if (
						$is_required
						&& array_key_exists( 'give_tributes_ecard_email', $required_fields )
						&& $is_valid_email
					) {
						unset( $required_fields['give_tributes_ecard_email'] );
					}
					break;
			}
		}

		return $required_fields;
	}

	/**
	 * Fires while inserting payments.
	 *
	 * Save Tributes data into the Payment meta.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 */
	public function insert_tribute_data( $payment_id ) {

		// Get Tribute enabled/disabled.
		$show_dedication = ! empty( $_POST['give_tributes_show_dedication'] ) ? $_POST['give_tributes_show_dedication'] : '';
		give_update_payment_meta( $payment_id, '_give_tributes_accept', $show_dedication ); // Update Give tribute type option selected or not.

		// Get the donation form id.
		$form_id = give_get_payment_form_id( $payment_id );

		// Update Give Tribute if accepted.
		if ( 'yes' !== $show_dedication ) {
			return;
		}

		// General Tribute Data.
		// Update Give Tribute type.
		$type = ! empty( $_POST['give_tributes_type'] ) ? $_POST['give_tributes_type'] : '';
		give_update_payment_meta( $payment_id, '_give_tributes_type', $type );

		// Tribute First name.
		$first_name = ! empty( $_POST['give_tributes_first_name'] ) ? give_clean( $_POST['give_tributes_first_name'] ) : '';
		give_update_payment_meta( $payment_id, '_give_tributes_first_name', $first_name );

		// Tribute First name.
		$last_name = ! empty( $_POST['give_tributes_last_name'] ) ? give_clean( $_POST['give_tributes_last_name'] ) : '';
		give_update_payment_meta( $payment_id, '_give_tributes_last_name', $last_name );

		// Tribute type option like : 'send_eCard', "send_mail_card" or 'none'.
		$posted_method = ( isset( $_POST['give_tributes_would_to'] ) && ! empty( $_POST['give_tributes_would_to'] ) ) ? give_clean( $_POST['give_tributes_would_to'] ) : 'none';

		// Get the honoree notification method.
		$ecard_or_mailed = give_tributes_get_notify_display_option( $form_id, $posted_method );

		// Update notification method to donation meta data.
		give_update_payment_meta( $payment_id, '_give_tributes_would_to', $ecard_or_mailed );

		// eCard data.
		if ( 'send_eCard' === $ecard_or_mailed ) {

			// Get the notification recipient data.
			$notify_recipient = $_POST['give_tributes_ecard_notify']['recipient'];

			// Get the notification multiple details.
			if ( give_tributes_is_allow_multiple_receipts( $form_id ) ) {

				// Check all recipient data for validation.
				foreach ( $notify_recipient as $notify_key => $notify_data ) {

					// Get the all of the person details.
					foreach ( $notify_data as $key_index => $notify_person_data ) {

						// Check key.
						switch ( $notify_key ) {
							case 'first_name':
								$ecards_firstname[ $notify_recipient['email'][ $key_index ] ] = give_clean( $notify_person_data );
								break;
							case 'last_name' :
								$ecards_lastname[ $notify_recipient['email'][ $key_index ] ] = give_clean( $notify_person_data );
								break;
							case 'email':
								$ecards_email[ $notify_recipient['email'][ $key_index ] ] = sanitize_email( $notify_person_data );
								break;
							case 'personalized':
								$ecards_personalized_msg[ $notify_recipient['email'][ $key_index ] ] = ! empty( $notify_person_data ) ? $notify_person_data : array();
								break;
						}
					}
				}
			} else {
				// If 'Multiple Receipt' is disabled.
				$ecards_firstname        = ! empty( $notify_recipient['first_name'][0] ) ? give_clean( $notify_recipient['first_name'][0] ) : '';
				$ecards_lastname         = ! empty( $notify_recipient['last_name'][0] ) ? give_clean( $notify_recipient['last_name'][0] ) : '';
				$ecards_email            = ! empty( $notify_recipient['email'][0] ) ? sanitize_email( $notify_recipient['email'][0] ) : '';
				$ecards_personalized_msg = ! empty( $notify_recipient['personalized'][0] ) ? sanitize_textarea_field( $notify_recipient['personalized'][0] ) : '';
			}

			give_update_payment_meta( $payment_id, '_give_tributes_ecard_notify_first_name', $ecards_firstname );
			give_update_payment_meta( $payment_id, '_give_tributes_ecard_notify_last_name', $ecards_lastname );
			give_update_payment_meta( $payment_id, '_give_tributes_honoree_ecard_email', $ecards_email );
			give_update_payment_meta( $payment_id, '_give_tributes_ecard_personalized_message', $ecards_personalized_msg );
			give_update_payment_meta( $payment_id, '_give_tributes_ecard_multiple_recipients', give_tributes_is_allow_multiple_receipts( $form_id ) ? 'enabled' : 'disabled' );

		} elseif ( 'send_mail_card' === $ecard_or_mailed ) {

			// Mail a card data.
			// Tribute Notify First name.
			$mail_card_notify_first_name = ! empty( $_POST['give_tributes_mail_card_notify_first_name'] ) ? give_clean( $_POST['give_tributes_mail_card_notify_first_name'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_notify_first_name', $mail_card_notify_first_name );

			// Tribute Notify Last name.
			$mail_card_notify_last_name = ! empty( $_POST['give_tributes_mail_card_notify_last_name'] ) ? give_clean( $_POST['give_tributes_mail_card_notify_last_name'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_notify_last_name', $mail_card_notify_last_name );

			// Mail a Card Personalized message.
			$mail_card_personalized_message = ! empty( $_POST['give-tributes-mail-card-personalized-message'] ) ? sanitize_textarea_field( $_POST['give-tributes-mail-card-personalized-message'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_personalized_message', $mail_card_personalized_message );

			// Mail a Card Honoree Address 1.
			$mail_card_address_1 = ! empty( $_POST['give_tributes_mail_card_address_1'] ) ? give_clean( $_POST['give_tributes_mail_card_address_1'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_address_1', $mail_card_address_1 );

			// Mail a Card Honoree Address 2.
			$mail_card_address_2 = ! empty( $_POST['give_tributes_mail_card_address_2'] ) ? give_clean( $_POST['give_tributes_mail_card_address_2'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_address_2', $mail_card_address_2 );

			// Mail a Card Honoree City.
			$mail_card_city = ! empty( $_POST['give_tributes_mail_card_city'] ) ? give_clean( $_POST['give_tributes_mail_card_city'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_city', $mail_card_city );

			// Mail a Card Honoree Country.
			$address_country = ! empty( $_POST['give_tributes_address_country'] ) ? give_clean( $_POST['give_tributes_address_country'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_address_country', $address_country );

			// Mail a Card Honoree state.
			$address_state = ! empty( $_POST['give_tributes_address_state'] ) ? give_clean( $_POST['give_tributes_address_state'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_address_state', $address_state );

			// Mail a Card Honoree Zip/Postal Code.
			$mail_card_zipcode = ! empty( $_POST['give_tributes_mail_card_zipcode'] ) ? give_clean( $_POST['give_tributes_mail_card_zipcode'] ) : '';
			give_update_payment_meta( $payment_id, '_give_tributes_mail_card_zipcode', $mail_card_zipcode );

		} // End if().

	}

	/**
	 * Include eCard header.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 * @param int $form_id    The form ID if present.
	 */
	public function ecard_email_header_call_back( $payment_id, $form_id ) {
		require( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/ecard/header-default.php' );
	}

	/**
	 * Include eCard Body for General Preview and Payment preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 */
	public function ecard_email_body_call_back( $payment_id ) {
		require( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/ecard/body-default.php' );
	}

	/**
	 * Include eCard footer for General Preview and Payment preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 */
	public function ecard_email_footer_call_back( $payment_id ) {
		require( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/ecard/footer-default.php' );
	}

	/**
	 * Include Mail a Card header for General Preview and Payment preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 */
	public function mail_card_email_header_call_back( $payment_id ) {
		require_once( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/mailCard/header-default.php' );
	}

	/**
	 * Include Mail a Card Body.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID for General Preview and Payment preview.
	 */
	public function mail_card_email_body_call_back( $payment_id ) {
		require_once( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/mailCard/body-default.php' );
	}

	/**
	 * Include Mail a Card footer for General Preview and Payment preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id The payment ID.
	 */
	public function mail_card_email_footer_call_back( $payment_id ) {
		require_once( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/mailCard/footer-default.php' );
	}

	/**
	 * Show Mail a Card message before the receipt main table.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param object $payment           The payment object.
	 * @param array  $give_receipt_args Receipt_argument.
	 */
	public function before_payment_table( $payment, $give_receipt_args ) {

		if ( ! isset( $give_receipt_args['id'] ) ) {
			return;
		}

		$form_id         = give_get_payment_form_id( $payment->ID );
		$gave_in_tribute = give_get_meta( $payment->ID, '_give_tributes_accept', true );
		$ecard_or_mailed = give_get_meta( $payment->ID, '_give_tributes_would_to', true );

		// Per form or global?
		if ( give_tributes_is_per_form_customized( $form_id ) ) {
			$who_sends_the_card    = give_get_meta( $form_id, '_give_tributes_per_form_who_sends_the_card', true );
			$card_creation         = give_get_meta( $form_id, '_give_tributes_per_form_card_creation_enable_disable', true );
			$admin_receipt_content = give_get_meta( $form_id, '_give_tributes_per_form_receipt_content_for_admin', true );
			$donor_receipt_content = give_get_meta( $form_id, '_give_tributes_per_form_receipt_content_for_donor', true );

		} else {
			$who_sends_the_card    = give_get_option( 'give_tributes_who_sends_the_card' );
			$card_creation         = give_get_option( 'give_tributes_card_creation_enable_disable' );
			$admin_receipt_content = give_get_option( 'give_tributes_receipt_content_for_admin' );
			$donor_receipt_content = give_get_option( 'give_tributes_receipt_content_for_donor' );
		}

		// Return if Tribute option is not Mail a Card.
		if ( empty( $gave_in_tribute ) || 'send_mail_card' !== $ecard_or_mailed ) {
			return;
		}

		if ( 'the_admin' === $who_sends_the_card ) {

			// Admin responsible for sending content. Output admin message.
			$mail_card_receipt_content = $admin_receipt_content;

		} else {

			// Return if Card creation option is disabled.
			if ( 'disabled' === $card_creation ) {
				return;
			}

			// Donor is responsible for mailing card.
			$mail_card_receipt_content = $donor_receipt_content;

		}

		$message = give_tribute_do_tags( $mail_card_receipt_content, $payment->ID );

		if ( ! empty( $message ) ) :
			?>
			<p><?php echo wpautop( $message ); ?></p>
			<?php
		endif;

	}

	/**
	 * Fires in the Donation receipt shortcode, after the receipt last item.
	 *
	 * Allows you to add new <td> elements after the receipt last item.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param object $payment           The payment object.
	 * @param array  $give_receipt_args Receipt_argument.
	 */
	public function donation_receipt_after( $payment, $give_receipt_args ) {

		$gave_in_tribute = give_get_meta( $payment->ID, '_give_tributes_accept', true );
		$ecard_or_mailed = give_get_meta( $payment->ID, '_give_tributes_would_to', true );

		// Return if Tribute option is not set.
		if ( empty( $gave_in_tribute ) || ! empty( $gave_in_tribute ) && 'no' === $gave_in_tribute ) {
			return;
		}

		// Prepare Honoree Full name.
		$honoree_first_name = give_get_meta( $payment->ID, '_give_tributes_first_name', true );
		$honoree_first_name = ! empty( $honoree_first_name ) ? ucfirst( $honoree_first_name ) : '';
		$honoree_last_name  = give_get_meta( $payment->ID, '_give_tributes_last_name', true );
		$honoree_last_name  = ! empty( $honoree_last_name ) ? ucfirst( $honoree_last_name ) : '';
		if ( ! empty( $honoree_first_name ) || ! empty( $honoree_last_name ) ) {
			$honoree_full_name = $honoree_first_name . ' ' . $honoree_last_name;
		} else {
			$honoree_full_name = '';
		}

		$notification_method = $notify_full_name = $notify_address = '';

		if ( 'send_eCard' === $ecard_or_mailed ) {

			if ( give_tributes_is_multiple_receipts_enabled( $payment->ID ) ) {
				$notify_full_name = give_tributes_ecards_notify_fields( $payment->ID, 'full_name', ', ', ARRAY_A );
				$notify_address   = give_tributes_ecards_notify_fields( $payment->ID, 'emails', ', ', ARRAY_A );
			} else {
				$notify_full_name = give_tributes_ecards_notify_fields( $payment->ID, 'full_name', '<br/>' );
				$notify_address   = give_tributes_ecards_notify_fields( $payment->ID, 'emails', '<br/>' );
			}

			// Notification method.
			$notification_method = __( 'eCard', 'give-tributes' );

		} elseif ( 'send_mail_card' === $ecard_or_mailed ) {

			$mail_card_notify_first_name = give_get_meta( $payment->ID, '_give_tributes_mail_card_notify_first_name', true );
			$mail_card_notify_first_name = ! empty( $mail_card_notify_first_name ) ? ucfirst( $mail_card_notify_first_name ) : '';

			$mail_card_notify_last_name = give_get_meta( $payment->ID, '_give_tributes_mail_card_notify_last_name', true );
			$mail_card_notify_last_name = ! empty( $mail_card_notify_last_name ) ? ucfirst( $mail_card_notify_last_name ) : '';

			// Mail a Card notify Full name.
			if ( ! empty( $mail_card_notify_first_name ) || ! empty( $mail_card_notify_last_name ) ) {
				$notify_full_name = $mail_card_notify_first_name . ' ' . $mail_card_notify_last_name;
			} else {
				$notify_full_name = '';
			}

			// Notification method.
			$notification_method = __( 'Mail a Card', 'give-tributes' );

			// Notify Honoree.
			$notify_address = give_tributes_notification_address( $payment->ID, false );

		}// End if().

		?>
		<tr>
			<td scope="row"><strong><?php _e( 'Dedication', 'give-tributes' ); ?></strong></td>
			<td class="give-tribute-dedication-information">
				<table>
					<tr>
						<td><strong><?php echo give_get_meta( $payment->ID, '_give_tributes_type', true ); ?></strong></td>
					</tr>
					<tr>
						<td><?php echo $honoree_full_name; ?></td>
					</tr>
					<?php if ( 'none' !== $ecard_or_mailed ) : ?>
						<tr>
							<td><strong><?php _e( 'Notification', 'give-tributes' ); ?></strong></td>
						</tr>
						<tr>
							<td><?php echo $notification_method; ?></td>
						</tr>
						<?php

						// If it has multiple notify receipts.
						if ( give_tributes_is_multiple_receipts_enabled( $payment->ID ) ) {
							?>
							<tr>
								<td>
									<ul>
										<?php
										if ( ! empty( $notify_full_name ) ) {

											// List out the the persons to be notified.
											foreach ( $notify_full_name as $index => $full_name ) {
												?>
												<li><?php echo $full_name . ' - ' ?> <a
															href="mailto:<?php echo $notify_address[ $index ]; ?>"><?php echo $notify_address[ $index ]; ?></a></li>
												<?php
											}
										}
										?>
									</ul>
								</td>
							</tr>
							<?php
						} else {
							?>
							<tr>
								<td><?php echo $notify_full_name; ?></td>
							</tr>
							<tr>
								<td><?php echo $notify_address; ?></td>
							</tr>
							<?php
						}
						?>

					<?php endif; ?>
				</table>
			</td>

		</tr>
		<?php

	}

	/**
	 * Register tribute detail item to receipt.
	 *
	 * @param DonationReceipt $receipt
	 * @since 1.5.7
	 */
	public function addTributeDetailItem( $receipt ){
		$updateReceipt = new UpdateDonationReceipt( $receipt );
		$updateReceipt->apply();
	}

	/**
	 * Add Send Tribute Information tag in Donation receipt.
	 *
	 * @since  1.1.1
	 * @access public
	 */
	public function tribute_info_tag() {
		give_add_email_tag( 'tribute_info', __( 'This email tag provides useful information for admins for donations given in tribute.', 'give-tributes' ), array(
			$this,
			'tribute_info_email_tag',
		) );
	}

	/**
	 * Add Custom call back function for {tribute_info} tag.
	 *
	 * @since   1.1.1
	 * @updated 1.3.4
	 * @access  public
	 *
	 * @param array|int $tag_args Email template tag arguments.
	 *
	 * @return string
	 */
	public function tribute_info_email_tag( $tag_args ) {
		$tribute_info = __( 'This donor has opted to <em>not</em> give this donation in dedication.', 'give-tributes' );

		// Backward compatibility.
		$payment_id = $tag_args;
		if ( is_array( $tag_args ) ) {
			$payment_id = $tag_args['payment_id'];
		}

		if ( isset( $payment_id ) && ! empty( $payment_id ) ) {
			$gave_in_tribute = give_get_meta( $payment_id, '_give_tributes_accept', true );
			$ecard_or_mailed = give_get_meta( $payment_id, '_give_tributes_would_to', true );

			if ( 'no' !== $gave_in_tribute && 'send_mail_card' === $ecard_or_mailed ) {
				$tribute_info = give_tribute_do_tags( give_tributes_get_tribute_info_content(), $payment_id );
			} elseif ( 'no' !== $gave_in_tribute && 'send_eCard' === $ecard_or_mailed ) {
				$tribute_info = give_tribute_do_tags( __( '{donor_name} has requested that their donation be made {tribute} {honoree_fullname} and opted to send an eCard.', 'give-tributes' ), $payment_id );
			} elseif ( 'no' !== $gave_in_tribute && 'none' === $ecard_or_mailed ) {
				$tribute_info = give_tribute_do_tags( __( '{donor_name} has requested that their donation be made {tribute} {honoree_fullname}.', 'give-tributes' ), $payment_id );
			}
		}

		/**
		 * Filter the {tribute_info} email template tag output.
		 *
		 * @since 1.3.4
		 *
		 * @param string $tribute_info
		 * @param array  $tag_args
		 */
		$tribute_info = apply_filters( 'give_tribute_info_email_tag', $tribute_info, $tag_args );

		return $tribute_info;

	}

	/**
	 * Preview default Send Tribute Information.
	 *
	 * @since  1.1.1
	 * @access public
	 *
	 * @param string $message
	 *
	 * @return string $message
	 */
	public function email_preview_tribute_info_tag( $message ) {
		$payment_id      = isset( $_GET['preview_id'] ) && ! empty( $_GET['preview_id'] ) ? give_clean( $_GET['preview_id'] ) : 0;
		$default_message = $this->tribute_info_email_tag( array( 'payment_id' => $payment_id ) );
		$message         = str_replace( '{tribute_info}', $default_message, $message );
		$message         = apply_filters( 'tribute_info_email_preview', $message );

		return $message;
	}

	/**
	 * Remove required fields for Manual donation with Tribute.
	 *
	 * @since 1.5
	 *
	 * @param array $required_fields
	 *
	 * @return array
	 */
	public function manual_donation_remove_required_fields( $required_fields ) {
		// Get the input field value(s) from the manual donation form page.
		if ( give_tribute_is_manual_donation_page() ) {
			unset( $required_fields );
			$required_fields = array();
		}

		return $required_fields;
	}

}
