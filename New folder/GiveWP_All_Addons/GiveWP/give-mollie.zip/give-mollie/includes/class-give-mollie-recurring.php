<?php
/**
 * Give Mollie - Recurring Donations.
 *
 * @link       https://givewp.com
 * @since      1.0.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/
 */

/**
 * The Give Mollie Recurring Donations Functionality Class.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes
 * @author     GiveWP
 */
class Give_Mollie_Recurring extends Give_Recurring_Gateway {

	/**
	 * Register Recurring support
	 * Give_Recurring_Gateway::init()
	 *
	 * @since 1.0
	 */
	public function init() {

		$this->id = 'mollie';

		// Cancellation action
		add_action( 'give_recurring_cancel_' . $this->id . '_subscription', array( $this, 'cancel' ), 10, 2 );

	}

	/**
	 * Create Payment Profiles.
	 *
	 * We will store temporary subscription's profile ID.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function create_payment_profiles() {

		// This is a temporary ID used to look it up later during Give Mollie payment creation.
		$this->subscriptions['profile_id']     = md5( $this->purchase_data['purchase_key'] . $this->subscriptions['id'] );
		$this->subscriptions['transaction_id'] = md5( uniqid( rand(), true ) );
	}

	/**
	 * Can cancel.
	 *
	 * @param $ret
	 * @param $subscription
	 *
	 * @return bool
	 */
	public function can_cancel( $ret, $subscription ) {

		if (
			$subscription->gateway == $this->id
			&& ! empty( $subscription->profile_id )
			&& 'active' === $subscription->status
		) {
			$ret = true;
		}

		return $ret;
	}

	/**
	 * Cancels a subscription.
	 *
	 * @param \Give_Subscription $subscription
	 * @param                    $valid
	 *
	 * @return bool
	 */
	public function cancel( $subscription, $valid ) {

		if ( empty( $valid ) ) {
			return false;
		}

		try {
			/** @var \Give_Mollie_API $give_mollie_obj */
			$give_mollie = new Give_Mollie_API();

			// Get Mollie customer and subscription ID.
			$mollie_sub_id     = $subscription->profile_id;
			$parent_payment_id = $subscription->parent_payment_id;
			$customer_id       = give_get_payment_meta( $parent_payment_id, Give_Mollie_API::get_customer_meta_key(), true );

			// Cancel the subscription in Give Mollie.
			$cancel_subscription = $give_mollie->give_mollie_obj->customers->get( $customer_id )->cancelSubscription( $mollie_sub_id );

			if ( 'canceled' === $cancel_subscription->status ) {
				give_insert_payment_note( $subscription->parent_payment_id, __( 'Subscription has been cancelled.', 'give-mollie' ) );
				give_update_payment_meta( $subscription->parent_payment_id, '_give_subscription_cancelled_response', $cancel_subscription );
			}


		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

			// Record gateway errors.
			give_record_gateway_error(
				__( 'Give Mollie error', 'give-mollie' ),
				sprintf( __( 'Give Mollie returned an error while cancelling a subscription. Details: %s', 'give-mollie' ), $e->getMessage() )
			);

			give_set_error( 'Mollie Error', __( 'An error occurred while cancelling the donation. Please try again.', 'give-mollie' ) );

			return false;
		}
	}

	/**
	 * Record subscription sign up.
	 *
	 * @see   https://docs.mollie.com/payments/recurring
	 *
	 * @since 1.0
	 */
	public function record_signup() {

		// Create subscription in 'pending' status and send donor to Mollie to complete payment.
		try {

			// Now create the subscription record.
			$subscriber = new Give_Recurring_Subscriber( $this->customer_id );

			// Support user_id if it is present in purchase_data.
			if ( isset( $this->purchase_data['user_info']['id'] ) ) {
				$args['user_id'] = $this->purchase_data['user_info']['id'];
			}

			$frequency               = ! empty( $this->subscriptions['frequency'] ) ? intval( $this->subscriptions['frequency'] ) : 1;
			$subscription_expiration = $subscriber->get_new_expiration( $this->subscriptions['id'], $this->subscriptions['price_id'], $frequency, $this->subscriptions['period'] );

			// Give subscription array.
			$subscription_args = array(
				'product_id'        => $this->subscriptions['id'],
				'parent_payment_id' => $this->payment_id,
				'status'            => 'pending',
				'period'            => $this->subscriptions['period'],
				'initial_amount'    => $this->subscriptions['initial_amount'],
				'recurring_amount'  => $this->subscriptions['recurring_amount'],
				'bill_times'        => $this->subscriptions['bill_times'],
				'frequency'         => $frequency,
				'expiration'        => $subscription_expiration,
				'profile_id'        => $this->subscriptions['profile_id'],
				'form_id'           => $this->subscriptions['form_id'],
			);

			// Support user_id if it is present in purchase_data.
			if ( isset( $this->purchase_data['user_info']['id'] ) ) {
				$args['user_id'] = $this->purchase_data['user_info']['id'];
			}

			/** @var \Give_Subscription $give_subscription */
			$give_subscription = $subscriber->add_subscription( $subscription_args );

			// Set subscription_payment.
			give_update_payment_meta( $this->payment_id, '_give_subscription_id', $give_subscription->id );

			/** @var \Give_Mollie_API $give_mollie */
			$give_mollie = new Give_Mollie_API();

			/** @var \Give_Mollie_Webhook $give_mollie_webhook */
			$give_mollie_webhook  = new Give_Mollie_Webhook();
			$additional_query_arg = '&secret=' . uniqid( 'g-payment', false ) . '&payment_id=' . $this->payment_id . '&first=true';
			$currency             = isset( $_POST['give-cs-form-currency'] ) ? give_clean( $_POST['give-cs-form-currency'] ) : give_get_currency( give_get_payment_form_id( $this->payment_id ) );

			// Mollie expects 1000.00 format (no thousands sep, but decimal sep with 2 decimals)
			// @see https://docs.mollie.com/reference/v2/payments-api/create-payment#parameters
			$mollie_formatted_amount = give_maybe_sanitize_amount(
				$this->purchase_data['price'],
				array(
					'number_decimals' => 2,
				)
			);

			/**
			 * Recurring payments happen in the background so the customer goes
			 * through payment steps only once for the first payment.
			 *
			 * @see https://docs.mollie.com/payments/recurring
			 */
			$mollie_subscription_args = array(
				'amount'       => array(
					'value'    => $mollie_formatted_amount,
					'currency' => $currency,
				),
				'description'  => strip_tags( Give_Mollie_API::get_payment_description( $this->payment_id, $give_subscription ) ),
				'redirectUrl'  => Give_Mollie_API::get_redirect_url( $this->payment_id, true ),
				'sequenceType' => 'first',
				// A first payment for the customer to agree to automatic recurring charges.
				'webhookUrl'   => $give_mollie_webhook->get_webhook_endpoint( 'payments', $additional_query_arg ),
				// "localhost", ".dev" are not acceptable.
				'metadata'     => array(
					'name'                 => give_get_donor_name_by( $this->payment_id ),
					'email'                => isset( $_POST['give_email'] ) ? $_POST['give_email'] : '',
					'give_form_id'         => isset( $_POST['give-form-id'] ) ? $_POST['give-form-id'] : '',
					'give_form_title'      => $this->purchase_data['post_data']['give-form-title'],
					'date'                 => $this->purchase_data['date'],
					'user_email'           => $this->purchase_data['post_data']['give_email'],
					'purchase_key'         => $this->purchase_data['purchase_key'],
					'user_info'            => $this->purchase_data['user_info'],
					'donation_id'          => $this->payment_id,
					'give-subscription-id' => $give_subscription->id,
				),
			);

			// Create subscription payment.
			$redirect_url = $give_mollie->create_payment( $mollie_subscription_args );

			if ( ! $redirect_url ) {
				throw new Exception();
			}

			// Redirect to payment page.
			wp_redirect( $redirect_url );
			exit;

		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

			// Payment creation failed.
			give_record_gateway_error(
				__( 'Payment Creation Failed', 'give-mollie' ),
				sprintf( __( 'First payment creation failed while processing the recurring donation. Details: %s', 'give-mollie' ), json_encode( $e->getMessage() ) )
			);

			// Give set error.
			give_set_error( 'mollie_error', $e->getMessage() );

			// Send back to checkout page.
			give_send_back_to_checkout( '?payment-mode=mollie' );
		}
	}

	/**
	 * Get the interval for subscription
	 *
	 * @since 1.0
	 *
	 * @param string $interval  Recurring Interval.
	 * @param int    $frequency Recurring Frequency.
	 *
	 * @return string
	 */
	public static function get_interval( $interval, $frequency ) {

		switch ( $interval ) {
			case 'day':
			case 'week':
			case 'month':
				$interval = $interval;
				break;
			case 'quarter':
				$interval = 'months';
				break;
			case 'year':
				$interval = 'months';
				break;
		}

		return $interval;
	}

	/**
	 * Gets interval length and interval unit for Authorize.net based on Give subscription period.
	 *
	 * @param  string $period
	 * @param  int    $frequency
	 *
	 * @since  1.3.0
	 * @access public
	 *
	 * @return array
	 */
	public static function get_interval_count( $period, $frequency ) {

		$interval_count = $frequency;

		switch ( $period ) {

			case 'quarter':
				$interval_count = 3 * $frequency;
				break;
			case 'year':
				$interval_count = 12 * $frequency;
				break;
		}

		return $interval_count;
	}
}

new Give_Mollie_Recurring();
