<?php defined( 'ABSPATH' ) or exit; ?>

<strong>
	<?php _e( 'Activation Error:', 'give-mailchimp' ); ?>
</strong>
<?php _e( 'You must have', 'give-mailchimp' ); ?> <a href="https://givewp.com" target="_blank">Give</a>
<?php _e( 'version', 'give-mailchimp' ); ?> <?php echo GIVE_VERSION; ?>+
<?php printf( esc_html__( 'for the %1$s add-on to activate', 'give-mailchimp' ), GIVE_MAILCHIMP_ADDON_NAME ); ?>.
