<?php
/**
 * Show Paytm transaction error.
 *
 * @since 1.0
 * @return bool
 */
function give_paytm_show_error( $content ) {
	if (
		! isset( $_GET['give-paytm-payment'] )
		|| 'failed' !== $_GET['give-paytm-payment']
		|| ! isset( $_GET['give-paytm-error-message'] )
		|| empty( $_GET['give-paytm-error-message'] )
		|| ! give_is_failed_transaction_page()
	) {
		return $content;
	}

	return Give_Notices::print_frontend_notice(
		sprintf(
			'Payment Error: %s',
			base64_decode( $_GET['give-paytm-error-message'] )
		),
		false,
		'error'
	) . $content;
}

add_filter( 'the_content', 'give_paytm_show_error' );
