<?php
namespace GivePayPalPro\PaymentGateways;

use GivePayPalPro\PaymentGateways\PayPalProNVP\PayPalProNVP;
use GivePayPalPro\PaymentGateways\PayPalProPayFlow\PayPalProPayFlow;
use GivePayPalPro\PaymentGateways\PayPalProRest\PayPalProRest;

/**
 * Class SettingPage
 * @package GivePayPalPro\PaymentGateways
 *
 * @since 1.2.3
 */
class SettingPage{
	const SETTING_PAGE_ID = 'paypal-payment-pro';

	/**
	 * Bootstrap functionality.
	 *
	 * @since 1.2.3s
	 */
	public function boot(){
		add_filter( 'give_get_groups_paypal', [ $this, 'registerGroup' ] );
		add_filter( 'give_get_groups_paypal_' . self::SETTING_PAGE_ID, [ $this, 'registerSubGroup' ] );
		add_filter( 'give_get_settings_gateways', [ $this, 'registerPaypalSettings' ], 11 );
	}

	/**
	 * Register setting group.
	 *
	 * @since 1.2.3
	 *
	 * @param  array  $groups
	 *
	 * @return array
	 */
	public function registerGroup( $groups ){
		$groups[self::SETTING_PAGE_ID] = esc_html__( 'PayPal Payment Pro', 'give-paypal-pro' );

		return $groups;
	}

	/**
	 * Register setting group.
	 *
	 * @since 1.2.3
	 *
	 * @param  array  $subGroups
	 *
	 * @return array
	 */
	public function registerSubGroup( $subGroups ){
		$subGroups[PayPalProPayFlow::GATEWAY_ID] = esc_html__( 'PayPal Flow', 'give-paypal-pro' );
		$subGroups[PayPalProRest::GATEWAY_ID ]   = esc_html__( 'PayPal REST API', 'give-paypal-pro' );
		$subGroups[PayPalProNVP::GATEWAY_ID]     = esc_html__( 'PayPal NVP', 'give-paypal-pro' );

		return $subGroups;
	}

	/**
	 * Register settings to PayPal section.
	 *
	 * @since 1.2.3
	 *
	 * @param $settings
	 *
	 * @return mixed
	 */
	public function registerPaypalSettings( $settings ) {
		$settings[ self::SETTING_PAGE_ID ] = [
			PayPalProPayFlow::GATEWAY_ID => give( PayPalProPayFlow::class )->getOptions(),
			PayPalProRest::GATEWAY_ID    => give( PayPalProRest::class )->getOptions(),
			PayPalProNVP::GATEWAY_ID     => give( PayPalProNVP::class )->getOptions(),
		];

		return $settings;
	}
}
