<?php
/**
 * Class Give_Tributes_Reports.
 *
 * Define Tributes Report int Give Report tab.
 *
 * @link       https://givewp.com
 * @since      1.0.0
 *
 * @package    Give_Tributes_Reports
 */

if ( ! class_exists( 'Give_Tributes_Reports' ) ) :
	/**
	 * Give_Tributes_Reports.
	 *
	 * @since 1.0.0
	 */
	class Give_Tributes_Reports extends Give_Settings_Page {

		/**
		 * Setting page id.
		 *
		 * @since  1.0.0
		 * @access protected
		 *
		 * @var   string
		 */
		protected $id = '';

		/**
		 * Setting page label.
		 *
		 * @since  1.0.0
		 * @access protected
		 *
		 * @var   string
		 */
		protected $label = '';

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->id          = 'tributes';
			$this->label       = __( 'Tributes', 'give-tributes' );
			$this->default_tab = 'give-tributes-donations';

			add_filter( 'give-reports_tabs_array', array( $this, 'add_settings_page' ), 20 );
			add_action( "give-reports_settings_{$this->id}_page", array( $this, 'output' ) );
			add_action( 'give_admin_field_tribute_mail_card_report', array( $this, 'give_tributes_display_mail_card_report' ), 10, 2 );
			add_action( 'give_admin_field_tribute_ecard_report', array( $this, 'give_tributes_display_ecard_report' ), 10, 2 );
			add_action( 'give_admin_field_tribute_donations_report', array( $this, 'give_tributes_display_donations_report' ), 10, 2 );

			// Do not use main form for this tab.
			if ( give_get_current_setting_tab() === $this->id ) {
				add_action( 'give-reports_open_form', '__return_empty_string' );
				add_action( 'give-reports_close_form', '__return_empty_string' );
			}

			parent::__construct();
		}

		/**
		 * Add this page to settings.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @param  array $pages Lst of pages.
		 *
		 * @return array
		 */
		public function add_settings_page( $pages ) {
			$pages[ $this->id ] = $this->label;

			return $pages;
		}

		/**
		 * Get settings array.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return array
		 */
		public function get_settings() {
			// Hide save button.
			$GLOBALS['give_hide_save_button'] = true;

			$settings        = array();
			$current_section = give_get_current_setting_section();

			switch ( $current_section ) {
				case 'give-tributes-donations':
					$settings = array(
						// Section 1: Tribute Donations.
						array(
							'id'         => 'give_tributes_donations_report',
							'type'       => 'title',
							'table_html' => false,
						),
						array(
							'id'   => 'give_tributes_donations_section',
							'name' => __( 'Tribute Donations', 'give-tributes' ),
							'type' => 'tribute_donations_report',
						),
						array(
							'id'         => 'give_tributes_donations_report',
							'type'       => 'sectionend',
							'table_html' => false,
						),
					);
					break;

				case 'give-tributes-mail-card':
					$settings = array(
						// Section 2: Mail a Card.
						array(
							'id'         => 'give_tributes_mail_card_report',
							'type'       => 'title',
							'table_html' => false,
						),
						array(
							'id'   => 'give_tributes_mail_card_section',
							'name' => __( 'Mail a Card', 'give-tributes' ),
							'type' => 'tribute_mail_card_report',
						),
						array(
							'id'         => 'give_tributes_mail_card_report',
							'type'       => 'sectionend',
							'table_html' => false,
						),
					);
					break;

				case 'give-tributes-ecard' :
					$settings = array(
						// Section 3: eCard.
						array(
							'id'         => 'give_tributes_ecard_report',
							'type'       => 'title',
							'table_html' => false,
						),
						array(
							'id'   => 'give_tributes_ecard_section',
							'name' => __( 'eCards', 'give-tributes' ),
							'type' => 'tribute_ecard_report',
						),
						array(
							'id'         => 'give_tributes_ecard_report',
							'type'       => 'sectionend',
							'table_html' => false,
						),
					);
					break;
			} // End switch().

			/**
			 * Filter the settings.
			 *
			 * @since  1.1.0
			 *
			 * @param  array $settings
			 */
			$settings = apply_filters( 'give_fee_get_settings_' . $this->id, $settings );

			// Output.
			return $settings;
		}

		/**
		 * Get sections.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return array
		 */
		public function get_sections() {
			$sections = array(
				'give-tributes-donations' => __( 'Tribute Donations', 'give-tributes' ),
				'give-tributes-mail-card' => __( 'Mail a Card', 'give-tributes' ),
				'give-tributes-ecard'     => __( 'eCards', 'give-tributes' ),
			);

			return apply_filters( 'give_tributes_get_sections_' . $this->id, $sections );
		}

		/**
		 * Output the settings.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return void
		 */
		public function output() {
			$settings = $this->get_settings();

			Give_Admin_Settings::output_fields( $settings, 'give_settings' );
		}


		/**
		 * Show Mail a Card Report.
		 *
		 * @access      public
		 * @since       1.0.0
		 *
		 * @param array  $field       Array of Field passed.
		 * @param string $field_value Field value.
		 *
		 * @return      void
		 */
		public function give_tributes_display_mail_card_report( $field, $field_value ) {

			do_action( 'give_tributes_mail_card_reports' );
		}

		/**
		 * Show eCard Report.
		 *
		 * @access      public
		 * @since       1.0.0
		 *
		 * @param array  $field       Array of Field passed.
		 * @param string $field_value Field value.
		 *
		 * @return      void
		 */
		public function give_tributes_display_ecard_report( $field, $field_value ) {

			do_action( 'give_tributes_ecard_reports' );
		}

		/**
		 * Show Tribute Donations Report.
		 *
		 * @access      public
		 * @since       1.0.0
		 *
		 * @param array  $field       Array of Field passed.
		 * @param string $field_value Field value.
		 *
		 * @return      void
		 */
		public function give_tributes_display_donations_report( $field, $field_value ) {

			do_action( 'give_tributes_donations_reports' );
		}
	}

endif;

return new Give_Tributes_Reports();
