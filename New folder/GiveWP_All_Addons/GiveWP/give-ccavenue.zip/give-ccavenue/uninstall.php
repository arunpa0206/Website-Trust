<?php
// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get Give core settigns.
$give_settings = give_get_settings();

// List of plugin settings.
$plugin_settings = array(
	'ccavenue_payment_method_label',
	'ccavenue_live_merchant_id',
	'ccavenue_live_access_code',
	'ccavenue_live_working_key',
	'ccavenue_phone_field',
);

// Unset all plugin settings.
foreach ( $plugin_settings as $setting ) {
	if ( isset( $give_settings[ $setting ] ) ) {
		unset( $give_settings[ $setting ] );
	}
}

// Remove payumoney from active gateways list.
if ( isset( $give_settings['gateways']['ccavenue'] ) ) {
	unset( $give_settings['gateways']['ccavenue'] );
}


// Update settings.
update_option( 'give_settings', $give_settings );
