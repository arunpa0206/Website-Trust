<?php
/**
 * Admin Functions
 *
 * @package     Give
 * @copyright   Copyright (c) 2019, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.2
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Proceed only, if class Give_Braintree_Admin_Settings not exists.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'Give_Braintree_Admin_Settings' ) ) {

	/**
	 * Class Give_Braintree_Admin_Settings
	 *
	 * @since 1.0.0
	 */
	class Give_Braintree_Admin_Settings {


		/**
		 * Give_Braintree_Admin_Settings constructor.
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function __construct() {

			add_filter( 'give_get_sections_gateways', array( $this, 'register_sections' ) );
			add_action( 'give_get_settings_gateways', array( $this, 'register_settings' ) );
		}


		/**
		 * Register Admin Settings.
		 *
		 * @param array $settings List of admin settings.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return array
		 */
		function register_settings( $settings ) {

			switch ( give_get_current_setting_section() ) {

				case 'braintree':

					$settings = array(
						array(
							'id'   => 'give_title_braintree',
							'type' => 'title',
						),
						array(
							'id'   => 'braintree_merchantId',
							'name' => __( 'Live Merchant ID', 'give-braintree' ),
							'desc' => __( 'Enter your LIVE unique merchant ID (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'text',
							'size' => 'regular',
						),
						array(
							'id'   => 'braintree_merchantAccountId',
							'name' => __( 'Live Merchant Account ID', 'give-braintree' ),
							'desc' => __( 'Enter your LIVE unique merchant account ID (found under Settings > Processing > Merchant Accounts).', 'give-braintree' ),
							'type' => 'text',
						),
						array(
							'id'   => 'braintree_publicKey',
							'name' => __( 'Live Public Key', 'give-braintree' ),
							'desc' => __( 'Enter your LIVE public key (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'text',
						),
						array(
							'id'   => 'braintree_privateKey',
							'name' => __( 'Live Private Key', 'give-braintree' ),
							'desc' => __( 'Enter your LIVE private key (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'api_key',
						),
						array(
							'id'   => 'sandbox_braintree_merchantId',
							'name' => __( 'Sandbox Merchant ID', 'give-braintree' ),
							'desc' => __( 'Enter your unique sandbox merchant ID (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'text',
							'size' => 'regular',
						),
						array(
							'id'   => 'sandbox_braintree_merchantAccountId',
							'name' => __( 'Sandbox Merchant Account ID', 'give-braintree' ),
							'desc' => __( 'Enter your sandbox unique merchant account ID (found under Settings > Business > Merchant Accounts).', 'give-braintree' ),
							'type' => 'text',
						),
						array(
							'id'   => 'sandbox_braintree_publicKey',
							'name' => __( 'Sandbox Public Key', 'give-braintree' ),
							'desc' => __( 'Enter your sandbox public key (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'text',
						),
						array(
							'id'   => 'sandbox_braintree_privateKey',
							'name' => __( 'Sandbox Private Key', 'give-braintree' ),
							'desc' => __( 'Enter your sandbox private key (found on the portal under API Keys when you first login).', 'give-braintree' ),
							'type' => 'api_key',
						),
						array(
							'id'   => 'braintree_collect_billing',
							'name' => __( 'Collect Billing Details', 'give-braintree' ),
							'desc' => __( 'This option will enable the billing details section for Braintree which requires the donor\'s address to complete the donation. These fields are not required by Braintree to process the transaction, but you may have the need to collect the data.', 'give-braintree' ),
							'type' => 'checkbox',
						),
						array(
							'id'      => 'braintree_submitForSettlement',
							'name'    => __( 'Submit for Settlement', 'give-braintree' ),
							'desc'    => __( 'Enable this option if you would like to immediately submit all transactions for settlement. This will charge the donation without needing your prior approval.', 'give-braintree' ),
							'default' => 'on',
							'type'    => 'checkbox',
						),
						array(
							'id'   => 'braintree_storeInVaultOnSuccess',
							'name' => __( 'Store In Vault on Success', 'give-braintree' ),
							'desc' => sprintf( __( 'Enable this option if you would like to store the customers <strong>payment information</strong> in the Braintree Vault upon a successful donation. <a href="%s" target="_blank">Read more about Braintree\'s Vault feature &raquo;</a>', 'give-braintree' ), 'http://docs.givewp.com/addon-braintree-vault' ),
							'type' => 'checkbox',
						),
						array(
							'id'   => 'give_title_braintree',
							'type' => 'sectionend',
						),
					);

					break;

			}// End switch().

			return $settings;
		}


		/**
		 * Register Section for Gateway Settings.
		 *
		 * @param array $sections List of sections.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return mixed
		 */
		public function register_sections( $sections ) {

			$sections['braintree'] = __( 'Braintree', 'give-braintree' );

			return $sections;
		}


	}
}

new Give_Braintree_Admin_Settings();