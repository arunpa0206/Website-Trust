<?php defined( 'ABSPATH' ) or exit; ?>
<tr>
	<td scope="row"><strong><?php esc_html_e( 'Fund', 'give-funds' ); ?></strong></td>
	<td><?php echo $fundName; ?></td>
</tr>

