/**
 * Give Tributes Frontend JS.
 */
var give_global_vars, Give_Tribute;

jQuery( document ).ready( function( $ ) {

	var $body = $( 'body' );

	/**
	 * Hide dedication fieldset after modal closes.
	 */
	$( document ).on( 'mfpAfterClose', function( event ) {
		$( '.give-display-modal .give-tributes-dedicate-donation' ).hide();
	} );

	/**
	 * Trigger show dedication and country after gateway ajax success.
	 */
	$( 'input.give-gateway' ).on( 'change', function() {

		var form = $( this ).parents( '.give-form' ),
			chosen_gateway = $( this ).val(),
			gateway_ajax_url = give_global_vars.ajaxurl + '?payment-mode=' + chosen_gateway;

		$( document ).ajaxComplete( function( event, XMLHttpRequest, ajaxOptions ) {
			var http_request_url = ajaxOptions.url;
			if ( http_request_url === gateway_ajax_url ) {
				Give_Tribute.give_tributes_show_dedication( form );
				form.find( '.give-tributes-dedicate-donation' ).show();
			}
		} );
	} );

	/**
	 * Reveal Btn which displays the checkout content.
	 */
	$body.on( 'click', '.give-btn-reveal', function( e ) {
		var this_form = $( this ).parents( 'form' );
		this_form.find( '.give-tributes-dedicate-donation' ).slideDown();
	} );

} );
