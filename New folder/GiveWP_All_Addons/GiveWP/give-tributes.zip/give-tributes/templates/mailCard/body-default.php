<?php
/**
 * Give Tributes Mail a Card Email Body.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/templates/mailCard
 * @author     GiveWP <https://givewp.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// {mail_card_message} is replaced by the content entered in Donations > Settings > Tributes > Mail a Card.
?>
{mail_card_message}
