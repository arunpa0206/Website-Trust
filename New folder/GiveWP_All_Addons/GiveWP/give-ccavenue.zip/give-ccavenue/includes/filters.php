<?php
// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Template include callback.
 *
 * @param $template
 *
 * @return string
 */
function give_ccavenue_template_include_callback( $template ) {
	if ( isset( $_GET['process_ccavenue_payment'] ) && 'processing' === esc_attr( $_GET['process_ccavenue_payment'] ) ) {
		return dirname( plugin_dir_path( __FILE__ ) ) . '/template/ccavenue-form.php';
	} elseif ( isset( $_GET['process_ccavenue_payment_success'] ) ) {
		return dirname( plugin_dir_path( __FILE__ ) ) . '/template/ccavenue-success.php';
	}

	return $template;
}

add_filter( 'template_include', 'give_ccavenue_template_include_callback' );

/**
 * This function will be used to validate phone number field.
 *
 * @since 1.0.3
 */
function give_ccavenue_validate_required_form_fields() {

	$post_data = give_clean( $_POST );

	if ( isset( $post_data['give_ccavenue_phone'] ) && empty( $post_data['give_ccavenue_phone'] ) ) {
		give_set_error( 'empty_phone', __( 'Please enter phone number to process the donation.', 'give-ccavenue' ) );
	}
}

add_filter( 'give_checkout_error_checks', 'give_ccavenue_validate_required_form_fields' );

/**
 * This function will add phone number to donation receipt.
 *
 * @param array $give_receipt_args Donation Receipt Arguments.
 * @param int   $donation_id       Donation ID.
 *
 * @since 1.0.3
 *
 * @return mixed
 */
function give_ccavenue_add_phone_number_to_receipt( $give_receipt_args, $donation_id ) {

	// Bailout.
	if ( 'ccavenue' !== give_get_payment_gateway( $donation_id ) ) {
		return $give_receipt_args;
	}

	$give_receipt_args['ccavenue_phone_number'] = array(
		'name'    => __( 'Phone Number', 'give-ccavenue' ),
		'value'   => give_ccavenue_get_phone_number_value( $donation_id ),
		'display' => true,
	);

	return $give_receipt_args;
}
add_filter( 'give_donation_receipt_args', 'give_ccavenue_add_phone_number_to_receipt', 10, 2 );
