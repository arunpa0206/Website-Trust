<?php
/**
 * Give Tributes Mail a Card Email Header.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/templates/mailCard
 * @author     GiveWP <https://givewp.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$form_id = give_get_payment_form_id( $payment_id );

// Check if Print from General settings.
if ( give_tributes_is_per_form_customized( $form_id ) ) {
	$mail_card_graphic      = give_get_meta( $form_id, '_give_tributes_per_form_card_graphic', true );
	$mail_card_logo_graphic = give_get_meta( $form_id, '_give_tributes_per_form_logo_graphic', true );
} else {
	$mail_card_logo_graphic = give_get_option( 'give_tributes_logo_graphic', '//placehold.it/250x100&text=' . urlencode( esc_attr__( 'Placeholder Logo Image', 'give-tributes' ) ) );
	$mail_card_graphic      = give_get_option( 'give_tributes_card_graphic' );
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo get_bloginfo( 'name' ); ?></title>
	<style>
		.aligncenter {
			text-align: center;
		}
	</style>
</head>
<body>
<table width="100%" style="font-weight: normal;">
	<tr>
		<td valign="top">
			<table id="template_container">
				<tr>
					<td align="left" valign="left">
						<!-- Body -->
						<table border="0" width="100%" id="template_body" style="<?php echo apply_filters( 'give_tributes_mail_card_header_padding', 'padding-top: 200px;' ); ?>">
							<tr>
								<td valign="left">
									<!-- Content -->
									<table border="0" width="100%">
										<tr>
											<td valign="left">
