<?php
/**
 * Plugin Name: Give - Mollie Gateway
 * Plugin URI:  https://givewp.com/addons/mollie-payment-gateway
 * Description: Allow your donors to be able to give quickly and securely with iDEAL, credit cards, bank transfers, PayPal, Belfius Direct Net, and SOFORT payments using the Mollie payment gateway.
 * Version:     1.2.4
 * Author:      GiveWP
 * Author URI:  https://givewp.com
 * Text Domain: give-mollie
 * Domain Path: /languages
 */


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Give_Mollie' ) ) {

	/**
	 * Class Give_Mollie
	 */
	class Give_Mollie {

		/**
		 * @since 1.0
		 *
		 * @var Give_Mollie The reference the singleton instance of this class.
		 */
		private static $instance;

		/**
		 * Payment gateway slug.
		 *
		 * @since 1.0
		 * @var string
		 */
		public $gateway_slug = 'mollie';

		/**
		 * Notices (array)
		 *
		 * @since 1.0
		 *
		 * @var array
		 */
		public $notices = array();


		/**
		 * Returns the singleton instance of this class.
		 *
		 * @since 1.0
		 * @return Give_Mollie The singleton instance.
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Setup Give Mollie.
		 *
		 * @since  1.0.0
		 * @access private
		 */
		private function setup() {

			// Setup constants.
			$this->setup_constants();

			// Activation and deactivation hooks.
			$this->init_hooks();

			// Give init hook.
			add_action( 'give_init', array( $this, 'init' ), 10 );
			add_action( 'admin_init', array( $this, 'check_environment' ), 999 );
			add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );
			add_action( 'give_loaded', array( $this, 'give_loaded' ), 15 );
		}

		/**
		 * Fires when Give class is loaded.
		 *
		 * @since 1.1.2
		 */
		public function give_loaded() {
			if ( ! has_action( 'activate_' . GIVE_PLUGIN_BASENAME, array( $this, 'give_mollie_install' ) ) ) {
				add_action( 'activate_' . GIVE_PLUGIN_BASENAME, array( $this, 'give_mollie_install' ), 15 );
			}
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since  1.1.1
		 */
		public function init_hooks() {
			register_activation_hook( GIVE_MOLLIE_PLUGIN_FILE, array( $this, 'give_mollie_install' ) );
		}

		/**
		 * Give-Mollie install, Upgrade.
		 *
		 * @access public
		 * @since 1.1.1
		 */
		public function give_mollie_install() {
			if ( $this->get_environment_warning() && class_exists( 'Give' ) ) {

				global $wpdb;

				$paymentmeta_table = Give()->payment_meta->table_name;

				update_option( 'give_mollie_version_upgraded_from', get_option( 'give_mollie_version', GIVE_MOLLIE_VERSION ) );
				update_option( 'give_mollie_version', GIVE_MOLLIE_VERSION );

				$payment_count = $wpdb->get_var(
					$wpdb->prepare(
						"
				SELECT count(*)
				FROM {$paymentmeta_table}
				WHERE meta_value=%s
				AND meta_key='_give_payment_gateway'
				",
						'mollie'
					)
				);

				if ( ! empty( $payment_count ) ) {
					return;
				}

				$completed_upgrades = array(
					'give_mollie_v111_price_id',
				);

				foreach ( $completed_upgrades as $completed_upgrade ) {
					give_set_upgrade_complete( $completed_upgrade );
				}
			}
		}

		/**
		 * Init the plugin after plugins_loaded so environment variables are set.
		 *
		 * @since 1.0
		 */
		public function init() {

			if ( ! $this->get_environment_warning() ) {
				return;
			}

			$this->licensing();
			$this->includes();
			$this->give_mollie_activation_banner();

			// Load pot language file.
			load_plugin_textdomain( 'give-mollie', false, GIVE_MOLLIE_PLUGIN_DIR . '/languages' );

			add_filter( 'give_recurring_available_gateways', array( $this, 'load_mollie_recurring_donations' ), 10, 1 );
		}

		/**
		 * Implement Give Licensing for Give Mollie Add On.
		 *
		 * @since  1.0.0
		 * @access private
		 */
		private function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License(
					GIVE_MOLLIE_PLUGIN_FILE,
					'Mollie Payment Gateway',
					GIVE_MOLLIE_VERSION,
					'WordImpress'
				);
			}
		}

		/**
		 * Define constants
		 *
		 * @since 1.0
		 */
		public function setup_constants() {

			/**
			 * Define constants.
			 *
			 * Required minimum versions, paths, urls, etc.
			 */
			if ( ! defined( 'GIVE_MOLLIE_VERSION' ) ) {
				define( 'GIVE_MOLLIE_VERSION', '1.2.4' );
			}
			if ( ! defined( 'GIVE_MOLLIE_MIN_GIVE_VER' ) ) {
				define( 'GIVE_MOLLIE_MIN_GIVE_VER', '2.3.0' );
			}
			if ( ! defined( 'GIVE_MOLLIE_PLUGIN_FILE' ) ) {
				define( 'GIVE_MOLLIE_PLUGIN_FILE', __FILE__ );
			}
			if ( ! defined( 'GIVE_MOLLIE_PLUGIN_DIR' ) ) {
				define( 'GIVE_MOLLIE_PLUGIN_DIR', dirname( GIVE_MOLLIE_PLUGIN_FILE ) );
			}
			if ( ! defined( 'GIVE_MOLLIE_PLUGIN_URL' ) ) {
				define( 'GIVE_MOLLIE_PLUGIN_URL', plugin_dir_url( GIVE_MOLLIE_PLUGIN_FILE ) );
			}
			if ( ! defined( 'GIVE_MOLLIE_BASENAME' ) ) {
				define( 'GIVE_MOLLIE_BASENAME', plugin_basename( GIVE_MOLLIE_PLUGIN_FILE ) );
			}
		}

		/**
		 * Include required files
		 *
		 * @since 1.0
		 */
		public function includes() {

			// Don't include if class already exists.
			if ( ! class_exists( 'Mollie_API_Autoloader' ) ) {

				/**
				 * Give Mollie API client.
				 *
				 * @version 1.9.4 API VERSION
				 * @see     https://github.com/mollie/mollie-api-php
				 */
				require_once GIVE_MOLLIE_PLUGIN_DIR . '/vendor/autoload.php';
			}

			/**
			 * Give Mollie Upgrade.
			 */
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/admin/upgrades/upgrade-functions.php';

			// Give - Mollie Helper functions.
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/class-give-mollie-api.php';

			// Include Give Mollie Web-hook handler class.
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/class-give-mollie-webhook.php';

			// Give - Mollie Helper functions.
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/give-mollie-helper.php';

			// Give - Mollie Admin class.
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/admin/class-give-mollie-admin.php';

			// Register Mollie Payment Gateway class.
			require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/class-give-mollie-gateway.php';
		}

		/**
		 * Load recurring class if Give-Recurring-Donations add-on is activate.
		 *
		 * @since  1.0
		 * @access public
		 *
		 * @param array $recurring_gateways Supported recurring gateways
		 *
		 * @return array $recurring_gateways Supported recurring gateways
		 */
		public function load_mollie_recurring_donations( $recurring_gateways ) {
			// Check if recurring donation add-on is activated.
			if ( class_exists( 'Give_Recurring_Gateway' ) ) {

				// Get recurring class.
				require_once GIVE_MOLLIE_PLUGIN_DIR . '/includes/class-give-mollie-recurring.php';

				$recurring_gateways['mollie'] = 'Give_Mollie_Recurring';
			}

			return $recurring_gateways;
		}

		/**
		 * Check plugin environment.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return bool
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/*
			 Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - Mollie to activate.', 'give-mollie' ), 'https://givewp.com' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Check plugin for Give environment.
		 *
		 * @since  1.1.2
		 * @access public
		 *
		 * @return bool
		 */
		public function get_environment_warning() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if (
				defined( 'GIVE_VERSION' )
				&& version_compare( GIVE_VERSION, GIVE_MOLLIE_MIN_GIVE_VER, '<' )
			) {

				/*
				 Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%1$s" target="_blank">Give</a> core version %2$s for the Give - Mollie add-on to activate.', 'give-mollie' ), 'https://givewp.com', GIVE_MOLLIE_MIN_GIVE_VER ) );

				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @since 1.0
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = array(
				'class'   => $class,
				'message' => $message,
			);
		}

		/**
		 * Display admin notices.
		 *
		 * @since 1.0
		 */
		public function admin_notices() {

			$allowed_tags = array(
				'a'      => array(
					'href'  => array(),
					'title' => array(),
					'class' => array(),
					'id'    => array(),
				),
				'br'     => array(),
				'em'     => array(),
				'span'   => array(
					'class' => array(),
				),
				'strong' => array(),
			);

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}

		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since 1.0
		 *
		 * @return bool
		 */
		public function give_mollie_activation_banner() {

			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {

				// Only runs on admin.
				$args = array(
					'file'              => GIVE_MOLLIE_PLUGIN_FILE,
					'name'              => __( 'Mollie Gateway', 'give-mollie' ),
					'version'           => GIVE_MOLLIE_VERSION,
					'settings_url'      => admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=mollie' ),
					'documentation_url' => 'http://docs.givewp.com/addon-mollie',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false,
				);
				new Give_Addon_Activation_Banner( $args );
			}

			return true;
		}
	}
}

/**
 * Loads a single instance of Give Mollie.
 *
 * @since   1.0
 * @see     Give_Mollie::get_instance()
 */
$GLOBALS['give_mollie'] = Give_Mollie::get_instance();
