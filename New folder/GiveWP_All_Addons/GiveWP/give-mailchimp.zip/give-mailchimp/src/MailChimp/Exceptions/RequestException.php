<?php

namespace GiveMailChimp\MailChimp\Exceptions;

/**
 * Class RequestException
 * @package GiveMailChimp\MailChimp\Exceptions
 * @since 1.5.0
 */
class RequestException extends \Exception {
	/**
	 * @var mixed
	 */
	private $errorData;

	/**
	 * RequestException constructor.
	 *
	 * @param $message
	 * @param  int  $code
	 * @param  null  $data
	 */
	public function __construct( $message, $code = 0, $data = null ) {
		parent::__construct( $message, $code );
		$this->errorData = $data;
	}

	/**
	 * @since 1.5.0
	 * @return mixed|null
	 */
	public function getErrorData() {
		return $this->errorData;
	}
}
