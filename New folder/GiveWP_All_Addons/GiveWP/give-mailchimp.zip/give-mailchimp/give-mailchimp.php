<?php
/**
 * Plugin Name: Give - MailChimp
 * Plugin URI: https://givewp.com/addons/mailchimp/
 * Description: Easily integrate MailChimp opt-ins within your Give donation forms.
 * Version: 1.5.0
 * Author: GiveWP
 * Author URI: https://givewp.com
 * Contributors: givewp
 * Text Domain: give-mailchimp
 * Domain Path: /languages
 */

use GiveMailChimp\MailChimp\ServiceProvider;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
if ( ! defined( 'GIVE_MAILCHIMP_VERSION' ) ) {
	define( 'GIVE_MAILCHIMP_VERSION', '1.5.0' );
}
if ( ! defined( 'GIVE_MAILCHIMP_MIN_GIVE_VER' ) ) {
	define( 'GIVE_MAILCHIMP_MIN_GIVE_VER', '2.10.0' );
}
if ( ! defined( 'GIVE_MAILCHIMP_STORE_API_URL' ) ) {
	define( 'GIVE_MAILCHIMP_STORE_API_URL', 'https://givewp.com' );
}
if ( ! defined( 'GIVE_MAILCHIMP_PRODUCT_NAME' ) ) {
	define( 'GIVE_MAILCHIMP_PRODUCT_NAME', 'MailChimp' );
}
if ( ! defined( 'GIVE_MAILCHIMP_ADDON_NAME' ) ) {
	define( 'GIVE_MAILCHIMP_ADDON_NAME', 'Give - MailChimp' );
}
if ( ! defined( 'GIVE_MAILCHIMP_FILE' ) ) {
	define( 'GIVE_MAILCHIMP_FILE', __FILE__ );
}
if ( ! defined( 'GIVE_MAILCHIMP_PATH' ) ) {
	define( 'GIVE_MAILCHIMP_PATH', dirname( GIVE_MAILCHIMP_FILE ) );
}
if ( ! defined( 'GIVE_MAILCHIMP_URL' ) ) {
	define( 'GIVE_MAILCHIMP_URL', plugin_dir_url( GIVE_MAILCHIMP_FILE ) );
}
if ( ! defined( 'GIVE_MAILCHIMP_BASENAME' ) ) {
	define( 'GIVE_MAILCHIMP_BASENAME', plugin_basename( GIVE_MAILCHIMP_FILE ) );
}
if ( ! defined( 'GIVE_MAILCHIMP_DIR' ) ) {
	define( 'GIVE_MAILCHIMP_DIR', plugin_dir_path( GIVE_MAILCHIMP_FILE ) );
}


if ( ! class_exists( 'Give_MailChimp' ) ) {
	/**
	 * Class Give_MailChimp
	 *
	 * @since 1.4.2
	 */
	class Give_MailChimp {

		/**
		 * @since 1.4.2
		 *
		 * @var Give_MailChimp The reference the singleton instance of this class.
		 */
		private static $instance;

		/**
		 * Notices (array)
		 *
		 * @since 1.4.2
		 *
		 * @var array
		 */
		public $notices = [];

		/**
		 * @unreleased
		 * @var array
		 */
		private $serviceProviders = [
			ServiceProvider::class,
		];

		/**
		 * Returns the singleton instance of this class.
		 *
		 * @since 1.4.2
		 * @return Give_MailChimp The singleton instance.
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Setup Give MailChimp.
		 *
		 * @since 1.4.2
		 * @access private
		 */
		private function setup() {
			// Load service providers.
			add_action( 'before_give_init', [ $this, 'registerServiceProviders' ] );

			// Give init hook.
			add_action( 'give_init', [ $this, 'init' ], 10 );
			add_action( 'admin_init', [ $this, 'check_environment' ], 999 );
			add_action( 'admin_notices', [ $this, 'admin_notices' ], 15 );
			add_action( 'give_add_email_tags', [ $this, 'add_email_tags' ], 9999999 );
		}

		/**
		 * Register service providers
		 *
		 * @since 1.4.2
		 */
		public function registerServiceProviders() {
			if ( GiveMailChimp\Infrastructure\Environment::giveMinRequiredVersionCheck() ) {
				foreach ( $this->serviceProviders as $className ) {
					give()->registerServiceProvider( $className );
				}
			}
		}

		/**
		 * Init the plugin after plugins_loaded so environment variables are set.
		 *
		 * @since 1.4.2
		 */
		public function init() {
			if ( ! $this->get_environment_warning() ) {
				return;
			}

			$this->licensing();
			$this->textdomain();
			$this->activation_banner();

			include GIVE_MAILCHIMP_PATH . '/includes/give-mailchimp-activation.php';

			if ( ! class_exists( 'Give' ) ) {
				return false;
			}

			include GIVE_MAILCHIMP_PATH . '/includes/give-mailchimp-custom-fields.php';

			if ( class_exists( 'Give_Manual_Donations' ) && is_admin() ) {
				/**
				 * Give Mailchimp helper functions for manual Donation Add-on.
				 */
				include GIVE_MAILCHIMP_PATH . '/includes/give-mailchimp-manual-donations.php';
			}

			if ( ! class_exists( 'Give_Newsletter' ) ) {
				include GIVE_MAILCHIMP_PATH . '/includes/class-give-newsletter.php';
			}

			if ( ! class_exists( 'Give_MailChimp_API' ) ) {
				include GIVE_MAILCHIMP_PATH . '/includes/class-give-mailchimp-api.php';
			}

			if ( ! class_exists( 'Give_MailChimp_Settings' ) ) {
				include GIVE_MAILCHIMP_PATH . '/includes/class-give-mailchimp.php';
			}

			/**
			 * @since 1.5.0
			 *
			 * Do not load MailChimp eCommerce logic. It is not yet fully implemented.
			 *
			 */

			// if ( ! class_exists( 'Give_MC_Ecommerce_360' ) ) {
			// 	include GIVE_MAILCHIMP_PATH . '/includes/class-give-ecommerce360.php';
			// }

			new Give_MailChimp_Settings( 'mailchimp', 'MailChimp' );

			/**
			 * @since 1.5.0
			 *
			 * Do not load MailChimp eCommerce logic. It is not yet fully implemented.
			 *
			 */
			//new Give_MC_Ecommerce_360();
		}

		/**
		 * Load the plugin's textdomain
		 *
		 * @since 1.4.2
		 */
		public function textdomain() {
			// Set filter for language directory.
			$lang_dir = GIVE_MAILCHIMP_DIR . '/languages/';
			$lang_dir = apply_filters( 'give_mailchimp_languages_directory', $lang_dir );

			// Traditional WordPress plugin locale filter.
			$locale = apply_filters( 'plugin_locale', get_locale(), 'give-mailchimp' );
			$mofile = sprintf( '%1$s-%2$s.mo', 'give-mailchimp', $locale );

			// Setup paths to current locale file.
			$mofile_local  = $lang_dir . $mofile;
			$mofile_global = WP_LANG_DIR . '/give-mailchimp/' . $mofile;

			if ( file_exists( $mofile_global ) ) {
				// Look in global /wp-content/languages/give-mailchimp/ folder.
				load_textdomain( 'give-mailchimp', $mofile_global );
			} elseif ( file_exists( $mofile_local ) ) {
				// Look in local /wp-content/plugins/give-mailchimp/languages/ folder.
				load_textdomain( 'give-mailchimp', $mofile_local );
			} else {
				// Load the default language files.
				load_plugin_textdomain( 'give-mailchimp', false, $lang_dir );
			}

			// Load the translations
			load_plugin_textdomain( 'give-mailchimp', false, GIVE_MAILCHIMP_PATH . '/languages/' );
		}

		/**
		 * Check plugin environment.
		 *
		 * @since 1.4.2
		 * @access public
		 *
		 * @return bool
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/*
			 Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice(
					'prompt_give_activate',
					'error',
					sprintf(
						__(
							'<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - MailChimp to activate.',
							'give-mailchimp'
						),
						'https://givewp.com'
					)
				);
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Check plugin for Give environment.
		 *
		 * @since 1.4.2
		 * @access public
		 *
		 * @return bool
		 */
		public function get_environment_warning() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if (
				defined( 'GIVE_VERSION' )
				&& version_compare( GIVE_VERSION, GIVE_MAILCHIMP_MIN_GIVE_VER, '<' )
			) {
				/*
				 Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice(
					'prompt_give_incompatible',
					'error',
					sprintf(
						__(
							'<strong>Activation Error:</strong> You must have the <a href="%1$s" target="_blank">Give</a> core version %2$s for the Give - MailChimp add-on to activate.',
							'give-mailchimp'
						),
						'https://givewp.com',
						GIVE_MAILCHIMP_MIN_GIVE_VER
					)
				);

				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Implement Give Licensing for Give MailChimp Add On.
		 *
		 * @since 1.4.2
		 * @access private
		 */
		private function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License(
					GIVE_MAILCHIMP_FILE,
					GIVE_MAILCHIMP_PRODUCT_NAME,
					GIVE_MAILCHIMP_VERSION,
					'WordImpress'
				);
			}
		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since 1.4.2
		 *
		 * @return bool
		 */
		public function activation_banner() {
			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {
				// Only runs on admin.
				$args = [
					'file'              => GIVE_MAILCHIMP_FILE,
					'name'              => esc_html__( 'MailChimp', 'give-mailchimp' ),
					'version'           => GIVE_MAILCHIMP_VERSION,
					'settings_url'      => admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=give-mailchimp&section=mailchimp-settings' ),
					'documentation_url' => 'http://docs.givewp.com/addon-mailchimp',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false, // Never leave true.
				];
				new Give_Addon_Activation_Banner( $args );
			}

			return true;
		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @since 1.4.2
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = [
				'class'   => $class,
				'message' => $message,
			];
		}

		/**
		 * Display admin notices.
		 *
		 * @since 1.4.2
		 */
		public function admin_notices() {
			$allowed_tags = [
				'a'      => [
					'href'  => [],
					'title' => [],
					'class' => [],
					'id'    => [],
				],
				'br'     => [],
				'em'     => [],
				'span'   => [
					'class' => [],
				],
				'strong' => [],
			];

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}
		}

		/**
		 *  Register Email Tag
		 *
		 * @since 1.4.2
		 */
		public function add_email_tags() {
			// Adds an email tag called {give_mailchimp_status} to indicate whether the donor opted in or not.
			give_add_email_tag(
				[
					'tag'      => 'give_mailchimp_status',
					// The tag name.
					'desc'     => __( 'This outputs whether the donor opted-in to the Newsletter', 'give-mailchimp' ),
					// For admins.
					'func'     => [ $this, 'render_give_mailchimp_status_email_tag' ],
					// Callback to function below.
					'context'  => 'donation',
					'is_admin' => false,
					// default is false. This is here to simply display it as an option.
				]
			);
		}

		/**
		 * Render give_mailchimp_status email tag
		 *
		 * @since 1.4.2
		 *
		 * @param  array  $tag_args  Array of arguments
		 *
		 * @return string
		 */
		public function render_give_mailchimp_status_email_tag( $tag_args ) {
			$opt_in_meta = give_get_meta( $tag_args['payment_id'], '_give_mc_donation_optin_status', true );
			$output      = __( 'Did not subscribe to newsletter', 'give-mailchimp' );

			if ( ! empty( $opt_in_meta ) ) {
				$output = __( 'Subscribed to newsletter', 'give-mailchimp' );
			}

			/**
			 * Filter is used change outputs whether the donor opted-in to the Newsletter.
			 *
			 * @since 1.4.2
			 *
			 * @param  string  $output  string whether the donor opted-in to the Newsletter.
			 */
			return apply_filters( 'give_email_tag_give_mailchimp_status', $output, $tag_args );
		}
	}

	/**
	 * Returns class object instance.
	 *
	 * @since 1.4.2
	 *
	 * @return Give_MailChimp bool|object
	 */
	function Give_MailChimp() {
		return Give_MailChimp::get_instance();
	}

	Give_MailChimp();
}

require_once GIVE_MAILCHIMP_DIR . 'vendor/autoload.php';

