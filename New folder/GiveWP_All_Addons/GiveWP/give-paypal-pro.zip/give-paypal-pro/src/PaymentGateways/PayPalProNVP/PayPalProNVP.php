<?php
namespace GivePayPalPro\PaymentGateways\PayPalProNVP;

use Give\PaymentGateways\PaymentGateway;

/**
 * Class PayPalProNVP
 * @package GivePayPalPro\PaymentGateways\PayPalProNVM
 *
 * @since 1.2.3
 */
class PayPalProNVP implements PaymentGateway {
	const GATEWAY_ID = 'paypalpro';

	/**
	 * @inheritDoc
	 */
	public function getId() {
		return self::GATEWAY_ID;
	}

	/**
	 * @inheritDoc
	 */
	public function getName() {
		return esc_html__( 'PayPal Website Payments Pro (NVP API)', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getPaymentMethodLabel() {
		return esc_html__( 'Credit Card', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getOptions() {
		return [
			[
				'id'   => 'give_title_paypal_pro_nvp',
				'type' => 'title',
				'desc' => '<p style="padding: 15px;border-radius: 5px;border: 1px solid #7e8993;margin-top: 2em;">' . sprintf( __( 'This gateway supports single donations, and recurring donations for accounts which have DPRP enabled. To enable DPRP on your account you have to contact PayPal Support directly. <a href="%s" target="_blank">Learn</a> which account type you currently have.', 'give-paypal-pro' ), 'http://docs.givewp.com/add-on-paypal-nvp' ) . '</p>',
			],
			[
				'id'   => 'live_paypal_api_username',
				'name' => esc_html__( 'Live API Username', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your live API username', 'give-paypal-pro' ),
				'type' => 'text',
				'size' => 'regular',
			],
			[
				'id'   => 'live_paypal_api_password',
				'name' => esc_html__( 'Live API Password', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your live API password', 'give-paypal-pro' ),
				'type' => 'password',
			],
			[
				'id'   => 'live_paypal_api_signature',
				'name' => esc_html__( 'Live API Signature', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your live API signature', 'give-paypal-pro' ),
				'type' => 'api_key',
			],
			[
				'id'   => 'test_paypal_api_username',
				'name' => esc_html__( 'Test API Username', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your test API username', 'give-paypal-pro' ),
				'type' => 'text',
			],
			[
				'id'   => 'test_paypal_api_password',
				'name' => esc_html__( 'Test API Password', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your test API password', 'give-paypal-pro' ),
				'type' => 'password',
			],
			[
				'id'   => 'test_paypal_api_signature',
				'name' => esc_html__( 'Test API Signature', 'give-paypal-pro' ),
				'desc' => esc_html__( 'Enter your test API signature', 'give-paypal-pro' ),
				'type' => 'api_key',
			],
			[
				'id'   => 'paypal_classic_collect_billing',
				'name' => esc_html__( 'Collect Billing Details', 'give-paypal-pro' ),
				'desc' => sprintf( esc_html__( 'This option will enable the billing details section for PayPal which requires the donor\'s address to complete the donation. These fields are not required by PayPal to process the transaction, but you may have the need to collect the data.', 'give-paypal-pro' ) ),
				'type' => 'checkbox',
			],
			[
				'id'      => 'paypal_nvp_invoice_prefix',
				'name'    => esc_html__( 'Invoice ID Prefix', 'give-paypal-pro' ),
				'desc'    => esc_html__( 'Please enter a prefix for your invoice numbers. If you use your PayPal account for multiple stores ensure this prefix is unique as PayPal will not allow orders with the same invoice number.', 'give-paypal-pro' ),
				'type'    => 'text',
				'default' => 'GIVE-',
			],
			[
				'id'   => 'give_title_paypal_pro_nvp',
				'type' => 'sectionend',
			],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function boot() {}
}
