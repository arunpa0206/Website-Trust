/**
 * Give Tributes Admin JS.
 */
var Give_Tribute;

jQuery( document ).ready( function( $ ) {

	var $body = $( 'body' ),
		give_tributes_enable_disable = $( 'input[name="give_tributes_enable_disable"]:radio' ),
		give_tributes_prepended_label_enable_disable = $( 'input[name="give_tributes_prepended_label_enable_disable"]:radio' ),
		give_tributes_card_creation_fields = $( '.give_tributes_card_creation_fields' ),
		give_tribute_fields = $( '.give_tributes_fields' ),
		give_tribute_admin_mailed = $( '.give_tribute_admin_mailed' ),
		give_tribute_donor_mailed = $( '.give_tribute_donor_mailed' ),
		card_mailed_email_fields = $( '.card_mailed_email_fields' ),
		give_tributes_ecard_fields = $( '.give_tributes_ecard_fields' ),
		give_tributes_prepended_wrap = $( '.give_tributes_prepended_wrap' ),
		give_tributes_who_sends_the_card_enable_disable = $( 'input[name="give_tributes_who_sends_the_card"]:radio' ),
		give_tributes_custom_message_change = $( 'input[name="give_tributes_custom_message_enable_disable"]:radio' ),
		give_tributes_card_mailed_change = $( 'input[name="give_tributes_card_mailed_email_enable_disable"]:radio' ),
		give_tributes_card_creation_enable_disable = $( 'input[name="give_tributes_card_creation_enable_disable"]:radio' ),
		give_tributes_ecards_enable_disable = $( 'input[name="give_tributes_ecards_enable_disable"]:radio' ),
		give_tributes_ecards_custom_message_enable_disable = $( 'input[name="give_tributes_ecards_custom_message_enable_disable"]:radio' ),
		give_tributes_notify_display_option = $( 'input[name="give_tributes_notify_display_option"]:radio, input[name="_give_tributes_per_form_notify_display_option"]:radio' );

	/**
	 *  Sortable tribute lists.
	 */
	var $tribute_lists = $('.give-tribute-options-wrap ul.give-tribute-option-list');
	if ($tribute_lists.length) {
		$tribute_lists.sortable();
	}

	/**
	 * Insert Tribute option and remove old.
	 */
	$( document ).on( 'give_md_check_form_setup', function( e ) {
		var manual_donation_form = $( '#give_md_create_payment' );

		jQuery( manual_donation_form.find( 'tr.give-tributes-row' ) ).each( function( i, em ) {
			$( this ).remove();
		} );

		$( e.response.tribute_html ).insertAfter( manual_donation_form.find( '#give-md-date' ).closest( '.form-field' ) );

		Give_Tribute.init();
	} );

	/**
	 * JS update logic - Handle when change the value of 'Globally Enabled' value.
	 */
	give_tributes_enable_disable.on( 'change', function() {

		var value = $( 'input[name="give_tributes_enable_disable"]:radio:checked' ).val();

		if ( value === 'enabled' ) {
			give_tribute_fields.show();
			give_tributes_notify_display_option.change();
		} else {
			give_tribute_fields.hide();
		}

	} ).change();

	/**
	 * Show/Hide Prepended Label.
	 */
	give_tributes_prepended_label_enable_disable.on( 'change', function() {

		var value = $( 'input[name="give_tributes_enable_disable"]:radio:checked' ).val(),
			give_tributes_prepended_label_value = $( 'input[name="give_tributes_prepended_label_enable_disable"]:radio:checked' ).val();

		// Bail out, If Tribute is disabled.
		if ( value !== 'enabled' ) {
			return false;
		}

		if ( give_tributes_prepended_label_value === 'enabled' ) {
			give_tributes_prepended_wrap.show();
		} else {
			give_tributes_prepended_wrap.hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle when change the value of 'Mail a card' value enabled or not.
	 */
	give_tributes_who_sends_the_card_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="give_tributes_who_sends_the_card"]:radio:checked' ).val();

		// If enable show other fields.
		if ( value === 'the_admin' ) {

			give_tribute_admin_mailed.show();
			give_tribute_donor_mailed.hide();
			give_tributes_card_mailed_change.change();

		} else {
			// Otherwise, hide rest of fields.
			give_tribute_admin_mailed.hide();
			give_tribute_donor_mailed.show();
			give_tributes_card_creation_enable_disable.change();
		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Mail a card message' change event.
	 */
	give_tributes_custom_message_change.on( 'change', function() {

		// Get the value of checked radio button value of Mail a card custom message enabled/disabled.
		var value = $( '.give-forminp input[name="give_tributes_custom_message_enable_disable"]:radio:checked' ).val();

		if ( value === 'enabled' ) {
			$( '.give_tributes_message_length' ).show();
		} else {
			$( '.give_tributes_message_length' ).hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Mail a card creation' change event.
	 */
	give_tributes_card_creation_enable_disable.on( 'change', function() {

		var give_tributes_who_sends_the_card_value = $( 'input[name="give_tributes_who_sends_the_card"]:radio:checked' ).val();

		// Return if Who Sends the Card is not The Donor.
		if ( give_tributes_who_sends_the_card_value !== 'the_donor' ) {
			return false;
		}

		var value = $( '.give-forminp input[name="give_tributes_card_creation_enable_disable"]:radio:checked' ).val();

		if ( value === 'enabled' ) {
			give_tributes_card_creation_fields.show();
			give_tributes_card_mailed_change.change();

		} else {
			give_tributes_card_creation_fields.hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Card Mailed Email' change event.
	 */
	give_tributes_card_mailed_change.on( 'change', function() {

		var give_tributes_who_sends_the_card_value = $( 'input[name="give_tributes_who_sends_the_card"]:radio:checked' ).val();

		// Return if Who Sends the Card is not The Admin.
		if ( give_tributes_who_sends_the_card_value !== 'the_admin' ) {
			return false;
		}

		// Get the value of checked radio button of card mailed email.
		var value = $( '.give-forminp input[name="give_tributes_card_mailed_email_enable_disable"]:radio:checked' ).val();

		if ( value === 'enabled' ) {
			card_mailed_email_fields.show();
		} else {
			card_mailed_email_fields.hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle when change the value of 'eCard' value enabled or not.
	 */
	give_tributes_ecards_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="give_tributes_ecards_enable_disable"]:radio:checked' ).val();

		// If enable show other fields.
		if ( value === 'enabled' ) {
			give_tributes_ecard_fields.show();
			give_tributes_ecards_custom_message_enable_disable.change();

		} else {
			// Otherwise, hide rest of fields.
			give_tributes_ecard_fields.hide();

		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Mail a card message' change event.
	 */
	give_tributes_ecards_custom_message_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of Give Tribute Custom message enable/disable.
		var value = $( '.give-forminp input[name="give_tributes_ecards_custom_message_enable_disable"]:radio:checked' ).val();

		if ( value === 'enabled' ) {
			$( '.give_tributes_ecards_message_length' ).show();
		} else {
			$( '.give_tributes_ecards_message_length' ).hide();
		}

	} ).change();

	/**
	 * JS for Notify the honoree option in Give Tributes admin setting.
	 */
	give_tributes_notify_display_option.on( 'change', function() {

		var is_tribute_enabled = $( 'input[name="_give_tributes_per_form_enable_disable"]:radio:checked' ).val(),
			is_tribute_global_enabled = $( 'input[name="give_tributes_enable_disable"]:radio:checked' ).val(),
			notify_option = '';

		if ( ! $( '.give-settings-page' ).is( ':visible' ) ) {

			// Return false, if the tribute is not active.
			if ( is_tribute_enabled !== 'enabled' )
				return false;

			// Get the notification methods list.
			notify_option = $( 'input[name="_give_tributes_per_form_notify_display_option"]:radio:checked' ).val();

		} else {
			// Return false, if the tribute is not active.
			if ( is_tribute_global_enabled !== 'enabled' )
				return false;

			// Get the notification methods list.
			notify_option = $( 'input[name="give_tributes_notify_display_option"]:radio:checked' ).val();
		}

		var notify_lists = $( this ).parents().find( '.give_tribute_notify_method_lists' );

		// If it's not admin choice then, hide it.
		notify_option !== 'admin_choice' ? notify_lists.hide() : notify_lists.show();

	} ).change();

	// Give Tribute text option length.
	var give_tribute_text_length = $( 'table.give-setting-tab-body-tributes-text' ).find( 'tr.give_tributes_text' ).length - 1;

	/**
	 *  Give Tribute text Add more script.
	 */
	$body.on( 'click', '.give-tribute-text-add-more', function() {
		var $this = $( this ),
			last_field = $this.closest( 'ul.give-tribute-option-list' ).find( 'li.give_tributes_text' ).last().find( 'input.give-tribute-input-field' );

		if ( $.trim( last_field.val() ) ) {
			give_tribute_text_length ++;

			var give_tribute_html = '<li class="give_tributes_text" id="give_tribute_text_option_' + give_tribute_text_length + '">' + '<span class="give-drag-handle"><span class="dashicons dashicons-menu"></span></span>' + '<div class="titledesc give-tribute-option-title"><span for="give_tributes_text">' + give_tributes_admin_message.give_tributes_text_label + '</span></div>' +
				'<input name="give_tributes_text[]" id="give_tributes_text_' + give_tribute_text_length + '" type="text" style="" value="" class="give-tribute-input-field"><span style="margin-left: 8px;" class="dashicons dashicons-trash"></span><span style="margin-left: 4px;" class="dashicons dashicons-plus give-tribute-text-add-more"></span>' +
				'</li>';

			$( give_tribute_html ).insertAfter( 'div.give-tribute-options-wrap ul li:last' );
		}

		return false;

	} );

	/**
	 *  Give Tribute remove text script.
	 */
	$body.on( 'click', 'div.give-tribute-options-wrap li.give_tributes_text span.dashicons.dashicons-trash', function() {
		$( this ).parent().remove();
	} );

	var $tab_links = $( '.give-metabox-tabs a' );
	$( 'ul.give-metabox-sub-tabs li.give-tributes-metabox-setting-fields_sub_fields_general_tab' ).hide();

	/**
	 *  Give Tribute: Hide Tribute tab in Meta box tab.
	 */
	$tab_links.on( 'click', function( e ) {
		e.preventDefault();

		// Hide all tab contents.
		$( '.give_options_panel' ).addClass( 'give-hidden' );

		$( $( this ).attr( 'href' ) ).removeClass( 'give-hidden' );
		return false;
	} );

	var _give_tributes_per_form_enable_disable = $( 'input[name="_give_tributes_per_form_enable_disable"]:radio' ),
		_give_tributes_per_form_prepended_label_enable_disable = $( 'input[name="_give_tributes_per_form_prepended_label_enable_disable"]:radio' ),
		_give_tributes_per_form_mail_a_card_enable_disable = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio' ),
		_give_tributes_per_form_custom_message_enable_disable = $( 'input[name="_give_tributes_per_form_custom_message_enable_disable"]:radio' ),
		_give_tributes_per_form_card_mailed_email_enable_disable = $( 'input[name="_give_tributes_per_form_card_mailed_email_enable_disable"]:radio' ),
		_give_tributes_per_form_card_creation_enable_disable = $( 'input[name="_give_tributes_per_form_card_creation_enable_disable"]:radio' ),
		_give_tributes_per_form_who_sends_the_card_enable_disable = $( 'input[name="_give_tributes_per_form_who_sends_the_card"]:radio' ),
		_give_tributes_per_form_ecards_enable_disable = $( 'input[name="_give_tributes_per_form_ecards_enable_disable"]:radio' ),
		_give_tributes_per_form_ecards_custom_message_enable_disable = $( 'input[name="_give_tributes_per_form_ecards_custom_message_enable_disable"]:radio' );

	/**
	 * JS update logic - Handle when change the value of 'Per-Form Tribute Settings' value.
	 */
	_give_tributes_per_form_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="_give_tributes_per_form_enable_disable"]:radio:checked' ).val();

		// If enable show other fields.
		if ( value === 'enabled' ) {

			give_tribute_fields.show();
			$( '#_give_tributes_per_form__repeater_field' ).show();
			$( 'ul.give-metabox-sub-tabs li.give-tributes-metabox-setting-fields_sub_fields_mail_card_tab' ).show();
			$( 'ul.give-metabox-sub-tabs li.give-tributes-metabox-setting-fields_sub_fields_ecard_tab' ).show();
			give_tributes_notify_display_option.change();

		} else {
			give_tribute_fields.hide();
			$( '#_give_tributes_per_form__repeater_field' ).hide();
			$( 'ul.give-metabox-sub-tabs li.give-tributes-metabox-setting-fields_sub_fields_mail_card_tab' ).hide();
			$( 'ul.give-metabox-sub-tabs li.give-tributes-metabox-setting-fields_sub_fields_ecard_tab' ).hide();
		}

	} ).change();

	/**
	 * Show/hide Per Form Prepended label.
	 */
	_give_tributes_per_form_prepended_label_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="_give_tributes_per_form_enable_disable"]:radio:checked' ).val(),
			give_tributes_per_form_prepended_label_enable_disable_value = $( 'input[name="_give_tributes_per_form_prepended_label_enable_disable"]:radio:checked' ).val();

		if ( value !== 'enabled' ) {
			return false;
		}

		// If enable show other fields.
		if ( give_tributes_per_form_prepended_label_enable_disable_value === 'enabled' ) {
			$( '#_give_tributes_per_form__repeater_field' ).show();
			give_tributes_prepended_wrap.show();

		} else {
			// Otherwise, hide rest of fields.
			give_tributes_prepended_wrap.hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle when change the value of 'Per-Form Mail a card' value enabled or not.
	 */
	_give_tributes_per_form_mail_a_card_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio:checked' ).val();

		// Bail out, if Tribute option is disabled.
		if ( value === 'enabled' ) {

			$( '.mail_a_card_wrapper' ).show();

			_give_tributes_per_form_custom_message_enable_disable.change();
			_give_tributes_per_form_who_sends_the_card_enable_disable.change();

		} else {
			// Otherwise, hide rest of fields.
			$( '.mail_a_card_wrapper' ).hide();

		}

	} ).change();

	/**
	 * JS update logic - Handle 'Who Sends the Card' change event.
	 */
	_give_tributes_per_form_who_sends_the_card_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of Mail a Card.
		var _give_tributes_per_form_mail_a_card_enable_disable = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio:checked' ).val(),
			value = $( 'input[name="_give_tributes_per_form_who_sends_the_card"]:radio:checked' ).val();

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_mail_a_card_enable_disable !== 'enabled' ) {
			return false;
		}

		if ( value === 'the_admin' ) {

			give_tribute_admin_mailed.show();
			give_tribute_donor_mailed.hide();
			_give_tributes_per_form_card_mailed_email_enable_disable.change();

		} else {
			// Otherwise, hide rest of fields.
			give_tribute_admin_mailed.hide();
			give_tribute_donor_mailed.show();
			_give_tributes_per_form_card_creation_enable_disable.change();
		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Mail a card message' change event.
	 */
	_give_tributes_per_form_custom_message_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of Mail a Card.
		var _give_tributes_per_form_mail_a_card_enable_disable = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio:checked' ).val(),
			value = $( 'input[name="_give_tributes_per_form_custom_message_enable_disable"]:radio:checked' ).val();

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_mail_a_card_enable_disable !== 'enabled' ) {
			return false;
		}

		if ( value === 'enabled' ) {
			$( '._give_tributes_per_form_message_length_field' ).show();
			_give_tributes_per_form_card_creation_enable_disable.change();
		} else {
			$( '._give_tributes_per_form_message_length_field' ).hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute Mail a card creation' change event.
	 */
	_give_tributes_per_form_card_creation_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of Mail a Card.
		var _give_tributes_per_form_mail_a_card_enable_disable = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio:checked' ).val(),
			_give_tributes_per_form_who_sends_the_card_value = $( 'input[name="_give_tributes_per_form_who_sends_the_card"]:radio:checked' ).val(),
			value = $( 'input[name="_give_tributes_per_form_card_creation_enable_disable"]:radio:checked' ).val();

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_mail_a_card_enable_disable !== 'enabled' ) {
			return false;
		}

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_who_sends_the_card_value !== 'the_donor' ) {
			return false;
		}

		if ( value === 'enabled' ) {
			give_tributes_card_creation_fields.show();
			_give_tributes_per_form_card_mailed_email_enable_disable.change();

		} else {
			give_tributes_card_creation_fields.hide();

		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute card sent' change event.
	 */
	_give_tributes_per_form_card_mailed_email_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of Mail a Card.
		var _give_tributes_per_form_mail_a_card_enable_disable = $( 'input[name="_give_tributes_per_form_mail_a_card_enable_disable"]:radio:checked' ).val(),
			_give_tributes_per_form_who_sends_the_card_value = $( 'input[name="_give_tributes_per_form_who_sends_the_card"]:radio:checked' ).val(),
			value = $( 'input[name="_give_tributes_per_form_card_mailed_email_enable_disable"]:radio:checked' ).val();

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_mail_a_card_enable_disable !== 'enabled' ) {
			return false;
		}

		// Return if Mail a card option is disable.
		if ( _give_tributes_per_form_who_sends_the_card_value !== 'the_admin' ) {
			return false;
		}

		if ( value === 'enabled' ) {
			card_mailed_email_fields.show();
		} else {
			card_mailed_email_fields.hide();
		}

	} ).change();

	/**
	 * JS update logic - Handle when change the value of 'Per-Form eCard' value enabled or not.
	 */
	_give_tributes_per_form_ecards_enable_disable.on( 'change', function() {

		// Get the value of checked radio button.
		var value = $( 'input[name="_give_tributes_per_form_ecards_enable_disable"]:radio:checked' ).val();

		// If enable show other fields.
		if ( value === 'enabled' ) {

			give_tributes_ecard_fields.show();

			_give_tributes_per_form_ecards_custom_message_enable_disable.change();

		} else {
			// Otherwise, hide rest of fields.
			give_tributes_ecard_fields.hide();

		}

	} ).change();

	/**
	 * JS update logic - Handle 'Tribute eCard message' change event.
	 */
	_give_tributes_per_form_ecards_custom_message_enable_disable.on( 'change', function() {

		// Get the value of checked radio button value of eCard.
		var _give_tributes_per_form_ecards_enable_disable = $( 'input[name="_give_tributes_per_form_ecards_enable_disable"]:radio:checked' ).val(),
			value = $( 'input[name="_give_tributes_per_form_ecards_custom_message_enable_disable"]:radio:checked' ).val();

		// Return if eCard option is disable.
		if ( _give_tributes_per_form_ecards_enable_disable !== 'enabled' ) {
			return false;
		}

		if ( value === 'enabled' ) {
			$( '._give_tributes_per_form_ecards_message_length_field' ).show();
		} else {
			$( '._give_tributes_per_form_ecards_message_length_field' ).hide();
		}

	} ).change();

	/**
	 * JS logic - Mail a Card sent.
	 */
	$body.on( 'click', '.give_tribute_card_sent', function() {

		var payment_id = $( this ).attr( 'id' ),
			card_sent_td = $( this ).parent(),
			card_sent = false,
			card_confirm = false,
			card_mailed_enabled_class = 'card_mailed_disabled';

		if ( $( this ).hasClass( 'card_mailed_enabled' ) ) {
			card_mailed_enabled_class = 'card_mailed_enabled';

			if ( confirm( give_tributes_admin_message.mail_card_confirm_message ) ) {

				card_confirm = true; // Set Card confirm as true.

				if ( confirm( give_tributes_admin_message.mail_card_with_notification ) ) {
					card_sent = true;  // Set Card sent as true for sent notification.
				}
			}
		} else {

			if ( confirm( give_tributes_admin_message.mail_card_confirm_message ) ) {
				card_confirm = true;  // Set Card confirm as true.
			}
		}

		// Do Ajax call if Card Confirmation true.
		if ( card_confirm ) {

			$.ajax( {
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'give_tributes_sent_mail_card',
					payment_id: payment_id,
                    card_sent: card_sent,
                    security: give_tributes_js_data.ajaxNonce,
				},
				success: function( response ) {

					if ( 'card_sent_success' === response ) {
						var notice_html = '<div id="setting-error-give-tribute-ecard-sent" class="give-notice settings-error notice is-dismissible updated" style="display: block;"><p><strong>' + give_tributes_admin_message.mail_card_notification_success + '</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">' + give_tributes_admin_message.dismiss_notice_text + '</span></button></div>';
					} else {
						notice_html = '<div id="setting-error-give-tribute-ecard-sent" class="give-notice settings-error notice is-dismissible updated" style="display: block;"><p><strong>' + give_tributes_admin_message.mail_card_marked_success + '</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">' + give_tributes_admin_message.dismiss_notice_text + '</span></button></div>';
					}

					$( '#setting-error-give-tribute-ecard-sent' ).hide();
					$( '#setting-error-give-tribute-ecard-resent' ).hide();
					$( 'h2' ).after( notice_html );
					$( 'h1#transaction-details-heading' ).after( notice_html );
					card_sent_td.html( '' );
					card_sent_td.append( '<span class="card-sent-text-wrap">' + give_tributes_admin_message.mail_card_sent_text + ' -' + '</span>' + ' <a href="javascript:void(0);" class="give_tribute_card_sent_undo card_sent_undo_' + payment_id + ' ' + card_mailed_enabled_class + '" id="' + payment_id + '">' + give_tributes_admin_message.mail_card_undo_text + '</a>' );

				}

			} );

		}

	} );

	/**
	 * JS logic - Show dialogue for sending notification emails.
	 */
	$body.on( 'click', '.give_tributes_ecard_resend, .give_tributes_ecard_preview', function(e) {

		// Get the render type.
		var render_type = $( this ).data( 'render' );

		if ( 'enabled' !== $(this).data('multiple_recipients') ) {

			if ( 'resend' === render_type ) {
				if ( confirm( give_tributes_admin_message.ecards_resends_confirm_message + ' ' + $(this).data('email') + '?' ) ) {
					return true;
				}
				return false;

			} else if ( 'preview' === render_type ) {
				return true;
			}

		}
		e.preventDefault();

		var payment_id = $(this).attr('id'),
			popup = $( this ).closest( '.give-tributes-ecard-options-wrap, .ecard_options' ).find( ".give-tributes-popup#notification_payment-" + payment_id + "[data-popuptype=" + render_type + "]" ),
			overlay = $( ".give-tributes-popup-backdark" );

		if ( ! popup.is(':visible' ) ) {
			overlay.show();
			popup.show();
		}else{
			overlay.hide();
			popup.hide();
		}

	});

	/**
	 * Close Give Tribute 'resend' or 'preview' popup.
	 */
	$('.give-tributes-popup-btn-close').click(function(e){

		// Removed checked checkboxes.
		$('.give-tributes-popup').find('input[type=checkbox]:checked').removeAttr('checked');

		$('.give-tributes-popup').hide();
		$(".give-tributes-popup-backdark").hide();
	});

	/**
	 * Send eCard emails.
	 */
	$( '.tribute-ecard-btn' ).on( 'click', function ( e ) {

		// Store selector.
		var $this = $( this );

		// if the button has disabled, return false.
		if ( $this.hasClass( 'disabled' ) ) {
			return false;
		}

		// Disabled the button.
		$this.addClass( 'disabled' );

		var user_lists_container = $this.closest( '.give-tributes-user-lists' ),
			payment_id = user_lists_container.find( 'input.give_tributes_payment_id' ).val(),
			is_edit_page = user_lists_container.find( 'input.is_edit_page' ).val(),
			action = $( this ).data( 'action' );

		// For resend action.
		if ( 'resend' === action ) {

			var emails = user_lists_container.find( 'input[name="give-tributes-notify-users[]"]:checked' );

			// Store emails.
			var selected_emails = [];

			// Get all the selected emails.
			$.each( emails, function () {

				// Collect email.
				selected_emails.push( $( this ).val() );
			} );

			// If no option were selected.
			if ( selected_emails.length <= 0 ) {

				alert( give_tributes_admin_message.ecards_option_is_not_selected );

				// Re-activate the button.
				$this.removeClass( 'disabled' );
				return false;
			}

			// Ajax Request for sending emails.
			$.post( ajaxurl, {
				'emails': selected_emails,
				'action': 'give_tributes_resend_ecards',
				'nonce': give_tributes_js_data.resend_ecards_nonce,
				'payment_id': payment_id,
				'is_edit_page': is_edit_page
			}, function ( res ) {

				// If email sent successfully.
				if ( 'success' === res.result ) {

					// Redirect to success page.
					window.location = res.redirect;

					// Close popup.
					$( '.give-tributes-popup .give-tributes-popup-btn-close' ).trigger( 'click' );
				}
			} );

		} else if ( 'preview' === action ) {

			// Get the email from selected radio input.
			var email = user_lists_container.find( 'input.give-tributes-preview-user:checked' ).val();

			// If no option were selected.
			if ( '' === email || undefined === email ) {

				alert( give_tributes_admin_message.ecards_option_is_not_selected );

				// Re-activate the button.
				$this.removeClass( 'disabled' );
				return false;
			}

			// Generate the preview eCards url.
			var preview_url = give_tributes_js_data.ecard_preview_url.replace( '%payment_id%', payment_id ).replace( '%email%', email );

			// If preview URL is not blank.
			if ( preview_url ) {

				$this.removeClass( 'disabled' );
				$this.closest('.give-tributes-popup').find( '.give-tributes-popup-btn-close' ).trigger( 'click' );

				// Redirect user to preview URL.
				window.open( preview_url );
			}

		}

	} );

	/**
	 * JS logic - Mail a Card sent Undo.
	 */
	$body.on( 'click', '.give_tribute_card_sent_undo', function() {

		var payment_id = $( this ).attr( 'id' ),
			card_sent_td = $( this ).parent(),
			card_confirm = false,
			card_mailed_enabled_class = 'card_mailed_disabled';

		if ( $( this ).hasClass( 'card_mailed_enabled' ) ) {
			card_mailed_enabled_class = 'card_mailed_enabled';
		}

		if ( confirm( give_tributes_admin_message.mail_card_undo_message ) ) {

			card_confirm = true; // Set Card confirm as true.
		}

		// Do undo Card sent Ajax call if Card Confirmation true.
		if ( card_confirm ) {

			$.ajax( {
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'give_tributes_undo_sent_mail_card',
                    payment_id: payment_id,
                    security: give_tributes_js_data.ajaxNonce,
				},
				success: function() {

					var notice_html = '<div id="setting-error-give-tribute-ecard-sent" class="give-notice settings-error notice is-dismissible updated" style="display: block;"><p><strong>' + give_tributes_admin_message.mail_card_undo_success + '</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">' + give_tributes_admin_message.dismiss_notice_text + '</span></button></div>';

					$( '#setting-error-give-tribute-ecard-sent' ).hide();
					$( '#setting-error-give-tribute-ecard-resent' ).hide();
					$( 'h2' ).after( notice_html );
					$( 'h1#transaction-details-heading' ).after( notice_html );
					card_sent_td.html( '' );
					card_sent_td.append( '<a href="javascript:void(0);" class="button give-admin-button give_tribute_card_sent card_sent_' + payment_id + ' ' + card_mailed_enabled_class + '" id="' + payment_id + '"><span class="dashicons dashicons-email-alt"></span>' + ' ' + give_tributes_admin_message.mail_card_mark_as_sent + '</a>' );

				}
			} );
		}

	} );

	/**
	 *  Js logic - remove dismiss ajax notice.
	 */
	$body.on( 'click', '.notice-dismiss', function() {
		$( this ).parent().slideUp( 'fast' );
	} );

} );