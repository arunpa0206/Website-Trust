<?php
/**
 * General Action Hooks
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Print cc field in donation form conditionally.
 *
 * @param int $form_id Donation Form ID.
 *
 * @since 1.0
 *
 * @return bool
 */
function give_payfast_cc_form_callback( $form_id ) {

	if ( give_is_setting_enabled( give_get_option( 'payfast_billing_details' ) ) ) {
		give_default_cc_address_fields( $form_id );
		return true;
	}

	return false;
}

add_action( 'give_payfast_cc_form', 'give_payfast_cc_form_callback' );


/**
 * Auto set pending payment to abandoned.
 *
 * @since 1.0
 *
 * @param int $payment_id
 */
function give_payfast_set_donation_abandoned_callback( $payment_id ) {
	/**
	 * @var Give_Payment $payment Payment object.
	 */
	$payment = new Give_Payment( $payment_id );

	if ( 'pending' === $payment->status ) {
		$payment->update_status( 'abandoned' );
	}
}

add_action( 'give_payfast_set_donation_abandoned', 'give_payfast_set_donation_abandoned_callback' );


/**
 * Register Give PayFast Gateway Admin Notices.
 *
 * @since  1.0
 */
function give_payfast_show_admin_notice() {

	// Bailout, if not admin.
	if ( ! is_admin() ) {
		return;
	}

	// Show PayFast notice, if currency is not set as "South African Rand (R)".
	if (
		current_user_can( 'manage_give_settings' ) &&
		'ZAR' !== give_get_currency() &&
		! class_exists( 'Give_Currency_Switcher' ) // Disable Notice, if Currency Switcher add-on is enabled.
	) {
		Give()->notices->register_notice( array(
			'id'          => 'give-payfast-currency-notice',
			'type'        => 'error',
			'dismissible' => false,
			'description' => sprintf(
				__( 'The currency must be set as "South African Rand (R)" within Give\'s <a href="%s">Currency Settings</a> in order to collect donations through the PayFast Payment Gateway.', 'give-payfast' ),
				admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=general&section=currency-settings' )
			),
			'show'        => true,
		) );
	}

}

add_action( 'admin_notices', 'give_payfast_show_admin_notice' );
