<?php
/**
 * Give Tribute Donations Report Table Class.
 *
 * @package     Give_Tributes
 * @subpackage  Give_Tributes/admin
 * @since       1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded.
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Give_Tributes_Donations_Reports_Table Class
 *
 * Renders the Tribute Donations Report table.
 *
 * @since 1.0
 */
class Give_Tributes_Donations_Reports_Table extends WP_List_Table {

	/**
	 * Number of items per page.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $per_page = 30;

	/**
	 * Number of items found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $count = 0;

	/**
	 * Total items.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $total = 0;

	/**
	 * Get things started.
	 *
	 * @since 1.0.0
	 * @see   WP_List_Table::__construct()
	 */
	public function __construct() {

		// Set parent defaults.
		parent::__construct( array(
			'singular' => __( 'Tribute Donation', 'give-tributes' ),     // Singular name of the listed records.
			'plural'   => __( 'Tribute Donations', 'give-tributes' ),    // Plural name of the listed records.
			'ajax'     => false,// Does this table support ajax?
		) );

	}

	/**
	 * Remove default search field in favor for repositioned location.
	 *
	 * Reposition the search field.
	 *
	 * @since       1.0.0
	 * @access      public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return false
	 */
	public function search_box( $text, $input_id ) {
		return false;
	}

	/**
	 * Show the search field.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return void
	 */
	public function give_search_box( $text, $input_id ) {
		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['order'] ) ) {
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
		}
		?>
		<p class="search-box donor-search" role="search">
			<label class="screen-reader-text" for="<?php echo $input_id ?>"><?php echo $text; ?>:</label>
			<input type="search" id="<?php echo $input_id ?>" name="s" value="<?php _admin_search_query(); ?>"/>
			<?php submit_button( $text, 'button', false, false, array( 'ID' => 'search-submit' ) ); ?>
		</p>
		<?php
	}

	/**
	 * Generate the table navigation above or below the table.
	 *
	 * @since  1.0.0
	 * @access protected
	 *
	 * @param string $which Position.
	 */
	protected function display_tablenav( $which ) {

		if ( 'top' === $which ) {
			wp_nonce_field( 'bulk-' . $this->_args['plural'] );
		}
		?>
		<div class="tablenav give-clearfix <?php echo esc_attr( $which ); ?> give-tributes-donations">

			<div class="alignright tablenav-right">
				<?php
				$this->extra_tablenav( $which );
				$this->pagination( $which );
				?>
			</div>

			<br class="clear"/>
		</div>
		<?php
	}

	/**
	 * This function renders most of the columns in the list table.
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @param array  $tributes_data Contains all the data of the tribute payment.
	 * @param string $column_name   The name of the column.
	 *
	 * @return string Column Name
	 */
	public function column_default( $tributes_data, $column_name ) {
		$single_donation_url = esc_url( add_query_arg( 'id', $tributes_data['id'], admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details' ) ) );
		switch ( $column_name ) {

			case 'donations' :
				$value = sprintf( '<a href="%1$s" data-tooltip="%2$s">%3$s</a>&nbsp;%4$s&nbsp;%5$s<br>', $single_donation_url, sprintf( esc_attr__( 'View Donation %s', 'give-tributes' ), $tributes_data['id'] ), $tributes_data['id'], __( 'by', 'give-tributes' ), $this->get_donor( $tributes_data ) );
				$value .= $this->get_donor_email( $tributes_data );
				break;
			case 'honoree_name' :
				$value = $tributes_data['honoree_name'];
				break;
			case 'tribute_action' :
				$value = $tributes_data['tribute_action'];
				break;
			case 'donation_date' :
				$value = $tributes_data['donation_date'];
				break;
			case 'view_donation' :
				$value = sprintf( '<a href="%1$s" data-tooltip="%2$s">%3$s</a><br>', $single_donation_url, sprintf( esc_attr__( 'View Donation %s', 'give-tributes' ), $tributes_data['id'] ), esc_attr__( 'View Donation', 'give-tributes' ) );
				break;
			default:
				$value = isset( $tributes_data[ $column_name ] ) ? $tributes_data[ $column_name ] : null;
				break;
		}// End switch().

		return apply_filters( "give_tributes_donations_report_column_{$column_name}", $value, $tributes_data['id'] );
	}

	/**
	 * Retrieve the table columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array $columns Array of all the list table columns.
	 */
	public function get_columns() {
		$columns = array(
			'donations'      => __( 'Donation', 'give-tributes' ),
			'honoree_name'   => __( 'Honoree Name', 'give-tributes' ),
			'tribute_action' => __( 'Tribute Action', 'give-tributes' ),
			'donation_date'  => __( 'Donation Date and Time', 'give-tributes' ),
			'view_donation'  => __( 'View Donation', 'give-tributes' ),
		);

		return apply_filters( 'give_tributes_donations_report_columns', $columns );

	}

	/**
	 * Get the sortable columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array Array of all the sortable columns.
	 */
	public function get_sortable_columns() {
		return array(
			'donations'     => array( 'id', true ),
			'honoree_name'  => array( 'honoree_name', true ),
			'donation_date' => array( 'post_date', true ),
		);
	}

	/**
	 * Outputs the reporting views.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param string $which Column for bulk action.
	 *
	 * @return void
	 */
	public function bulk_actions( $which = '' ) {

	}

	/**
	 * Retrieve the current page number.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return int Current page number
	 */
	public function get_paged() {
		return isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : null;
	}

	/**
	 * Retrieves the search query string.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return mixed string If search is present, false otherwise
	 */
	public function get_search() {
		return ! empty( $_GET['s'] ) ? urldecode( give_clean( $_GET['s'] ) ) : false;
	}

	/**
	 * Retrieve all the data for all the payments.
	 *
	 * @access public
	 * @since  1.0.0
	 * @return array  objects in array containing all the data for the payments
	 */
	public function payments_data() {

		$per_page = $this->per_page;
		$order    = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby  = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => $per_page,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'meta_key'   => $meta_key = ( 'honoree_name' === $orderby ) ? '_give_tributes_last_name' : '',
			'orderby'    => $orderby = ( 'honoree_name' === $orderby ) ? 'meta_value' : $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();

	}

	/**
	 * Setup the final data for the table
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @uses   Give_Donor_Reports_Table::get_columns()
	 * @uses   WP_List_Table::get_sortable_columns()
	 *
	 * @return void
	 */
	public function prepare_items() {

		$columns  = $this->get_columns();
		$hidden   = array(); // No hidden columns.
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );

		$this->items = $this->reports_data();

		$donations   = $this->give_tribute_donations_query();
		$this->total = count( $donations );

		$this->set_pagination_args( array(
			'total_items' => $this->total,
			'per_page'    => $this->per_page,
			'total_pages' => ceil( $this->total / $this->per_page ),
		) );
	}

	/**
	 * Retrieve all the data for Tribute Donations.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array  objects in array containing all the data for the payments.
	 */
	public function give_tribute_donations_query() {
		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => - 1,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();
	}

	/**
	 * Build all the reports data.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @global object $wpdb Used to query the database using the WordPress
	 *                      Database API
	 * @return array $reports_data All the data for donor reports
	 */
	public function reports_data() {

		$data = array();

		$donations = $this->payments_data();

		if ( $donations ) {

			$this->count = count( $donations );

			foreach ( $donations as $donation ) {

				$user_id            = ! empty( $donation->user_id ) ? absint( $donation->user_id ) : 0;
				$honoree_first_name = give_get_meta( $donation->ID, '_give_tributes_first_name', true );
				$honoree_first_name = ! empty( $honoree_first_name ) ? $honoree_first_name : '';

				$honoree_last_name = give_get_meta( $donation->ID, '_give_tributes_last_name', true );
				$honoree_last_name = ! empty( $honoree_last_name ) ? $honoree_last_name : '';

				// Prepare Honoree Full name.
				if ( ! empty( $honoree_first_name ) || ! empty( $honoree_last_name ) ) {
					$honoree_full_name = $honoree_first_name . ' ' . $honoree_last_name;
				} else {
					$honoree_full_name = '';
				}

				// Tribute Action.
				$ecard_or_mailed = give_get_meta( $donation->ID, '_give_tributes_would_to', true );
				$ecard_or_mailed = ! empty( $ecard_or_mailed ) ? $ecard_or_mailed : '';

				if ( 'send_eCard' === $ecard_or_mailed ) {
					$give_tribute_action = __( 'eCard', 'give-tributes' );
				} elseif ( 'send_mail_card' === $ecard_or_mailed ) {
					$give_tribute_action = __( 'Mail a Card', 'give-tributes' );
				} else {
					$give_tribute_action = __( 'No', 'give-tributes' );
				}

				// Donation date.
				$give_donation_date = $donation->date;
				$give_donation_date = date( 'F j, Y, g:i a', strtotime( $give_donation_date ) );

				$data[] = array(
					'id'             => $donation->ID,
					'user_id'        => $user_id,
					'honoree_name'   => ucfirst( $honoree_full_name ),
					'tribute_action' => $give_tribute_action,
					'donation_date'  => $give_donation_date,
				);
			}// End foreach().
		}// End if().

		return $data;
	}

	/**
	 * Get donor html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string Data shown in the User column.
	 */
	public function get_donor( $payment ) {

		$donor_id           = give_get_payment_donor_id( $payment['id'] );
		$donor_billing_name = give_get_donor_name_by( $payment['id'], 'donation' );
		$donor_name         = give_get_donor_name_by( $donor_id, 'donor' );

		$value = '';
		if ( ! empty( $donor_id ) ) {

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= $donor_billing_name . ' (';
			}

			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-donors&view=overview&id=$donor_id" ) ) . '">' . $donor_name . '</a>';

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= ')';
			}
		} else {
			$email = give_get_payment_user_email( $payment['id'] );
			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-payment-history&s=$email" ) ) . '">' . __( '(donor missing)', 'give-tributes' ) . '</a>';
		}

		return apply_filters( 'give_tributes_donation_table_column', $value, $payment['id'], 'tributes' );
	}

	/**
	 * Get donor email html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string                Data shown in the Email column.
	 */
	public function get_donor_email( $payment ) {

		$email = give_get_payment_user_email( $payment['id'] );

		if ( empty( $email ) ) {
			$email = __( '(unknown)', 'give-tributes' );
		}

		$value = '<a href="mailto:' . $email . '" data-tooltip="' . esc_attr__( 'Email donor', 'give-tributes' ) . '">' . $email . '</a>';

		return apply_filters( 'give_payments_donation_table_column', $value, $payment['id'], 'email' );
	}
}
