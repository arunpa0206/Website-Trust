<?php
/**
 * Give Mollie API.
 *
 * @link       https://givewp.com
 * @since      1.0
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/
 */

/**
 * The Give Mollie Payment API Functionality Class.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes
 * @author     GiveWP
 */
class Give_Mollie_API {

	/**
	 * Give Mollie API key.
	 *
	 * @since 1.0
	 * @var $api_key
	 */
	private $api_key;

	/**
	 * Store Give mollie object.
	 *
	 * @since 1.0
	 * @var \Mollie\Api\MollieApiClient $give_mollie_obj
	 */
	public $give_mollie_obj;

	/**
	 * Set of Errors.
	 *
	 * @since 1.0
	 * @var array $errors
	 */
	private $errors = false;

	/**
	 * Give_Mollie_API constructor.
	 *
	 * @since 1.0
	 */
	public function __construct() {

		// Setup Mollie object.
		$this->setup();
	}

	/**
	 * Setup Mollie object
	 *
	 * @since 1.0
	 * @return mixed
	 */
	public function setup() {

		try {
			/** @var \Mollie\Api\MollieApiClient $this ->give_mollie_obj */
			$this->give_mollie_obj = new \Mollie\Api\MollieApiClient();

			// Get the API key.
			$api_key = $this->get_api_key();

			// If we have API key.
			if ( ! empty( $api_key ) ) {

				// Set the API key.
				$this->give_mollie_obj->setApiKey( $api_key );
			} else {
				throw new Exception( __( 'NO API key is set', 'give-mollie' ) );
			}
		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {
			$this->errors = sprintf( __( 'API call failed: %s', 'give-mollie' ), htmlspecialchars( $e->getMessage() ) );
		} catch ( Exception $e ) {
			$this->errors = htmlspecialchars( $e->getMessage() );
		}

		return $this->errors;
	}

	/**
	 * Get the success redirection URL.
	 *
	 * @since 1.0
	 *
	 * @param integer $donation_id  Donation ID.
	 * @param integer $is_recurring Is recurring or not.
	 *
	 * @return mixed
	 */
	public static function get_redirect_url( $donation_id, $is_recurring = 0 ) {

		// Create success redirect URL.
		$success_redirect = give_get_success_page_uri();

		/**
		 * Filter the redirection URL.
		 *
		 * @param $success_redirect
		 * @param $donation_id
		 *
		 * @since 1.0
		 */
		return apply_filters( 'give_mollie_redirect_url', $success_redirect, $donation_id );
	}

	/**
	 * Get the API Key.
	 *
	 * @since 1.0
	 * @return mixed
	 */
	public function get_api_key() {
		global $give_mollie;

		// Get and set API key.
		$this->api_key = give_get_option( "_give_{$give_mollie->gateway_slug}_api_key", '' );

		return $this->api_key;
	}

	/**
	 * Get all of the payment methods activated in the merchant account filtered by amount and currency.
	 *
	 * @since 1.0
	 *
	 * @param $form_id
	 *
	 * @return array|\Mollie\Api\Resources\MethodCollection
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	public function fetch_payment_methods( $form_id ) {

		$currency = isset( $_POST['give-cs-form-currency'] ) ? give_clean( $_POST['give-cs-form-currency'] ) : give_get_currency( $form_id );
		$value    = isset( $_POST['give_total'] ) ? give_clean( $_POST['give_total'] ) : give_get_default_form_amount( $form_id );

		$args = array(
			'sequenceType' => give_is_form_recurring( $form_id ) ? 'recurring' : 'oneoff',
			'amount'       => array(
				'currency' => $currency,
				'value'    => give_sanitize_amount( $value, array(
					'decimals' => true,
					'currency' => give_get_currency( $form_id )
				) ),
			),
		);

		$api_response = $this->give_mollie_obj->methods->all( $args );

		return null !== $this->give_mollie_obj ? $api_response : array();
	}

	/**
	 * Create payment for the merchant account.
	 *
	 * @since 1.0
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 * @throws \Exception
	 *
	 * @param array $payment_data
	 *
	 * @return null|string
	 */
	public function create_payment( $payment_data ) {

		// 1. Lookup to see if a customer exists, if not create one.
		$customer_data = array(
			'donor_name'  => $payment_data['metadata']['name'],
			'donor_email' => $payment_data['metadata']['email'],
		);

		$mollie_customer = $this->get_customer( $customer_data );

		// Not a customer already? Then create one at Mollie.
		if ( false === $mollie_customer ) {
			$mollie_customer = $this->create_customer( $customer_data );
		}

		// Stop processing if any error.
		if( give_get_errors() ) {
			give_send_back_to_checkout();
		}

		// 2. Make a charge associated with the Mollie customer.
		// Get the donation ID.
		$donation_id = $payment_data['metadata']['donation_id'];

		// Create the payment via Mollie API
		$payment = $mollie_customer->createPayment( $payment_data );

		/**
		 * After payment created
		 *
		 * @since 1.0
		 *
		 * @param \Mollie\Api\Endpoints\PaymentCaptureEndpoint $payment
		 */
		do_action( 'give_mollie_after_payment_created', $payment );

		// Save Transaction ID to Donation.
		give_set_payment_transaction_id( $donation_id, $payment->id );

		// Insert Payment note.
		give_insert_payment_note(
			$donation_id, sprintf(
				__( 'Payment created in Mollie account. Transaction ID: <a href="%2$s" target="_blank">%1$s</a>', 'give-mollie' ),
				$payment->id,
				'https://www.mollie.com/dashboard/payments/' . $payment->id
			)
		);

		if ( isset( $payment_data['customerId'] ) ) {
			// Store customer ID.
			give_update_meta( $donation_id, $this->get_customer_meta_key(), $payment_data['customerId'] );
		}

		// Return the URL to redirect Payment gateway.
		return $payment->getCheckoutUrl();
	}

	/**
	 * Create a Mollie customer.
	 *
	 * @since 1.0
	 *
	 * @param array $customer_data donor_name and donor_email
	 *
	 * @return bool|\Mollie\Api\Resources\Customer
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	public function create_customer( $customer_data ) {

		// If donor name or email is blank then return false.
		if ( empty( $customer_data['donor_name'] ) || empty( $customer_data['donor_email'] ) ) {
			return false;
		}

		// Create customer on merchant account.
		try {
			$customer = $this->give_mollie_obj->customers->create(
				array(
					'name'  => give_clean( $customer_data['donor_name'] ),
					'email' => give_clean( $customer_data['donor_email'] ),
				)
			);
		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

			give_record_gateway_error( esc_html__( 'Mollie Error', 'give-mollie' ), $e->getMessage() );
			give_set_error( 'mollie_creating_customer_error', __( 'An error creating the customer at Mollie, please try again.', 'give-mollie' ) );

			// No customer exists.
			return false;
		}


		// Set the Mollie customer ID in donor meta.
		$donor = new Give_Donor( $customer_data['donor_email'] );
		$donor->add_meta( self::get_customer_meta_key(), $customer->id );

		/**
		 * Customer created
		 *
		 * @since 1.0
		 *
		 * @param \Mollie\Api\MollieApiClient $customer
		 */
		do_action( 'give_mollie_customer_created', $customer );

		return $customer;
	}

	/**
	 * Get the payment description
	 *
	 * @since 1.0
	 *
	 * @param integer                  $payment_id   Donation ID.
	 * @param \Give_Subscription|array $subscription Subscription.
	 *
	 * @return string
	 */
	public static function get_payment_description( $payment_id, $subscription = array() ) {

		/** @var \Give_Payment $payment */
		$payment             = new Give_Payment( $payment_id );
		$payment_description = sprintf( __( '%s - One-off payment', 'give-mollie' ), $payment->form_title );

		// Make description for subscription.
		if ( isset( $subscription->id ) ) {

			$period        = $subscription->period;
			$times         = $subscription->bill_times;
			$frequency     = $subscription->frequency;
			$pretty_period = give_recurring_pretty_subscription_frequency( $period, $times, false, $frequency );

			// Description text for recurring payment.
			$payment_description = sprintf( __( '%1$s - %2$s', 'give-mollie' ), $payment->form_title, $pretty_period);
		}

		/**
		 * Give Payment description
		 *
		 * @param string $payment_description Payment description.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'give_mollie_payment_description', $payment_description );
	}

	/**
	 * Get the Mollie customer. If not found create one.
	 *
	 * @param $customer_data
	 *
	 * @return \Mollie\Api\Resources\Customer|bool
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	public function get_customer( $customer_data ) {

		// Check if this customer already exists
		$donor              = new Give_Donor( $customer_data['donor_email'] );
		$mollie_customer_id = $donor->get_meta( self::get_customer_meta_key() );

		// If not customer ID found within donor meta return false.
		if ( empty( $mollie_customer_id ) ) {
			return false;
		}

		try {

			return $this->give_mollie_obj->customers->get( $mollie_customer_id );

		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

			give_record_gateway_error( esc_html__( 'Mollie Error', 'give-mollie' ), $e->getMessage() );
			give_set_error( 'mollie_fetching_customer_error', __( 'An error occurred retrieving your customer record at Mollie, please try again.', 'give-mollie' ) );

			// No customer exists.
			return false;

		}

	}

	/**
	 * Get the meta key for storing Stripe customer IDs in.
	 *
	 * @access      public
	 * @since       1.0
	 * @return      string $key
	 */
	public static function get_customer_meta_key() {

		$key = '_give_mollie_customer_id';
		if ( give_is_test_mode() ) {
			$key .= '_test';
		}

		return $key;
	}


	/**
	 * Get Payment from the Mollie account.
	 *
	 * @since 1.0
	 *
	 * @param integer $payment_id Donation ID.
	 *
	 * @return \Mollie\Api\Resources\Payment
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	public function get_payment( $payment_id ) {
		return $this->give_mollie_obj->payments->get( $payment_id );
	}

	/**
	 * Return all the Mollie API errors.
	 *
	 * @since 1.0
	 */
	public function get_errors() {

		/**
		 * Get the Mollie API errors.
		 *
		 * @param array $errors Error list.
		 *
		 * @since 1.0
		 */
		return apply_filters( 'give_mollie_api_errors', $this->errors );
	}
}
