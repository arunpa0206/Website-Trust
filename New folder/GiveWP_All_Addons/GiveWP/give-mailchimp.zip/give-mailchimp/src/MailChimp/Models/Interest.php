<?php

namespace GiveMailChimp\MailChimp\Models;

use GiveMailChimp\MailChimp\Models\Contracts\MailChimpApiDataModel;

/**
 * Class Interest
 * @package GiveMailChimp\MailChimp\Models
 * @since 1.5.0
 */
class Interest extends MailChimpApiDataModel {
}
