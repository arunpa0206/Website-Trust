<?php

namespace GiveMailChimp\MailChimp;

use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Repositories\ApiKey;

/**
 * Class Configuration
 *
 * @since 1.5.0
 * @package GiveMailChimp\MailChimp\Marketing
 */
class Configuration {
	/**
	 * @var ApiKey
	 */
	private $apiKeyRepository;
	private $apiUrl        = 'https://server.api.mailchimp.com/3.0';
	public $requestTimeout = 20;

	/**
	 * Configuration constructor.
	 *
	 * @param  ApiKey  $apiKeyRepository
	 */
	public function __construct( ApiKey $apiKeyRepository ) {
		$this->apiKeyRepository = $apiKeyRepository;
	}

	/**
	 * Get api url.
	 *
	 * @since 1.5.0
	 * @return string|string[]
	 */
	public function getApiUrl() {
		return str_replace(
			'server',
			$this->apiKeyRepository->server,
			$this->apiUrl
		);
	}

	/**
	 * Get string for basic authorization.
	 *
	 * @since 1.5.0
	 * @return string
	 */
	public function getStringForBasicAuthorization() {
		return base64_encode( "user:{$this->apiKeyRepository->apiKey}" );
	}

	/**
	 * @since 1.5.0
	 */
	public function hasValidApiKey() {
		return $this->apiKeyRepository->isValidApiKey();
	}
}
