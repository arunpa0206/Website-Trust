<?php
/**
 * Plugin Name: Give - Braintree Gateway
 * Plugin URI:  https://givewp.com/addons/braintree-payment-gateway/
 * Description: Quickly and easily accept credit card donations using your Braintree merchant account.
 * Version:     1.2.4
 * Author:      GiveWP
 * Author URI:  https://givewp.com
 * Text Domain: give-braintree
 * Domain Path: /languages
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define constants.
 *
 * Required minimum versions, paths, urls, etc.
 */
if ( ! defined( 'GIVE_BRAINTREE_VERSION' ) ) {
	define( 'GIVE_BRAINTREE_VERSION', '1.2.4' );
}

if ( ! defined( 'GIVE_BRAINTREE_MIN_PHP_VER' ) ) {
	define( 'GIVE_BRAINTREE_MIN_PHP_VER', '5.4.0' );
}

if ( ! defined( 'GIVE_BRAINTREE_MIN_GIVE_VERSION' ) ) {
	define( 'GIVE_BRAINTREE_MIN_GIVE_VERSION', '2.3.0' );
}

if ( ! defined( 'GIVE_BRAINTREE_PLUGIN_FILE' ) ) {
	define( 'GIVE_BRAINTREE_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'GIVE_BRAINTREE_PLUGIN_DIR' ) ) {
	define( 'GIVE_BRAINTREE_PLUGIN_DIR', dirname( GIVE_BRAINTREE_PLUGIN_FILE ) );
}

if ( ! defined( 'GIVE_BRAINTREE_PLUGIN_URL' ) ) {
	define( 'GIVE_BRAINTREE_PLUGIN_URL', plugin_dir_url( GIVE_BRAINTREE_PLUGIN_FILE ) );
}

if ( ! defined( 'GIVE_BRAINTREE_BASENAME' ) ) {
	define( 'GIVE_BRAINTREE_BASENAME', plugin_basename( GIVE_BRAINTREE_PLUGIN_FILE ) );
}


// check if Give_Braintree Class exists or not.
if ( ! class_exists( 'Give_Braintree' ) ) {

	/**
	 * Class Give_Braintree
	 *
	 * @since 1.2
	 */
	class Give_Braintree {

		/**
		 * This refer to the *Singleton* class instance that is being called.
		 */
		private static $instance;

		/**
		 * Notices (array)
		 *
		 * @var array
		 */
		public $notices = array();

		/**
		 * Returns the *Singleton* instance of this class.
		 *
		 * @return Give_Braintree
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Private clone method to prevent cloning of the instance of the
		 * *Singleton* instance.
		 *
		 * @return void
		 */
		private function __clone() {
		}

		/**
		 * Give_Braintree constructor.
		 *
		 * Protected constructor to prevent creating a new instance of the
		 * *Singleton* via the `new` operator from outside of this class.
		 */
		protected function setup() {
			add_action( 'admin_init', array( $this, 'check_environment' ) );
			add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );
			add_action( 'give_init', array( $this, 'init' ) );
		}

		/**
		 * Init the plugin after plugins_loaded so environment variables are set.
		 */
		public function init() {

			$this->licensing();

			// Don't hook anything else in the plugin if we're in an incompatible environment.
			if ( ! $this->get_environment_warning() ) {
				return;
			}

			$this->activation_banner();
			add_filter( 'give_payment_gateways', array( $this, 'register_gateway' ) );

			// Set filter for plugin's languages directory
			$give_lang_dir = dirname( plugin_basename( GIVE_BRAINTREE_PLUGIN_FILE ) ) . '/languages/';
			$give_lang_dir = apply_filters( 'give_braintree_languages_directory', $give_lang_dir );

			// Load the translations
			load_plugin_textdomain( 'give-braintree', false, $give_lang_dir );

			$this->includes();
		}

		/**
		 * Give BrainTree Includes.
		 */
		private function includes() {

			// Checks if Give is installed.
			if ( ! class_exists( 'Give' ) ) {
				return false;
			}

			// Plugin includes
			include( GIVE_BRAINTREE_PLUGIN_DIR . '/includes/give-braintree-helpers.php' );

			if ( is_admin() ) {
				include( GIVE_BRAINTREE_PLUGIN_DIR . '/includes/admin/give-braintree-settings.php' );
				include( GIVE_BRAINTREE_PLUGIN_DIR . '/includes/admin/give-braintree-activation.php' );
				include( GIVE_BRAINTREE_PLUGIN_DIR . '/includes/admin/give-braintree-upgrades.php' );
			}

			include( GIVE_BRAINTREE_PLUGIN_DIR . '/includes/give-braintree-gateway.php' );
		}

		/**
		 * Register the BrainTree payment gateways.
		 *
		 * @access      public
		 *
		 * @param $gateways array
		 *
		 * @return array
		 */
		public function register_gateway( $gateways ) {
			$gateways['braintree'] = array(
				'admin_label'    => __( 'Braintree', 'give-braintree' ),
				'checkout_label' => __( 'Credit Card', 'give-braintree' )
			);

			return $gateways;
		}

		/**
		 * Braintree Licensing
		 */
		public function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License( GIVE_BRAINTREE_PLUGIN_FILE, 'Braintree Gateway', GIVE_BRAINTREE_VERSION, 'WordImpress', 'braintree_license_key' );
			}
		}

		/**
		 * Display admin notices.
		 */
		public function admin_notices() {

			$allowed_tags = array(
				'a'      => array(
					'href'  => array(),
					'title' => array(),
					'class' => array(),
					'id'    => array(),
				),
				'br'     => array(),
				'em'     => array(),
				'span'   => array(
					'class' => array(),
				),
				'strong' => array(),
			);

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}

		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = array(
				'class'   => $class,
				'message' => $message,
			);
		}

		/**
		 * Check the server environment.
		 *
		 * The backup sanity check, in case the plugin is activated in a weird way,
		 * or the environment changes after activation.
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/* Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - BrainTree Gateway to activate.', 'give-braintree' ), 'https://givewp.com' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since 1.2.3
		 */
		public function activation_banner() {

			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {
				//Only runs on admin
				$args = array(
					'file'              => GIVE_BRAINTREE_PLUGIN_FILE,
					'name'              => __( 'BrainTree Gateway', 'give-braintree' ),
					'version'           => GIVE_BRAINTREE_VERSION,
					'settings_url'      => admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=braintree' ),
					'documentation_url' => 'http://docs.givewp.com/addon-braintree',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false
				);

				new Give_Addon_Activation_Banner( $args );
			}
		}

		/**
		 * Environment warnings.
		 *
		 * Checks the environment for compatibility problems.
		 * Returns a string with the first incompatibility found or false if the environment has no problems.
		 *
		 * @return bool|mixed|string
		 */
		public function get_environment_warning() {

			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if ( defined( 'GIVE_VERSION' ) && version_compare( GIVE_VERSION, GIVE_BRAINTREE_MIN_GIVE_VERSION, '<' ) ) {

				/* Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> core version %s or above for the Give - Braintree Gateway gateway add-on to activate.', 'give-braintree' ), 'https://givewp.com', GIVE_BRAINTREE_MIN_GIVE_VERSION ) );

				$is_working = false;
			}

			if ( ! function_exists( 'curl_init' ) ) {
				$this->add_admin_notice( 'prompt_curl_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">cURL</a> installed for the Give - Braintree Gateway gateway add-on to activate.', 'give-braintree' ), 'https://givewp.com/documentation/core/requirements/' ) );

				$is_working = false;
			}

			if ( version_compare( phpversion(), GIVE_BRAINTREE_MIN_PHP_VER, '<' ) ) {
				$this->add_admin_notice( 'prompt_php_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">PHP</a> version %s or above for the Give - Braintree Gateway add-on to activate.', 'give-braintree' ), 'https://givewp.com/documentation/core/requirements/', GIVE_BRAINTREE_MIN_PHP_VER ) );

				$is_working = false;
			}

			return $is_working;
		}
	}

	/**
	 * Fire it up.
	 *
	 * @return Give_Braintree
	 */
	function Give_Braintree() {
		return Give_Braintree::get_instance();
	}

	$GLOBALS['give_braintree'] = Give_Braintree();
}