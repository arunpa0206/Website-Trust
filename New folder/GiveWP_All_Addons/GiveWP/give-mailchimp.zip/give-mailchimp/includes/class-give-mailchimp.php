<?php

use GiveMailChimp\MailChimp\Repositories\ListInterestCategories;
use GiveMailChimp\MailChimp\Repositories\Lists as ListsRepository;
use GiveMailChimp\MailChimp\Api\Marketing\Lists as ListsApiClient;

/**
 * Class Give_MailChimp
 *
 * Extends the base newsletter class with MailChimp specific functionality.
 *
 * @since       1.0
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @copyright   Copyright (c) 2017, GiveWP
 */
class Give_MailChimp_Settings extends Give_Newsletter {

	/**
	 * Sets up the checkout label
	 */
	public function init() {
		add_action( 'give_save_options-page_fields', [ $this, 'save_settings' ], 10, 4 );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ], 100 );
		add_action( 'give_admin_field_mailchimp_list_select', [ $this, 'give_mailchimp_list_select' ], 10, 2 );
	}

	/**
	 * Load Admin Scripts
	 *
	 * Enqueues the required admin scripts.
	 *
	 * @since 1.0
	 * @global  WP_Post $post
	 *
	 * @param  string  $hook  Page hook
	 *
	 * @return void
	 */
	public function admin_scripts( $hook ) {
		global $post_type;

		// Directories of assets.
		$js_dir  = GIVE_MAILCHIMP_URL . 'assets/dist/js/';
		$css_dir = GIVE_MAILCHIMP_URL . 'assets/dist/css/';

		wp_register_script(
			'give-' . $this->id . '-admin-ajax-js',
			$js_dir . 'admin-ajax.js',
			[ 'jquery' ]
		);

		// Forms CPT Script.
		if ( 'give_forms' === $post_type || ( give_is_admin_page() && isset( $_GET['tab'] ) && 'give-mailchimp' === $_GET['tab'] ) ) {
			// CSS.
			wp_register_style( 'give-mailchimp-admin-css', $css_dir . 'admin-forms.css', GIVE_MAILCHIMP_VERSION );
			wp_enqueue_style( 'give-mailchimp-admin-css' );

			// JS.
			wp_register_script(
				'give-mailchimp-admin-forms-scripts',
				$js_dir . 'admin-forms.js',
				[ 'jquery' ],
				GIVE_MAILCHIMP_VERSION
			);
			wp_enqueue_script( 'give-mailchimp-admin-forms-scripts' );

			wp_enqueue_script( 'give-' . $this->id . '-admin-ajax-js' );
		}

		// Admin settings.
		if ( $hook == 'give_forms_page_give-settings' ) {
			wp_enqueue_script( 'give-' . $this->id . '-admin-ajax-js' );
		}
	}


	/**
	 * Retrieves the lists from MailChimp
	 *
	 * @return array
	 */
	public function get_lists() {
		try {
			/* @var ListsRepository $listRepository */
			$listRepository = give( ListsRepository::class );

			return $listRepository->getAllListsTitles();
		} catch ( Exception $e ) {
			return [];
		}
	}

	/**
	 * Retrieve the list of groupings associated with a list id
	 *
	 * @param  string  $list_id  List id for which groupings should be returned
	 *
	 * @return bool|array  $groups_data Data about the groups
	 */
	public function get_groupings( $list_id = '' ) {
		try {
			/* @var ListInterestCategories $listInterestCategoriesRepository */
			$listInterestCategoriesRepository = give( ListInterestCategories::class );

			return $listInterestCategoriesRepository->getInterestCategoriesTitles( $list_id );
		} catch ( Exception $exception ) {
			return [];
		}
	}

	/**
	 * Registers the plugin settings.
	 *
	 * @param $settings
	 *
	 * @return array
	 */
	public function settings( $settings ) {
		$give_mailchimp_settings = [
			[
				'name' => __( 'MailChimp Settings', 'give-mailchimp' ),
				'id'   => 'give_title_mailchimp',
				'type' => 'give_title',
			],
			[
				'id'   => 'give_mailchimp_api',
				'name' => __( 'MailChimp API Key', 'give-mailchimp' ),
				'desc' => __( 'Enter your MailChimp API key', 'give-mailchimp' ),
				'type' => 'api_key',
			],
			[
				'id'   => 'give_mailchimp_double_opt_in',
				'name' => __( 'Double Opt-In', 'give-mailchimp' ),
				'desc' => __(
					'When checked, users will be sent a confirmation email after signing up, and will only be added once they have confirmed the subscription.',
					'give-mailchimp'
				),
				'type' => 'checkbox',
			],
			[
				'id'   => 'give_mailchimp_show_checkout_signup',
				'name' => __( 'Enable Globally', 'give-mailchimp' ),
				'desc' => __(
					'Allow donors to sign up for the list selected below on all donation forms? Note: the list(s) can be customized per form.',
					'give-mailchimp'
				),
				'type' => 'checkbox',
			],
			[
				'id'      => 'give_mailchimp_checked_default',
				'name'    => __( 'Opt-in Default', 'give-mailchimp' ),
				'desc'    => __(
					'Would you like the newsletter opt-in checkbox checked by default? This option can be customized per form.',
					'give-mailchimp'
				),
				'options' => [
					'yes' => __( 'Checked', 'give-mailchimp' ),
					'no'  => __( 'Unchecked', 'give-mailchimp' ),
				],
				'default' => 'no',
				'type'    => 'radio_inline',
			],
			[
				'id'   => 'give_mailchimp_list',
				'name' => __( 'Default List', 'give-mailchimp' ),
				'desc' => __(
					'Select the list you wish for all donors to subscribe to by default. Note: the list(s) can be customized per form.',
					'give-mailchimp'
				),
				'type' => 'mailchimp_list_select',
			],
			[
				'id'         => 'give_mailchimp_label',
				'name'       => __( 'Default Label', 'give-mailchimp' ),
				'desc'       => __(
					'This is the text shown by default next to the MailChimp sign up checkbox. Yes, this can also be customized per form.',
					'give-mailchimp'
				),
				'type'       => 'text',
				'attributes' => [
					'placeholder' => __( 'Subscribe to our newsletter', 'give-mailchimp' ),
				],
			],
			[
				'id'   => 'give_mailchimp_donation_data',
				'name' => __( 'Send Donation Data', 'give-mailchimp' ),
				'desc' => __(
					'Enabling this option will send donation data such as Donation Form Title, ID, Payment Method and more to MailChimp under the Subscriber\'s Details.',
					'give-mailchimp'
				),
				'type' => 'checkbox',
			],

		];

		/**
		 * If FFM is activated then add new option which ask to send custom
		 * field data to Mail Chimp or not.
		 *
		 * @since 1.4
		 */
		if ( give_mc_ffm_is_activated() ) {
			$give_mailchimp_settings[] = [
				'id'   => 'give_mailchimp_ffm_pass_field',
				'name' => __( 'Send FFM Fields', 'give-mailchimp' ),
				'desc' => __(
					'Would you like to send Form Field Manager field data to MailChimp? Note: FFM data will only send if the <code>Send Donation Data</code> option is checked.',
					'give-mailchimp'
				),
				'type' => 'checkbox',
			];
		}

		// Docs link is always last.
		$give_mailchimp_settings[] = [
			'name'  => __( 'MailChimp Docs Link', 'give-mailchimp' ),
			'id'    => 'mailchimp_settings_docs_link',
			'url'   => esc_url( 'http://docs.givewp.com/addon-mailchimp' ),
			'title' => __( 'MailChimp Settings', 'give-mailchimp' ),
			'type'  => 'give_docs_link',
		];

		return array_merge( $settings, $give_mailchimp_settings );
	}


	/**
	 * Flush the list transient on settings save.
	 */
	public function save_settings() {
		$api_key = give_get_option( 'give_mailchimp_api' );

		// Is this a new API key?
		if ( isset( $_POST['give_mailchimp_api'] ) && $api_key !== $_POST['give_mailchimp_api'] ) {
			delete_transient( 'give_mailchimp_list_data' );
			echo '<script>window.location.reload();</script>';
		}
	}

	/**
	 * Determines if the donation form signup option should be displayed.
	 */
	public function show_signup_checkbox() {
		$give_options = give_get_settings();

		return ! empty( $give_options['give_mailchimp_show_checkout_signup'] );
	}

	/**
	 * Subscribe Email.
	 *
	 * Subscribe an email to a list.
	 *
	 * @param  array  $user_info
	 * @param  bool|string|array  $list_id
	 * @param  int  $form_id
	 *
	 * @return bool
	 */
	public function subscribe_email( $user_info = [], $list_id = false, $form_id = null ) {

		$give_options = give_get_settings();

		// Retrieve the global list ID if none is provided.
		if ( ! $list_id ) {
			$list_id = ! empty( $give_options['give_mailchimp_list'] ) ? $give_options['give_mailchimp_list'] : false;
			if ( ! $list_id ) {
				return false;
			}
		}

		$opt_in = ( isset( $give_options['give_mailchimp_double_opt_in'] ) && ! empty( $give_options['give_mailchimp_double_opt_in'] ) );

		$subscriber_tags = $this->sanitizeTags( give_get_meta( $form_id, '_give_mailchimp_tags', true, [] ) );

		$merge_vars = [
			'FNAME' => $user_info['first_name'],
			'LNAME' => $user_info['last_name'],
		];

		if ( is_array( $list_id ) ) {
			$temp                    = $list_id;
			$list_id                 = $temp['id'];
			$merge_vars['groupings'] = $temp['groupings'];
		} elseif ( strpos( $list_id, '|' ) !== false ) {
			$parts = explode( '|', $list_id );

			$list_id     = $parts[0];
			$grouping_id = $parts[1];
			$group_name  = $parts[2];

			$groupings = [
				[
					'id'     => $grouping_id,
					'groups' => [ $group_name ],
				],
			];

			$merge_vars['groupings'] = $groupings;
		}

		$api_args = apply_filters(
			'give_mc_subscribe_vars',
			[
				'id'                => $list_id,
				'email'             => [ 'email' => $user_info['email'] ],
				'merge_vars'        => $merge_vars,
				'double_optin'      => $opt_in,
				'update_existing'   => true,
				'replace_interests' => false,
				'send_welcome'      => false,
				'tags'				=> $subscriber_tags,
			]
		);

		// Collect interest ids from groupings
		$interests = [];

		if ( array_key_exists( 'groupings', $api_args['merge_vars'] ) ) {
			foreach ( $api_args['merge_vars']['groupings'] as $groupData ) {
				foreach ( $groupData['groups'] as $interestId ) {
					$interests[ $interestId ] = true;
				}
			}

			unset( $api_args['merge_vars']['groupings'] );
		}

		$bodyArguments = [
			'status_if_new' => $api_args['double_optin'] ? 'pending' : 'subscribed',
			'email_address' => $user_info['email'],
			'merge_fields'  => $api_args['merge_vars'],
			'tags'			=> $api_args['tags'],
		];

		if ( $interests ) {
			$bodyArguments['interests'] = $interests;
		}

		try {
			/* @var ListsApiClient $listApiClient */
			$listApiClient = give( ListsApiClient::class );
			$result        = $listApiClient->addOrUpdateListMember( $list_id, $bodyArguments );
		} catch ( Exception $e ) {
			return false;
		}

		if ( $result ) {
			return true;
		}

		return false;
	}

	/**
	 * Sanitize Member Tags by returning an array of HTML escaped strings
	 * 
	 * @param array $tags
	 * 
	 * @return array
	 */
	protected function sanitizeTags ( $tags ) {
		if ( !empty( $tags ) ) {
			return array_map([$this, 'sanitizeTag'], $tags);
		}
		return [];
	}

	/**
	 * Sanitize Member Tag by return a single HTML escaped string
	 * 
	 * @param array $tag
	 * 
	 * @return string
	 */
	protected function sanitizeTag ( $tag ) {
		return html_entity_decode( $tag, ENT_QUOTES );
	}

	/**
	 * Give add MailChimp list select with refresh button.
	 *
	 * @param              $field
	 * @param  array|string  $value
	 */
	public function give_mailchimp_list_select( $field, $value ) {
		$is_list_fetched      = $this->is_list_fetched();
		$lists                = [];
		$is_auto_refresh_list = ( ! $is_list_fetched ) && give_get_option( 'give_mailchimp_api', '' );

		if ( $is_list_fetched ) {
			$lists = $this->get_lists();
		}

		// Backward compatibility.
		$value = ! is_array( $value ) ? (array) $value : $value;

		$give_mailchimp_nonce = wp_create_nonce( 'give-mailchimp-nonce' );

		ob_start(); ?>

		<tr valign="top"
		<?php echo ! empty( $value['wrapper_class'] ) ? 'class="' . $value['wrapper_class'] . '"' : ''; ?>>
			<th scope="row" class="titledesc">
				<label for=""><?php _e( 'Default List', 'give-mailchimp' ); ?></label>
			</th>
			<td class="give-mailchimp-list-td">

				<div class="give-mailchimp-list-container">
					<label
						class=""
						style="font-weight:bold; float:left;"
						for="<?php echo "{$field['id']}"; ?>"
					><?php _e( '', 'give-mailchimp' ); ?></label>

					<div class="give-mailchimp-list-wrap" data-refresh-list="<?php echo absint( $is_auto_refresh_list ); ?>">
						<?php echo $is_list_fetched ? $this->get_list_options( $lists, $value, $field ) : ''; ?>
					</div>
					<div class="give-mailchimp-list-refresh-btn">
						<button
							class="give-reset-mailchimp-button button-secondary" style="margin:1px 0 0 !important;"
							data-action="give_reset_mailchimp_lists"
							data-field_type="global"
							data-nonce="<?php echo $give_mailchimp_nonce; ?>"
						><?php echo esc_html__( 'Refresh Lists', 'give-mailchimp' ); ?></button>
						<span class="give-spinner spinner"></span>
					</div>
					<p class="give-field-description"><?php echo "{$field['desc']}"; ?></p>
				</div>


			</td>
		</tr>

		<?php
		echo ob_get_clean();
	}

}
