"use strict";

is_visible_init();
bighearts_slick_navigation_init();

jQuery(document).ready(function($) {
    bighearts_sticky_init();
    bighearts_search_init();
    bighearts_side_panel_init();
    bighearts_mobile_header();
    bighearts_woocommerce_helper();
    bighearts_woocommerce_login_in();
    bighearts_init_appear();
    bighearts_accordion_init();
    bighearts_services_accordion_init();
    bighearts_progress_bars_init();
    bighearts_carousel_slick();
    bighearts_image_comparison();
    bighearts_counter_init();
    bighearts_countdown_init();
    bighearts_img_layers();
    bighearts_page_title_parallax();
    bighearts_extended_parallax();
    bighearts_portfolio_parallax();
    bighearts_message_anim_init();
    bighearts_scroll_up();
    bighearts_link_scroll();
    bighearts_skrollr_init();
    bighearts_sticky_sidebar();
    bighearts_videobox_init();
    bighearts_parallax_video();
    bighearts_tabs_init();
    bighearts_circuit_service();
    bighearts_select_wrap();
    jQuery( '.wgl_module_title .carousel_arrows' ).bighearts_slick_navigation();
    jQuery( '.wgl-filter_wrapper .carousel_arrows' ).bighearts_slick_navigation();
    jQuery( '.wgl-products > .carousel_arrows' ).bighearts_slick_navigation();
    jQuery( '.bighearts_module_custom_image_cats > .carousel_arrows' ).bighearts_slick_navigation();
    bighearts_scroll_animation();
    bighearts_woocommerce_mini_cart();
    bighearts_text_background();
    bighearts_give_wp_sidebar();
    bighearts_dynamic_styles();
    bighearts_pie_chart_init();
});

jQuery(window).load(function () {
    bighearts_images_gallery();
    bighearts_isotope();
    bighearts_blog_masonry_init();
    setTimeout(function(){
        jQuery('#preloader-wrapper').fadeOut();
    },1100);

    bighearts_menu_lavalamp();
    jQuery(".wgl-currency-stripe_scrolling").each(function(){
        jQuery(this).simplemarquee({
            speed: 40,
            space: 0,
            handleHover: true,
            handleResize: true
        });
    })
});
