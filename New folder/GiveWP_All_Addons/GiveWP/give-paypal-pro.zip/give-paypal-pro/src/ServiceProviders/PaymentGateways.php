<?php

namespace GivePayPalPro\ServiceProviders;

use Give\PaymentGateways\PaymentGateway;
use Give\ServiceProviders\ServiceProvider;
use GivePayPalPro\PaymentGateways\PayPalProNVP\PayPalProNVP;
use GivePayPalPro\PaymentGateways\PayPalProPayFlow\PayPalProPayFlow;
use GivePayPalPro\PaymentGateways\PayPalProRest\PayPalProRest;
use GivePayPalPro\PaymentGateways\SettingPage;

/**
 * Class PaymentGateways
 *
 * The Service Provider for loading the Payment Gateways
 *
 * @since 1.2.3
 */
class PaymentGateways implements ServiceProvider {
	/**
	 * Array of PaymentGateway classes to be bootstrapped
	 *
	 * @var string[]
	 */
	public $gateways = [
		PayPalProPayFlow::class,
		PayPalProNVP::class,
		PayPalProRest::class
	];

	/**
	 * Array of SettingPage classes to be bootstrapped
	 *
	 * @var string[]
	 */
	private $gatewaySettingsPages = [
		SettingPage::class,
	];

	/**
	 * @inheritDoc
	 */
	public function register() {}

	/**
	 * @inheritDoc
	 */
	public function boot() {
		add_filter( 'give_register_gateway', [ $this, 'bootGateways' ] );
		add_action( 'give-settings_start', [ $this, 'registerPayPalSettingPage' ] );
	}

	/**
	 * Register all payment gateways setting pages with GiveWP.
	 *
	 * @since 1.2.3
	 */
	public function registerPayPalSettingPage() {
		foreach ( $this->gatewaySettingsPages as $page ) {
			give($page)->boot();
		}
	}

	/**
	 * Registers all of the payment gateways with GiveWP
	 *
	 * @since 1.2.3
	 *
	 * @param array $gateways
	 *
	 * @return array
	 */
	public function bootGateways( array $gateways ) {
		foreach ( $this->gateways as $gateway ) {
			/** @var PaymentGateway $gateway */
			$gateway = give( $gateway );

			$gateways[ $gateway->getId() ] = [
				'admin_label'    => $gateway->getName(),
				'checkout_label' => $gateway->getPaymentMethodLabel(),
			];

			$gateway->boot();
		}

		return $gateways;
	}
}
