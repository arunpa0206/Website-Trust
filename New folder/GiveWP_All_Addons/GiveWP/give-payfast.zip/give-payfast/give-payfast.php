<?php
/**
 * Plugin Name: Give - PayFast Payment Gateway
 * Plugin URI: https://givewp.com/addons/payfast-gateway/
 * Description: Process online donations via the PayFast payment gateway.
 * Author: GiveWP
 * Author URI: https://givewp.com
 * Version: 1.0.3
 * Text Domain: give-payfast
 * Domain Path: /languages
 * GitHub Plugin URI: https://github.com/impress-org/give-payfast
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Give_PayFast' ) ) {

	final class Give_PayFast {
		/**
		 * Instance.
		 *
		 * @since  1.0
		 * @access static
		 * @var
		 */
		static private $instance;

		/**
		 * Notices (array)
		 *
		 * @since 1.0.3
		 *
		 * @var array
		 */
		public $notices = array();

		/**
		 * Singleton pattern.
		 *
		 * @since  1.0
		 * @access private
		 */
		private function __construct() {
		}


		/**
		 * Get instance.
		 *
		 * @since  1.0
		 * @access static
		 *
		 * @return static
		 */
		static function get_instance() {
			if ( null === static::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Setup Give PayFast.
		 *
		 * @since 1.0.3
		 * @access private
		 */
		private function setup() {

			// Setup constants.
			$this->setup_constants();

			// Give init hook.
			add_action( 'give_init', array( $this, 'init' ), 10 );
			add_action( 'admin_init', array( $this, 'check_environment' ), 999 );
			add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );
		}

		/**
		 * Setup constants.
		 *
		 * @since  1.0
		 * @access public
		 *
		 * @return Give_PayFast
		 */
		public function setup_constants() {

			if ( ! defined( 'GIVE_PAYFAST_VERSION' ) ) {
				define( 'GIVE_PAYFAST_VERSION', '1.0.3' );
			}

			if ( ! defined( 'GIVE_PAYFAST_MIN_GIVE_VER' ) ) {
				define( 'GIVE_PAYFAST_MIN_GIVE_VER', '2.1.0' );
			}

			if ( ! defined( 'GIVE_PAYFAST_FILE' ) ) {
				define( 'GIVE_PAYFAST_FILE', __FILE__ );
			}

			if ( ! defined( 'GIVE_PAYFAST_BASENAME' ) ) {
				define( 'GIVE_PAYFAST_BASENAME', plugin_basename( GIVE_PAYFAST_FILE ) );
			}

			if ( ! defined( 'GIVE_PAYFAST_URL' ) ) {
				define( 'GIVE_PAYFAST_URL', plugins_url( '/', GIVE_PAYFAST_FILE ) );
			}

			if ( ! defined( 'GIVE_PAYFAST_DIR' ) ) {
				define( 'GIVE_PAYFAST_DIR', plugin_dir_path( GIVE_PAYFAST_FILE ) );
			}

			return self::$instance;
		}

		/**
		 * Load the text domain.
		 *
		 * @access private
		 * @since  1.0
		 *
		 * @return void
		 */
		public function load_textdomain() {

			// Set filter for plugin's languages directory.
			$lang_dir = dirname( GIVE_PAYFAST_BASENAME ) . '/languages/';
			$lang_dir = apply_filters( 'give_payfast_languages_directory', $lang_dir );

			// Traditional WordPress plugin locale filter.
			$locale  = apply_filters( 'plugin_locale', get_locale(), 'give-payfast' );
			$mo_file = sprintf( '%1$s-%2$s.mo', 'give-payfast', $locale );

			// Setup paths to current locale file.
			$local_mo_file  = $lang_dir . $mo_file;
			$global_mo_file = WP_LANG_DIR . '/give-payfast/' . $mo_file;

			if ( file_exists( $global_mo_file ) ) {
				load_textdomain( 'give-payfast', $global_mo_file );
			} elseif ( file_exists( $local_mo_file ) ) {
				load_textdomain( 'give-payfast', $local_mo_file );
			} else {
				// Load the default language files.
				load_plugin_textdomain( 'give-payfast', false, $lang_dir );
			}

		}

		/**
		 * Set hooks
		 *
		 * @since 1.0.3
		 * @access public
		 */
		public function init() {

			if ( ! $this->get_environment_warning() ) {
				return;
			}

			$this->load_textdomain();
			$this->licensing();
			$this->activation_banner();

			if ( is_admin() ) {
				// Process plugin dependency.
				require_once GIVE_PAYFAST_DIR . 'includes/admin/plugin-activation.php';
			}

			require_once GIVE_PAYFAST_DIR . 'includes/functions.php';
			require_once GIVE_PAYFAST_DIR . 'includes/admin/class-admin-settings.php';
			require_once GIVE_PAYFAST_DIR . 'includes/payment-processing.php';
			require_once GIVE_PAYFAST_DIR . 'includes/actions.php';
			require_once GIVE_PAYFAST_DIR . 'includes/filters.php';
			require_once GIVE_PAYFAST_DIR . 'includes/admin/give-payfast-upgrades.php';
		}

		/**
		 * Check plugin environment.
		 *
		 * @since  1.0.3
		 * @access public
		 *
		 * @return bool
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/* Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - PayFast to activate.', 'give-payfast' ), 'https://givewp.com' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since  1.0.3
		 *
		 * @return bool
		 */
		public function activation_banner() {

			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {

				$args = array(
					'file'              => GIVE_PAYFAST_FILE,
					'name'              => __( 'Payfast Gateway', 'give-payfast' ),
					'version'           => GIVE_PAYFAST_VERSION,
					'settings_url'      => admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=payfast' ),
					'documentation_url' => 'http://docs.givewp.com/addon-payfast',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false, // Never leave true.
				);
				new Give_Addon_Activation_Banner( $args );
			}

			return true;
		}

		/**
		 * Check plugin for Give environment.
		 *
		 * @since  1.0.3
		 * @access public
		 *
		 * @return bool
		 */
		public function get_environment_warning() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if (
				defined( 'GIVE_VERSION' )
				&& version_compare( GIVE_VERSION, GIVE_PAYFAST_MIN_GIVE_VER, '<' )
			) {

				/* Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> core version %s for the Give - PayFast add-on to activate.', 'give-payfast' ), 'https://givewp.com', GIVE_PAYFAST_MIN_GIVE_VER ) );

				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Implement Give Licensing for Give PayFast Add On.
		 *
		 * @since 1.0.3
		 * @access private
		 */
		private function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License( GIVE_PAYFAST_FILE, 'PayFast', GIVE_PAYFAST_VERSION, 'WordImpress' );
			}
		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @since 1.0.3
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = array(
				'class'   => $class,
				'message' => $message,
			);
		}

		/**
		 * Display admin notices.
		 *
		 * @since 1.0.3
		 */
		public function admin_notices() {

			$allowed_tags = array(
				'a'      => array(
					'href'  => array(),
					'title' => array(),
					'class' => array(),
					'id'    => array(),
				),
				'br'     => array(),
				'em'     => array(),
				'span'   => array(
					'class' => array(),
				),
				'strong' => array(),
			);

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}

		}
	}

	/**
	 * Returns class object instance.
	 *
	 * @since 1.0.3
	 *
	 * @return Give_PayFast bool|object
	 */
	function Give_PayFast() {
		return Give_PayFast::get_instance();
	}


	Give_PayFast();
}
