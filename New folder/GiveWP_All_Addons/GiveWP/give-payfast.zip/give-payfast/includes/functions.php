<?php
/**
 * List of general function used to process PayFast Payment Gateway
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check whether PayFast gateway is in test mode or not.
 *
 * @since 1.0
 *
 * @return bool
 */
function give_payfast_is_test_mode() {
	return apply_filters( 'give_payfast_is_test_mode', give_is_test_mode() );
}

/**
 * Get PayFast API URL.
 *
 * @since 1.0
 *
 * @return string
 */
function give_payfast_get_api_url() {

	$payfast_redirect = 'https://sandbox.payfast.co.za/eng/process';

	// LIVE Mode - API URL.
	if ( ! give_payfast_is_test_mode() ) {
		$payfast_redirect = 'https://www.payfast.co.za/eng/process';
	}

	return $payfast_redirect;
}

/**
 * Get PayFast Validate API URL.
 *
 * @since 1.0
 *
 * @return string
 */
function give_payfast_get_validate_url() {

	$validate_url = 'https://sandbox.payfast.co.za/eng/query/validate';

	// LIVE Mode - Validate URL.
	if ( ! give_payfast_is_test_mode() ) {
		$validate_url = 'https://www.payfast.co.za/eng/query/validate';
	}

	return $validate_url;
}

/**
 * Get Payment Method Label.
 *
 * @since 1.0
 *
 * @return string
 */
function give_payfast_get_payment_method_label() {
	return give_get_option( 'payfast_checkout_label', __( 'PayFast', 'give-payfast' ) );
}

/**
 * Get PayFast Valid Hosts.
 *
 * @since 1.0
 *
 * @return array
 */
function give_payfast_get_valid_hosts() {
	return apply_filters( 'give_payfast_valid_hosts', array(
		'www.payfast.co.za',
		'sandbox.payfast.co.za',
		'w1w.payfast.co.za',
		'w2w.payfast.co.za',
	) );
}

/**
 * Get PayFast merchant credentials.
 *
 * @since 1.0
 *
 * @return array
 */
function give_payfast_get_merchant_credentials() {
	$credentials = array(
		'merchant_id'  => give_get_option( 'give_payfast_sandbox_merchant_id', '' ),
		'merchant_key' => give_get_option( 'give_payfast_sandbox_merchant_access_key', '' ),
		'passphrase'   => give_get_option( 'give_payfast_sandbox_passphrase', '' ),
	);

	if ( ! give_payfast_is_test_mode() ) {
		$credentials = array(
			'merchant_id'  => give_get_option( 'give_payfast_live_merchant_id', '' ),
			'merchant_key' => give_get_option( 'give_payfast_live_merchant_access_key', '' ),
			'passphrase'   => give_get_option( 'give_payfast_live_passphrase', '' ),
		);
	}

	return $credentials;

}

/**
 * Generate Parameter String.
 *
 * @param array $data                   Response Variables.
 * @param bool  $sort_data_before_merge Perform Sorting of response variables or not.
 * @param bool  $skip_empty_values      Want to skip empty values or not.
 *
 * @since 1.0
 *
 * @return string
 */
function give_payfast_generate_parameter_string( $data, $sort_data_before_merge = true, $skip_empty_values = true ) {

	$pass_phrase = give_get_option( 'give_payfast_live_passphrase' );
	if ( give_payfast_is_test_mode() ) {
		$pass_phrase = give_get_option( 'give_payfast_sandbox_passphrase' );
	}

	// if sorting is required the passphrase should be added in before sort.
	if ( ! empty( $pass_phrase ) && $sort_data_before_merge ) {
		$data['passphrase'] = $pass_phrase;
	}

	if ( $sort_data_before_merge ) {
		ksort( $api_data );
	}

	// concatenate the array key value pairs.
	$parameter_string = '';
	foreach ( $data as $key => $value ) {

		if ( $skip_empty_values && empty( $value ) ) {
			continue;
		}

		if ( 'signature' !== $key ) {
			$encoded_value    = urlencode( $value );
			$parameter_string .= "{$key}={$encoded_value}&";
		}
	}

	// When not sorting, pass-phrase should be added to the end before md5.
	if ( $sort_data_before_merge ) {
		$parameter_string = rtrim( $parameter_string, '&' );
	} elseif ( ! empty( $pass_phrase ) ) {
		$parameter_string .= 'passphrase=' . urlencode( $pass_phrase );
	} else {
		$parameter_string = rtrim( $parameter_string, '&' );
	}

	return $parameter_string;
}

/**
 * Validate PayFast Signature to verify donation.
 *
 * @param array  $data      Response Variables.
 * @param string $signature PayFast Signature.
 *
 * @since 1.0
 *
 * @return bool
 */
function give_payfast_validate_signature( $data, $signature ) {
	$result = $data['signature'] === $signature;

	return $result;
}

/**
 * Validate PayFast Response Data.
 *
 * @param array $post_data Posted Variable Data.
 *
 * @since 1.0
 *
 * @return bool
 */
function give_payfast_validate_response_data( $post_data ) {

	if ( ! is_array( $post_data ) ) {
		return false;
	}

	$response = wp_remote_post(
		give_payfast_get_validate_url(),
		array(
			'body'    => $post_data,
			'timeout' => 70,
		)
	);

	if ( is_wp_error( $response ) || empty( $response['body'] ) ) {
		return false;
	}

	parse_str( $response['body'], $parsed_response );

	$response = $parsed_response;

	// Interpret Response.
	if ( is_array( $response ) && in_array( 'VALID', array_keys( $response ) ) ) {
		return true;
	} else {
		return false;
	}
}
