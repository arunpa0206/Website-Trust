<?php
/**
 * Listen paytm ipn
 *
 * @since  1.0
 */
function give_paytm_listen_ipn() {

	if ( isset( $_GET['give-listener'] ) && $_GET['give-listener'] == 'PAYTM_IPN' ) {
		do_action( 'give_verify_paytm_gateway_ipn' );
	}
}

add_action( 'init', 'give_paytm_listen_ipn' );

/**
 * Process paytm ipn
 *
 * @since  1.0
 */
function give_paytm_process_ipn() {
	$donation_id = isset( $_GET['payment-id'] ) ? absint( $_GET['payment-id'] ) : 0;
	$form_id     = isset( $_GET['form-id'] ) ? absint( $_GET['form-id'] ) : 0;

	// Bailout.
	if (
		empty( $donation_id )
		|| empty( $form_id )
		|| empty( $_POST )
		|| ! isset( $_POST['ORDERID'], $_POST['RESPCODE'], $_POST['CHECKSUMHASH'] )
	) {
		exit();
	}

	$merchant          = give_paytm_get_merchant_credentials();
	$is_valid_checksum = 'TRUE' === verifychecksum_e( $_POST, $merchant['merchant_key'], $_POST['CHECKSUMHASH'] );

	if ( $is_valid_checksum && '01' === $_POST['RESPCODE'] ) {

		// Verify donation again.
		$status_query_args = array(
			'MID'     => $_POST['MID'],
			'ORDERID' => $_POST['ORDERID'],
		);

		$status_query_args['CHECKSUMHASH'] = getChecksumFromArray( $status_query_args, $merchant['merchant_key'] );
		$status_response_param             = callNewAPI( give_paytm_get_api_url( 'TxnStatus' ), $status_query_args );

		if (
			'TXN_SUCCESS' === $status_response_param['STATUS']
			&& $status_response_param['TXNAMOUNT'] === $_POST['TXNAMOUNT']
		) {
			give_insert_payment_note( $donation_id, sprintf( __( 'Transaction Successful. Paytm Transaction ID: %s', 'give-paytm' ), $_POST['TXNID'] ) );
			give_set_payment_transaction_id( $donation_id, $_POST['TXNID'] );
			update_post_meta( $donation_id, 'paytm_donation_response', $_POST );
			give_update_payment_status( $donation_id, 'complete' );

			give_send_to_success_page();
		}
	}

	$response_msg = esc_attr( $_POST['RESPMSG'] );
	give_record_gateway_error(
		__( 'Paytm Error', 'give-paytm' ),
		sprintf( __( 'Transaction Failed. Paytm response message: %s', 'give-paytm' ), $response_msg ) . '<br><br>' . sprintf( esc_attr__( 'Details: %s', 'give-paytm' ), '<br>' . print_r( $_REQUEST, true ) ),
		$donation_id
	);

	give_update_payment_status( $donation_id, 'failed' );
	update_post_meta( $donation_id, 'paytm_donation_response', $_POST );
	give_insert_payment_note( $donation_id, sprintf( __( 'Transaction Failed.Paytm response message:  %s', 'give-paytm' ), $response_msg ) );

	wp_redirect( give_get_failed_transaction_uri() . '?give-paytm-payment=failed&give-paytm-error-message=' . base64_encode( $response_msg ) );
	exit();
}

add_action( 'give_verify_paytm_gateway_ipn', 'give_paytm_process_ipn' );


/**
 * Processes the payment
 *
 * @since  1.0
 *
 * @param $purchase_data
 */
function give_paytm_process_payment( $purchase_data ) {
	$paytm_redirect = give_paytm_get_api_url();

	// check for any stored errors
	$errors = give_get_errors();
	if ( ! $errors ) {

		/**
		 **************************************
		 * setup the payment details to be stored
		 */
		// setup the payment details
		$payment_data = array(
			'price'           => $purchase_data['price'],
			'give_form_title' => $purchase_data['post_data']['give-form-title'],
			'give_form_id'    => (int) $purchase_data['post_data']['give-form-id'] ,
			'give_price_id'   => isset( $purchase_data['post_data']['give-price-id'] ) ? $purchase_data['post_data']['give-price-id'] : '',
			'date'            => $purchase_data['date'],
			'user_email'      => $purchase_data['user_email'],
			'purchase_key'    => $purchase_data['purchase_key'],
			'currency'        => give_get_currency(),
			'user_info'       => $purchase_data['user_info'],
			'status'          => 'pending',
			'gateway'         => $purchase_data['gateway'],
		);

		// Record the pending payment
		$payment = give_insert_payment( $payment_data );

		// Verify donation payment.
		if ( ! $payment ) {
			// Record the error.
			give_record_gateway_error(
				esc_html__( 'Payment Error', 'give-paytm' ),
				/* translators: %s: payment data */
				sprintf(
					esc_html__( 'Payment creation failed before process PayUmoney gateway. Payment data: %s', 'give-paytm' ),
					json_encode( $purchase_data )
				),
				$payment
			);

			// Problems? Send back.
			give_send_back_to_checkout( '?payment-mode=' . $purchase_data['post_data']['give-gateway'] );
		}

		// Auto set payment to abandoned in one hour if donor is not able to donate in that time.
		wp_schedule_single_event( current_time( 'timestamp', 1 ) + HOUR_IN_SECONDS, 'give_paytm_set_donation_abandoned', array( $payment ) );

		// Set paytm query params.
		$merchant   = give_paytm_get_merchant_credentials();

		$params     = array(
			'MID'              => $merchant['merchant_id'],
			'WEBSITE'          => $merchant['website_name'],
			'CHANNEL_ID'       => 'WEB',
			'ORDER_ID'         => $purchase_data['purchase_key'],
			'INDUSTRY_TYPE_ID' => $merchant['industry_type'],
			'TXN_AMOUNT'       => $purchase_data['price'],
			'CUST_ID'          => $purchase_data['user_email'],
			'EMAIL'            => $purchase_data['user_email'],
			'CALLBACK_URL' => get_site_url() . "/?give-listener=PAYTM_IPN&payment-id={$payment}&form-id={$purchase_data['post_data']['give-form-id']}"
		);

		// Add billing info if admin want to collect donor billing address.
		if ( give_is_setting_enabled( give_get_option( 'paytm_billing_details' ) ) ) {
			$params['ADDRESS_1'] = $purchase_data['post_data']['card_address'];
			$params['ADDRESS_2'] = $purchase_data['post_data']['card_address_2'];
			$params['CITY']      = $purchase_data['post_data']['card_city'];
			$params['STATE']     = $purchase_data['post_data']['card_state'];
			$params['PINCODE']   = $purchase_data['post_data']['card_zip'];
		}

		/**
		 * Filter the Paytm transaction request params
		 *
		 * @since 1.0
		 *
		 * @param array $params
		 */
		$params = apply_filters( 'give_paytm_transaction_request_params', $params );

		$checksum               = getChecksumFromArray( $params, $merchant['merchant_key'] );
		$params['CHECKSUMHASH'] = $checksum;
		$submit_Params          = '';

		foreach ( $params as $key => $val ) {
			$submit_Params .= trim( $key ) . '=' . trim( urlencode( $val ) ) . '&';
		}

		$submit_Params = substr( $submit_Params, 0, - 1 );

		wp_redirect( "{$paytm_redirect}?{$submit_Params}" );
		exit();
	}// End if().

	// if errors are present, send the user back to the purchase page so they can be corrected
	give_send_back_to_checkout( "?payment-mode={$purchase_data['gateway']}&form-id={$purchase_data['post_data']['give-form-id']}" );
}

add_action( 'give_gateway_paytm', 'give_paytm_process_payment' );

