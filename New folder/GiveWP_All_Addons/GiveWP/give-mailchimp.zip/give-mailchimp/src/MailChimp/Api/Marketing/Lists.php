<?php

namespace GiveMailChimp\MailChimp\Api\Marketing;

use GiveMailChimp\MailChimp\ApiClient;
use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;
use stdClass;

/**
 * Class Model
 * @package GiveMailChimp\MailChimp\Marketing\Lists
 * @since 1.5.0
 */
class Lists {
	/**
	 * @var ApiClient
	 */
	private $apiClient;

	/**
	 * Repository constructor.
	 *
	 * @since 1.5.0
	 *
	 * @param  ApiClient  $apiClient
	 */
	public function __construct( ApiClient $apiClient ) {
		$this->apiClient = $apiClient;
	}

	/**
	 * Retrieve MailChimp list interest categories
	 *
	 * @since 1.5.0
	 *
	 * @see https://mailchimp.com/developer/marketing/api/interests/list-interests-in-category/
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 *
	 * @return stdClass
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function getInterestCategories( $listId, $bodyParameters = [] ) {
		$default = [
			'count' => 500,
		];

		$bodyParameters = wp_parse_args( $bodyParameters, $default );

		return $this->apiClient->get(
			"lists/{$listId}/interest-categories",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * @since 1.5.0
	 * @see https://mailchimp.com/developer/marketing/api/interests/list-interests-in-category/
	 *
	 * @param  string  $interestCategoryId
	 * @param  array  $bodyParameters
	 *
	 * @param  string  $listId
	 *
	 * @return stdClass
	 * @throws ApiException|MailchimpApiKeyDoesNotExistException|RequestException
	 */
	public function getInterestCategoryInterests( $listId, $interestCategoryId, $bodyParameters = [] ) {
		return $this->apiClient->get(
			"lists/{$listId}/interest-categories/{$interestCategoryId}/interests",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * Subscribe to MailChimp list by email
	 *
	 * @since 1.5.0
	 * @see https://mailchimp.com/developer/marketing/api/list-members/add-member-to-list/
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 * @param  bool  $skipMergeFieldValidation
	 *
	 * @return stdClass
	 * @throws ApiException
	 * @throws MailchimpApiKeyDoesNotExistException
	 * @throws RequestException
	 */
	public function addListMember( $listId, $bodyParameters, $skipMergeFieldValidation = false ) {
		$tempValeForSkipMergeFieldValidation = $skipMergeFieldValidation ? 'true' : 'false';

		return $this->apiClient->post(
			"lists/{$listId}/members?skip_merge_validation={$tempValeForSkipMergeFieldValidation}",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * Subscribe to MailChimp list by email
	 *
	 * @since 1.5.0
	 * @see https://mailchimp.com/developer/marketing/api/list-members/add-or-update-list-member/
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 * @param  bool  $skipMergeFieldValidation
	 *
	 * @return stdClass
	 * @throws ApiException
	 * @throws MailchimpApiKeyDoesNotExistException
	 * @throws RequestException
	 */
	public function addOrUpdateListMember( $listId, $bodyParameters, $skipMergeFieldValidation = false ) {
		$email     = strtolower( $bodyParameters['email_address'] );
		$emailHash = md5( $email );

		$tempValeForSkipMergeFieldValidation = $skipMergeFieldValidation ? 'true' : 'false';

		return $this->apiClient->put(
			"lists/{$listId}/members/{$emailHash}?skip_merge_validation={$tempValeForSkipMergeFieldValidation}",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * Retrieve MailChimp list merge fields
	 *
	 * @since 1.5.0
	 *
	 * @see https://mailchimp.com/developer/marketing/api/list-merges/list-merge-fields/
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 *
	 * @return stdClass
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function getMergeFields( $listId, $bodyParameters = [] ) {
		return $this->apiClient->get(
			"lists/{$listId}/merge-fields",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * Add new MailChimp list merge field
	 *
	 * @since 1.5.0
	 *
	 * @see https://mailchimp.com/developer/marketing/api/list-merges/add-merge-field/
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 *
	 * @return bool
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function addMergeField( $listId, $bodyParameters ) {
		return $this->apiClient->post(
			"lists/{$listId}/merge-fields",
			$bodyParameters
		)->getResponseBody();
	}

	/**
	 * Retrieve MailChimp lists
	 *
	 * @since 1.5.0
	 *
	 * @param  array  $bodyArguments
	 *
	 * @return stdClass
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function getAllLists( $bodyArguments = [] ) {
		return $this->apiClient->get(
			'lists',
			$bodyArguments
		)->getResponseBody();
	}
}
