<?php
/**
 * Give Tributes Mailed Cards functions.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/includes
 * @author     GiveWP <https://givewp.com>
 */

/**
 * Get Give Tributes Card Content.
 *
 * @since  1.0.0
 *
 * @param int $form_id Form ID.
 *
 * @return string $mail_card_content
 */
function give_tributes_mail_card_get_body_content( $form_id ) {

	if ( give_tributes_is_per_form_customized( $form_id ) ) {
		$mail_card_content = give_get_meta( $form_id, '_give_tributes_per_form_card_content', true );
	} else {
		$mail_card_content = give_get_option( 'give_tributes_card_content' );
	}

	return apply_filters( 'give_tributes_mail_card_get_body_content', wpautop( $mail_card_content ) );
}

/**
 *  Get default Mail a Card Content.
 *
 * @return string $mail_card_content
 */
function give_tributes_get_mail_card_default_content() {

	$mail_card_content = '{donor_fullname} gave {tribute} {honoree_fullname}!' . "\n\n";
	$mail_card_content .= 'The {amount} donation that {donor_name} made {tribute} {honoree_name} is going to help fund our cause and will be put to good use making a difference.';

	return $mail_card_content;
}

/**
 *  Get default Card sent notification content.
 *
 * @return string $card_sent_content
 */
function give_tributes_get_mail_card_sent_notification_content() {

	$card_sent_content = 'Dear {donor_name},' . "\n\n";
	$card_sent_content .= 'This email is to notify you that we have mailed a card on your behalf to:' . "\n\n";
	$card_sent_content .= '{card_address}' . "\n\n";
	$card_sent_content .= '{download_card}' . "\n\n";
	$card_sent_content .= 'With our thanks,' . "\n";
	$card_sent_content .= '{sitename}';

	return $card_sent_content;
}

/**
 *  Get default Mail a Card footer text.
 *
 * @return string $card_default_footer_text
 */
function give_tributes_get_mail_card_default_back_text() {

	$card_default_footer_text = '';
	$site_name                = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$card_default_footer_text .= 'Thank you for giving to ' . $site_name;

	return $card_default_footer_text;
}

/**
 *  Get default receipt content for admin/donor.
 *
 * @since   1.0
 * @updated 4.0
 *
 * @param string $who_sends
 *
 * @return string $give_tribute_admin_receipt_default_content
 */
function give_tributes_default_mail_card_receipt_content( $who_sends = 'admin' ) {

	if ( 'admin' === $who_sends ) {
		$give_tributes_default_mail_card_receipt_content = 'Thank you for your donation {tribute} {honoree_fullname}. Per your request, we will send the notification recipient a card to this address:' . "\n\n";
		$give_tributes_default_mail_card_receipt_content .= '{card_address}' . "\n\n";
		$give_tributes_default_mail_card_receipt_content .= 'You will receive a confirmation email once your card has been mailed.' . "\n\n";
	} else {
		$give_tributes_default_mail_card_receipt_content = 'Thank you for your donation {tribute} {honoree_fullname}. You can send the notification recipient a card to this address:' . "\n\n";
		$give_tributes_default_mail_card_receipt_content .= '{card_address}' . "\n\n";
		$give_tributes_default_mail_card_receipt_content .= 'Below is PDF Download link:' . "\n\n";
		$give_tributes_default_mail_card_receipt_content .= '{download_card}' . "\n\n";
	}

	/**
	 * Modify Tribute Default Receipt content.
	 *
	 * @since 4.0
	 *
	 * @param string $give_tributes_default_mail_card_receipt_content.
	 * @param string $who_sends Is default content for Admin/Donor.
	 */
	return apply_filters( 'give_tributes_default_mail_card_receipt_content', $give_tributes_default_mail_card_receipt_content, $who_sends );
}

/**
 *  Get default Tribute Info content for email tag.
 *
 * @return string $tribute_info_content
 */
function give_tributes_get_tribute_info_content() {

	$tribute_info_content = '{donor_name} has requested that their donation be made {tribute} {honoree_fullname}. Here is the mailing address for this Tribute:' . "\n\n";
	$tribute_info_content .= '{notify_fullname}' . "\n";
	$tribute_info_content .= '{card_address}';
	$tribute_info_content .= '{donor_message}';

	return apply_filters( 'tribute_info_content', $tribute_info_content );
}

/**
 * Output Mail a Card Template Preview Buttons.
 *
 * @since  1.0.0
 *
 * @param int $form_id Form ID.
 */
function give_tributes_mail_card_preview_buttons_callback( $form_id = 0 ) {
	ob_start();
	?>
	<a href="<?php echo esc_url( add_query_arg( array(
		'give_action' => 'preview_mail_card',
		'form_id'     => $form_id,
	), home_url() ) ); ?>" class="button-secondary"
	   target="_blank"><?php _e( 'Preview Card', 'give-tributes' ); ?></a>
	<?php
	echo ob_get_clean();
}

/**
 * Give Tribute Mail Card HTML.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return mixed
 */
function give_tribute_mail_card_build_pdf( $payment_id ) {

	$form_id = give_get_payment_form_id( $payment_id );
	$message = give_tribute_do_tags( give_tributes_mail_card_get_body_content( $form_id ), $payment_id );

	ob_start();

	/**
	 * Fires in the Give Tribute mailCard head.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_mail_card_email_header', $payment_id );

	/**
	 * Fires in the Give Tribute Mail a Card body.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_mail_card_email_body', $payment_id );

	/**
	 * Fires in the Give Tribute Mail a Card footer.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_mail_card_email_footer', $payment_id );

	$body    = ob_get_clean();
	$message = str_replace( '{mail_card_message}', $message, $body );

	return apply_filters( 'give_tribute_mail_card_email_message', $message );

}

/**
 * Give - Tribute Generate Mail a card PDF for General settings preview.
 *
 * Preview Mail a Card for General settings, Report and Per Form.
 *
 * @since 1.0.0
 *
 * @param int  $payment_id          Payment ID.
 * @param bool $is_pdf_downloadable Check whether PDF downloadable or just for Preview.
 */
function give_tributes_mail_card_pdf_generate( $payment_id, $is_pdf_downloadable ) {

	$pdf_unit        = 'in';
	$pdf_page_format = 'LETTER';
	$form_id         = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : give_get_payment_form_id( $payment_id );

	// Global options.
	$card_sizes             = maybe_unserialize( give_get_option( 'give_tributes_card_sizes', array( 'letter' ) ) );
	$mail_card_logo_graphic = give_get_option( 'give_tributes_logo_graphic', '//placehold.it/250x100&text=' . rawurlencode( esc_attr__( 'Placeholder Logo Image', 'give-tributes' ) ) );
	$mail_card_graphic      = give_get_option( 'give_tributes_card_graphic', give_tributes_get_placeholder_image() );
	$card_font              = give_get_option( 'give_tributes_card_font', 'helvetica' );
	$card_font              = give_is_setting_enabled( give_get_option( 'give_tributes_special_chars' ) ) ? 'dejavusans' : $card_font;
	$card_layout            = give_get_option( 'give_tributes_card_layout', 'L' );
	$card_footer_text       = give_get_option( 'give_tributes_card_footer_text', give_tributes_get_mail_card_default_back_text() );

	// Check Per-Form.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {

		$card_sizes = give_get_meta( $form_id, '_give_tributes_per_form_card_sizes', true );
		$card_sizes = ! empty( $card_sizes ) ? $card_sizes : array( 'letter' );

		$mail_card_graphic = give_get_meta( $form_id, '_give_tributes_per_form_card_graphic', true );
		$mail_card_graphic = ! empty( $mail_card_graphic ) ? $mail_card_graphic : give_tributes_get_placeholder_image();

		$mail_card_logo_graphic = give_get_meta( $form_id, '_give_tributes_per_form_logo_graphic', true );
		$mail_card_logo_graphic = ! empty( $mail_card_logo_graphic ) ? $mail_card_logo_graphic : '//placehold.it/250x100&text=' . rawurlencode( esc_attr__( 'Placeholder Logo Image', 'give-tributes' ) );
		$card_font              = give_get_meta( $form_id, '_give_tributes_per_form_card_font', true );
		$card_font              = ! empty( $card_font ) ? $card_font : 'helvetica';
		$special_char           = give_get_meta( $form_id, '_give_tributes_per_form_special_chars', true );
		$card_font              = give_is_setting_enabled( $special_char ) ? 'dejavusans' : $card_font;
		$card_layout            = give_get_meta( $form_id, '_give_tributes_per_form_card_layout', true );
		$card_layout            = ! empty( $card_layout ) ? $card_layout : 'L';
		$card_footer_text       = give_get_meta( $form_id, '_give_tributes_per_form_card_footer_text', true );
		$card_footer_text       = ! empty( $card_footer_text ) ? $card_footer_text : give_tributes_get_mail_card_default_back_text();
	}

	$html      = give_tribute_mail_card_build_pdf( $payment_id );
	$card_font = ( in_array( give_get_currency(), array( 'RIAL', 'RUB', 'IRR' ) ) ) ? 'CODE2000' : $card_font; // Set 'CODE2000' font if Currency is Iranian rial.

	/**
	 * Composer's autoload.php.
	 */
	if ( file_exists( GIVE_PLUGIN_DIR . 'vendor/autoload.php' ) ) {
		require_once GIVE_PLUGIN_DIR . 'vendor/autoload.php';
	} else {
		require_once GIVE_PLUGIN_DIR . 'includes/libraries/tcpdf/tcpdf.php';
	}

	// Create new PDF document.
	$pdf = new TCPDF( $card_layout, $pdf_unit, $pdf_page_format, true, 'UTF-8', false );

	// Set document information.
	$pdf->SetAuthor( apply_filters( 'give_tributes_card_author', get_option( 'blogname' ) ) );
	$pdf->SetTitle( apply_filters( 'give_tributes_card_title', 'Mail a Card' ) );
	$pdf->SetSubject( apply_filters( 'give_tributes_card_subject', 'Mail a Card' ) );
	$pdf->AddFont( 'code2000', '' );

	foreach ( $card_sizes as $card_size ) {
		$pdf_font_size          = ( 'P' === $card_layout ) ? 10 : 12;
		$pdf_image_scale_ration = 2.25;
		$bottom_text_align      = 1.50;
		$logo_align             = 0.50;

		$pdf->setPrintHeader( false ); // Remove default header.
		$pdf->setPrintFooter( false ); // Remove default footer.
		$pdf->SetHeaderMargin( 0 ); // Set Header Margin 0.
		$pdf->SetFooterMargin( 0 ); // Set Footer Margin 0.
		$pdf->SetMargins( 0, 0, 0 ); // Set Margins 0.

		if ( 'letter' === $card_size ) {
			$pdf->setCellPaddings( 15, 0, 15, 0 );
			$pdf_page_format = 'LETTER';
		} elseif ( 'a4' === $card_size ) {
			$pdf->setCellPaddings( 10, 0, 10, 0 );
			$pdf_page_format = 'A4';
		} elseif ( 'a5' === $card_size ) {
			$pdf->setCellPaddings( 7, 0, 7, 0 );
			$pdf_page_format        = 'A5';
			$pdf_font_size          = ( 'P' === $card_layout ) ? 8 : 10;
			$pdf_image_scale_ration = 3.25;
			$bottom_text_align      = 1.00;
		} elseif ( 'a6' === $card_size ) {
			$pdf->setCellPaddings( 7, 0, 7, 0 );
			$pdf_page_format        = 'A6';
			$pdf_font_size          = 6;
			$pdf_image_scale_ration = 6.25;
			$bottom_text_align      = 0.50;
			$logo_align             = 0.25;
		}// End if().

		$pdf->SetFont( apply_filters( 'give_tributes_mail_card_fonts', $card_font ), '', $pdf_font_size, 'false' ); // Set Mail a Card Font with font size.
		$pdf->setImageScale( $pdf_image_scale_ration );  // Set Image scale ratio per page size.
		$pdf->setPageUnit( 'mm' ); // Set Page Unit to 'mm' for HTML Content.
		$pdf->AddPage( $card_layout, $pdf_page_format ); // Add Cover Page.
		$page_width_html  = $pdf->getPageWidth(); // Get Page Width.
		$page_height_html = $pdf->getPageHeight(); // Get Page Height.
		$page_y_html      = $page_height_html / 2; // Get Height of Vertical Portrait.

		if ( 'P' === $card_layout ) {
			$pdf->writeHTMLCell( $w = $page_width_html, $h = '', $x = '', $page_y_html, $html, $border = 0, $ln = 0, $fill = false, $reseth = true, $align = 'C', $autopadding = false );
		} else {
			$cell_height = $pdf->getCellHeight( $pdf_font_size );
			$pdf->writeHTMLCell( $w = '', $h = $page_height_html - $cell_height, $x = $page_width_html / 2, '', $html, $border = 0, $ln = 0, $fill = false, $reseth = true, $align = 'C', $autopadding = false );
		}// End if().

		$pdf->SetAutoPageBreak( true, 0 );// Set Auto Page break 0.

		/**
		 * Code start for Cover image.
		 */
		$pdf->setPrintHeader( false ); // Remove default header.
		$pdf->setPrintFooter( false ); // Remove default footer.
		$pdf->SetHeaderMargin( 0 ); // Set Header Margin 0.
		$pdf->setCellPaddings( 0, 0, 0, 0 ); // Set Cell Margins 0.
		$pdf->setCellMargins( 0, 0, 0, 0 ); // Set Cell Margins 0.
		$pdf->setPageUnit( 'in' ); // Set Page Unit to inch for cover images.

		$pdf->AddPage( $card_layout, $pdf_page_format ); // Add Mail a Card Cover Page.
		$page_width  = $pdf->getPageWidth(); // Get Page Width.
		$page_height = $pdf->getPageHeight(); // Get Page Height.

		// Create columns content.
		$right_column_logo_image = '<img height="200" src="' . $mail_card_logo_graphic . '">';

		// Footer text.
		$right_column_bottom_text = apply_filters( 'give_tributes_mail_card_email_footer_link', $card_footer_text );

		$page_x = ( $page_width / 2 );
		$page_y = ( $page_height / 2 );

		for ( $i = 0; $i < 1; ++ $i ) {

			for ( $j = 0; $j < 2; ++ $j ) {

				if ( 0 === $j ) {
					// Set Image aspect ratio.
					$pdf->setImageScale( PDF_IMAGE_SCALE_RATIO );

					if ( 'P' === $card_layout ) {
						// Write the first column.
						$pdf->Image( $mail_card_graphic, $x = '', $y = $page_y, $w = $page_width, $h = $page_y, $type = '', $link = '', $align = '', $resize = false, $dpi = 300, $palign = '', $ismask = false, $imgmask = false, $border = 0, $fitbox = false, $hidden = false, $fitonpage = false, $alt = false, $altimgs = array() );
					} else {
						$pdf->Image( $mail_card_graphic, $x = $page_x, $y = '', $w = $page_x, $h = $page_height, $type = '', $link = '', $align = '', $resize = false, $dpi = 300, $palign = '', $ismask = false, $imgmask = false, $border = 0, $fitbox = false, $hidden = false, $fitonpage = false, $alt = false, $altimgs = array() );
					}// End if().
				} else {
					// Set Image aspect ratio for logo image for scale it proper.
					$pdf->setImageScale( $pdf_image_scale_ration );

					if ( 'P' === $card_layout ) {
						// Start Transform.
						$pdf->StartTransform();

						// Transform logo and URL to Portrait Mirror.
						$pdf->MirrorP( $page_x, $page_y / 2 );

						// Write the second column.
						$pdf->writeHTMLCell( $w = $page_width, $h = '', $x = '', ( $page_y / 2 ) - $logo_align, $right_column_logo_image, $border = 0, $ln = 0, $fill = false, $reseth = true, $align = 'C', $autopadding = false );
						$pdf->writeHTMLCell( $w = $page_width, $h = '', $x = '', ( $page_y / 2 ) + $bottom_text_align, $right_column_bottom_text, $border = 0, $ln = 2, $fill = false, $reseth = true, $align = 'C', $autopadding = false );

						// Stop Transform.
						$pdf->StopTransform();
					} else {
						// Write the second column.
						$pdf->writeHTMLCell( $w = $page_x, $h = '', $x = '', $page_y - $logo_align, $right_column_logo_image, $border = 0, $ln = 0, $fill = false, $reseth = true, $align = 'C', $autopadding = false );
						$pdf->writeHTMLCell( $w = $page_x, $h = '', $x = '', $page_y + $bottom_text_align, $right_column_bottom_text, $border = 0, $ln = 2, $fill = false, $reseth = true, $align = 'C', $autopadding = false );
					}// End if().
				}
				$pdf->SetAutoPageBreak( false, 0 );
			}// End for().
		}// End for().
		$pdf->SetAutoPageBreak( true, 0 ); // Set Auto page break.
	}// End foreach().

	$pdf->lastPage();

	if ( $is_pdf_downloadable ) {
		// Download Card.
		$pdf->Output( apply_filters( 'give_tributes_mail_card_download_text', 'mail_card_download' ) . '.pdf', wp_is_mobile() ? 'I' : 'D' );
	} else {
		// Preview Card.
		$pdf->Output( apply_filters( 'give_tributes_preview_mail_card_text', 'mail_card_preview' ) . '.pdf', 'I' );
	}
}

/**
 * Give - Tribute Card Sent Notification Email Build.
 *
 * @since 1.0.0
 *
 * @param  int $payment_id Payment ID.
 *
 * @return mixed
 */
function give_tributes_mail_card_notification_build_email( $payment_id ) {

	ob_start();

	/**
	 * Fires in the Give Tribute Mail a Card Notification and Build HTML.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tributes_mail_card_notification_html', $payment_id );

	$body = ob_get_clean();

	return apply_filters( 'give_tributes_mail_card_notification_preview', $body );
}

/**
 * Give - Tribute Card Sent Notification Email.
 *
 * This Notification will sent to Donor when Admin will checked Card Sent checkbox.
 *
 * @since 1.0.0
 *
 * @param  int $payment_id Payment ID.
 */
function give_tributes_mail_card_notification( $payment_id ) {

	// Card Sent Notification from name.
	$from_name = give_get_option( 'from_name', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
	$from_name = apply_filters( 'give_tributes_mail_card_notification_from_name', $from_name );

	// Card Sent Notification from email.
	$from_email = give_get_option( 'from_email', get_bloginfo( 'admin_email' ) );
	$from_email = apply_filters( 'give_tributes_mail_card_notification_from_address', $from_email );
	$to_email   = give_get_meta( $payment_id, '_give_payment_donor_email', true );


	// Card Sent Notification email receipt subject.
	$form_id = give_get_payment_form_id( $payment_id );

	// The eCard email receipt subject.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {
		$subject = give_get_meta( $form_id, '_give_tributes_per_form_card_sent_email_subject', true );
	} else {
		$subject = give_get_option( 'give_tributes_card_sent_email_subject' );
	}

	$subject = ! empty( $subject ) ? $subject : __( 'Card Sent Receipt', 'give-tributes' );
	$subject = apply_filters( 'give_tributes_mail_card_notification_email_subject', $subject );

	/**
	 * Filters the Give Tributes Card Sent Notification email receipt attachments. By default, there is no attachment but plugins can hook in to provide one more multiple for the donor.
	 * Examples would be a printable ticket or PDF receipt.
	 *
	 * @since 1.0.0
	 */
	$attachments = apply_filters( 'give_tributes_mail_card_notification_attachments', array() );

	/**
	 * Filters the Card Sent Notification receipt's email headers.
	 *
	 * @since 1.0.0
	 */
	$headers = "From: {$from_name} <{$from_email}>\r\n";
	$headers .= "Reply-To: {$from_email}\r\n";
	$headers .= "Content-Type: text/html; charset=utf-8\r\n";
	$headers = apply_filters( 'give_tributes_mail_card_notification_headers', $headers );

	// Card notification body.
	$message = give_tributes_mail_card_notification_build_email( $payment_id );

	// Send Card Sent Notification Email.
	wp_mail( $to_email, $subject, $message, $headers, $attachments );
}

/**
 * Placeholder image.
 *
 * @return string
 */
function give_tributes_get_placeholder_image() {

	$image_size = give_get_option( 'give_tributes_card_layout' );

	// Portrait placeholder.
	if ( 'L' === $image_size ) {
		return GIVE_TRIBUTES_PLUGIN_URL . 'assets/images/give-tiger-example.jpg';
	}

	// Landscape placeholder.
	return apply_filters( 'give_tributes_get_placeholder_image',  GIVE_TRIBUTES_PLUGIN_URL . 'assets/images/give-bear-example.jpg' );

}