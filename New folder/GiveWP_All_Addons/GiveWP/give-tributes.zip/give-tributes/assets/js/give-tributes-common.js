/**
 * Give Tributes Frontend JS.
 */

var give_global_vars, give_tributes_public_strings, Give_Tribute, give_tributes_common_vars;

jQuery( document ).ready( function( $ ) {

	var $body = $( 'body' );

	/**
	 * On Change Show dedication.
	 */
	$body.on( 'change', 'input[name="give_tributes_show_dedication"]:radio', function() {
		var form = $( this ).closest( 'form.give-form' );

		if ( 0 === form.length ) {
			form = $( this ).closest( '#give_md_create_payment' );
			if ( ! form ) {
				form = $( this ).parents( 'form' );
			}
		}

		Give_Tribute.give_tributes_show_dedication( form );
	} ).change();

	/**
	 * On Change of Would like to option.
	 */
	$body.on( 'change', 'input[name="give_tributes_would_to"]:radio', function() {
		var form = $( this ).closest( 'form.give-form' );

		if ( 0 === form.length ) {
			form = $( this ).closest( '#give_md_create_payment' );
			if ( ! form ) {
				form = $( this ).parents( 'form' );
			}
		}
		Give_Tribute.give_tributes_would_to( form );

	} ).change();

	/**
	 * Get state list based on Country.
	 */
	$body.on( 'change', 'select[name="give_tributes_address_country"]', function() {
		var $this = $( this ),
			form = $this.closest( 'form.give-form' );

		if ( 0 === form.length ) {
			form = $( this ).closest( '#give_md_create_payment' );
		}
		Give_Tribute.give_tributes_address_country( form );
	} ).change();

	/**
	 * Give Tribute type Buttons: Update tribute type Field based on select.
	 */
	$body.on( 'change touchend click', '.give-tribute-type-button, .give-tribute-type-radio, .give-tributes-type-select', function() {
		var give_tribute_type = $( this ).val(),
			form = $( this ).closest( 'form.give-form' ),
			this_btn = $(this);

		if ( ! form ) {
			form = $( this ).parents( 'form' );
		}

		if ( 0 === form.length ) {
			form = $( this ).closest( '#give_md_create_payment' );

			if ( $( this ).hasClass( 'give-tribute-type-button' ) ) {
				$( form ).find( '.give-tribute-type-button' ).each( function( i, em ) {
					$( this ).removeClass( 'active' );
				} );

				// Add active class.
				this_btn.addClass( 'active' );
			}
		}

		form.find( '.give-tributes-type' ).val( give_tribute_type );
	} );

	/**
	 * Character count logic for eCard.
	 */
	$body.on( 'keyup change', 'textarea.give-tributes-personalized-message, textarea[name="give-tributes-mail-card-personalized-message"]', function() {
		var $this = $( this );

		$this
			.closest( '.give_tributes_send_ecard_fields' )
			.find( '.give-tributes-ecard-personalized-message-left' )
			.text( parseInt( $this.attr( 'maxlength' ) ) - $this.val().length + ' ' + give_tributes_common_vars.give_tribute_characters_left );
	} );

	/**
	 * Character count logic for Mail card.
	 */
	$body.on( 'keyup change', 'textarea[name="give-tributes-mail-card-personalized-message"]', function() {
		var $this = $( this );

		$this
			.closest( '.give_tributes_mail_card_personalized_message' )
			.find( '.give-tributes-mail-card-personalized-message-left' )
			.text( parseInt( $this.attr( 'maxlength' ) ) - $this.val().length + ' ' + give_tributes_common_vars.give_tribute_characters_left );
	} );

	/**
	 * Control repeater for notification field.
	 *
	 * @since 1.0
	 */
	$( document ).on( 'click', 'span.give-tributes-clone-field', function( e ) {

		// Prevent Default.
		e.preventDefault();

		var form = $( this ).closest( 'form.give-form' ),
			lists_container = $( this ).closest( '.give-tributes-notification-lists' );

		if ( 0 === form.length ) {
			form = $( this ).closest( '#give_md_create_payment' );

			if ( ! form ) {
				form = $( this ).parents( 'form' );
			}
		}

		// Get the button action.
		var btn_action = jQuery( this ).data( 'action' ),
			recipient_fields = $( this ).closest( '.give_tributes_send_ecard_fields' ),
			count_recipient = lists_container.find( '.give_tributes_send_ecard_fields' ).length,
			max_length = recipient_fields.find( 'textarea.give-tributes-personalized-message' ).attr( 'maxlength' ),
			form_id = form.find( 'input[name="give-form-id"]' ).val(),
			recipient_count = 0;

		// If 'add' action were requested.
		if ( 'add' === btn_action ) {

			// Limit exceed after 5 receipts.
			if ( count_recipient >= 5 ) {
				alert( give_tributes_public_strings.give_tribute_receipt_limit_exceed );
				return false;
			}

			// Increase recipient count.
			recipient_count = recipient_count + 1;

			// Wrap receipt field-set into a div container.
			recipient_fields = '<div id="give-tributes-send-ecard-fields-' + form_id + '-recipient-' + (recipient_count) + '" class="' + recipient_fields.attr( 'class' ) + ' cloned-field" >' + recipient_fields.html() + '</div>';

			var appended_html = lists_container.append( recipient_fields ),
				notify_person_section = jQuery( '#give-tributes-send-ecard-fields-' + form_id + '-recipient-' + recipient_count );

			// Loop all the label
			notify_person_section.find( '.give-label' ).each( function( em, i ) {

				var $this = $( this ),
					attr_for = $this.attr( 'for' ),
					new_id = attr_for + '-' + recipient_count;

				$( this ).attr( 'for', new_id );
				notify_person_section.find( 'input#' + attr_for + ',textarea#' + attr_for ).attr( 'id', new_id );
			} );

			var character_left = appended_html.find( '.cloned-field .give-tributes-ecard-personalized-message-left' );

			if ( character_left.length > 0 ) {
				character_left.html( character_left.html().replace( /\d+/, max_length ) );
			}

			// Add recipient field.
			appended_html.find( '.cloned-field input' ).val( '' ).closest( '.cloned-field' ).removeClass( 'cloned-field' );

			if ( ! $( this ).closest( '#give_md_create_payment' ) ) {

				// Floating labels.
				give_fl_trigger();
			}

		} else if ( 'remove' === btn_action ) {
			// If the action is about to remove the fieldset.

			// Do not remove if, its last recipient.
			if ( count_recipient <= 1 ) {
				return false;
			}

			// Remove receipt set group.
			jQuery( this ).closest( '.give_tributes_send_ecard_fields' ).remove();

		}

		// Remove Cross sign.
		Give_Tribute.remove_cross_sign();

	} );

	/**
	 * Give Tribute init.
	 */
	Give_Tribute = {

		/**
		 * Init.
		 */
		init: function() {
			var forms = $( 'form.give-form' );

			// If there is no form element then trigger init() function for manual donation.
			if ( 0 === forms.length ) {
				// Get the form from manual donation creation.
				Give_Tribute.initial_trigger( $( '#give_md_create_payment' ) );

				$( '#give_md_create_payment' ).find( 'button.give-tribute-type-button' ).each( function( i, em ) {
					if ( i === 0 ) {
						$( this ).addClass( 'active' );
					}
					$( this ).addClass( 'button' );
				} );
			} else {
				forms.each( function() { Give_Tribute.initial_trigger( $( this ) ); } );
			}
		},

		/**
		 * Initial load
		 *
		 * @since 1.4.1
		 *
		 * @param $form
		 */
		initial_trigger: function( $form ) {
			Give_Tribute.give_tributes_show_dedication( $form );
			Give_Tribute.give_tributes_would_to( $form );
			Give_Tribute.remove_cross_sign();
		},

		/**
		 * Show dedication.
		 *
		 * @param $form
		 */
		give_tributes_show_dedication: function( $form ) {

			var form_id = Give_Tribute.getFormID( $form ),
				value = $form.find( 'input[name="give_tributes_show_dedication"]:radio:checked' ).val(),
				tribute_type_wrap = $form.find( '#give-tributes-type-wrap-' + form_id ),
				tribute_info_wrap = $form.find( '#give-tributes-info-wrap-' + form_id ),
				tribute_grab_info_wrap = $form.find( '#give-tributes-grab-info-wrap-' + form_id ),
				tribute_mail_card_fields = $form.find( '#give-tributes-mail-card-fields-' + form_id ),
				tribute_ecard_fields = $form.find( '#give-tributes-notification-list-' + form_id ),
				give_tribute_type = $form.find( '.give-tributes-type-button-list li:first button' ).val(),
				give_tribute_email = $( '#give_md_create_payment tr.give-tributes-row.give-tributes-email-option' );

			if ( tribute_type_wrap.hasClass( 'has_radios' ) ) {
				give_tribute_type = $form.find( 'input[name="give_tributes_radio_type"]:radio:checked' ).val();
			} else if ( tribute_type_wrap.hasClass( 'has_dropdown' ) ) {
				give_tribute_type = $form.find( '.give-tributes-type-select option:first' ).val();
			}

			var give_tribute_type_append_value = $form.find( '.give-tributes-type-' + form_id );
			give_tribute_type_append_value.val( give_tribute_type );

			// If enable show other fields.
			if ( 'no' === value ) {

				// Hide it.
				tribute_type_wrap.hide();
				tribute_info_wrap.hide();
				tribute_grab_info_wrap.hide();
				tribute_mail_card_fields.hide();
				tribute_ecard_fields.hide();
				give_tribute_email.hide();

				tribute_type_wrap.closest( 'tr.give-tributes-row' ).hide();
				tribute_info_wrap.closest( 'tr.give-tributes-row' ).hide();
				tribute_grab_info_wrap.closest( 'tr.give-tributes-row' ).hide();
				tribute_mail_card_fields.closest( 'tr.give-tributes-row' ).hide();
				tribute_ecard_fields.closest( 'tr.give-tributes-row' ).hide();
			} else {

				// Otherwise, show rest of fields.
				tribute_type_wrap.show();
				tribute_info_wrap.show();
				tribute_grab_info_wrap.show();
				tribute_mail_card_fields.show();
				tribute_ecard_fields.show();
				give_tribute_email.show();

				// Show manual donation entities.
				tribute_type_wrap.closest( 'tr.give-tributes-row' ).show();
				tribute_info_wrap.closest( 'tr.give-tributes-row' ).show();
				tribute_grab_info_wrap.closest( 'tr.give-tributes-row' ).show();
				tribute_mail_card_fields.closest( 'tr.give-tributes-row' ).show();
				tribute_ecard_fields.closest( 'tr.give-tributes-row' ).show();

				$( 'input[name="give_tributes_would_to"]:radio' ).trigger( 'change' );
			}// End if().
		},

		/**
		 *
		 * @param $form
		 */
		give_tributes_would_to: function( $form ) {

			var form_id = Give_Tribute.getFormID( $form ),
				give_tributes_would_like_to = $form.find( '#give-tributes-grab-info-wrap-' + form_id + ' input[name="give_tributes_would_to"]:radio:checked' ).val(),
				give_tributes_mail_card_fields = $form.find( '#give-tributes-mail-card-fields-' + form_id ),
				give_tributes_ecard_fields = $form.find( '.give-tributes-notification-lists' ),
				give_tribute_email = $( '#give_md_create_payment tr.give-tributes-row.give-tributes-email-option' );

			if ( 'send_eCard' === give_tributes_would_like_to ) {
				give_tributes_ecard_fields.show();
				give_tributes_ecard_fields.closest( 'tr.give-tributes-row' ).show(); // Manual Donation.

				give_tributes_mail_card_fields.hide();
				give_tributes_mail_card_fields.closest( 'tr.give-tributes-row' ).show(); // Manual Donation.
				give_tribute_email.show();

			} else if ( 'send_mail_card' === give_tributes_would_like_to ) {
				give_tributes_ecard_fields.hide();
				give_tributes_mail_card_fields.show();

				give_tributes_ecard_fields.closest( 'tr.give-tributes-row' ).show(); // Manual Donation.
				give_tribute_email.hide();

			} else {
				give_tributes_ecard_fields.hide();
				give_tributes_mail_card_fields.hide();

				give_tributes_mail_card_fields.closest( 'tr.give-tributes-row' ).hide(); // Manual Donation.
				give_tributes_ecard_fields.closest( 'tr.give-tributes-row' ).hide(); // Manual Donation.
				give_tribute_email.hide();
			}
		},

		/**
		 * Tributes Mail a Card Address Country Change.
		 *
		 * @param $form
		 */
		give_tributes_address_country: function( $form ) {

			var form_id = Give_Tribute.getFormID( $form ),
				state_wrap = $form.find( '#give-tributes-mail-card-state-' + form_id ),
				default_country = $form.find( '#give_tributes_address_country_' + form_id ).val();

			if ( 'undefined' !== typeof(default_country) && '' !== default_country ) {
				var data = {
					action: 'give_get_states',
					country: default_country,
					field_name: 'give_tributes_address_state',
					form_id: form_id
				};

				$.post( give_tributes_common_vars.ajax_url, data, function( response ) {

					state_wrap.find( '*' ).not( '.give_tributes_address_state_label, span' ).remove();

					// Show the states dropdown menu.
					state_wrap.removeClass( 'give-hidden' );

					// Add support to zip fields.
					$form.find( '.give_tributes_adjust_zip' ).removeClass( 'form-row-wide' );
					$form.find( '.give_tributes_adjust_zip' ).addClass( 'form-row-last' );

					if ( 'undefined' !== typeof(response.states_found) && true === response.states_found ) {
						state_wrap.append( response.data );
					} else {
						state_wrap.append( '<input aria-required="true" name="give_tributes_address_state" id="give_tributes_address_state_' + form_id + '" class="text give-input required" type="text" value="" />' );

						if ( 'undefined' !== typeof(response.show_field) && false === response.show_field ) {
							// Hide the states drop-down menu.
							state_wrap.addClass( 'give-hidden' );

							// Add support to zip fields.
							$form.find( '.give_tributes_adjust_zip' ).addClass( 'form-row-wide' );
							$form.find( '.give_tributes_adjust_zip' ).removeClass( 'form-row-last' );
						}
					}
				} );
			}
		},

		/**
		 * Get the Donation form Id from the manual donation page
		 * or from front-end donation form.
		 *
		 * @since 1.4.1
		 *
		 * @param $form
		 * @returns {*}
		 */
		getFormID: function( $form ) {

			// Get the form ID.
			var form_id = $form.find( 'input[name="give-form-id"]' ).val();

			// If form id is undefined.
			if ( undefined === form_id ) {
				form_id = jQuery( 'select[name="forms[id]"]' ).val();
			}

			return form_id;
		},

		/**
		 * Remove cross sign for the first repeater field.
		 */
		remove_cross_sign: function() {
			var ecard_fields = jQuery( '.give_tributes_send_ecard_fields' );

			ecard_fields.each( function( index ) {
				$( this ).find( '.give-icon-minus' ).parent().show();

				if ( 0 === index && 1 === ecard_fields.length ) {
					$( this ).find( '.give-icon-minus' ).parent().hide();
				}
			} );
		}
	};

	// Give Tribute init.
	Give_Tribute.init();
});