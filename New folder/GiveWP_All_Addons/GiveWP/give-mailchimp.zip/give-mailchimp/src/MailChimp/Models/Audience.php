<?php

namespace GiveMailChimp\MailChimp\Models;

use GiveMailChimp\MailChimp\Models\Contracts\MailChimpApiDataModel;

/**
 * Class Audience
 * @package GiveMailChimp\MailChimp\Models
 * @since 1.5.0
 * @property-read string $id
 * @property-read string $name
 */
class Audience extends MailChimpApiDataModel {
}
