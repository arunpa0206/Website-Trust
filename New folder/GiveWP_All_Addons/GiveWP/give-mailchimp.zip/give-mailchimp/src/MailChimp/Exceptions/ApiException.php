<?php

namespace GiveMailChimp\MailChimp\Exceptions;

/**
 * Class ApiException
 * @package GiveMailChimp\MailChimp\Exceptions
 * @since 1.5.0
 */
class ApiException extends \Exception {
	protected $responseHeaders;
	protected $responseBody;

	/**
	 * ApiException constructor.
	 *
	 * @param $message
	 * @param  int  $code
	 * @param  null  $headers
	 * @param  null  $body
	 */
	public function __construct( $message, $code = 0, $headers = null, $body = null ) {
		parent::__construct( $message, $code );

		$this->responseHeaders = $headers;
		$this->responseBody    = $body;
	}

	/**
	 * @since 1.5.0
	 */
	public function getResponseHeader() {
		return $this->responseHeaders;
	}

	/**
	 * @since 1.5.0
	 */
	public function getResponseBody() {
		return $this->responseBody;
	}
}
