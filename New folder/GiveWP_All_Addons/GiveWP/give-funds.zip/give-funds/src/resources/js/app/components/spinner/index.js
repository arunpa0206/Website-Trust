import './style.scss';

const Spinner = () => {
	return (
		<div className="givewp-spinner"> </div>
	);
};

export default Spinner;
