=== Give - Paytm Gateway ===
Contributors: givewp
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, paytm, gateway
Requires at least: 4.8
Tested up to: 5.1
Requires Give: 2.4.1
Stable tag: 1.1.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Paytm Gateway Add-on for Give.

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds a payment gateway for paytm.com.

== Installation ==

= Minimum Requirements =

* WordPress 4.8 or greater
* PHP version 5.3 or greater
* MySQL version 5.0 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.1.0: February 20th, 2019 =
* New: Updated the Paytm API to the latest version.
* Fix: Removed deprecated functions and completed code audit.

= 1.0.1: September 13th, 2018 =
* Fix: Resolved conflicts with other plugins using the PayTM SDK like Woo and WP Paytm Pay.
* Tweak: Don't deactivate plugin when Give Core is not active but rather show message.

= 1.0.0 =
* Initial plugin release. Yippee!
