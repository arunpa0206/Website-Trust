<?php

namespace GiveMailChimp\Infrastructure;

/**
 * Class Log
 *
 * @package GiveMailChimp\Infrastructure
 * @since 1.5.0
 *
 */
class Log extends \Give\Log\Log {
	/**
	 * @inheritDoc
	 * @since 1.5.0
	 *
	 * @param  string  $type
	 * @param  array  $args
	 */
	public static function __callStatic( $type, $args ) {
		$args[1]['source'] = 'Give Mailchimp';

		parent::__callStatic( $type, $args );
	}

}
