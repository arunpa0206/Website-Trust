<table id="fresh_blue" class="fresh_blue" style="margin: 0; padding: 0; color: #333; height: 100%; background-color: #ededed; max-height: 100%; min-height: 100%;" border="0" width="100%">
	<tbody>
	<tr>
		<td width="100%">
			<table style="margin: 0; padding: 0;" border="0" width="100%">
				<tbody>
				<tr>
					<td style="font-family: Helvetica; background-color: #4d596b; font-size: 14px; color: #fff; font-style: italic; line-height: 40px; text-align:center;" align="center" valign="middle" width="100%">Your tagline here</td>
				</tr>
				</tbody>
			</table>
		</td>
	</tr>
	<tr>
		<td width="100%"></td>
	</tr>
	<tr>
		<td width="100%">
			<table style="margin: 0; padding: 0;" border="0" width="100%">
				<tbody>
				<tr>
					<td style="text-align:center;"  align="center" valign="middle" width="100%"><img class="aligncenter size-medium wp-image-13" src="%assets_url%/images/logo_placeholder.png" alt="" width="300" height="127" /></td>
				</tr>
				</tbody>
			</table>
		</td>
	</tr>
	<tr>
		<td width="100%"></td>
	</tr>
	<tr>
		<td width="100%">
			<table style="margin: 0; padding: 0;" border="0" width="100%">
				<tbody>
				<tr>
					<td class="width_27_5" width="15%"></td>
					<td class="width_45" style="min-width:600px;" align="center" width="70%">
						<table style="margin: 0; padding: 0; background-color: #fff; border: 1px solid #dedede; text-align:center;" border="0" width="100%">
							<tbody>
							<tr>
								<td width="100%">
									<table style="margin: 0; padding: 0;" border="0" width="100%">
										<tbody>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-size: 24px; font-weight: bold; line-height: 30px; text-align:center;" align="center" width="100%">Organization Name</td>
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-style: italic; font-size: 16px; line-height: 1.75; text-align:center;" align="center"  width="100%">123 Street Address</td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-style: italic; font-size: 16px; line-height: 1.75; text-align:center;" align="center"
											    width="100%">City, State, Zip</td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-style: italic; font-size: 16px; line-height: 1.75; text-align:center;" align="center" width="100%">Tel: 1.888.555.5555</td>
										</tr>
										<tr>
											<td align="center" width="100%"></td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-size: 16px; font-weight: bold; line-height: 1.75; text-align:center;" align="center" width="100%">Website: <a style="color: #51aef0; text-decoration: none;" href="http://mywebsite.org">http://mywebsite.org</a></td>
										</tr>
										<tr>
											<td style="font-family: Helvetica; font-size: 16px; font-weight: bold; line-height: 1.75; text-align:center;" align="center" width="100%">Email: <a style="color: #51aef0; text-decoration: none;" href="email@hotmail.com">email@hotmail.com</a></td>
										</tr>
										<tr>
											<td align="center" width="100%"></td>
										</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="font-family: Helvetica; background-color: #4d596b; font-size: 20px; color: #fff; font-weight: bold; line-height: 40px; text-align:center;" align="center" valign="middle" width="100%">Receipt of Charitable Donation</td>
							</tr>
							<tr>
								<td width="100%">
									<table style="margin: 0; padding: 0; background-color: #f8f8f8;" border="0" width="100%">
										<tbody>
										<tr>
											<td colspan="3" width="10%"></td>
											<td width="80%">
												<table style="margin: 0px; padding: 0px; background-color: #f8f8f8;" border="0" width="100%">
													<tbody>
													<tr>
														<td width="100%"></td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px; line-height: 1.75;" align="center" width="100%">This is an official tax receipt issued by *Organization Name* - a non-profit agency located in the *Country Name*.</td>
													</tr>
													<tr>
														<td width="100%"></td>
													</tr>
													<tr>
														<td width="100%">
															<table style="margin: 0; padding: 0; background-color: #f8f8f8;" border="0" width="100%">
																<tbody>
																<tr>
																	<td style="font-family: Helvetica; font-weight: bold; font-size: 16px;" align="left" valign="middle" width="100%">Invoice to:</td>
																</tr>
																<tr>
																	<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%">{full_name}</td>
																</tr>
																<tr>
																	<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%">{billing_address}</td>
																</tr>
																</tbody>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%"></td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Payment ID:</strong> {payment_id}</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Transaction Key:</strong> {transaction_key}</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Transaction ID:</strong> {transaction_id}</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Donation Status:</strong> {payment_status}</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Payment Method:</strong> {payment_method}</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Donation Name:</strong> {donation_name}</td>
													</tr>
													<tr>
														<td style="font-size: 16px;" align="left" valign="middle" width="100%">
															<strong style="font-family: Helvetica;">Donation Amount:</strong> {amount}
														</td>
													</tr>
													<tr>
														<td style="font-family: Helvetica; font-size: 16px;" align="left" valign="middle" width="100%"><strong>Donation Date:</strong> {date}</td>
													</tr>
													<tr>
														<td width="100%"></td>
													</tr>
													</tbody>
												</table>
											</td>
											<td colspan="3" width="10%"></td>
										</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%">
									<table style="font-family: Helvetica; margin: 0; padding: 0; border-top: 1px solid #dedede;" border="0" width="100%">
										<tbody>
										<tr>
											<td colspan="3" width="100%"></td>
										</tr>
										<tr>
											<td width="10%"></td>
											<td style="text-align: justify; font-size: 16px; line-height: 1.75; font-weight: 400;" width="80%">Seductaque tepescunt nullo fuit. Obliquis motura circumfluus. Omnia terram pace nunc. Militis arce mortales et. Sui regio vindice caelo sui! Tuti natura capacius illic turba obliquis orbem abdeorum! Naturae colebat locis sinistra pronaque semina! Ubi duae</td>
											<td width="10%"></td>
										</tr>
										<tr>
											<td colspan="3" width="100%"></td>
										</tr>
										</tbody>
									</table>
								</td>
							</tr>
							</tbody>
						</table>
					</td>
					<td class="width_27_5" width="15%"></td>
				</tr>
				<tr>
					<td></td>
				</tr>
				</tbody>
			</table>
		</td>
	</tr>
	</tbody>
</table>
