<?php
namespace GiveManualDonations\Revenue;

use Give\Revenue\Repositories\Revenue;

/**
 * Class DonationHandler
 * @package GiveManualDonations\Revenue
 *
 * @since 1.4.8
 */
class DonationHandler {
	/**
	 * Add revenue when create new donation manually.
	 *
	 * @param int $donationId
	 *
	 * @since 1.4.8
	 */
	public function handle( $donationId ) {
		/* @var Revenue $revenueRepository */
		$revenueRepository = give( Revenue::class );
		/* @var \Give\Revenue\DonationHandler $donationHandler*/
		$donationHandler = give( \Give\Revenue\DonationHandler::class );

		$revenueData = $donationHandler->getData( $donationId );

		$fundId = isset( $_POST['give-selected-fund'] ) ? (int) $_POST['give-selected-fund'] : 0;
		if ( $fundId ) {
			$revenueData['fund_id'] = $fundId;
		}

		$revenueRepository->insert( $revenueData );
	}
}
