/**
 * Give - Sofort Gateway Add-on ADMIN JS
 */
var give_admin_sofort_vars;
jQuery.noConflict();
(function ($) {

    //On DOM Ready
    $(function () {


    });

})(jQuery);