<?php
// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Process donation for CCAvenue.
 *
 * @param $donation_data
 */
function give_process_ccavenue_payment( $donation_data ) {

	if ( ! wp_verify_nonce( $donation_data['gateway_nonce'], 'give-gateway' ) ) {
		wp_die(
			esc_html__( 'Nonce verification has failed.', 'give-ccavenue' ), esc_html__( 'Error', 'give-ccavenue' ), array(
				'response' => 403,
			)
		);
	}

	$form_id  = intval( $donation_data['post_data']['give-form-id'] );
	$price_id = isset( $donation_data['post_data']['give-price-id'] ) ? $donation_data['post_data']['give-price-id'] : '';

	// Collect payment data.
	$donation_payment_data = array(
		'price'           => $donation_data['price'],
		'give_form_title' => $donation_data['post_data']['give-form-title'],
		'give_form_id'    => $form_id,
		'give_price_id'   => $price_id,
		'date'            => $donation_data['date'],
		'user_email'      => $donation_data['user_email'],
		'purchase_key'    => $donation_data['purchase_key'],
		'currency'        => give_get_currency( $form_id ),
		'user_info'       => $donation_data['user_info'],
		'status'          => 'pending',
		'gateway'         => 'ccavenue',
	);

	// Record the pending payment.
	$donation_id = give_insert_payment( $donation_payment_data );

	// Verify donation payment.
	if ( ! $donation_id ) {
		// Record the error.
		give_record_gateway_error(
			esc_html__( 'Payment Error', 'give-ccavenue' ),
			/* translators: %s: payment data */
			sprintf( esc_html__( 'Payment creation failed before process CCAvenue gateway. Payment data: %s', 'give-ccavenue' ), wp_json_encode( $donation_payment_data ) ),
			$donation_id
		);

		// Problems? Send back.
		give_send_back_to_checkout( '?payment-mode=' . $donation_data['post_data']['give-gateway'] );
	}

	// Add phone number field value to donation meta, once pending donation is created.
	if ( isset( $donation_data['post_data']['give_ccavenue_phone'] ) ) {

		// Sanitize phone number.
		$phone_number = give_clean( $donation_data['post_data']['give_ccavenue_phone'] );

		// Add phone number data to donation meta.
		Give()->payment_meta->update_meta( $donation_id, '_give_ccavenue_phone_number', $phone_number );
	}

	// Redirect to ccavenue checkout page.
	wp_safe_redirect( home_url( "/?process_ccavenue_payment=processing&donation={$donation_id}&form-id={$form_id}" ) );
}

add_action( 'give_gateway_ccavenue', 'give_process_ccavenue_payment' );
