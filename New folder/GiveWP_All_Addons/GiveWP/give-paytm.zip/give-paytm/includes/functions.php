<?php
/**
 * Check if paytm gateways in test mode or not
 *
 * @since 1.0
 *
 * @return bool
 */
function give_paytm_is_test_mode() {
	return apply_filters( 'give_paytm_is_test_mode', give_is_test_mode() );
}

/**
 * Get paytm api url.
 *
 * @since 1.0
 *
 * @param string $type API query type
 *
 * @return string
 */
function give_paytm_get_api_url( $type = 'processTransaction' ) {
	$paytm_redirect = '';

	switch ( $type ) {
		case 'processTransaction':
			$paytm_redirect = give_paytm_is_test_mode() ?
				'https://securegw-stage.paytm.in/theia/processTransaction'
				: 'https://securegw.paytm.in/theia/processTransaction';
			break;

		case 'TxnStatus':
			$paytm_redirect = give_paytm_is_test_mode() ?
				'https://securegw-stage.paytm.in/merchant-status/getTxnStatus'
				: 'https://securegw.paytm.in/merchant-status/getTxnStatus';
	}

	return apply_filters( 'give_paytm_get_api_url', $paytm_redirect );
}

/**
 * Get payment method label.
 *
 * @since 1.0
 *
 * @return string
 */
function give_paytm_get_payment_method_label() {
	$checkout_label = give_get_option( 'paytm_checkout_label', '' );

	return ( empty( $checkout_label )
		? __( 'Paytm', 'give-paytm' )
		: $checkout_label
	);
}


/**
 * Get paytm merchant credentials.
 *
 * @since 1.0
 * @return array
 */
function give_paytm_get_merchant_credentials() {
	$credentials = array(
		'merchant_id'   => give_get_option( 'paytm_sandbox_merchant_id', '' ),
		'merchant_key'  => give_get_option( 'paytm_sandbox_mer_access_key', '' ),
		'website_name'  => give_get_option( 'paytm_sandbox_website_name', '' ),
		'industry_type' => give_get_option( 'paytm_sandbox_industry_type', '' ),
	);

	if ( ! give_paytm_is_test_mode() ) {
		$credentials = array(
			'merchant_id'   => give_get_option( 'paytm_live_merchant_id', '' ),
			'merchant_key'  => give_get_option( 'paytm_live_mer_access_key', '' ),
			'website_name'  => give_get_option( 'paytm_live_website_name', '' ),
			'industry_type' => give_get_option( 'paytm_live_industry_type', '' ),
		);
	}

	return $credentials;

}
