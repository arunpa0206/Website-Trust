<?php
/**
 * Plugin Name: Give - Donation Upsells for WooCommerce
 * Plugin URI:  https://givewp.com/addons/donation-upsells-for-woocommerce/
 * Description: Allow your shop customers to donate at the cart or checkout in WooCommerce.
 * Version:     1.1.6
 * Author:      GiveWP
 * Author URI:  https://givewp.com
 * Text Domain: give-woocommerce
 * Domain Path: /languages
 * WC requires at least: 3.0.0
 * WC tested up to: 4.0.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Check if class isn't already exists.
if ( ! class_exists( 'Give_WooCommerce' ) ) {

	/**
	 * Class Give_WooCommerce
	 *
	 * @since 1.0.0
	 */
	class Give_WooCommerce {

		/**
		 * @since 1.0.0
		 *
		 * @var Give_WooCommerce The reference the singleton instance of this class.
		 */
		private static $instance;

		/**
		 * Notices (array)
		 *
		 * @since 1.0.0
		 *
		 * @var array
		 */
		public $notices = array();

		/**
		 * Returns the singleton instance of this class.
		 *
		 * @since 1.0.0
		 * @return Give_WooCommerce The singleton instance.
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Setup Give WooCommerce.
		 *
		 * @since  1.0.0
		 * @access private
		 */
		private function setup() {

			// Setup constants.
			$this->setup_constants();

			// Give init hook.
			add_action( 'give_init', array( $this, 'init' ), 10 );
			add_action( 'admin_init', array( $this, 'check_environment' ), 999 );
			add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );

			/**
			 * Filter added for display Settings and Documentation links in plugin page.
			 *
			 * @since 1.0.4
			 */
			add_filter( 'plugin_action_links_' . GIVE_WOOCOMMERCE_BASENAME, array( $this, 'action_links' ), 10, 2 );
			add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );
		}


		/**
		 * Init the plugin after plugins_loaded so environment variables are set.
		 *
		 * @since 1.0.0
		 */
		public function init() {

			$this->licensing();
			load_plugin_textdomain( 'give-woocommerce', false, GIVE_WOOCOMMERCE_PLUGIN_DIR . '/languages' );

			if ( ! $this->get_environment_warning() ) {
				return;
			}

			$this->includes();
			$this->activation_banner();

			// Register WooCommerce payment gateway.
			add_filter( 'give_payment_gateways', array( $this, 'register_woocommerce_gateway' ), 10, 1 );

			// Load pot language file.
		}

		/**
		 * Register WooCommerce Gateway.
		 *
		 * @since 1.0.0
		 *
		 * @param array $gateways Give gateways list.
		 *
		 * @return array
		 */
		public function register_woocommerce_gateway( $gateways ) {
			// Include all of the helper functions.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/class-give-woocommerce-gateway.php';

			$gateways['woocommerce'] = array(
				'admin_label'    => __( 'WooCommerce', 'give-woocommerce' ),
				'checkout_label' => __( 'WooCommerce', 'give-woocommerce' ),
			);

			return $gateways;
		}

		/**
		 * Implement Give Licensing for Give WooCommerce Add On.
		 *
		 * @since  1.0.0
		 * @access private
		 */
		private function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License(
					GIVE_WOOCOMMERCE_PLUGIN_FILE,
					'Donation Upsells for WooCommerce',
					GIVE_WOOCOMMERCE_VERSION,
					'WordImpress'
				);
			}
		}

		/**
		 * Define constants
		 *
		 * @since 1.0.0
		 */
		public function setup_constants() {

			/**
			 * Define constants.
			 *
			 * Required minimum versions, paths, urls, etc.
			 */
			if ( ! defined( 'GIVE_WOOCOMMERCE_VERSION' ) ) {
				define( 'GIVE_WOOCOMMERCE_VERSION', '1.1.6' );
			}
			if ( ! defined( 'GIVE_WOOCOMMERCE_MIN_GIVE_VER' ) ) {
				define( 'GIVE_WOOCOMMERCE_MIN_GIVE_VER', '2.4.0' );
			}
			if ( ! defined( 'GIVE_WOOCOMMERCE_PLUGIN_FILE' ) ) {
				define( 'GIVE_WOOCOMMERCE_PLUGIN_FILE', __FILE__ );
			}
			if ( ! defined( 'GIVE_WOOCOMMERCE_PLUGIN_DIR' ) ) {
				define( 'GIVE_WOOCOMMERCE_PLUGIN_DIR', dirname( GIVE_WOOCOMMERCE_PLUGIN_FILE ) );
			}
			if ( ! defined( 'GIVE_WOOCOMMERCE_PLUGIN_URL' ) ) {
				define( 'GIVE_WOOCOMMERCE_PLUGIN_URL', plugin_dir_url( GIVE_WOOCOMMERCE_PLUGIN_FILE ) );
			}
			if ( ! defined( 'GIVE_WOOCOMMERCE_BASENAME' ) ) {
				define( 'GIVE_WOOCOMMERCE_BASENAME', plugin_basename( GIVE_WOOCOMMERCE_PLUGIN_FILE ) );
			}
		}

		/**
		 * Include required files
		 *
		 * @since 1.0.0
		 */
		public function includes() {
			// Give WooCommerce custom exception handling.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/class-give-wc-exception.php';

			// Give WooCommerce add-on's all of the Admin functionality.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/class-give-woocommerce-admin.php';

			// Give WooCommerce add-on's front-end functionality.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/class-give-woocommerce-frontend.php';

			// Include all of the helper functions.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/give-woocommerce-helper.php';

			// Keep WC Order and Give Donation sync.
			require_once GIVE_WOOCOMMERCE_PLUGIN_DIR . '/includes/class-give-woocommerce-sync.php';
		}

		/**
		 * Check plugin environment.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @return bool
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/* Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for the Donation Upsells for WooCommerce to activate.', 'give-woocommerce' ), 'https://givewp.com' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Check plugin for Give environment.
		 *
		 * @since  1.0.4
		 * @access public
		 *
		 * @return bool
		 */
		public function get_environment_warning() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if (
				defined( 'GIVE_VERSION' )
				&& version_compare( GIVE_VERSION, GIVE_WOOCOMMERCE_MIN_GIVE_VER, '<' )
			) {

				/* Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> core version %s for the Donation Upsells for WooCommerce add-on to activate.', 'give-woocommerce' ), 'https://givewp.com', GIVE_WOOCOMMERCE_MIN_GIVE_VER ) );

				$is_working = false;
			}

			// Show notice only if WooCommerce isn't activated.
			if ( ! class_exists( 'WooCommerce' ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_woocommerce_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">WooCommerce</a> plugin installed and activated for the Donation Upsells for WooCommerce to activate.', 'give-woocommerce' ), 'https://wordpress.org/plugins/woocommerce/' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @since  1.0.4
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = array(
				'class'   => $class,
				'message' => $message,
			);
		}

		/**
		 * Display admin notices.
		 *
		 * @since  1.0.4
		 */
		public function admin_notices() {

			$allowed_tags = array(
				'a'      => array(
					'href'  => array(),
					'title' => array(),
					'class' => array(),
					'id'    => array(),
				),
				'br'     => array(),
				'em'     => array(),
				'span'   => array(
					'class' => array(),
				),
				'strong' => array(),
			);

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}

		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since 1.0.0
		 *
		 * @return bool
		 */
		public function activation_banner() {

			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {

				// Only runs on admin.
				$args = array(
					'file'              => GIVE_WOOCOMMERCE_PLUGIN_FILE,
					'name'              => __( 'Donation Upsells for WooCommerce', 'give-woocommerce' ),
					'version'           => GIVE_WOOCOMMERCE_VERSION,
					'settings_url'      => admin_url( 'admin.php?page=wc-settings&tab=settings_tab_give' ),
					'documentation_url' => 'http://docs.givewp.com/addon-give-woocommerce',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false,
				);

				// Show activation banner.
				new Give_Addon_Activation_Banner( $args );
			}

			return true;
		}

		/**
		 * Adding additional setting page link along plugin's action link.
		 *
		 * @since   1.0.4
		 * @access  public
		 *
		 * @param   array $actions get all actions.
		 *
		 * @return  array return new action array
		 */
		public function action_links( $actions ) {

			if ( ! class_exists( 'Give' ) ) {
				return $actions;
			}

			// Check min Give version.
			if ( defined( 'GIVE_WOOCOMMERCE_MIN_GIVE_VER' ) && version_compare( GIVE_VERSION, GIVE_WOOCOMMERCE_MIN_GIVE_VER, '<' ) ) {
				return $actions;
			}

			$new_actions = array(
				'settings' => sprintf( '<a href="%1$s">%2$s</a>', admin_url( 'admin.php?page=wc-settings&tab=settings_tab_give' ), __( 'Settings', 'give-woocommerce' ) ),
			);

			return array_merge( $new_actions, $actions );

		}

		/**
		 * Plugin row meta links.
		 *
		 * @since   1.0.4
		 * @access  public
		 *
		 * @param   array  $plugin_meta An array of the plugin's metadata.
		 * @param   string $plugin_file Path to the plugin file, relative to the plugins directory.
		 *
		 * @return  array  return meta links for plugin.
		 */
		public function plugin_row_meta( $plugin_meta, $plugin_file ) {

			// Return if not Give-Woocommerce plugin.
			if ( $plugin_file !== GIVE_WOOCOMMERCE_BASENAME ) {
				return $plugin_meta;
			}

			$new_meta_links = array(
				sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( add_query_arg( array(
					'utm_source'   => 'plugins-page',
					'utm_medium'   => 'plugin-row',
					'utm_campaign' => 'admin',
				), 'http://docs.givewp.com/addon-give-woocommerce' ) ), __( 'Documentation', 'give-woocommerce' ) ),
			);

			return array_merge( $plugin_meta, $new_meta_links );

		}
	}
}

/**
 * Loads a single instance of Give WooCommerce Add-on.
 *
 * This follows the PHP singleton design pattern.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * @since   1.0.0
 *
 * @see     Give_WooCommerce::get_instance()
 *
 * @return object Give_WooCommerce Returns an instance of the  class
 */
function give_woocommerce() {
	return Give_WooCommerce::get_instance();
}

give_woocommerce();
