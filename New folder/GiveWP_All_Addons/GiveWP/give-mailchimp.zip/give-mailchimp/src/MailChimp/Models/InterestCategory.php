<?php

namespace GiveMailChimp\MailChimp\Models;

use GiveMailChimp\MailChimp\Models\Contracts\MailChimpApiDataModel;

/**
 * Class InterestCategory
 * @package GiveMailChimp\MailChimp\Models
 * @since 1.5.0
 */
class InterestCategory extends MailChimpApiDataModel {
}
