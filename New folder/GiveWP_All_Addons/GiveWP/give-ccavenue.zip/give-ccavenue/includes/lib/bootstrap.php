<?php
// Load ccavenue payment gateway lib.
require_once 'CCAvenue-PHP-Library/src/Utils.php';
require_once 'CCAvenue-PHP-Library/src/Payment.php';
