<?php

namespace GiveMailChimp\MailChimp\Models\Contracts;

use stdClass;

/**
 * Class MailchimpApiDataModel
 * @package GiveMailChimp\MailChimp\Models\Contracts
 */
abstract class MailChimpApiDataModel {
	/**
	 * @var stdClass
	 */
	protected $apiResponse;

	/**
	 * Audience constructor.
	 *
	 * @param stdClass $apiResponse
	 */
	public function __construct( $apiResponse ) {
		$this->apiResponse = $apiResponse;
	}

	/**
	 * @since 1.5.0
	 * @return stdClass
	 */
	public function getRawData() {
		return $this->apiResponse;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $name
	 *
	 * @return mixed
	 */
	public function __get( $name ) {
		if ( property_exists( $this->apiResponse, $name ) ) {
			return $this->apiResponse->id;
		}
	}
}
