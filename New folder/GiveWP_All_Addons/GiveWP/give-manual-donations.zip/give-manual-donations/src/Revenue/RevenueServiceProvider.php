<?php
namespace GiveManualDonations\Revenue;

use Give\Helpers\Hooks;
use Give\ServiceProviders\ServiceProvider;

/**
 * Class RevenueServiceProvider
 * @package GiveManualDonations
 *
 * @since 1.4.8
 */
class RevenueServiceProvider implements ServiceProvider {
	/**
	 * @inheritdoc
	 */
	public function register() {}

	/**
	 * @inheritdoc
	 */
	public function boot() {
		Hooks::addAction( 'give_manual_insert_payment', DonationHandler::class, 'handle' );
	}
}
