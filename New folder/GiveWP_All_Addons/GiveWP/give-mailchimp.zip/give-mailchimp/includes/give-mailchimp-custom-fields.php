<?php

use GiveMailChimp\MailChimp\Api\Marketing\Lists as ListApiClient;

/**
 * Handles sending custom fields to MailChimp for the donor profile.
 */

/**
 * Append field values to MailChimp data array.
 *
 * Creates custom "Merge" tags and sends data from FFM, Fee Recovery, and Recurring to the donor's MailChimp profile.
 *
 * @since 1.4
 *
 * @param  array  $api_fields  MailChimp data.
 *
 * @return array $api_fields
 */
function give_mc_send_custom_fields( $api_fields ) {
	// Get submitted post data.
	$posted_data = array_map( 'give_clean', $_POST );
	$form_id     = isset( $posted_data['give-form-id'] ) ? absint( $posted_data['give-form-id'] ) : $posted_data['forms']['id'];
	$form_title  = isset( $posted_data['give-form-title'] ) ? $posted_data['give-form-title'] : get_the_title( $form_id );

	// Get all of the activated lists.
	$form_lists = give_get_meta( $form_id, '_give_mailchimp', true );

	// Get the form's "Send Donation Data" setting
	$mailchimp_send_donation_data = give_get_meta( $form_id, '_give_mailchimp_send_donation_data', true );

	// Determine whether settings are configured per form or globally for "Send Donation Data" setting.
	$global_donation_data_option = give_get_option( 'give_mailchimp_donation_data' );

	$mailchimp_send_donation_data = ! empty( $mailchimp_send_donation_data )
		? $mailchimp_send_donation_data
		: ( ! empty( $global_donation_data_option ) ? $global_donation_data_option : 'no' );

	// Sanity Check: If sending data is not enabled, return original $api_fields array.
	if ( ! give_is_setting_enabled( $mailchimp_send_donation_data ) ) {
		return $api_fields;
	}

	// Check if $form_lists is set.
	$form_lists      = ! empty( $form_lists ) ? $form_lists : give_get_option( 'give_mailchimp_list' );
	$donation_amount = isset( $posted_data['give-amount'] ) ? $posted_data['give-amount'] : $posted_data['forms']['amount'];

	/**
	 * List of the fields to be passed in Mail-Chimp.
	 *
	 * @since 1.4
	 *
	 * Eg.
	 *      'MERGE_FIELD_TAG' <- Should not exceed string length 10.
	 *              => Label : 'Field Label'
	 *              => Value : 'Field Value'
	 *              [ Extra arguments... ]
	 */
	$donation_data = [
		'FORM_ID'    => [
			'label' => __( 'Form ID', 'give-mailchimp' ),
			'value' => $form_id,
		],
		'FORM_TITLE' => [
			'label' => __( 'Form Title', 'give-mailchimp' ),
			'value' => $form_title,
		],
		'GATEWAY'    => [
			'label' => __( 'Payment Gateway', 'give-mailchimp' ),
			'value' => isset( $posted_data['give-gateway'] ) ? $posted_data['give-gateway'] : $posted_data['gateway'],
		],
		'AMOUNT'     => [
			'label' => __( 'Donation Amount', 'give-mailchimp' ),
			'value' => give_format_amount( $donation_amount ),
		],
		'SOURCE_URL' => [
			'label' => __( 'Source Url', 'give-mailchimp' ),
			'value' => isset( $posted_data['give-current-url'] ) ? $posted_data['give-current-url'] : __(
				'Manual Donation',
				'give-mailchimp'
			),
		],
	];

	// Get WP User ID if present.
	$wp_user_id = isset( $posted_data['give-user-id'] ) ? $posted_data['give-user-id'] : ( isset( $posted_data['user_id'] ) ? $posted_data['user_id'] : '' );

	// Add to MC array.
	if ( ! empty( $wp_user_id ) ) {
		$donation_data['USER_ID'] = [
			'label' => __( 'WP User ID', 'give-mailchimp' ),
			'value' => $posted_data['give-user-id'],
		];
	}

	// Support for Recurring
	if ( isset( $posted_data['_give_is_donation_recurring'] ) && ! empty( $posted_data['_give_is_donation_recurring'] ) ) {
		// Get period / pretty frequency.
		$frequency = isset( $posted_data['give-recurring-period-donors-choice'] ) ? $posted_data['give-recurring-period-donors-choice'] : '';

		if ( function_exists( 'give_recurring_pretty_subscription_frequency' ) && ! empty( $frequency ) ) {
			$frequency = give_recurring_pretty_subscription_frequency( $frequency );
		}

		$donation_data['RECURRING'] = [
			'label' => __( 'Recurring Donation', 'give-mailchimp' ),
			'value' => ( ! empty( $frequency ) ? $frequency : 'TRUE' ),
		];
	}

	// Support for Fee Recovery
	if ( isset( $posted_data['give-fee-mode-enable'] ) && ! empty( $posted_data['give-fee-mode-enable'] ) ) {
		$donation_data['FEE'] = [
			'label' => __( 'Fee Recovery', 'give-mailchimp' ),
			'value' => give_format_amount( $posted_data['give-fee-amount'] ),
		];
	}

	/**
	 * Array of data which will be sent to MailChimp.
	 *
	 * @since 1.4
	 *
	 * @param  array  $donation_data  Submitted data.
	 * @param  integer  $form_id  Donation Form ID.
	 */
	$donation_data = apply_filters( 'give_mailchimp_pass_fields', $donation_data, $form_id );

	// Get all of the list to be subscribed.
	$activated_lists = is_array( $form_lists ) ? $form_lists : (array) $form_lists;

	// Modify interest ids to list id if any.
	$activated_lists = array_map(
		static function ( $list ) {
			if ( false !== strpos( $list, '|' ) ) {
				return current( explode( '|', $list ) );
			}

			return $list;
		},
		$activated_lists
	);
	$activated_lists = array_unique( $activated_lists );

	foreach ( $activated_lists as $list_id ) {
		foreach ( $donation_data as $field_tag => $field ) {
			// Create merge field in MailChimp if not exists.
			$api_fields['merge_vars'][ $field_tag ] = give_mc_create_merge_field( $list_id, $field, $field_tag );
		}
	}

	return $api_fields;
}

// Add FFM fields.
add_filter( 'give_mc_subscribe_vars', 'give_mc_send_custom_fields', 10, 1 );

/**
 * MailChimp create field if not available.
 *
 * @since 1.4
 *
 * @param  string  $list_id
 * @param  array  $field
 * @param  string  $tag
 *
 * @return string
 */
function give_mc_create_merge_field( $list_id, $field, $tag ) {
	/* @var ListApiClient $listModel */
	$listModel = give( ListApiClient::class );
	try {
		$var_lists = $listModel->getMergeFields( $list_id, [ 'count' => 1000 ] );
	} catch ( Exception $e ) {
		return '';
	}

	// If merge field array is not empty.
	$exists_merge_fields = $var_lists->total_items ? $var_lists->merge_fields : [];

	// If tag does not exist in MailChimp add it.
	if (
		! empty( $exists_merge_fields ) &&
		! in_array( $tag, wp_list_pluck( $exists_merge_fields, 'tag' ), true )
	) {
		$api_args = [
			'name' => $field['label'],
			'type' => give_mc_get_ffm_field_type( $field ),
			'tag'  => $tag,
		];

		/**
		 * Alter Api args while processing fields for MailChimp.
		 *
		 * @since 1.4
		 *
		 * @param  array  $filteredArgs  API Arguments
		 * @param  array  $field  Field array.
		 * @param  string  $list_id  List ID.
		 */
		$filteredArgs = apply_filters( 'give_mailchimp_processing_field', $api_args, $field, $list_id );

		try {
			$listModel->addMergeField( $list_id, $filteredArgs );
		} catch ( \Exception $e ) {
			return '';
		}
	}

	// Get the field value.
	$field_value = isset( $field['name'] ) ? $_POST[ $field['name'] ] : $field['value'];

	// If field value is array.
	$field_value = is_array( $field_value ) ? ( ( 1 === count( $field_value ) ) ? $field_value[0] : json_encode( $field_value ) ) : give_clean( $field_value );

	// Return field value.
	return $field_value;
}

/**
 * Get the type of the field for MailChimp.
 *
 * @since 1.4
 *
 * @param  array  $field  Field options.
 *
 * @return bool|mixed
 */
function give_mc_get_ffm_field_type( $field ) {
	$field_type = ( isset( $field['input_type'] ) ) ? $field['input_type'] : '';

	switch ( $field_type ) {
		case 'date':
			$type = 'date';
			break;
		case 'radio':
			$type = 'radio';
			break;
		case 'select':
			$type = 'dropdown';
			break;
		case 'url':
		case 'phone':
			$type = $field_type;
			break;
		case 'checkbox':
		case 'email':
		case 'text':
		case 'hidden':
		case 'textarea':
		case 'html':
		default:
			$type = 'text';
			break;
	}

	/**
	 * Alter field type.
	 *
	 * @since 1.4
	 */
	return apply_filters( 'give_mc_ffm_field_type', $type, $field );
}

/**
 * Return if FFM is activated or not.
 *
 * @since 1.4
 *
 * @return bool
 */
function give_mc_ffm_is_activated() {
	return class_exists( 'Give_Form_Fields_Manager' );
}

/**
 * Pass FFM fields to pass in MailChimp.
 *
 * @since 1.4
 *
 * @param  array  $fields_array  Fields array.
 * @param  integer  $form_id  Form ID.
 *
 * @return mixed
 */
function give_mc_ffm_add_fields( $fields_array, $form_id ) {
	// If form field manager is not activated.
	if ( ! give_mc_ffm_is_activated() ) {
		return $fields_array;
	}

	// Should the opt-on be checked or unchecked by default?
	$mailchimp_ffm_send = give_get_meta( $form_id, '_give_mailchimp_send_ffm', true );
	$mailchimp_ffm_send = ! empty( $mailchimp_ffm_send ) ? give_is_setting_enabled( $mailchimp_ffm_send ) : give_is_setting_enabled( give_get_option( 'give_mailchimp_ffm_pass_field' ) );

	// If not, return original array.
	if ( ! give_is_setting_enabled( $mailchimp_ffm_send ) ) {
		return $fields_array;
	}

	// Admin wants FFM field in MailChimp... get the ffm fields.
	$ffm_fields = give_get_meta( $form_id, 'give-form-fields', true );

	if ( ! empty( $ffm_fields ) && is_array( $ffm_fields ) ) {
		foreach ( $ffm_fields as $ffm_field ) {
			$field_label = '';

			if ( isset( $ffm_field['label'] ) && ! empty( $ffm_field['label'] ) ) {
				$field_label = $ffm_field['label'];
			}

			$field_label = apply_filters( 'give_mailchimp_ffm_field_label', $field_label, $form_id, $fields_array );

			if ( array_key_exists( $ffm_field['name'], $_POST ) && ! empty( $field_label ) ) {
				// Generate MailChimp Merge field's tag name.
				$mailchimp_tag_name = substr( strtoupper( str_replace( ' ', '_', $field_label ) ), 0, 10 );

				// Get all fields.
				$fields_array[ $mailchimp_tag_name ] = [
					'label'      => give_clean( $field_label ),
					'value'      => $_POST[ $ffm_field['name'] ],
					'input_type' => $ffm_field['input_type'],
				];

				// Get the FFM field type.
				$field_type = give_mc_get_ffm_field_type( $ffm_field );

				// If type is date.
				if ( 'date' === $field_type ) {
					$fields_array[ $mailchimp_tag_name ]['args']['date_format'] = $ffm_field['format'];
				} elseif ( in_array( $field_type, [ 'dropdown', 'radio' ], 1 ) ) {
					$fields_array[ $mailchimp_tag_name ]['args']['choices'] = $ffm_field['options'];
				}
			}
		}
	}

	return apply_filters( 'give_mc_ffm_add_fields', $fields_array );
}

// Add FFM field(s) to be passed in MailChimp.
add_filter( 'give_mailchimp_pass_fields', 'give_mc_ffm_add_fields', 10, 2 );

/**
 * Set field type for FFM field.
 *
 * @since 1.4
 *
 * @param  array  $api_arg  MC API Arguments.
 * @param  array  $field  Field arguments.
 *
 * @return mixed
 */
function give_mc_ffm_processing_field( $api_arg, $field ) {
	// Get the field type.
	$field_type = $api_arg['type'];

	// If field type is date then add 'date' format.
	if ( 'date' === $field_type ) {
		$api_arg['options']['date_format'] = $field['args']['date_format'];
	} elseif ( in_array( $api_arg['type'], [ 'dropdown', 'radio' ], 1 ) ) {
		// ...Or if field type is drop-down or radio then include choices.
		$api_arg['options']['choices'] = $field['args']['choices'];
	}

	return $api_arg;
}

// Add field additional option while sending them to MailChimp account.
add_filter( 'give_mailchimp_processing_field', 'give_mc_ffm_processing_field', 10, 2 );
