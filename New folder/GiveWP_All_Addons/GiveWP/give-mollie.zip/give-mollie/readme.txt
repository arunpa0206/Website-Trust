=== Give - Mollie Payment Gateway ===
Contributors: givewp
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, mollie, gateway
Requires at least: 4.8
Tested up to: 5.3
Stable tag: 1.2.4
Requires Give: 2.5.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Mollie Gateway add-on for Give.

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds a payment gateway for mollie.com.

== Installation ==

= Minimum Requirements =

* WordPress 4.8 or greater
* PHP version 5.3 or greater
* MySQL version 5.0 or greater

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.2.4: February 7th, 2020 =
* Fix: Resolved a compatibility issue with Form Field Manager latest version which in certain environments would create a PHP fatal error.

= 1.2.3: July 11th, 2019 =
* New: Added support for quarterly recurring donations. Note: You must be using Give Core 2.5.0+ and Recurring Donations 1.9.0+ in order to use the quarterly functionality.

= 1.2.2: June 3rd, 2019 =
* Fix: Resolved conflict with the unofficial WooCommerce Mollie extension by updating and testing the Mollie PHP SDK hto the latest version 2.10.0.

= 1.2.1: January 22nd, 2019 =
* Fix: Resolved a PHP warning happening on the plugin listings page in WP-Admin due to incorrect method visibility.

= 1.2.0: January 17th, 2019 =
* New: Added improved support for Recurring Donations and Currency Switcher add-ons by updating the Mollie API to the new version 2 which supports multiple currencies.
* New: Added support for yearly recurring donations.
* Fix: Ensure that Customers and their Donations are inter-related.
* Fix: Complete audit or the recurring integration to ensure charges and renewals work as expected.
* Fix: Added links to "Settings" and "Documentation" on the plugin listing screen.

= 1.1.2: August 30th, 2018 =
* Fix: Ensure users don't have a duplicate pending donations when a donor gives.
* Fix: Resolved reference to non existing file frontend.css causing unnecessary 404.
* Fix: Resolved conflict with webhooks when Give - Mollie and Give - GoCardless are activated at the same time.
* Tweak: Added compatibility to Give Core 2.2.0+. Please update Give Core to version 2.2.0 before performing this update.

= 1.1.1: May 22nd, 2018 =
* Fix: Multi-level donations were not displaying the proper level given in the donations admin panel. This update includes and upgrade routine to fix these incorrect levels.

= 1.1: May 2nd, 2018 =
* New: Added support for new recurring options found in Recurring Donations 1.6+ - please update recurring if you're using it alongside Mollie!
* Fix: Activation banner settings link was incorrect.

= 1.0.3: March 20th, 2018 =
* New: An enhancement has been built in to support additional recurring giving frequency interval options coming out soon!
* Fix: Mollie does not support annual (yearly) subscriptions. We have now built in checks to prevent yearly recurring donations via Mollie.
* Fix: Email addresses for recurring subscriptions were not displaying properly for donors within wp-admin's subscriptions list table.

= 1.0.2: February 28th, 2018 =
* Fix: When a payment is cancelled or fails at the Mollie gateway it is now properly reflected on the Give payment.

= 1.0.1: February 27th, 2018 =
* Fix: Mollie's currency validation for Euro was validating other other gateways incorrectly.

= 1.0 =
* Initial plugin release. Yippee!
