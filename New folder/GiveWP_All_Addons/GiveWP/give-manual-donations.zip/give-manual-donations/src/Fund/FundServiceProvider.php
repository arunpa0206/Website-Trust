<?php
namespace GiveManualDonations\Fund;

use Give\Helpers\Hooks;
use Give\ServiceProviders\ServiceProvider;
use GiveManualDonations\Fund\Admin\CreateNewDonationPage;
use GiveManualDonations\Infrastructure\Traits\FundAddonTrait;

/**
 * Class FundServiceProvider
 * @package GiveManualDonations\Fund
 *
 * @since 1.4.8
 */
class FundServiceProvider implements ServiceProvider {
	use FundAddonTrait;

	/**
	 * @inheritdoc
	 */
	public function register() {
	}

	/**
	 * @inheritdoc
	 */
	public function boot() {
		if ( $this->isFundAddonActive() ) {
			Hooks::addAction( 'give_manual_donation_table_before_create_donor_fieldset', CreateNewDonationPage::class, 'addSelectFundOption' );
		}
	}
}
