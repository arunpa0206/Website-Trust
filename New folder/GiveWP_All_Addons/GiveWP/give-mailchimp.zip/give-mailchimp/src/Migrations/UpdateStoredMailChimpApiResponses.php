<?php

namespace GiveMailChimp\Migrations;

use Exception;
use GiveMailChimp\Infrastructure\Log;
use GiveMailChimp\MailChimp\ApiKeyValidator;
use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\InvalidMailChimpApiKeyException;
use GiveMailChimp\MailChimp\RefreshMailchimpApiData;
use GiveMailChimp\MailChimp\Repositories\ApiKey;
use GiveMailChimp\MailChimp\Repositories\ListInterestCategories;
use GiveMailChimp\MailChimp\Repositories\Lists;
use GiveMailChimp\Migrations\Contracts\Migration;

/**
 * Class UpdateStoredMailChimpApiResponses
 *
 * @package GiveMailChimp\Migrations
 * @since 1.5.0
 */
class UpdateStoredMailChimpApiResponses extends Migration {
	/**
	 * @var Lists
	 */
	private $listsRepository;

	/**
	 * @var RefreshMailchimpApiData
	 */
	private $refreshMailchimpDataHandler;

	/**
	 * @var ListInterestCategories
	 */
	private $listInterestCategoriesRepository;

	/**
	 * UpdateStoredMailChimpApiResponses constructor.
	 *
	 * @param  Lists  $listsRepository
	 * @param  ListInterestCategories  $listInterestCategoriesRepository
	 * @param  RefreshMailchimpApiData  $refreshMailchimpDataHandler
	 */
	public function __construct(
		Lists $listsRepository,
		ListInterestCategories $listInterestCategoriesRepository,
		RefreshMailchimpApiData $refreshMailchimpDataHandler
	) {
		$this->listsRepository                  = $listsRepository;
		$this->refreshMailchimpDataHandler      = $refreshMailchimpDataHandler;
		$this->listInterestCategoriesRepository = $listInterestCategoriesRepository;
	}

	/**
	 * @inheritDoc
	 * @since 1.5.0
	 * @return void
	 */
	public function run() {
		/* @var ApiKey $apiKeyRepository */
		$apiKeyRepository = give( ApiKey::class );

		if ( ! $apiKeyRepository->isValidApiKey() ) {
			$this->deleteMailchimpApiDataWithApiKey();

			return;
		}

		/* @var ApiKeyValidator $apiKeyValidator */
		$apiKeyValidator = give( ApiKeyValidator::class );

		try {
			$apiKeyValidator->canUseForApiRequest( $apiKeyRepository );
		} catch ( InvalidMailChimpApiKeyException $e ) {
			$this->deleteMailchimpApiDataWithApiKey();

			Log::http(
				esc_html__( 'An error occurred while updating mailchimp api data', 'give-mailchimp' ),
				[
					'category'     => 'Give Mailchimp Migration',
					'Migration ID' => self::id(),
					'Error'        => $e->getMessage(),
				]
			);

			return;
		}

		try {
			$this->refreshMailchimpDataHandler->refreshMailchimpData();
		} catch ( Exception $e ) {
			Log::http(
				esc_html__( 'An error occurred while updating mailchimp api data', 'give-mailchimp' ),
				[
					'category'     => 'Give Mailchimp Migration',
					'Migration ID' => self::id(),
					'Error'        => $e->getMessage(),
				]
			);
		}
	}

	/**
	 * @inheritDoc
	 *
	 * @return string
	 */
	public static function id() {
		return 'give-mailchimp-update-stored-mailchimp-api-responses';
	}

	/**
	 * @inheritDoc
	 *
	 * @since 1.5.0
	 *
	 * @return int Unix timestamp for when the migration was created
	 */
	public static function timestamp() {
		return strtotime( '2021-04-01' );
	}

	/**
	 * @since 1.5.0
	 */
	private function deleteMailchimpApiDataWithApiKey() {
		$this->listsRepository->deleteListsData();
		$this->listInterestCategoriesRepository->deleteAllInterestCategories();

		/* @var ApiKey $apiKeyRepository */
		$apiKeyRepository = give( ApiKey::class );
		$apiKeyRepository->deleteMailchimpApiKey();
	}
}
