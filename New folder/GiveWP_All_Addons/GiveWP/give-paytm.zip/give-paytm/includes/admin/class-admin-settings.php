<?php

class Give_Paytm_Admin_Settins {
	/**
	 * Instance.
	 *
	 * @since  1.0
	 * @access static
	 * @var
	 */
	static private $instance;

	/**
	 * Payment gateways ID
	 *
	 * @since 1.0
	 * @var string
	 */
	private $gateways_id = '';

	/**
	 * Payment gateways label
	 *
	 * @since 1.0
	 * @var string
	 */
	private $gateways_label = '';

	/**
	 * Singleton pattern.
	 *
	 * @since  1.0
	 * @access private
	 * Give_Paytm_Admin_Settins constructor.
	 */
	private function __construct() {
	}

	/**
	 * Get instance.
	 *
	 * @since  1.0
	 * @access static
	 * @return static
	 */
	static function get_instance() {
		if ( null === static::$instance ) {
			self::$instance = new static();
		}

		return self::$instance;
	}

	/**
	 * Setup hooks
	 *
	 * @since  1.0
	 * @access public
	 */
	public function setup() {
		$this->gateways_id    = 'paytm';
		$this->gateways_label = __( 'Paytm', 'give-paytm' );

		add_filter( 'give_payment_gateways', array( $this, 'register_gateway' ) );
		add_filter( 'give_get_settings_gateways', array( $this, 'add_settings' ) );
		add_filter( 'give_get_sections_gateways', array( $this, 'add_gateways_section' ) );
	}

	/**
	 * Registers the gateway.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param $gateways
	 *
	 * @return mixed
	 */
	public function register_gateway( $gateways ) {
		$gateways[ $this->gateways_id ] = array(
			'admin_label'    => $this->gateways_label,
			'checkout_label' => give_paytm_get_payment_method_label(),
		);

		return $gateways;
	}

	/**
	 * adds the settings to the Payment Gateways section
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param $settings
	 *
	 * @return array
	 */
	public function add_settings( $settings ) {

		if ( $this->gateways_id !== give_get_current_setting_section() ) {
			return $settings;
		}

		$paytm_settings = array(
			array(
				'id'   => $this->gateways_id,
				'type' => 'title',
			),
			array(
				'name'    => esc_html__( 'Payment Method Label', 'give-paytm' ),
				'id'      => 'paytm_checkout_label',
				'type'    => 'text',
				'default' => esc_html__( 'Paytm', 'give-paytm' ),
				'desc'    => __( 'Payment method label will appear on the frontend.', 'give-paytm' ),
			),
			array(
				'id'   => 'paytm_sandbox_merchant_id',
				'name' => __( 'Sandbox Merchant ID', 'give-paytm' ),
				'desc' => __( 'Sandbox merchant id parameter provided by paytm', 'give-paytm' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_sandbox_mer_access_key',
				'name' => __( 'Sandbox Merchant Key', 'give-paytm' ),
				'desc' => __( 'Sandbox secret key parameter provided by paytm', 'give-paytm' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_sandbox_website_name',
				'name' => __( 'Sandbox Website Name', 'give-paytm' ),
				'desc' => __( 'Sandbox website parameter provided by paytm', 'give-paytm' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_sandbox_industry_type',
				'name' => __( 'Sandbox Industry Type', 'give-paytm' ),
				'desc' => __( 'Sandbox industry type parameter provided by paytm (Retail, Entertainment, etc.)', 'give-paytm' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_live_merchant_id',
				'name' => __( 'Live Merchant ID', 'give-paytm' ),
				'desc' => __( 'Live merchant id parameter provided by paytm', 'give-paytm' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_live_mer_access_key',
				'name' => __( 'Live Merchant Key', 'give-paytm' ),
				'desc' => __( 'Live secret key parameter provided by paytm', 'give-paytm' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_live_website_name',
				'name' => __( 'Live Website Name', 'give-paytm' ),
				'desc' => __( 'Live website parameter provided by paytm', 'give-paytm' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'id'   => 'paytm_live_industry_type',
				'name' => __( 'Live Industry Type', 'give-paytm' ),
				'desc' => __( 'Live industry type parameter provided by paytm (Retail, Entertainment, etc.)', 'give-paytm' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'title'       => __( 'Collect Billing Details', 'give-paytm' ),
				'id'          => 'paytm_billing_details',
				'type'        => 'radio_inline',
				'options'     => array(
					'enabled'  => esc_html__( 'Enabled', 'give-paytm' ),
					'disabled' => esc_html__( 'Disabled', 'give-paytm' ),
				),
				'default'     => 'disabled',
				'description' => __( 'This option will enable the billing details section for Paytm which requires the donor\'s address to complete the donation. These fields are not required by Paytm to process the transaction, but you may have the need to collect the data.', 'give-paytm' ),
			),
			array(
				'id'   => $this->gateways_id,
				'type' => 'sectionend',
			),
		);

		return $paytm_settings;
	}

	/**
	 * Add gateway section
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param $section
	 *
	 * @return mixed
	 */
	public function add_gateways_section( $section ) {
		$section[ $this->gateways_id ] = __( 'Paytm', 'give-paytm' );

		return $section;
	}
}


// Initialize settings.
Give_Paytm_Admin_Settins::get_instance()->setup();
