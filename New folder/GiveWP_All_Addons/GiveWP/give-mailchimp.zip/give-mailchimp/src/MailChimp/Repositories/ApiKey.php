<?php

namespace GiveMailChimp\MailChimp\Repositories;

/**
 * Class MailchimpApiKey
 *
 * @since 1.5.0
 * @package GiveMailChimp\Repositories
 */
class ApiKey {
	const MAILCHIMP_API_OPTION_KEY = 'give_mailchimp_api';

	private $apiKeyRaw;
	public $apiKey = '';
	public $server = '';

	/**
	 * MailchimpApiKey constructor.
	 *
	 * @param  string|null  $apiKey
	 */
	public function __construct( $apiKey = null ) {
		$this->apiKeyRaw = $apiKey ?: give_get_option( 'give_mailchimp_api', '' );
		$apiKeyParts     = explode( '-', $this->apiKeyRaw );

		if ( 2 === count( $apiKeyParts ) ) {
			$this->apiKey = isset( $apiKeyParts[0] ) ? $apiKeyParts[0] : '';
			$this->server = isset( $apiKeyParts[1] ) ? $apiKeyParts[1] : '';
		}
	}

	/**
	 * Return whether or not api key valid.
	 *
	 * @since 1.5.0
	 * @return bool
	 */
	public function isValidApiKey() {
		return $this->apiKey && $this->server;
	}

	/**
	 * Return ApiKey class object.
	 *
	 * @since 1.5.0
	 *
	 * @param  string  $apiKey
	 *
	 * @return ApiKey
	 */
	public static function fromApiKey( $apiKey ) {
		return new static( $apiKey );
	}

	/**
	 * @since 1.5.0
	 */
	public function deleteMailchimpApiKey() {
		give_delete_option( self::MAILCHIMP_API_OPTION_KEY );
	}
}
