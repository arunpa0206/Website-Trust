<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://givewp.com
 * @since      1.0.0
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/admin
 * @author     GiveWP
 */
class Give_Mollie_Admin {

	/**
	 * Setting prefix
	 *
	 * @since 1.0
	 *
	 * @var string
	 */
	public static $setting_prefix = '_give_mollie_';

	/**
	 * Give_Mollie_Admin constructor.
	 *
	 * @since 1.0
	 */
	public function __construct() {

		// Register Give Mollie sections.
		add_filter( 'give_get_sections_gateways', array( $this, 'give_square_register_sections' ) );

		// Register Give Mollie settings.
		add_action( 'give_get_settings_gateways', array( $this, 'give_mollie_register_settings' ) );

		// Register Mollie payment gateway.
		add_filter( 'give_payment_gateways', array( $this, 'give_mollie_register_gateway' ) );

		// Add admin notices.
		add_action( 'admin_notices', array( $this, 'show_admin_notice' ), 10 );

		// Add plugin row links.
		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );

		// Add plugin action link to settings.
		add_filter( 'plugin_action_links_' . GIVE_MOLLIE_BASENAME, array( $this, 'plugin_action_links' ) );

		// Display Mollie Subscription Status from API within Sub Details.
		add_action( 'give_subscription_before_tables_wrapper', array( $this, 'display_mollie_sub_details' ), 10, 1 );
	}

	/**
	 * Register Give - Mollie Gateway setting
	 *
	 * @param $sections array.
	 *
	 * @since 1.0
	 *
	 * @return mixed
	 */
	public function give_square_register_sections( $sections ) {

		$sections['mollie'] = __( 'Mollie Settings', 'give-mollie' );

		return $sections;
	}

	/**
	 * Register Admin Settings.
	 *
	 * @param array $settings List of admin settings.
	 *
	 * @since 1.0
	 *
	 * @return array
	 */
	public function give_mollie_register_settings( $settings ) {

		switch ( give_get_current_setting_section() ) {

			case 'mollie':
				$settings = array(
					array(
						'id'   => 'give_title_mollie',
						'type' => 'title',
					),
					array(
						'name'          => __( 'API key', 'give-mollie' ),
						'desc'          => __( 'Enter your Mollie API key. This is found in your Mollie account dashboard and it starts with <code>live_</code> or <code>test_</code>. If you are testing the integration use the test key when Give is in test
 mode. For live payments use the live key without test mode on.', 'give-mollie' ),
						'id'            => self::$setting_prefix . 'api_key',
						'type'          => 'api_key',
						'wrapper_class' => 'give-mollie-api-key',
					),
					array(
						'name' => __( 'Collect Billing Details?', 'give-mollie' ),
						'desc' => __( 'Check if you want to collect the donor\'s address.', 'give-mollie' ),
						'id'   => self::$setting_prefix . 'collect_billing_details',
						'type' => 'checkbox',
					),
					array(
						'name'  => __( 'Give Mollie Settings Docs Link', 'give-mollie' ),
						'id'    => 'give_mollie_settings_docs_link',
						'url'   => esc_url( 'http://docs.givewp.com/addon-mollie' ),
						'title' => __( 'Mollie Payment Gateway', 'give-mollie' ),
						'type'  => 'give_docs_link',
					),
					array(
						'id'   => 'give_title_mollie',
						'type' => 'sectionend',
					),
				);

				break;
		}

		return $settings;
	}

	/**
	 * Register Mollie Payment Gateway.
	 *
	 * @since 1.0
	 *
	 * @param array $gateways Give Payment gateways.
	 *
	 * @return array
	 */
	public function give_mollie_register_gateway( $gateways ) {

		$gateways['mollie'] = array(
			'admin_label'    => __( 'Mollie Gateway', 'give-mollie' ),
			'checkout_label' => __( 'Mollie Gateway', 'give-mollie' ),
		);

		return $gateways;
	}

	/**
	 * Show admin notices depending on requirements.
	 *
	 * @since 1.0
	 */
	public function show_admin_notice() {

		if (
			defined( 'GIVE_RECURRING_PLUGIN_BASENAME' )
			&& is_plugin_active( GIVE_RECURRING_PLUGIN_BASENAME )
			&& version_compare( GIVE_RECURRING_VERSION, '1.7.2', '<' )
		) {
			Give()->notices->register_notice(
				array(
					'id'          => 'give-mollie-require-minimum-recurring-version',
					'type'        => 'error',
					'dismissible' => false,
					'description' => sprintf(
						'%1$s <strong>%2$s</strong> %3$s',
						__( 'Please update the', 'give-mollie' ),
						__( 'Give Recurring Donations', 'give-mollie' ),
						__( 'add-on to version 1.7.2+ to be compatible with the latest version of the Mollie payment gateway.', 'give-mollie' )
					),
				)
			);
		}
	}

	/**
	 * Plugin row meta links
	 *
	 * @param array  $plugin_meta An array of the plugin's metadata.
	 * @param string $plugin_file Path to the plugin file, relative to the plugins directory.
	 *
	 * @since 1.2.0
	 *
	 * @return array
	 */
	public function plugin_row_meta( $plugin_meta, $plugin_file ) {

		if ( $plugin_file !== GIVE_MOLLIE_BASENAME ) {
			return $plugin_meta;
		}

		$new_meta_links = array(
			sprintf(
				'<a href="%1$s" target="_blank">%2$s</a>',
				esc_url(
					add_query_arg(
						array(
							'utm_source'   => 'plugins-page',
							'utm_medium'   => 'plugin-row',
							'utm_campaign' => 'admin',
						), 'http://docs.givewp.com/addon-mollie'
					)
				),
				__( 'Documentation', 'give-mollie' )
			),
			sprintf(
				'<a href="%1$s" target="_blank">%2$s</a>',
				esc_url(
					add_query_arg(
						array(
							'utm_source'   => 'plugins-page',
							'utm_medium'   => 'plugin-row',
							'utm_campaign' => 'admin',
						), 'https://givewp.com/addons/'
					)
				),
				__( 'Add-ons', 'give-mollie' )
			),
		);

		return array_merge( $plugin_meta, $new_meta_links );
	}

	/**
	 * Plugins row action links
	 *
	 * @param array $actions An array of plugin action links.
	 *
	 * @since 1.0.0
	 *
	 * @return array An array of updated action links.
	 */
	public function plugin_action_links( $actions ) {

		$new_actions = array(
			'settings' => sprintf(
				'<a href="%1$s">%2$s</a>',
				admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=mollie' ),
				__( 'Settings', 'give-square' )
			),
		);

		return array_merge( $new_actions, $actions );
	}


	/**
	 * Display the Mollie Subscription details retrieved from the Mollie API within subscription details.
	 *
	 * For debugging purposes. WP_DEBUG must set to true to output.
	 *
	 * @param $give_subscription Give_Subscription
	 *
	 * @return bool|void
	 */
	public function display_mollie_sub_details( $give_subscription ) {

		if ( ! WP_DEBUG ) {
			return;
		}

		try {
			/** @var \Give_Mollie_API $give_mollie_obj */
			$give_mollie = new Give_Mollie_API();

			// Get Mollie customer and subscription ID.
			$mollie_sub_id     = $give_subscription->profile_id;
			$parent_payment_id = $give_subscription->parent_payment_id;
			$customer_id       = give_get_payment_meta( $parent_payment_id, Give_Mollie_API::get_customer_meta_key(), true );

			// Cancel the subscription in Give Mollie.
			$mollie_subscription = $give_mollie->give_mollie_obj->customers->get( $customer_id )->getSubscription( $mollie_sub_id );

			// Check proactively if cancelled.
			if ( 'canceled' === $mollie_subscription->status ) {
				give_insert_payment_note( $give_subscription->parent_payment_id, __( 'Subscription has been cancelled.', 'give-mollie' ) );
				give_update_payment_meta( $give_subscription->parent_payment_id, '_give_subscription_cancelled_response', $mollie_subscription );
			} ?>

			<table class="widefat" style="margin: 20px 0;">
				<tbody>
				<?php
				$display_keys = array( 'id', 'customerId', 'mode', 'amount', 'times', 'interval', 'webhookUrl' );
				foreach ( $mollie_subscription as $key => $sub_data ) :
					if ( in_array( $key, $display_keys ) ) :
						?>
						<tr>
							<td class="row-title">
								<label for="tablecell"><?php echo strtoupper( $key ); ?></label>
							</td>
							<td>
								<?php
								// Output data whether object or not.
								if ( is_object( $sub_data ) ) {
									print_r( $sub_data );
								} else {
									echo $sub_data;
								}
								?>
							</td>
						</tr>
					<?php
					endif;
				endforeach;
				?>
				</tbody>
			</table>

			<?php
		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

			// Record API errors.
			give_record_gateway_error(
				__( 'Give Mollie error', 'give-mollie' ),
				sprintf( __( 'Give Mollie returned an error while retrieveing a subscription. Details: %s', 'give-mollie' ), $e->getMessage() )
			);

			return;
		}

		?>

		<?php

	}

}

new Give_Mollie_Admin();
