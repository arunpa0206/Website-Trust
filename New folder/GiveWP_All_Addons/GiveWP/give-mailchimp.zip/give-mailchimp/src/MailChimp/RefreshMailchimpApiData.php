<?php

namespace GiveMailChimp\MailChimp;

use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;
use GiveMailChimp\MailChimp\Repositories\ApiKey;
use GiveMailChimp\MailChimp\Repositories\ListInterestCategories;
use GiveMailChimp\MailChimp\Repositories\Lists;

/**
 * Class RefreshMailchimpApiData
 *
 * @package GiveMailChimp\MailChimp
 * @since 1.5.0
 */
class RefreshMailchimpApiData {
	/**
	 * @var Lists
	 */
	private $listsRepository;

	/**
	 * @var ApiKey
	 */
	private $apiKeyRepository;

	/**
	 * @var Api\Marketing\Lists
	 */
	private $listApiClient;


	/**
	 * @var ListInterestCategories
	 */
	private $listInterestCategoriesRepository;

	/**
	 * RefreshMailchimpApiData constructor.
	 *
	 * @since 1.5.0
	 *
	 * @param  Lists  $listsRepository
	 * @param  ListInterestCategories  $listInterestCategoriesRepository
	 * @param  ApiKey  $apiKeyRepository
	 * @param  Api\Marketing\Lists  $listApiClient
	 */
	public function __construct(
		Lists $listsRepository,
		ListInterestCategories $listInterestCategoriesRepository,
		ApiKey $apiKeyRepository,
		Api\Marketing\Lists $listApiClient
	) {
		$this->listsRepository                  = $listsRepository;
		$this->apiKeyRepository                 = $apiKeyRepository;
		$this->listApiClient                    = $listApiClient;
		$this->listInterestCategoriesRepository = $listInterestCategoriesRepository;
	}

	/**
	 * Refresh mailchimp api data.
	 *
	 * admin_init hook handler
	 *
	 * @since 1.5.0
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function handle() {
		$this->apiKeyRepository = new ApiKey( give_clean( $_POST[ ApiKey::MAILCHIMP_API_OPTION_KEY ] ) );
		$this->listApiClient    = new Api\Marketing\Lists( new ApiClient( new Configuration( $this->apiKeyRepository ) ) );

		if ( ! $this->apiKeyRepository->isValidApiKey() ) {
			$this->listsRepository->deleteListsData();
			$this->listInterestCategoriesRepository->deleteAllInterestCategories();

			return;
		}

		$this->refreshMailchimpData();
	}

	/**
	 * @since 1.5.0
	 * @throws RequestException|ApiException|MailchimpApiKeyDoesNotExistException
	 */
	public function refreshMailchimpData() {
		$this->listsRepository->deleteListsData();
		$listsData = $this->listApiClient->getAllLists( [ 'count' => 1000 ] );
		$this->listsRepository->updateLists( $listsData );

		$this->listInterestCategoriesRepository->deleteAllInterestCategories();

		if ( $listsData->total_items ) {
			foreach ( $listsData->lists as $list ) {
				$interestCategories = $this->listApiClient->getInterestCategories( $list->id );

				$this->listInterestCategoriesRepository->updateInterestCategories(
					$list->id,
					$interestCategories
				);

				if ( ! $interestCategories->total_items ) {
					continue;
				}

				foreach ( $interestCategories->categories as $category ) {
					$categoryInterests = $this->listApiClient->getInterestCategoryInterests( $list->id, $category->id );

					$this->listInterestCategoriesRepository->updateInterestCategoryInterests(
						$list->id,
						$category->id,
						$categoryInterests
					);
				}
			}
		}
	}
}
