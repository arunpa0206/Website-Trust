<?php
/**
 * Give Mollie - Handle Mollie Web-hook request.
 *
 * @link       https://givewp.com
 * @since      1.0
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes/
 */

/**
 * The Give Mollie Web-hook handler class.
 *
 * @package    Give_Mollie
 * @subpackage Give_Mollie/includes
 * @author     GiveWP
 */
class Give_Mollie_Webhook {

	/**
	 * Web-hook endpoint URL.
	 *
	 * @since 1.0
	 * @var $webhook_endpoint
	 */
	public $webhook_endpoint;

	/**
	 * Endpoint type.
	 *
	 * @since 1.0
	 * @var string $endpoint_type
	 */
	private $endpoint_type;

	/**
	 * Give_Mollie_Webhook constructor.
	 *
	 * @param string $type endpoint type.
	 *
	 * @since 1.0
	 */
	public function __construct() {

		// Check if web-hook response request is valid.
		add_action( 'init', array( $this, 'give_check_is_webhook_response' ) );
	}

	/**
	 * Check if request is valid web-hook request.
	 *
	 * @since 1.0
	 */
	public function give_check_is_webhook_response() {

		// Check if it's web-hook URL.
		if ( isset( $_GET['give-listener'] ) && 'mollie' === $_GET['give-listener'] ) {

			// Check if Mollie Transaction ID is set.
			if ( ! isset( $_POST['id'] ) || empty( $_POST['id'] ) ) {
				$this->resource_not_found( __( 'The Mollie Transaction ID in the POST request sent from the Mollie webhook API is missing.', 'give-mollie' ) );
				// Provide notice that this is indeed the Mollie endpoint.
				esc_html_e( 'Mollie endpoint.', 'give-mollie' );
				exit();
			}

			$mollie_payment_id = give_clean( $_POST['id'] );

			// Handle Web-Hook request.
			$this->handle_wehook_request( $mollie_payment_id );
			http_response_code( 200 );

		}
	}

	/**
	 * Handle Give Mollie web-hook request.
	 *
	 * @see   https://docs.mollie.com/guides/webhooks
	 *
	 * @since 1.0
	 *
	 * @param $mollie_payment_id string
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	public function handle_wehook_request( $mollie_payment_id ) {

		/** @var \Give_Mollie_API $give_mollie_api */
		$give_mollie_api = new Give_Mollie_API();

		// Check the API connection.
		if ( $give_mollie_api->get_errors() ) {
			$this->resource_not_found( __( 'Give Mollie Authentication Failed', 'give-mollie' ) );
			exit;
		}

		// Get the query vars.
		$request_query_vars = isset( $_GET ) ? $_GET : array();

		switch ( $request_query_vars['hook_type'] ) {

			case 'payments':
				// Get the Give Donation ID.
				$donation_id = give_get_purchase_id_by_transaction_id( $mollie_payment_id );

				// Get donation status.
				$payment_status = give_get_payment_status( $donation_id );

				// Check if donation exists.
				if ( ! $donation_id ) {
					$this->resource_not_found( __( 'Donation not found', 'give-mollie' ) );
				}

				/** @var \Mollie\Api\Resources\Payment $payment */
				$payment = $give_mollie_api->get_payment( $mollie_payment_id );

				// Update Donation payment method.
				give_update_payment_meta( $donation_id, '_give_mollie_payment_method', $payment->method );

				// Update Donation payment mode. (live or test)
				give_update_payment_meta( $donation_id, '_give_mollie_payment_mode', $payment->mode );

				/**
				 * Check if it is recurring donation or not.
				 *
				 * @since 1.0
				 */
				if ( $payment->isPaid() && ! $payment->hasRefunds() && ! $payment->hasChargebacks() ) {

					/*
					 * The payment is paid and isn't refunded or charged back. It's considered paid in full.
					 */
					// Update payment status.
					$this->update_payment_status( $donation_id, $payment->status );

					/**
					 * If it is subscription's first payment.
					 */
					if ( isset( $request_query_vars['first'] ) && isset( $request_query_vars['secret'] ) ) {

						$this->create_subscription( $payment, $give_mollie_api, $mollie_payment_id );

					}
				} elseif ( $payment->hasRefunds() ) {

					$this->process_refund( $donation_id, $payment );

				} elseif ( ! $payment->isOpen() ) {
					/**
					 * The payment isn't paid and isn't open anymore. We can assume it was aborted.
					 */
					if ( 'abandoned' !== $payment_status && 'expired' === $payment->status ) {

						// Update Payment status.
						$this->update_payment_status( $donation_id, 'abandoned' );

						// Insert payment expiration note.
						give_insert_payment_note( $donation_id, __( 'Payment has expired.', 'give-mollie' ) );
					}

					if ( $payment->isCanceled() ) {
						// Make this payment cancelled.
						$this->update_payment_status( $donation_id, 'cancelled' );

						// Insert payment expiration note.
						give_insert_payment_note( $donation_id, __( 'The donor has cancelled this payment.', 'give-mollie' ) );

						$subscription = give_recurring_get_subscription_by( 'payment', $donation_id );

						// If subscription is 'pending' cancel it  since the donor cancelled the payment.
						if ( isset( $subscription->status ) && 'pending' === $subscription->status ) {
							$subscription->update( array( 'status' => 'cancelled' ) );
						}
					} elseif ( $payment->isFailed() ) {
						// Make payment failed.
						$this->update_payment_status( $donation_id, 'failed' );
					}
				} elseif ( $payment->isPending() ) {
					/**
					 * The payment has started but is not complete yet.
					 */
					$this->update_payment_status( $donation_id, 'pending' );
				}
				break;
			case 'subscription':
				$this->renew_subscription( $mollie_payment_id, $give_mollie_api );

				break;
			default:
				/**
				 * Allow developers to handle the web-hook request.
				 *
				 * @since 1.0
				 *
				 * @param array $_POST Web-hook request data.
				 * @param array $_GET  Get params.
				 */
				do_action( "give_mollie_handle_{$request_query_vars['type'] }_hook", $_POST, $_GET );
				break;
		}
	}

	/**
	 * Created the subscription for donors.
	 *
	 * @since 1.2.0
	 *
	 * @param $payment
	 * @param $give_mollie_api
	 * @param $mollie_payment_id
	 */
	private function create_subscription( $payment, $give_mollie_api, $mollie_payment_id ) {

		$customer_id = isset( $payment->customerId ) ? $payment->customerId : '';
		// Get the Give Donation ID.
		$donation_id = give_get_purchase_id_by_transaction_id( $mollie_payment_id );

		try {

			/** @var \Mollie\Api\Resources\Customer $mollie_customer */
			$mollie_customer = $give_mollie_api->give_mollie_obj->customers->get( $customer_id );

			// Must have a valid Mollie Mandate to subscribe to.
			if ( ! $mollie_customer->hasValidMandate() ) {
				$this->resource_not_found( __( 'No valid mandate found for the Mollie customer.', 'give-mollie' ) );
			}

			/**
			 * Create Subscription with customer's mandate ID.
			 */
			try {

				// Get the subscription ID.
				$subscription_id = give_get_payment_meta( $donation_id, '_give_subscription_id', true );

				/** @var \Give_Subscription $subscription */
				$subscription = new Give_Subscription( $subscription_id );
				$frequency    = ! empty( $subscription->frequency ) ? intval( $subscription->frequency ) : 1;

				// API request for recurring donation in Mollie.
				$mollie_recurring_data = array(
					'amount'      => array(
						'value'    => $payment->amount->value,
						'currency' => $payment->amount->currency,
					),
					'startDate'   => date( 'Y-m-d', strtotime( $subscription->expiration ) ),
					'interval'    => "{$frequency} {$subscription->period}",
					'description' => Give_Mollie_API::get_payment_description( $subscription->parent_payment_id, $subscription ),
					'webhookUrl'  => $this->get_webhook_endpoint( 'subscription', '&give-sub-id=' . $subscription_id ),
				);

				// If bill time was passed subtract 1 because of the initial payment and proceed.
				if ( ! empty( $subscription->bill_times ) ) {
					$mollie_recurring_data['times'] = ( intval( $subscription->bill_times ) - 1 );
				}

				/** @var \Mollie\Api\Resources\Subscription $mollie_subscription */
				$mollie_subscription = $mollie_customer->createSubscription( $mollie_recurring_data );

				// Retrieve pending subscription from database and update it's status to active and set proper profile ID
				$subscription->update(
					array(
						'profile_id'        => $mollie_subscription->id,
						'parent_payment_id' => $donation_id,
						'status'            => $mollie_subscription->status,
					)
				);

				// Store Give Mollie subscription data and subscription id into payment meta.
				give_update_payment_meta( $donation_id, '_give_mollie_subscription_response', $mollie_subscription );
				give_update_payment_meta( $donation_id, '_give_mollie_subscription_id', $mollie_subscription->id );
				give_update_payment_meta( $donation_id, Give_Mollie_API::get_customer_meta_key(), $mollie_subscription->customerId );

			} catch ( \Mollie\Api\Exceptions\ApiException $e ) {

				give_record_gateway_error( esc_html__( 'Mollie Error', 'give-mollie' ), $e->getMessage() );
				throw new \Mollie\Api\Exceptions\ApiException( $e->getMessage() );

			}
		} catch ( \Mollie\Api\Exceptions\ApiException $e ) {
			// Give set error.
			give_set_error( 'mollie_recurring_error', $e->getMessage() );

			// Send back to checkout page.
			give_send_back_to_checkout( '?payment-mode=mollie' );
		}

	}


	/**
	 * Renews a subscription when a subscription payment renewal posts from Mollie.
	 *
	 * @since 1.2.0
	 *
	 * @param $mollie_payment_id
	 * @param $give_mollie_api Give_Mollie_API
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	private function renew_subscription( $mollie_payment_id, $give_mollie_api ) {

		// Check the existence of payment ID.
		if ( ! $mollie_payment_id ) {
			$this->resource_not_found( __( 'Payment ID is missing ', 'give-mollie' ) );
		}

		$mollie_payment = $give_mollie_api->get_payment( $mollie_payment_id );

		// Get the subscription ID.
		if ( isset( $mollie_payment->subscriptionId ) ) {

			/** @var \Give_Subscription $give_subscription */
			$give_subscription = new Give_Subscription( $mollie_payment->subscriptionId, true );

			// If subscription is not available.
			if ( ! $give_subscription->id ) {
				$this->resource_not_found( __( 'Subscription is missing.', 'give-mollie' ) );
			}

			// Get give donation id.
			$give_donation_id = give_get_purchase_id_by_transaction_id( $mollie_payment->id );

			// If renewal is not found.
			if ( empty( $give_donation_id ) ) {

				$bill_times = intval( $give_subscription->bill_times );

				// If subscription is ongoing or bill_times is less than total payments.
				if ( 0 === $bill_times || $give_subscription->get_total_payments() < $bill_times ) {

					// Params for payment.
					$give_subscription->add_payment(
						array(
							'amount'         => give_donation_amount( $give_subscription->parent_payment_id ),
							'transaction_id' => $mollie_payment->id,
						)
					);

					// Add a new renewal donation.
					$give_subscription->renew();

					// Get renew payment id.
					$renew_payment_id = give_get_purchase_id_by_transaction_id( $mollie_payment->id );

					// Store Give Mollie subscription data and subscription id into payment meta.
					give_update_payment_meta( $renew_payment_id, '_give_mollie_subscription_id', $give_subscription->transaction_id );

					// If customer ID is not blank.
					if ( null !== $mollie_payment->customerId ) {

						// Update donation customer
						give_update_payment_meta( $renew_payment_id, Give_Mollie_API::get_customer_meta_key(), $mollie_payment->customerId );
					}
				}
			} else {
				// Update payment status.
				$this->update_payment_status( $give_donation_id, $mollie_payment->status );

				if ( null !== $mollie_payment->customerId ) {
					give_update_payment_meta( $give_donation_id, Give_Mollie_API::get_customer_meta_key(), $mollie_payment->customerId );
				}
				give_update_payment_meta( $give_donation_id, '_give_mollie_payment_method', $mollie_payment->method );
				give_update_payment_meta( $give_donation_id, '_give_mollie_payment_mode', $mollie_payment->mode );
			}
		}
	}

	/**
	 * Process full and partial refunds as they come in from Mollie webhooks.
	 *
	 * @param $donation_id
	 * @param $payment
	 *
	 * @throws \Mollie\Api\Exceptions\ApiException
	 */
	private function process_refund( $donation_id, $payment ) {

		$donation_amount  = give_maybe_sanitize_amount( give_donation_amount( $donation_id ) );
		$remaining_amount = $donation_amount - $payment->amountRefunded->value;

		/** @var \Give_Mollie_API $give_mollie */
		$give_mollie = new Give_Mollie_API();

		/** @var \Mollie\Api\Resources\RefundCollection $refunds */
		$refunds = $give_mollie->give_mollie_obj->payments->get( $payment->id )->refunds();

		// Get previous refunds.
		$previous_refunds = give_get_payment_meta( $donation_id, '_give_mollie_refund_lists', true );
		$previous_refunds = is_array( $previous_refunds ) ? $previous_refunds : array();

		// Get the refund ids.
		$refund_ids = array_map(
			function ( $r ) {
				return is_object( $r ) ? $r->id : $r['id'];
			}, $refunds->getArrayCopy()
		);

		// Get the last inserted refund ID.
		$new_refund_id = array_diff( $refund_ids, $previous_refunds );

		// Prevent duplicate entries.
		if ( 0 !== count( $new_refund_id ) ) {

			// Insert refund note.
			give_insert_payment_note(
				$donation_id,
				sprintf(
					__( 'Total %1$s refunded, Remaining amount: %2$s. Refund ID: %3$s', 'give-mollie' ),
					give_currency_filter( $payment->amountRefunded->value, array( 'currency' => give_get_payment_currency_code( $donation_id ) ) ), // Total amount refunded.
					give_currency_filter( $remaining_amount, array( 'currency' => give_get_payment_currency_code( $donation_id ) ) ),  // Remaining amount.
					$new_refund_id[0] // Get the first refund ID.
				)
			);

			// Update refund Ids.
			give_update_payment_meta( $donation_id, '_give_mollie_refund_lists', $refund_ids );

			// Update status if refunded in full
			if ( intval( $remaining_amount ) === 0 ) {

				// Update payment status.
				$this->update_payment_status( $donation_id, 'refunded' );
			}
		}
	}

	/**
	 * Get the web-hook endpoint URL.
	 *
	 * @since 1.0
	 *
	 * @param string $endpoint_type Endpoint type.
	 * @param string $query_args    Additional query args.
	 *
	 * @return mixed
	 */
	public function get_webhook_endpoint( $endpoint_type = '', $query_args = '' ) {

		// Set the endpoint type.
		$this->endpoint_type = $endpoint_type;

		// Set web-hook endpoint.
		$this->webhook_endpoint = site_url() . "?give-listener=mollie&hook_type={$this->endpoint_type}{$query_args}";

		/**
		 * Get the web-hook endpoint.
		 *
		 * @since 1.0
		 *
		 * @param string $webhook_endpoint Web-hook Endpoint URL.
		 */
		return apply_filters( 'give_mollie_webhook_endpoint', $this->webhook_endpoint );
	}

	/**
	 * Show 404 resource not found.
	 *
	 * @since 1.0
	 *
	 * @param string $message Failed message.
	 */
	public function resource_not_found( $message ) {

		// Payment creation failed.
		give_record_gateway_error( __( 'Mollie Webhook Failed', 'give-mollie' ), sprintf( __( 'A Mollie webhook failed to process. Details: %1$s', 'give-mollie' ), $message ) );

		http_response_code( 404 );

	}

	/**
	 *  Update payment status.
	 *
	 * @since 1.0
	 *
	 * @param integer $donation_id Donation ID.
	 * @param string  $status      Payment status.
	 */
	public function update_payment_status( $donation_id, $status ) {

		switch ( $status ) {
			case 'paid':
				// Make donation completed.
				give_update_payment_status( $donation_id );
				break;
			case 'failed':
			case 'cancelled':
			case 'refunded':
			case 'abandoned':
				// Update payment status.
				give_update_payment_status( $donation_id, $status );
				break;
			default:
				give_record_gateway_error( esc_html__( 'Mollie Error', 'give-mollie' ), __( 'An error occurred updating the payment status.', 'give-mollie' ) );
				break;
		}
	}
}

new Give_Mollie_Webhook();
