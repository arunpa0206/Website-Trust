<?php

use GiveFunds\Models\Fund;

defined( 'ABSPATH' ) or exit;
?>
<tr class="form-field">
	<th scope="row" valign="top">
			<label for="give-md-select-fund">
				<?php esc_html_e( 'Associated Fund', 'give-manual-donations' ); ?>
			</label>
	</th>
	<td>
		<div class="give-md-select-fund-wrap">
			<select id="give-md-select-fund" name="give-selected-fund" class="give-select">
				<?php
				/* @var Fund[] $funds*/
				foreach ( $funds as $fund ) :
					?>
					<option value="<?php echo $fund->getId(); ?>">
						<?php echo $fund->getTitle(); ?>
						<?php if ( $fund->isDefault() ) : ?>
							( <?php esc_html_e( 'Default fund', 'give-manual-donations' ); ?> )
						<?php endif; ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	</td>
</tr>
