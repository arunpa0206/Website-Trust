<?php

namespace GiveMailChimp\MailChimp\Models;

use GiveMailChimp\MailChimp\Models\Contracts\MailChimpApiDataModel;

/**
 * Class MailChimpApiError
 * @package GiveMailChimp\MailChimp\Models
 * @since 1.5.0
 *
 * @property-read string $type
 * @property-read string $title
 * @property-read string $status
 * @property-read string $details
 * @property-read string $instance
 */
class MailChimpApiError extends MailChimpApiDataModel {
}
