<?php
/**
 * Give_Twocheckout_Payments
 *
 * @package     Give
 * @copyright   Copyright (c) 2016, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Give_Twocheckout_Payments
 */
class Give_Twocheckout_Payments {

	/**
	 * The twocheckout Private Key.
	 *
	 * @since  1.1
	 *
	 * @var string twocheckout Private Key
	 */
	protected static $twocheckout_private_key = '';

	/**
	 * The twocheckout seller ID.
	 *
	 * @since  1.1
	 *
	 * @var string twocheckout seller ID
	 */
	protected static $twocheckout_sellerID = '';

	/**
	 * The twocheckout API username.
	 *
	 * @since  1.1
	 *
	 * @var string twocheckout API Username
	 */
	protected static $twocheckout_api_username = '';

	/**
	 * The twocheckout API Password.
	 *
	 * @since  1.1
	 *
	 * @var string twocheckout API Password
	 */
	protected static $twocheckout_api_password = '';

	/**
	 * Give_Twocheckout_Payments constructor.
	 */
	function __construct() {

		self::$twocheckout_private_key = trim( give_get_option( 'twocheckout-private-key' ) );
		self::$twocheckout_sellerID    = trim( give_get_option( 'twocheckout-sellerId' ) );

		self::$twocheckout_api_username = trim( give_get_option( 'twocheckout-api-username' ) );
		self::$twocheckout_api_password = trim( give_get_option( 'twocheckout-api-password' ) );

		add_action( 'give_gateway_twocheckout', array( $this, 'give_process_twocheckout_payment' ), 10, 1 );

		add_filter( 'give_should_update_payment_status', array( $this, 'give_should_update_payment_status' ), 10, 4 );
	}

	/**
	 * On donation status change from complete to refunded.
	 *
	 * @since  1.1
	 *
	 * @param $do_change
	 * @param $donation_id
	 * @param $status
	 * @param $old_status
	 *
	 * @return $do_change
	 */
	public function give_should_update_payment_status( $do_change, $donation_id, $status, $old_status ) {

		// Only move forward if refund requested.
		if ( isset( $_POST['give_refund_in_twocheckout'] ) && empty( $_POST['give_refund_in_twocheckout'] ) || 'refunded' !== $status || 'publish' !== $old_status ) {
			return $do_change;
		}

		$gateway = strtolower( give_get_payment_gateway( $donation_id ) );
		if ( '2checkout' !== $gateway ) {
			return $do_change;
		}

		$twocheckout_api_username = self::$twocheckout_api_username;
		$twocheckout_api_password = self::$twocheckout_api_password;
		if ( empty( $twocheckout_api_username ) || empty( $twocheckout_api_password ) ) {
			return $do_change;
		}

		// Pass credentials to Twocheckout object
		Twocheckout::username( $twocheckout_api_username );
		Twocheckout::password( $twocheckout_api_password );

		// Check for sandbox
		if ( give_is_test_mode() ) {
			Twocheckout::sandbox( true );
		}

		$sale_id = absint( give_get_meta( $donation_id, '_give_payment_transaction_id', true ) );

		$args = array(
			'sale_id'  => $sale_id,
			'comment'  => 'Redunded by Admin.',
			'category' => 10,
		);

		try {
			$result = Twocheckout_Sale::refund( $args, 'array' );
			give_insert_payment_note( $donation_id, sprintf( esc_html__( 'Charge refunded in 2Checkout: %s', 'give-twocheckout' ), $sale_id ) );
			give_update_meta( $donation_id, 'give_twocheckout_refunded_success_responsive', $result );
			$do_change = true;

		} catch ( Twocheckout_Error $e ) {
			give_update_meta( $donation_id, 'give_twocheckout_refunded_fail_responsive', $e->getMessage() );
			give_insert_payment_note( $donation_id, sprintf( __( 'The 2Checkout payment gateway returned an error while refunding a donation: %s', 'give-twocheckout' ), $sale_id ) );
			$do_change = false;
		}

		/**
		 * Fire after the 2checkout refund is process
		 *
		 * @since 1.1
		 *
		 * @param $donation_id
		 * @param $do_change
		 */
		do_action( 'give_twocheckout_donation_refunded', $donation_id, $do_change );

		return $do_change;
	}

	/**
	 * 2Checkout Payments
	 *
	 * @param array $payment_data
	 */
	public function give_process_twocheckout_payment( $payment_data ) {

		$twocheckout_private_key = self::$twocheckout_private_key;
		$twocheckout_sellerID    = self::$twocheckout_sellerID;
		$twocheckout_token       = isset( $_POST['token'] ) ? give_clean( $_POST['token'] ) : '';

		// Error checks
		// Private key
		if ( ! isset( $twocheckout_private_key ) || '' === $twocheckout_private_key ) {
			give_set_error( 'private_key', esc_html__( 'Missing API account number or keys. Check the plugin settings.', 'give-twocheckout' ) );
		}
		// Token
		if ( '' === $twocheckout_token ) {
			give_set_error( 'missing_token', esc_html__( 'Invalid request: missing token. Check payment gateway in the plugin settings.', 'give-twocheckout' ) );
		}

		$errors = give_get_errors();

		// No errors: Continue with payment processing.
		if ( ! $errors ) {

			// Pass credentials to Twocheckout object.
			Twocheckout::privateKey( $twocheckout_private_key );
			Twocheckout::sellerId( $twocheckout_sellerID );

			// Don't need to verify SSL in test mode.
			if ( give_is_test_mode() ) {
				Twocheckout::verifySSL( false );
			}

			$form_id  = intval( $payment_data['post_data']['give-form-id'] );
			$price_id = isset( $payment_data['post_data']['give-price-id'] ) ? $payment_data['post_data']['give-price-id'] : 0;

			// Begin 2Checkout API Request
			$payment_args = array(
				'price'           => $payment_data['price'],
				'give_form_title' => $payment_data['post_data']['give-form-title'],
				'give_form_id'    => $form_id,
				'give_price_id'   => $price_id,
				'date'            => $payment_data['date'],
				'user_email'      => isset( $payment_data['post_data']['give_email'] ) ? $payment_data['post_data']['give_email'] : $payment_data['user_email'],
				'purchase_key'    => $payment_data['purchase_key'],
				'currency'        => give_get_currency( $form_id ),
				'user_info'       => $payment_data['user_info'],
				'status'          => 'pending',
				'gateway'         => '2Checkout',
			);

			$total      = $payment_data['price'];
			$currency   = $payment_args['currency'];
			$card_info  = $payment_data['card_info'];
			$first_name = isset( $payment_data['post_data']['give_first'] ) ? $payment_data['post_data']['give_first'] : $payment_data['user_info']['first_name'];
			$last_name  = isset( $payment_data['post_data']['give_last'] ) ? $payment_data['post_data']['give_last'] : $payment_data['user_info']['last_name'];

			$name    = $first_name . ' ' . $last_name;
			$address = $card_info['card_address'] . ' ' . $card_info['card_address_2'];
			$city    = $card_info['card_city'];
			$country = $card_info['card_country'];
			$state   = $card_info['card_state'];
			$zip     = $card_info['card_zip'];
			$email   = $payment_data['user_email'];

			try {
				$charge = Twocheckout_Charge::auth(
					apply_filters(
						'give_twocheckout_charge_args',
						[
							'sellerId'        => $twocheckout_sellerID,
							'demo'            => give_is_test_mode(),
							'merchantOrderId' => '0',
							'token'           => $twocheckout_token,
							'currency'        => $currency,
							'lineItems'       => [
								[
									'type'      => 'product',
									'price'     => $total,
									'name'      => $this->generate_payment_name( $form_id, $price_id ),
									'productId' => $form_id,
								],
							],
							'billingAddr'     => [
								'name'      => $name,
								'addrLine1' => $address,
								'city'      => $city,
								'state'     => $state,
								'zipCode'   => $zip,
								'country'   => $country,
								'email'     => $email,
							],
						]
					),
					'array'
				);

				$payment_id = give_insert_payment( $payment_args );

				if ( $payment_id && 'APPROVED' === $charge['response']['responseCode'] ) {

					give_update_meta( $payment_id, 'give_twocheckout_responce', $charge );
					give_set_payment_transaction_id( $payment_id, $charge['response']['orderNumber'] );

					give_update_payment_status( $payment_id, 'publish' );
					give_send_to_success_page();

				} else {
					give_set_error( 'twocheckout_error', esc_html__( 'Your payment could not be recorded. Please try again.', 'give-twocheckout' ) );
					give_send_back_to_checkout( '?payment-mode=' . $payment_data['post_data']['give-gateway'] );
				}
			} catch ( Twocheckout_Error $e ) {
				if ( strpos( $e->getMessage(), 'Payment Authorization Failed' ) !== false ) {
					give_set_error( 'invalid_card', esc_html__( 'Authorization failed. Please verify your credit card information, or try another payment method.', 'give-twocheckout' ) );
				} elseif ( 'Unauthorized' === $e->getMessage() ) {
					give_set_error( 'keys_error', esc_html__( 'Incorrect API account number or keys. Check the plugin settings.', 'give-twocheckout' ) );
				} else {
					give_set_error( 'api_error', $e->getMessage() );
				}
				give_send_back_to_checkout( '?payment-mode=' . $payment_data['post_data']['give-gateway'] );
			}
		} else {
			give_send_back_to_checkout( '?payment-mode=' . $payment_data['post_data']['give-gateway'] );
		}
	}


	/**
	 * Generates payment name
	 *
	 * @param  integer $form_id
	 * @param  integer $price_id
	 *
	 * @return string
	 */
	public function generate_payment_name( $form_id, $price_id = 0 ) {

		$payment_name = get_post_field( 'post_title', $form_id );

		if ( 0 !== $price_id ) {
			$payment_name .= ' - ' . give_get_price_option_name( $form_id, $price_id );
		}

		return apply_filters( 'twocheckout_payment_name', $payment_name );

	}


}
