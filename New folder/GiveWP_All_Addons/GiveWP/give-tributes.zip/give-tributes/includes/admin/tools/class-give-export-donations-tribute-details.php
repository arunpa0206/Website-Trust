<?php
/**
 * Give Tribute Export Fields Class.
 *
 * @package     Give_Tributes
 * @subpackage  Give_Tributes/admin
 * @since       1.5
 */

if ( ! class_exists( 'Give_Export_Donations_Tribute_Details' ) ) {

	/**
	 * This class deals with the export of Tribute fields.
	 *
	 * @since 1.5
	 */
	class Give_Export_Donations_Tribute_Details {


		/**
		 * Constructor function.
		 */
		public function __construct() {
			add_action( 'give_export_donation_fields', array( $this, 'add_tribute_fields_to_export_list' ) );
			add_filter( 'give_export_donation_get_columns_name', array(
				$this,
				'tributes_export_donation_get_columns_name'
			), 10, 2 );
			add_filter( 'give_export_donation_data', array( $this, 'tributes_give_export_donation_data' ), 30, 4 );

			add_filter( 'give_export_donations_ignore_hidden_keys', array( $this, 'remove_hidden_keys' ) );
		}

		/**
		 * Remove all the hidden filed that has special column name
		 *
		 * @since 1.5
		 *
		 * @return array $ignore_hidden_keys Hidden fields that are not going to get display in hidden fields columns
		 *
		 * @return array $ignore_hidden_keys Hidden fields that are not going to get display in hidden fields columns
		 */
		public function remove_hidden_keys( $ignore_hidden_keys ) {
			$ignore_hidden_keys[] = '_give_tributes_first_name';
			$ignore_hidden_keys[] = '_give_tributes_last_name';
			$ignore_hidden_keys[] = '_give_tributes_type';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_notify_first_name';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_notify_last_name';
			$ignore_hidden_keys[] = '_give_tributes_ecard_notify_first_name';
			$ignore_hidden_keys[] = '_give_tributes_ecard_notify_last_name';
			$ignore_hidden_keys[] = '_give_tributes_would_to';
			$ignore_hidden_keys[] = '_give_tributes_honoree_ecard_email';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_address_1';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_address_2';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_city';
			$ignore_hidden_keys[] = '_give_tributes_address_state';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_zipcode';
			$ignore_hidden_keys[] = '_give_tributes_address_country';
			$ignore_hidden_keys[] = '_give_tributes_mail_card_personalized_message';
			$ignore_hidden_keys[] = '_give_tributes_ecard_personalized_message';

			return $ignore_hidden_keys;
		}

		/**
		 * Adds custom column which contains checkboxes
		 * for Tribute fields.
		 *
		 * @since 1.5
		 *
		 * @return void
		 */
		public function add_tribute_fields_to_export_list() {
			?>
			<tr class="give-export-option-fields give-export-option-tribute-fields">
				<td scope="row" class="row-title">
					<label><?php esc_html_e( 'Tribute Fields:', 'give-tributes' ); ?></label>
				</td>
				<td class="give-field-wrap">
					<div class="give-clearfix">
						<ul class="give-export-option-tribute-fields-ul">
							<!-- Honoree First Name checkbox -->
							<li>
								<label for="give-export-tribute-honoree-first-name">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[honoree_first_name]"
										id="give-export-tribute-honoree-first-name"><?php esc_html_e( 'Honoree First Name', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Honoree Last Name checkbox -->
							<li>
								<label for="give-export-tribute-honoree-last-name">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[honoree_last_name]"
										id="give-export-tribute-honoree-last-name"><?php esc_html_e( 'Honoree Last Name', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Notification First Name checkbox -->
							<li>
								<label for="give-export-tribute-notification-first-name">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[notification_first_name]"
										id="give-export-tribute-notification-first-name"><?php esc_html_e( 'Notification First Name', 'give-tributes' ); ?>
								</label>
							</li>


							<!-- Notification Last Name checkbox -->
							<li>
								<label for="give-export-tribute-notification-last-name">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[notification_last_name]"
										id="give-export-tribute-notification-last-name"><?php esc_html_e( 'Notification Last Name', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Notification Method checkbox -->
							<li>
								<label for="give-export-tribute-notification-method">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[notification_method]"
										id="give-export-tribute-notification-method"><?php esc_html_e( 'Notification Method', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Tribute Type checkbox -->
							<li>
								<label for="give-export-tribute-tribute-type">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[tribute_type]"
										id="give-export-tribute-tribute-type"><?php esc_html_e( 'Tribute Type', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Tribute personal message checkbox -->
							<li>
								<label for="give-export-tribute-personalized_message">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[tribute_personalized_message]"
										id="give-export-tribute-personalized_message"><?php esc_html_e( 'Tribute Personalized Message', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Tribute Email/Address checkbox -->
							<li>
								<label for="give-export-tribute-contact">
									<input
										type="checkbox" checked
										name="give_give_donations_export_option[tribute_contact]"
										id="give-export-tribute-contact"><?php esc_html_e( 'Tribute Email/Address', 'give-tributes' ); ?>
								</label>
							</li>

							<!-- Tribute eCard Date and Time Sent  -->
							<li>
								<label for="give-export-tribute-date-time">
									<input
											type="checkbox" checked
											name="give_give_donations_export_option[tribute_date_time]"
											id="give-export-tribute-date-time"><?php esc_html_e( 'Date/Time eCard Sent', 'give-tributes' ); ?>
								</label>
							</li>
						</ul>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Add tributes columns in CSV heading.
		 *
		 * @since 1.5
		 *
		 * @param array $cols Columns names in CSV.
		 * @param array $columns Total number of column names in CSV.
		 *
		 * @return array $cols   Columns names in CSV.
		 */
		public function tributes_export_donation_get_columns_name( $cols, $columns ) {
			foreach ( $columns as $key => $value ) {
				switch ( $key ) {
					case 'honoree_first_name':
						$cols['honoree_first_name'] = __( 'Honoree First Name', 'give-tributes' );
						break;

					case 'honoree_last_name':
						$cols['honoree_last_name'] = __( 'Honoree Last Name', 'give-tributes' );
						break;

					case 'notification_first_name':
						$cols['notification_first_name'] = __( 'Notification First Name', 'give-tributes' );
						break;

					case 'notification_last_name':
						$cols['notification_last_name'] = __( 'Notification Last Name', 'give-tributes' );
						break;

					case 'notification_method':
						$cols['notification_method'] = __( 'Notification Method', 'give-tributes' );
						break;

					case 'tribute_type':
						$cols['tribute_type'] = __( 'Tribute Type', 'give-tributes' );
						break;

					case 'tribute_personalized_message':
						$cols['tribute_personalized_message'] = __( 'Tribute Personalized Message', 'give-tributes' );
						break;

					case 'tribute_contact':
						$cols['tribute_contact'] = __( 'Tribute Email/Address', 'give-tributes' );
						break;

					case 'tribute_date_time':
						$cols['tribute_date_time'] = __( 'Date/Time eCard Sent', 'give-tributes' );
						break;

					default:
						break;
				}
			}

			return $cols;
		}

		/**
		 * Populates the CSV rows.
		 *
		 * @since 1.5
		 *
		 * @param array                     $data     Donation data.
		 * @param Give_Payment              $payment  Instance of Give_Payment.
		 * @param array                     $columns  Donation data $columns that are not being merge.
		 * @param Give_Export_Donations_CSV $instance Instance of Give_Export_Donations_CSV.
		 *
		 * @return array
		 */
		public function tributes_give_export_donation_data( $data, $payment, $columns, $instance ) {

			// Get payment ID.
			$payment_id = $payment->ID;

			// Tributes Type.
			$tribute_type = give_get_meta( $payment_id, '_give_tributes_type', true );

			// Check if the donation is dedicated to someone.
			$tribute_status = give_get_meta( $payment_id, '_give_tributes_accept', true );

			// The notification method: 'eCard' or 'Mail a Card'.
			$notification_method = give_get_meta( $payment_id, '_give_tributes_would_to', true );

			/**
			 * If the donation is dedicated to someone, then populate
			 * the rows with the respective values else populate with
			 * empty string.
			 */
			if ( give_is_setting_enabled( 'yes', $tribute_status ) ) {

				// Honoree First Name.
				$hf_name = give_get_meta( $payment_id, '_give_tributes_first_name', true );
				$hf_name = ! empty( $hf_name ) ? ucfirst( $hf_name ) : '';

				// Honoree Last Name.
				$hl_name = give_get_meta( $payment_id, '_give_tributes_last_name', true );
				$hl_name = ! empty( $hl_name ) ? ucfirst( $hl_name ) : '';

				$data['honoree_first_name'] = $hf_name;
				$data['honoree_last_name']  = $hl_name;

				// Notification First Name.
				$nf_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_first_name', true );

				// Notification Last Name.
				$nl_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_last_name', true );

				$nf_name = ! empty( $nf_name ) ? ucfirst( $nf_name ) : '';
				$nl_name = ! empty( $nl_name ) ? ucfirst( $nl_name ) : '';

				if ( 'send_eCard' === $notification_method ) {
					$nf_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_first_name', true );
					$nf_name = is_array( $nf_name ) ? implode( PHP_EOL, $nf_name ) : ucfirst( $nf_name );

					$nl_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_last_name', true );
					$nl_name = is_array( $nl_name ) ? implode( PHP_EOL, $nl_name ) : ucfirst( $nl_name );
				}

				$data['notification_first_name'] = $nf_name;
				$data['notification_last_name']  = $nl_name;

				// The notification method: 'eCard' or 'Mail a Card' or 'Not selected'.
				if ( 'send_eCard' === $notification_method ) {
					$data['notification_method'] = 'eCard';
				} else if ( 'send_mail_card' === $notification_method ) {
					$data['notification_method'] = 'Mail a Card';
				} else {
					$data['notification_method'] = 'Not selected';
				}

				// The Tribute Type. 2 defaults are 'In honor of' and 'In memory of'.
				$data['tribute_type'] = $tribute_type;

				if ( 'send_eCard' === $notification_method ) {
					$personalized_message = give_get_meta( $payment_id, '_give_tributes_ecard_personalized_message', true );

					if ( is_array( $personalized_message ) ) {
						$new_personalized_message = array();
						foreach ( $personalized_message as $message ) {
							$new_message = '';
							// check it an array and it's empty or not.
							if ( is_array( $message ) && ! empty( $message ) ) {
								$new_message = isset( $message[0] ) ? $message[0] : '';
								// check if it's an string or not.
							} elseif ( is_string( $message ) ) {
								$new_message = $message;
							}

							$new_personalized_message[] = $new_message;
						}
						$personalized_message = $new_personalized_message;
					}
					$personalized_message = is_array( $personalized_message ) ? implode( PHP_EOL, $personalized_message ) : $personalized_message;
				} else {
					$personalized_message = give_get_meta( $payment_id, '_give_tributes_mail_card_personalized_message', true );
				}

				$data['tribute_personalized_message'] = $personalized_message;

				if ( 'send_eCard' === $notification_method ) {
					// Tribute Email ( for eCard ) OR Address ( for Mail a Card ).
					$tributes_contact = give_get_meta( $payment_id, '_give_tributes_honoree_ecard_email', true );
					$tributes_contact = is_array( $tributes_contact ) ? implode( PHP_EOL, $tributes_contact ) : $tributes_contact;
				} else {
					$tributes_contact = wp_strip_all_tags( give_tributes_notification_address( $payment_id, false ) );
				}
				$data['tribute_contact'] = $tributes_contact;
				// eCard Email sent date.
				$give_ecard_email_sent_date = give_get_meta( $payment_id, '_give_tributes_ecard_email_sent_date', true );
				$give_ecard_email_sent_date = ! empty( $give_ecard_email_sent_date ) ? $give_ecard_email_sent_date : $payment->date;
				$data['tribute_date_time']  = $give_ecard_email_sent_date;
			} else {

				$data['honoree_first_name']           = '';
				$data['honoree_last_name']            = '';
				$data['notification_first_name']      = '';
				$data['notification_last_name']       = '';
				$data['notification_method']          = '';
				$data['tribute_type']                 = '';
				$data['tribute_personalized_message'] = '';
				$data['tribute_contact']              = '';
				$data['tribute_date_time']            = '';
			}

			return $data;
		}
	}

	new Give_Export_Donations_Tribute_Details();
}
