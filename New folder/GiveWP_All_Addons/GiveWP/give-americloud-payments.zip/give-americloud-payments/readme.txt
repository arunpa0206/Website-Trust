=== Give - AmeriCloud Payments ===
Contributors: givewp, americloud
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, americloud, gateway
Requires at least: 4.8
Tested up to: 5.2
Stable tag: 1.3.4
Requires Give: 2.4.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

AmeriCloud Payments Gateway Add-on for Give.

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds a payment gateway for AmeriCloud Payments.

== Installation ==

= Minimum Requirements =

* WordPress 4.8 or greater
* PHP version 5.5 or greater
* MySQL version 5.0 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.3.4: June 3rd, 2019 =
* Tweak: The phone number field now displays after the email field.
* Tweak: Adjusted the plugin's settings screens code logic to work with GiveWP Core 2.5.0+ which deprecates the old methods used to register settings in previous versions of this add-on.
* Tweak: Removed the outdated option to set a gateway label which is now part of GiveWP Core.

= 1.3.3: January 4th, 2019 =
* Fix: Resolved issue with API package missing methods for successful ACH transactions.
* Fix: Resolved incorrect validation for missing fields for non-AmeriCloud gateways.

= 1.3.2: January 2nd, 2019 =
* Fix: Ensure that the AmeriCloud required fields for phone number and zip / postal code do not display for other gateways that do not require them.

= 1.3.1: October 4th, 2018 =
* New: Recurring Donation functionality developed by AmeriCloud Solutions. Note: By default, recurring donations start on the next day. Important: You DO NOT need to use the "Give - Recurring Donations" add-on to use this functionality. If you have already installed it, please deactivate it.
* Fix: Corrected discrepancy of version numbers.

= 1.3.0 =
* Tweak: Improve transaction error handling.
* New: Allow donors to enter no. of months for recurring donations.
* Fix: Several minor improvements and enhancements.

= 1.2.1: January 12th, 2018 =
* Tweak: Plugin code reviewed and updated with latest specs and minor improvements.
* Fix: There was a broken link to settings tab within wp-admin notice.

= 1.1.1 =
* Fix: Resolved issue with accepting eChecks.

= 1.1 =
* Fix: Added proper validation for the credit card payment fields.

= 1.0 =
* Initial plugin release. Yippee!
