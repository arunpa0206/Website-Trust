<?php
/**
 * Give MailChimp Settings Page/Tab
 *
 * @package    Give_MailChimp
 * @subpackage Give_MailChimp/includes
 * @author     GiveWP <https://givewp.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Give_MailChimp_Settings_Output' ) ) :

	/**
	 * Give_MailChimp_Settings.
	 *
	 * @sine 1.4.2
	 */
	class Give_MailChimp_Settings_Output extends Give_Settings_Page {

		/**
		 * Constructor.
		 *
		 * @since 1.4.2
		 */
		public function __construct() {
			$this->id    = 'give-mailchimp';
			$this->label = __( 'MailChimp', 'give-mailchimp' );
			parent::__construct();
		}

		/**
		 * Get settings array.
		 *
		 * @since  1.4.2
		 * @access public
		 *
		 * @return array
		 */
		public function get_settings() {
			$give_mailchimp_settings = [
				[
					'name' => __( 'MailChimp Settings', 'give-mailchimp' ),
					'id'   => 'give_title_mailchimp',
					'type' => 'title',
				],
				[
					'id'   => 'give_mailchimp_api',
					'name' => __( 'MailChimp API Key', 'give-mailchimp' ),
					'desc' => __( 'Enter your MailChimp API key', 'give-mailchimp' ),
					'type' => 'api_key',
				],
				[
					'id'   => 'give_mailchimp_double_opt_in',
					'name' => __( 'Double Opt-In', 'give-mailchimp' ),
					'desc' => __( 'When checked, users will be sent a confirmation email after signing up, and will only be added once they have confirmed the subscription.', 'give-mailchimp' ),
					'type' => 'checkbox',
				],
				[
					'id'   => 'give_mailchimp_show_checkout_signup',
					'name' => __( 'Enable Globally', 'give-mailchimp' ),
					'desc' => __( 'Allow donors to sign up for the list selected below on all donation forms? Note: the list(s) can be customized per form.', 'give-mailchimp' ),
					'type' => 'checkbox',
				],
				[
					'id'      => 'give_mailchimp_checked_default',
					'name'    => __( 'Opt-in Default', 'give-mailchimp' ),
					'desc'    => __( 'Would you like the newsletter opt-in checkbox checked by default? This option can be customized per form.', 'give-mailchimp' ),
					'options' => [
						'yes' => __( 'Checked', 'give-mailchimp' ),
						'no'  => __( 'Unchecked', 'give-mailchimp' ),
					],
					'default' => 'no',
					'type'    => 'radio_inline',
				],
				[
					'id'   => 'give_mailchimp_list',
					'name' => __( 'Default List', 'give-mailchimp' ),
					'desc' => __( 'Select the list you wish for all donors to subscribe to by default. Note: the list(s) can be customized per form.', 'give-mailchimp' ),
					'type' => 'mailchimp_list_select',
				],
				[
					'id'         => 'give_mailchimp_label',
					'name'       => __( 'Default Label', 'give-mailchimp' ),
					'desc'       => __( 'This is the text shown by default next to the MailChimp sign up checkbox. Yes, this can also be customized per form.', 'give-mailchimp' ),
					'type'       => 'text',
					'attributes' => [
						'placeholder' => __( 'Subscribe to our newsletter', 'give-mailchimp' ),
					],
				],
				[
					'id'   => 'give_mailchimp_donation_data',
					'name' => __( 'Send Donation Data', 'give-mailchimp' ),
					'desc' => __( 'Enabling this option will send donation data such as Donation Form Title, ID, Payment Method and more to MailChimp under the Subscriber\'s Details.', 'give-mailchimp' ),
					'type' => 'checkbox',
				],
			];

			/**
			 * If FFM is activated then add new option which ask to send custom
			 * field data to Mail Chimp or not.
			 *
			 * @since 1.4.0
			 */
			if ( give_mc_ffm_is_activated() ) {

				$give_mailchimp_settings[] = [
					'id'   => 'give_mailchimp_ffm_pass_field',
					'name' => __( 'Send FFM Fields', 'give-mailchimp' ),
					'desc' => __( 'Would you like to send Form Field Manager field data to MailChimp? Note: FFM data will only send if the <code>Send Donation Data</code> option is checked.', 'give-mailchimp' ),
					'type' => 'checkbox',
				];
			}

			// Docs link is always last.
			$give_mailchimp_settings[] = [
				'name'  => __( 'MailChimp Docs Link', 'give-mailchimp' ),
				'id'    => 'mailchimp_settings_docs_link',
				'url'   => esc_url( 'http://docs.givewp.com/addon-mailchimp' ),
				'title' => __( 'MailChimp Settings', 'give-mailchimp' ),
				'type'  => 'give_docs_link',
			];
			$give_mailchimp_settings[] = [
				'id'   => 'give_mailchimp_settings',
				'type' => 'sectionend',
			];

			return $give_mailchimp_settings;
		}
	}

endif;

return new Give_MailChimp_Settings_Output();
