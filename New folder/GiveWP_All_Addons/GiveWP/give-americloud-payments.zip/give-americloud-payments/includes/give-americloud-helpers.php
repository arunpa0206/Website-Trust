<?php
/**
 * AmeriCloud Helper Functions.
 *
 * @since 1.3.2
 */


$recurring_enabled = give_get_option( 'americloud_enable_recurring' );
$billing_enabled   = give_get_option( 'americloud_collect_billing' );

/**
 * Show recurring checkbox on the form
 */
function give_americloud_recurring_checkbox() { ?>

	<div style="margin: 0 0 25px; display: block; line-height: 1em; clear: both; cursor: pointer;">
		<input name="recurring-donation" type="checkbox" value="yes"/>
		<label for="recurring">Make this donation recurring for <input id="number" type="tel" maxlength="3"
																	   name="months" value="12"
																	   style="width: 60px; height: 25px; font-size: 15px; text-align: center">
			months</label>
	</div>

	<?php
	return true;
}


// Show Recurring checkbox if user has option enabled
if ( $recurring_enabled ) {
	add_action( 'give_after_donation_levels', 'give_americloud_recurring_checkbox', 1, 2 );
}


/**
 * Add zip field to form only if collect billing details is disabled
 *
 * @param int $form_id
 *
 * @return false|string
 */
function give_americloud_add_donor_zip_form_field( $form_id ) {
	?>

	<p id="give-card-zip-wrap" class="form-row form-row-first form-row-responsive">
		<label for="card_zip" class="give-label">
			<?php _e( 'Zip / Postal Code', 'give' ); ?>
			<span class="give-required-indicator">*</span>
			<?php echo Give()->tooltips->render_help( __( 'The ZIP Code or postal code for your billing address.', 'give' ) ); ?>
		</label>

		<input
				type="text"
				size="5"
				id="card_zip"
				name="zip_code"
				autocomplete="postal-code"
				class="card-zip give-input<?php echo( give_field_is_required( 'card_zip', $form_id ) ? ' required' : '' ); ?>"
				placeholder="<?php _e( 'Zip / Postal Code', 'give' ); ?>"
				value=""
				minlength="5" maxlength="5" title="Zip code must be 5 digits"
				aria-required="true"
		/>
	</p>
	<?php
}

if ( ! $billing_enabled ) {
	add_action( 'give_americloud_after_cc_fields', 'give_americloud_add_donor_zip_form_field' );
}

/**
 * Add donor phone field to form
 *
 * @param int $form_id
 */
function give_americloud_add_donor_phone_form_field( $form_id ) {
	?>
	<p id="give-email-wrap" class="form-row form-row-wide">
		<label class="give-label" for="give-email">
			<?php _e( 'Phone No.', 'give' ); ?>
			<span class="give-required-indicator">*</span>
			<?php echo Give()->tooltips->render_help( __( 'Please enter your phone number.', 'give' ) ); ?>
		</label>

		<input
				class="give-input required"
				type="tel"
				name="give_phone"
				autocomplete="phone"
				maxlength="10"
				placeholder="<?php _e( 'Phone No.', 'give' ); ?>"
				id="give-email"
				value="<?php isset( $_POST['give_phone'] ) ? give_clean( $_POST['give_phone'] ) : ''; ?>"
				aria-required="true"
		>
	</p>
	<?php
}

add_action( 'give_donation_form_after_email', 'give_americloud_add_donor_phone_form_field' );
add_action( 'give_donation_form_after_email', 'give_americloud_add_donor_phone_form_field' );

/**
 * Set donor phone form field as required
 *
 * @param array $required_fields
 * @param int   $form_id
 *
 * @return array
 */
function give_americloud_required_fields( $required_fields, $form_id ) {

	$gateway = give_get_chosen_gateway( $form_id );

	// Bailout if not this gateway.
	if ( ! in_array( $gateway, array(
			'americloudpayments',
			'americloudpayments_ach',
		)
	) ) {
		return $required_fields;
	}

	$required_fields['give_phone'] = array(
		'error_id'      => 'invalid_phone',
		'error_message' => __( 'Please enter a phone number.', 'give-americloud' ),
	);

	$billing_enabled = give_get_option( 'americloud_collect_billing' );

	// Only validate zip for CC payments.
	if ( ! give_is_setting_enabled( $billing_enabled ) && 'americloudpayments' === $gateway ) {
		$required_fields['zip_code'] = array(
			'error_id'      => 'no_zip_code',
			'error_message' => __( 'Please enter a zip/postal code.', 'give-americloud' ),
		);
	}

	return $required_fields;
}

add_action( 'give_donation_form_required_fields', 'give_americloud_required_fields', 10, 2 );

/**
 * Save phone number to donation meta
 *
 * @param $donation_id
 */
function give_americloud_save_donor_phone_number( $donation_id ) {
	$donor_id         = give_get_payment_donor_id( $donation_id );
	$new_phone_number = give_clean( $_POST['give_phone'] );
	$phone_numbers    = Give()->donor_meta->get_meta( $donor_id, 'give_phone' );

	// Add phone number only if not exist.
	if ( ! in_array( $new_phone_number, $phone_numbers ) ) {
		Give()->donor_meta->add_meta( $donor_id, 'give_phone', $new_phone_number );
	}
	Give()->payment_meta->update_meta( $donation_id, '_give_phone', $new_phone_number );

}

add_action( 'give_insert_payment', 'give_americloud_save_donor_phone_number', 10 );

/**
 * Show donor phone numbers on donor profile
 *
 * @param Give_Donor $donor
 */
function give_americloud_show_donor_phone_numbers( $donor ) {
	$phone_numbers = $donor->get_meta( 'give_phone', false );
	?>
	<div id="donor-address-wrapper" class="donor-section clear">
		<h3><?php _e( 'Phone Numbers', 'give' ); ?></h3>

		<div class="postbox">
			<div class="inside">
				<?php if ( empty( $phone_numbers ) ) : ?>
					<?php _e( 'This donor does not have any phone number saved.', 'give' ); ?>
				<?php else : ?>
					<?php foreach ( $phone_numbers as $phone_number ) : ?>
						<?php echo $phone_number; ?><br>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}

add_action( 'give_donor_before_address', 'give_americloud_show_donor_phone_numbers' );

/**
 * Set the content of the confirmation and failure page according to payment response
 */
function give_americloud_confirmation_page_content( $content ) {

	$session = give_get_purchase_session();

	// Only modify AmeriCloud payments.
	if ( ! isset( $session['gateway'] ) || ! in_array(
			$session['gateway'], array(
				'americloudpayments',
				'americloudpayments_ach',
			)
		) ) {
		return $content;
	}

	// If donation was successful.
	if ( give_is_success_page() ) {

		// recurring
		if ( isset( $_GET['type'] ) && $_GET['type'] == 'recurring' ) {
			$content = '';
			$content .= '<div class="give_notices give_errors" id="give_error_success"><p class="give_error give_notice give_success" data-dismissible="" data-dismiss-interval="5000" data-dismiss-type="">';
			$content .= 'Success! Your monthly donation is scheduled to start on: <strong>' . date( 'F j, Y', strtotime( '+1 day' ) ) . '</strong>';
			$content .= '</p></div>';
			$content .= '[give_receipt]';
			$content .= '<p style="text-align: center;">← <u><a href="' . get_home_url() . '">Make another donation?</a></u></p>';
		} // one time
		else {
			$content = '';
			$content .= '<div class="give_notices give_errors" id="give_error_success"><p class="give_error give_notice give_success" data-dismissible="" data-dismiss-interval="5000" data-dismiss-type="">';
			$content .= '<strong>Success!</strong> We have received your donation. Please check your email for a receipt.';
			$content .= '</p></div>';
			$content .= '[give_receipt]';
			$content .= '<p style="text-align: center;">← <a href="' . ( isset( $session['post_data']['give-form-url'] ) ? $session['post_data']['give-form-url'] : get_home_url() ) . '">Make another donation?</a></p>';

		}
	}

	// If donation failed
	if ( give_is_failed_transaction_page() ) {
		$content = '';
		$content .= '<div class="give_notices give_errors" id="give_error_failed"><p class="give_error give_notice give_failed" data-dismissible="" data-dismiss-interval="5000" data-dismiss-type="">';
		$content .= 'Sorry, your donation failed to process. <strong>' . $_GET['result'] . '</strong>';
		$content .= '</p></div>';
		$content .= '<p style="text-align: center;">← <a href="' . ( isset( $session['post_data']['give-form-url'] ) ? $session['post_data']['give-form-url'] : get_home_url() ) . '">Try again?</a></p>';
	}

	return $content;
}

add_filter( 'the_content', 'give_americloud_confirmation_page_content' );


/**
 * Hide default notices in favor of custom detailed notices
 */
function give_americloud_prefix_custom_notice( $notice, $id, $status, $meta ) {
	return '';
}

add_filter( 'give_receipt_status_notice', 'give_americloud_prefix_custom_notice', 10, 4 );
