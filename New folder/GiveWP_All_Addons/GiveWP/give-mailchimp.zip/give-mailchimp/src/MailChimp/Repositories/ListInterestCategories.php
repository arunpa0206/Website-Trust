<?php

namespace GiveMailChimp\MailChimp\Repositories;

use Give\Framework\Database\DB;
use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;
use stdClass;

/**
 * Class ListInterestCategories
 *
 * @package GiveMailChimp\MailChimp\Repositories
 * @since 1.5.0
 */
class ListInterestCategories {
	private $transientExpirationTime = WEEK_IN_SECONDS;

	/**
	 * @var \GiveMailChimp\MailChimp\Api\Marketing\Lists
	 */
	private $listApiClient;

	/**
	 * Lists constructor.
	 *
	 * @param  \GiveMailChimp\MailChimp\Api\Marketing\Lists  $listApiClient
	 */
	public function __construct( \GiveMailChimp\MailChimp\Api\Marketing\Lists $listApiClient ) {
		$this->listApiClient = $listApiClient;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 * @param  array  $bodyParameters
	 *
	 * @return stdClass
	 * @throws ApiException
	 * @throws RequestException
	 * @throws MailchimpApiKeyDoesNotExistException
	 */
	public function getInterestCategories( $listId, $bodyParameters = [] ) {
		$interestCategories = get_transient( $this->getInterestCategoriesOptionKey( $listId ) );

		if ( $interestCategories ) {
			return $interestCategories;
		}

		$data = $this->listApiClient->getInterestCategories( $listId, $bodyParameters );

		$this->updateInterestCategories( $listId, $data );

		return $data;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 * @param  string  $interestCategoryId
	 * @param  array  $bodyParameters
	 *
	 * @return stdClass
	 * @throws ApiException
	 * @throws MailchimpApiKeyDoesNotExistException
	 * @throws RequestException
	 */
	public function getInterestCategoriesInterests( $listId, $interestCategoryId, $bodyParameters = [] ) {
		$data = get_transient( $this->getInterestCategoriesInterestsOptionKey( $listId, $interestCategoryId ) );

		if ( $data ) {
			return $data;
		}

		$data = $this->listApiClient->getInterestCategoryInterests( $listId, $interestCategoryId, $bodyParameters );

		$this->updateInterestCategoryInterests( $listId, $interestCategoryId, $data );

		return $data;
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 *
	 * @return string
	 */
	public function getInterestCategoriesOptionKey( $listId ) {
		return "give_mailchimp_groupings_{$listId}";
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 * @param  string  $interestCategoryId
	 *
	 * @return string
	 */
	public function getInterestCategoriesInterestsOptionKey( $listId, $interestCategoryId ) {
		return "give_mailchimp_groupings_{$listId}_group_{$interestCategoryId}";
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string|null  $listId
	 *
	 * @return bool
	 */
	public function deleteInterestCategories( $listId ) {
		return delete_transient( $this->getInterestCategoriesOptionKey( $listId ) );
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 * @param  stdClass  $data
	 *
	 * @return bool
	 */
	public function updateInterestCategories( $listId, $data ) {
		return set_transient(
			$this->getInterestCategoriesOptionKey( $listId ),
			$data,
			$this->transientExpirationTime
		);
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 * @param  string  $interestCategoryId
	 * @param  stdClass  $data
	 *
	 * @return bool
	 */
	public function updateInterestCategoryInterests( $listId, $interestCategoryId, $data ) {
		return set_transient(
			$this->getInterestCategoriesInterestsOptionKey( $listId, $interestCategoryId ),
			$data,
			$this->transientExpirationTime
		);
	}

	/**
	 * @since 1.5.0
	 *
	 * @return bool
	 */
	public function deleteAllInterestCategories() {
		global $wpdb;

		return (bool) DB::query(
			"
			DELETE FROM {$wpdb->options}
			WHERE option_name
			LIKE '%give_mailchimp_groupings_%'"
		);
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  string  $listId
	 *
	 * @return array
	 * @throws ApiException|MailchimpApiKeyDoesNotExistException|RequestException
	 */
	public function getInterestCategoriesTitles( $listId ) {
		$data = $this->getInterestCategories( $listId );

		if ( ! $data->total_items ) {
			return [];
		}

		$newData = [];
		foreach ( $data->categories as $category ) {
			$categoryId        = $category->id;
			$categoryTitle     = $category->title;
			$categoryInterests = $this->getInterestCategoriesInterests( $listId, $categoryId );

			if ( ! $categoryInterests->total_items ) {
				continue;
			}

			foreach ( $categoryInterests->interests as $interest ) {
				$interestId   = $interest->id;
				$interestName = $interest->name;

				$newData[ "{$listId}|{$categoryId}|{$interestId}" ] = "{$categoryTitle}-{$interestName}";
			}
		}

		return $newData;
	}
}
