<?php
// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Kishanio\CCAvenue\Payment as CCAvenueClient;

/**
 * Check if CCAvenue payment gateway active or not.
 *
 * @since 1.0
 * @return bool
 */
function give_is_ccavenue_active() {
	$give_settings = give_get_settings();
	$is_active     = false;

	if (
		array_key_exists( 'ccavenue', $give_settings['gateways'] )
		&& ( 1 == $give_settings['gateways']['ccavenue'] )
	) {
		$is_active = true;
	}

	return $is_active;
}

/**
 * Get payment gayeway label.
 *
 * @since 1.0
 * @return string
 */
function give_ccavenue_get_payment_method_label() {
	return give_get_gateway_checkout_label( 'ccavenue' );
}

/**
 * Check if sandbox mode is enabled or disabled.
 *
 * @since 1.0
 * @return bool
 */
function give_ccavenue_is_sandbox_mode_enabled() {
	return give_is_test_mode();
}


/**
 * Get ccavenue agent credentials.
 *
 * @since 1.0
 * @return array
 */
function give_ccavenue_get_merchant_credentials() {
	$give_settings = give_get_settings();

	$credentials = array(
		'merchant_id' => $give_settings['ccavenue_live_merchant_id'],
		'working_key' => $give_settings['ccavenue_live_working_key'],
		'access_code' => $give_settings['ccavenue_live_access_code'],
	);

	return apply_filters( 'give_ccavenue_get_merchant_credentials', $credentials );

}


/**
 * Get form from donation purchase info.
 *
 * @since 1.0
 *
 * @return string
 */
function give_ccavenue_get_form() {

	$donation_data   = Give()->session->get( 'give_purchase' );
	$form_url        = trailingslashit( current( explode( '?', $donation_data['post_data']['give-current-url'] ) ) );
	$merchant        = give_ccavenue_get_merchant_credentials();
	$ccavenue        = new CCAvenueClient( $merchant['merchant_id'], $merchant['working_key'], $form_url . '?process_ccavenue_payment_success' );
	$donation_id     = absint( $_GET['donation'] );
	$form_id         = absint( $_GET['form-id'] );
	$country_list    = give_get_country_list();
	$donation_amount = give_sanitize_amount( $donation_data['post_data']['give-amount'] );

	$ccavenue->setAmount( $donation_amount );
	$ccavenue->setOrderId( $donation_id );
	$ccavenue->setCurrency( give_get_currency() ); // Only INR currency.
	$ccavenue->setRedirectUrl( $form_url . '?process_ccavenue_payment_success' );
	$ccavenue->setBillingName( $donation_data['post_data']['give_first'] . ' ' . $donation_data['post_data']['give_last'] );
	$ccavenue->setBillingAddress( $donation_data['post_data']['card_address'] . " {$donation_data['post_data']['card_address_2']}" );
	$ccavenue->setBillingCity( $donation_data['post_data']['card_city'] );
	$ccavenue->setBillingZip( $donation_data['post_data']['card_zip'] );
	$ccavenue->setBillingTel( ( isset( $donation_data['post_data']['give_ccavenue_phone'] ) ? $donation_data['post_data']['give_ccavenue_phone'] : '' ) );
	$ccavenue->setBillingEmail( $donation_data['post_data']['give_email'] );
	$ccavenue->setBillingState( $donation_data['post_data']['card_state'] );
	$ccavenue->setBillingCountry( $country_list[ $donation_data['post_data']['billing_country'] ] );
	$ccavenue->setBillingEmail( $donation_data['user_email'] );
	$ccavenue->setBillingNotes( sprintf( __( 'This is a donation payment for %s', 'give-ccavenue' ), $donation_id ) );

	// Copy all billing details into shipping
	$ccavenue->billingSameAsShipping();

	// Get Encrypted Data
	$data = $ccavenue->getEncryptedData();
	ob_start();
	?>
	<form method="post" name="redirect" action="<?php echo esc_url( give_ccavenue_get_api_url() ); ?>">
		<input type="hidden" name="encRequest" value="<?php echo $data; ?>"/>
		<input type="hidden" name="access_code" value="<?php echo $merchant['access_code']; ?>"/>
	</form>
	<?php

	return ob_get_clean();
}

/**
 * Get api urls.
 *
 * @since 1.0
 * @return string
 */
function give_ccavenue_get_api_url() {
	$api_url = 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

	if ( ! give_ccavenue_is_sandbox_mode_enabled() ) {
		$api_url = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';
	}

	return $api_url;
}

/**
 * Process ccavenue success payment.
 *
 * @since  1.0
 *
 * @access public
 *
 * @param int   $donation_id
 * @param array $response
 */
function give_ccavenue_process_success_payment( $donation_id, $response ) {
	$donation = new Give_Payment( $donation_id );
	$donation->update_status( 'completed' );
	$donation->add_note( sprintf( __( 'CCavenue payment completed (Transaction id: %s)', 'give-ccavenue' ), $response['tracking_id'] ) );

	give_set_payment_transaction_id( $donation_id, $response['tracking_id'] );
	update_post_meta( $donation_id, 'ccavenue_donation_response', $response );

	give_send_to_success_page();
}

/**
 * Process ccavenue failure payment.
 *
 * @since  1.0
 *
 * @access public
 *
 * @param int   $donation_id
 * @param array $response
 */
function give_ccavenue_process_failed_payment( $donation_id, $response ) {
	$donation = new Give_Payment( $donation_id );
	$donation->update_status( 'failed' );
	$donation->add_note( sprintf( __( 'CCAvenue payment failed (Transaction id: %s)', 'give-ccavenue' ), $response['tracking_id'] ) );

	give_set_payment_transaction_id( $donation_id, $response['tracking_id'] );
	update_post_meta( $donation_id, 'ccavenue_donation_response', $response );

	give_record_gateway_error(
		esc_html__( 'CCAvenue Error', 'give-ccavenue' ),
		esc_html__( 'The CCAvenue Gateway returned an error while charging a donation.', 'give-ccavenue' ) . '<br><br>' . sprintf( esc_attr__( 'Details: %s', 'give-ccavenue' ), '<br>' . print_r( $response, true ) ),
		$donation_id
	);

	wp_redirect( give_get_failed_transaction_uri() );
	exit();
}

/**
 * Process ccavenue pending payment.
 *
 * @since  1.0
 *
 * @access public
 *
 * @param int   $donation_id
 * @param array $response
 */
function give_ccavenue_process_pending_payment( $donation_id, $response ) {
	$donation = new Give_Payment( $donation_id );
	$donation->add_note( sprintf( __( 'CCAvenue payment has "%1$s" status. Check <a href="%1$s" target="_blank">CCAvenue merchant dashboard</a> for more information or check the <a href="%1$s" target="_blank">payment gateway error logs</a> for additional details', 'give-ccavenue' ), $response['order_status'], "#{$response['tracking_id']}", admin_url( 'edit.php?post_type=give_forms&page=give-tools&tab=logs&section=gateway_errors' ) ) );

	give_set_payment_transaction_id( $donation_id, $response['tracking_id'] );
	update_post_meta( $donation_id, 'ccavenue_donation_response', $response );

	give_record_gateway_error(
		esc_html__( 'CCAvenue Error', 'give-ccavenue' ),
		esc_html__( 'The CCAvenue Gateway returned an error while charging a donation.', 'give-ccavenue' ) . '<br><br>' . sprintf( esc_attr__( 'Details: %s', 'give-ccavenue' ), '<br>' . print_r( $response, true ) ),
		$donation_id
	);

	give_send_to_success_page();
}

/**
 * This function will fetch phone number field value with backward compatibility support.
 *
 * @param int $donation_id Donation ID.
 *
 * @since 1.0.3
 *
 * @return string
 */
function give_ccavenue_get_phone_number_value( $donation_id ) {

	$phone_number = Give()->payment_meta->get_meta( $donation_id, '_give_ccavenue_phone_number', true );

	// Add backward compatibility support.
	if ( empty( $phone_number ) ) {
		$ccavenue_response = Give()->payment_meta->get_meta( $donation_id, 'ccavenue_donation_response', true );
		$phone_number      = isset( $ccavenue_response['billing_tel'] ) ? $ccavenue_response['billing_tel'] : '';
	}

	return $phone_number;
}
