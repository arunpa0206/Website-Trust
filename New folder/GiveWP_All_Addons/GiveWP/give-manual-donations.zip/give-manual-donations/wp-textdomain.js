const wpTextdomain = require( 'wp-textdomain' );

process.argv.slice(2).forEach( filePath => {
	wpTextdomain( filePath, {
		domain: 'give-manual-donations',
		fix: true,
	} );
})
