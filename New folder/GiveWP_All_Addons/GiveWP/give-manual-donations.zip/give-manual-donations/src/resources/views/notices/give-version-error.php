<?php defined( 'ABSPATH' ) or exit; ?>

<strong>
	<?php _e( 'Activation Error:', 'give-manual-donations' ); ?>
</strong>
<?php _e( 'You must have', 'give-manual-donations' ); ?> <a href="https://givewp.com" target="_blank">Give</a>
<?php _e( 'version', 'give-manual-donations' ); ?> <?php echo GIVE_VERSION; ?>+
<?php printf( esc_html__( 'for the %1$s add-on to activate', 'give-manual-donations' ), GIVE_MD_ADDON_NAME ); ?>.

