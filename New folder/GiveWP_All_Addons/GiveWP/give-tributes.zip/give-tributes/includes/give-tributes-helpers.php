<?php
/**
 * Give Tributes Helper functions.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/includes
 * @author     GiveWP <https://givewp.com>
 */


/**
 * Output HTML of Tribute type.
 *
 * @since 1.0.0
 *
 * @param  int  $form_id  Form ID.
 * @param  bool $is_admin To show in admin or not..
 *
 * @return mixed
 */
function give_tributes_type_output( $form_id, $is_admin = false ) {

	$field_label = apply_filters( 'give_tributes_dedication_type_label_text', __( 'Dedication Type', 'give-tributes' ) );

	// Store HTML.
	$output = '';

	if ( ! $is_admin ) {
		// Get the value of tribute form enable or not.
		$field_label = '<label class="give-tributes-label" for="give-tribute-type-' . $form_id . '" id="give-tribute-type-' . $form_id . '">' . $field_label . '</label>';
	} else {
		ob_start();
		?>
		<tr class="form-field give-tributes-row give-tributes-types">
		<th scope="row" valign="top">
			<label><?php echo $field_label; ?></label>
		</th>
		<td>
		<?php
		$field_label = '';
		$output      .= ob_get_clean();
	}

	// Check if global tribute settings is enabled.
	if ( ! give_tributes_is_per_form_customized( $form_id ) ) {

		// Get Give Tribute option texts.
		$tributes      = json_decode( give_get_option( 'give_tributes_text', array() ) );
		$display_style = give_get_option( 'give_tributes_display_style', 'radios' );

		switch ( $display_style ) {
			case 'buttons':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_buttons give_tributes_type_wrap"> <!-- Give - Tributes type wrap start -->';
				$output .= $field_label;

				$output .= '<ul id="give-tributes-type-button-list-' . $form_id . '" class="give-tributes-type-button-list">';

				foreach ( $tributes as $display_key => $text ) :

					if ( ! empty( $text ) ) :
						$output .= '<li>';
						$output .= '<button type="button" data-tribute-type="' . $text . '" class="give-btn give-tribute-type-button" value="' . $text . '">';
						$output .= $text;
						$output .= '</button>';
						$output .= '</li>';
					endif;

				endforeach;

				$output .= '</ul>';
				$output .= '</div> <!-- Give - Tributes type wrap end -->';

				break;

			case 'radios':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_radios give_tributes_type_wrap"> <!-- Give - Tributes type wrap start -->';
				$output .= $field_label;
				$output .= '<ul id="give-tributes-type-radio-list-' . $form_id . '" class="give-tribute-radio-ul">';

				foreach ( $tributes as $display_key => $text ) :

					// Set first value as a default tribute type and checked as a radio button.
					$give_tribute_type_checked = '';
					if ( 0 === $display_key ) {
						$give_tribute_type_checked = 'checked="checked"';
					}

					if ( ! empty( $text ) ) :

						$per_form_text_lower = strtolower( str_replace( ' ', '-', $text ) );
						$output              .= '<li>';
						$output              .= '<input type="radio" id="give-tributes-type-radio-' . $per_form_text_lower . '-' . $form_id . '" name="give_tributes_radio_type" data-tribute-type="' . $text . '" class="give-tribute-type-radio" value="' . $text . '"  ' . $give_tribute_type_checked . '>';
						$output              .= '<label for="give-tributes-type-radio-' . $per_form_text_lower . '-' . $form_id . '" class="give-tributes-type-radio">' . $text . '</label>';
						$output              .= '</li>';
					endif;

				endforeach;

				$output .= '</ul>';
				$output .= '</div> <!-- Give - Tributes type wrap end -->';

				break;

			case 'dropdown':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_dropdown give_tributes_type_wrap form-row"> <!-- Give - Tributes type wrap start -->';
				$output .= $field_label;

				$output .= '<select id="give-tributes-type-select-' . $form_id . '" class="give-select give-tributes-type-select" name="give-tributes-type">';

				foreach ( $tributes as $display_key => $text ) :

					if ( ! empty( $text ) ) :
						$output .= '<option value="' . $text . '">';
						$output .= '' . $text . '';
						$output .= '</option>';
					endif;

				endforeach;

				$output .= '</select>';
				$output .= '</div> <!-- Give - Tributes type wrap end -->';

				break;
		}// End switch().

	} else {

		// Get Give Tribute option texts.
		$per_form_repeater = give_get_meta( $form_id, '_give_tributes_per_form__repeater', true );
		$tributes          = maybe_unserialize( $per_form_repeater );
		$tributes          = isset( $tributes ) ? $tributes : array();
		$tributes_size     = count( $tributes );

		// Set default "In Honor Of" tribute text if empty.
		if ( 1 === $tributes_size && empty( $tributes[0]['_give_tributes_per_form_give_tributes_text'] ) ) {
			$tributes = array(
				0 => array(
					'_give_tributes_per_form_give_tributes_text' => 'In Honor of',
				),
			);
		}

		$display_style = give_get_meta( $form_id, '_give_tributes_per_form_display_style', true );
		$display_style = isset( $display_style ) ? $display_style : 'radios';

		switch ( $display_style ) {
			case 'buttons':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_buttons give_tributes_type_wrap"><!-- Give - Tributes type wrap start -->';
				$output .= $field_label;

				$output .= '<ul id="give-tributes-type-button-list-' . $form_id . '" class="give-tributes-type-button-list">';

				foreach ( $tributes as $display_key => $text ) :

					$per_form_text_option = ! empty( $text['_give_tributes_per_form_give_tributes_text'] ) ? $text['_give_tributes_per_form_give_tributes_text'] : '';

					if ( ! empty( $per_form_text_option ) ) :
						$output .= '<li>';
						$output .= '<button type="button" data-tribute-type="' . $per_form_text_option . '" class="give-btn give-tribute-type-button" value="' . $per_form_text_option . '">';
						$output .= $per_form_text_option;
						$output .= '</button>';
						$output .= '</li>';
					endif;

				endforeach;

				$output .= '</ul>';
				$output .= '</div><!-- Give - Tributes type wrap end -->';

				break;

			case 'radios':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_radios give_tributes_type_wrap"><!-- Give - Tributes type wrap start -->';
				$output .= $field_label;
				$output .= '<ul id="give-tributes-type-radio-list-' . $form_id . '">';

				foreach ( $tributes as $display_key => $text ) :

					// Set first value as a default tribute type and checked as a radio button.
					$give_tribute_type_checked = '';
					if ( 0 === $display_key ) {
						$give_tribute_type_checked = 'checked="checked"';
					}

					$per_form_text_option = ! empty( $text['_give_tributes_per_form_give_tributes_text'] ) ? $text['_give_tributes_per_form_give_tributes_text'] : '';

					if ( ! empty( $per_form_text_option ) ) :
						$per_form_text_lower = strtolower( str_replace( ' ', '-', $per_form_text_option ) );

						$output .= '<li>';
						$output .= '<input type="radio" id="give-tributes-type-radio-' . $per_form_text_lower . '-' . $form_id . '" name="give_tributes_radio_type" data-tribute-type="' . $per_form_text_option . '" class="give-tribute-type-radio" value="' . $per_form_text_option . '"  ' . $give_tribute_type_checked . '>';
						$output .= '<label for="give-tributes-type-radio-' . $per_form_text_lower . '-' . $form_id . '">' . $per_form_text_option . '</label>';
						$output .= '</li>';
					endif;

				endforeach;

				$output .= '</ul>';
				$output .= '</div><!-- Give - Tributes type wrap end -->';

				break;

			case 'dropdown':

				$output .= '<div id="give-tributes-type-wrap-' . $form_id . '" class="has_dropdown give_tributes_type_wrap form-row"><!-- Give - Tributes type wrap start -->';
				$output .= $field_label;
				$output .= '<select id="give-tributes-type-select-' . $form_id . '" class="give-select give-tributes-type-select" name="give-tributes-type">';

				foreach ( $tributes as $display_key => $text ) :

					$per_form_text_option = ! empty( $text['_give_tributes_per_form_give_tributes_text'] ) ? $text['_give_tributes_per_form_give_tributes_text'] : '';

					if ( ! empty( $per_form_text_option ) ) :
						$output .= '<option value="' . $per_form_text_option . '">';
						$output .= '' . $per_form_text_option . '';
						$output .= '</option>';
					endif;

				endforeach;

				$output .= '</select>';
				$output .= '</div><!-- Give - Tributes type wrap end -->';

				break;
		}// End switch().
	}// End if().

	if ( $is_admin ) {
		?>
		</td></tr>
		<?php
	}

	return $output;
}

/**
 * Output Tribute Options fields.
 *
 * @since 1.4.0
 *
 * @param int $form_id $tribute_field_vars Useful Field vars.
 *
 * @return string
 */
function give_tribute_options_fields( $form_id ) {
	ob_start();
	?>
	<div id="give-tributes-options-<?php echo $form_id; ?>">
		<ul id="give-tributes-show-wrap-<?php echo $form_id; ?>" class="give-tributes-show-wrap">
			<li class="give-tributes-show-wrap-li">
				<input
						class="give-input"
						type="radio"
						id="give-tributes-yes-<?php echo $form_id; ?>"
						name="give_tributes_show_dedication"
						value="yes"
				/>
				<label for="give-tributes-yes-<?php echo $form_id; ?>" class="give-tributes-yes"> <?php _e( 'Yes, please', 'give-tributes' ); ?></label>
			</li>
			<li class="give-tributes-show-wrap-li">
				<input
						class="give-input"
						type="radio"
						id="give-tributes-no-<?php echo $form_id; ?>"
						name="give_tributes_show_dedication"
						checked="checked"
						value="no"
				/>
				<label for="give-tributes-no-<?php echo $form_id; ?>" class="give-tributes-no"> <?php _e( 'No, thank you', 'give-tributes' ); ?></label>
			</li>
		</ul>
	</div>
	<?php
	$tribute_options_fields = ob_get_clean();

	return $tribute_options_fields;
}

/**
 * Output Tribute Honoree detail fields.
 *
 * @since 1.4.0
 *
 * @param array $tribute_field_vars Useful Field vars.
 * @param bool  $is_admin           Where to display.
 *
 * @return string
 */
function give_tribute_honoree_detail_fields( $tribute_field_vars, $is_admin = false ) {

	$form_id         = $tribute_field_vars['form_id'];
	$prepended_label = $tribute_field_vars['prepended_label'];

	ob_start();

	if ( $is_admin ) {
		?>
		<tr class="form-field give-tributes-row give-tributes-honoree-details">
		<th scope="row" valign="top">
			<label><?php printf( __( '%s Details', 'give-tributes' ), $prepended_label ); ?></label>
		</th>
		<td id="give-tributes-info-wrap-<?php echo $form_id; ?>">
		<?php
	} else {
		?>
		<div id="give-tributes-info-wrap-<?php echo $form_id; ?>" class="give_tributes_info_wrap"><!-- Give - Tributes Info Wrap Start -->
		<h3 class="give-section-break give-tributes-legend"><?php printf( __( '%s Details', 'give-tributes' ), $prepended_label ); ?></h3>
		<?php
	}
	?>

	<p id="give-tributes-first-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-first form-row-responsive">
		<label class="give-label" for="give-tributes-first-name-<?php echo $form_id; ?>">
			<?php _e( 'First Name', 'give-tributes' ); ?>

			<?php
			$honoree_first_name_required = give_field_is_required( 'give_tributes_first_name', $form_id );
			if ( $honoree_first_name_required ): ?>
				<span class="give-required-indicator">*</span>
			<?php endif; ?>

			<span class="give-tooltip give-icon give-icon-question"
			      data-tooltip="<?php echo sprintf( __( 'The first name of the %s.', 'give-tributes' ), strtolower( $prepended_label ) ); ?>"></span>
		</label>
		<input
				class="give-input <?php echo ( $honoree_first_name_required ) ? 'required' : ''; ?>"
				type="text"
				name="give_tributes_first_name"
				placeholder="<?php echo sprintf( __( '%s First Name', 'give-tributes' ), $prepended_label ); ?>"
				id="give-tributes-first-name-<?php echo $form_id; ?>"
				value=""
		/>
	</p>

<p id="give-tributes-last-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-last form-row-responsive">
	<label class="give-label" for="give-tributes-last-name-<?php echo $form_id; ?>">
		<?php _e( 'Last Name', 'give-tributes' ); ?>
		<?php
		$honoree_last_required = give_field_is_required( 'give_tributes_last_name', $form_id );
		if ( $honoree_last_required ) : ?>
			<span class="give-required-indicator">*</span>
		<?php endif; ?>
		<span class="give-tooltip give-icon give-icon-question"
		      data-tooltip="<?php echo sprintf( __( 'The last name of the %s.', 'give-tributes' ), strtolower( $prepended_label ) ); ?>"></span>
	</label>
	<input
			class="give-input <?php echo ( $honoree_last_required ) ? 'required' : ''; ?>"
			type="text"
			name="give_tributes_last_name"
			placeholder="<?php echo sprintf( __( '%s Last Name', 'give-tributes' ), $prepended_label ); ?>"
			id="give-tributes-last-name-<?php echo $form_id; ?>"
			value=""
	/>
	<?php

	if ( $is_admin ) {
		?>
		</td></tr>
		<?php
	} else {
		?>
		</p>
		</div><!-- Give - Tributes Info Wrap End -->
		<?php
	}
	?>
	<?php
	$honoree_detail_fields = ob_get_clean();

	return $honoree_detail_fields;
}

/**
 * Output Tribute grab field wrap.
 *
 * @since 1.4.0
 *
 * @param array $tribute_field_vars Useful Field vars.
 * @param bool  $is_admin           Display.
 *
 * @return string
 */
function give_tribute_grab_info_wrap_fields( $tribute_field_vars, $is_admin = false ) {
	$form_id                    = $tribute_field_vars['form_id'];
	$mail_a_card_enable_disable = $tribute_field_vars['mail_a_card_enable_disable'];
	$ecards_enable_disable      = $tribute_field_vars['ecards_enable_disable'];
	ob_start();

	if ( $is_admin ) {
		?>
		<tr class="form-field give-tributes-row give-tribute-notifications" id="give-tributes-grab-info-wrap-<?php echo $form_id; ?>" >
		<th scope="row" valign="top">
			<label><?php echo __( 'Notification', 'give-tributes' ); ?></label>
		</th>
		<td>
		<?php
	} else {
		?>
		<div id="give-tributes-grab-info-wrap-<?php echo $form_id; ?>" class="give_tributes_grab_info_wrap"><!-- Give - Tributes Grab Info Start -->
		<label for="i-would-like-to"
		       class="give-tribute-type give-tributes-label"><?php _e( 'Would you like us to notify anyone of your donation?', 'give-tributes' ); ?></label>
		<?php
	}
	?>
	<ul id="give-tributes-grab-info-<?php echo $form_id; ?>" class="give-tributes-grab-info">
		<?php if ( 'disabled' !== $mail_a_card_enable_disable ) : ?>
			<li>
				<input
						class="give-input"
						id="give-tributes-mail-a-card-<?php echo $form_id; ?>"
						type="radio" name="give_tributes_would_to"
						value="send_mail_card"
				/>
				<label for="give-tributes-mail-a-card-<?php echo $form_id; ?>"
				       class="give-tributes-would-to"> <?php _e( 'Yes, mail a card', 'give-tributes' ); ?></label>
			</li>
		<?php endif; ?>

		<?php if ( 'disabled' !== $ecards_enable_disable ) : ?>
			<li>
				<input
						class="give-input"
						id="give-tributes-send-an-ecard-<?php echo $form_id; ?>"
						type="radio"
						name="give_tributes_would_to"
						value="send_eCard"
				/>
				<label for="give-tributes-send-an-ecard-<?php echo $form_id; ?>"
				       class="give-tributes-would-to"> <?php _e( 'Yes, send an eCard', 'give-tributes' ); ?></label>
			</li>
		<?php endif; ?>

		<li>
			<input
					class="give-input"
					id="give-tributes-none-<?php echo $form_id; ?>"
					type="radio"
					name="give_tributes_would_to"
					checked="checked"
					value="none"
			/>
			<label for="give-tributes-none-<?php echo $form_id; ?>"
			       class="give-tributes-would-to"> <?php _e( 'No thanks', 'give-tributes' ); ?></label>
		</li>

	</ul>

	<?php
	if ( $is_admin ) {
		?>
		</td></tr>
		<?php
	} else {
		?>
		</div><!-- Give - Tributes Info Wrap End -->
		<?php
	}

	$grab_info_wrap_fields = ob_get_clean();

	return $grab_info_wrap_fields;
}

/**
 * Output eCard Notification fields.
 *
 * @since 1.4.0
 *
 * @param array $tribute_field_vars Useful Field vars.
 *
 * @return string
 */
function give_tribute_ecard_notification_fields( $tribute_field_vars ) {
	$form_id                              = $tribute_field_vars['form_id'];
	$ecards_custom_message_enable_disable = $tribute_field_vars['ecards_custom_message_enable_disable'];
	$ecards_message_length                = $tribute_field_vars['ecards_message_length'];
	ob_start(); ?>

	<div class="give-tributes-notification-lists" id="give-tributes-notification-list-<?php echo $form_id; ?>"><!-- Give - Tributes eCard Notification list Start -->
		<div id="give-tributes-send-ecard-fields-<?php echo $form_id; ?>" class="give_tributes_send_ecard_fields"><!-- Give - Tributes eCard Fields Start -->
			<h3 class="give-section-break give-tributes-legend"><?php _e( 'Notification Details', 'give-tributes' ); ?>
				<?php
				// Check if option is enabled or not.
				if ( give_tributes_is_allow_multiple_receipts( $form_id ) ) {
					?>
					<div class="give-tributes-add-recipient">
									<span data-tooltip="Add Notification" class="give-tributes-clone-field give-tooltip" data-action="add"><span
												class="give-icon give-icon-plus"></span></span>
						<span href="javascript:void(0);" data-tooltip="Remove this notification" class="give-tributes-clone-field give-tooltip"
						      data-action="remove"><span class="give-icon give-icon-minus"></span></span>
					</div>
					<?php
				}
				?>
			</h3>

			<?php if ( 'disabled' !== $ecards_custom_message_enable_disable ) : ?>
				<div id="give-tributes-ecard-personalized-message-<?php echo $form_id; ?>"
				     class="form-row form-row-responsive give_tributes_ecard_personalized_message">
					<label class="give-label" for="give-tributes-ecard-personalized-message-area-<?php echo $form_id; ?>">
						<?php _e( 'Personalized Message', 'give-tributes' ); ?>

						<?php
						$ecard_notify_message_required = give_field_is_required( 'give_tributes_ecard_notify_personalized_message', $form_id );
						if ( $ecard_notify_message_required ): ?>
							<span class="give-required-indicator">*</span>
						<?php endif; ?>

						<span class="give-tooltip give-icon give-icon-question"
						      data-tooltip="<?php esc_attr_e( 'This is the personalized notification message that is sent to the recipient.', 'give-tributes' ); ?>"></span>
					</label>
					<textarea
							maxlength="<?php echo $ecards_message_length; ?>"
							name="give_tributes_ecard_notify[recipient][personalized][]"
							id="give-tributes-ecard-personalized-message-area-<?php echo $form_id; ?>"
							class="give-tributes-personalized-message large-text"></textarea>
					<span id="give-tributes-ecard-personalized-message-left-<?php echo $form_id; ?>"
					      class="give-tributes-ecard-personalized-message-left"><?php echo sprintf( __( '%s Characters left', 'give-tributes' ), $ecards_message_length ); ?></span>
				</div>
			<?php else: ?>
				<input type="hidden" name="give_tributes_ecard_notify[recipient][personalized][]" value="" />
			<?php endif; ?>

			<div id="give-tributes-ecard-notify-first-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-first form-row-responsive">
				<label class="give-label" for="give-tributes-ecard-notify-first-name-<?php echo $form_id; ?>">
					<?php _e( 'First Name', 'give-tributes' ); ?>

					<?php
					$ecard_notify_first_name_required = give_field_is_required( 'give_tributes_ecard_notify_first_name', $form_id );
					if ( $ecard_notify_first_name_required ): ?>
						<span class="give-required-indicator">*</span>
					<?php endif; ?>

					<span class="give-tooltip give-icon give-icon-question"
					      data-tooltip="<?php esc_attr_e( 'The first name of the recipient.', 'give-tributes' ); ?>"></span>
				</label>
				<input
						class="give-input <?php echo ( $ecard_notify_first_name_required ) ? 'required' : ''; ?>"
						type="text"
						name="give_tributes_ecard_notify[recipient][first_name][]"
						placeholder="<?php esc_attr_e( 'Recipient First Name', 'give-tributes' ); ?>"
						id="give-tributes-ecard-notify-first-name-<?php echo $form_id; ?>"
						value=""
				/>
			</div>

			<div id="give-tributes-ecard-notify-last-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-last form-row-responsive">
				<label class="give-label" for="give-tributes-ecard-notify-last-name-<?php echo $form_id; ?>">
					<?php _e( 'Last Name', 'give-tributes' ); ?>
					<?php
					$ecard_last_required = give_field_is_required( 'give_tributes_ecard_last_name', $form_id );
					if ( $ecard_last_required ): ?>
						<span class="give-required-indicator">*</span>
					<?php endif; ?>
					<span class="give-tooltip give-icon give-icon-question"
					      data-tooltip="<?php esc_attr_e( 'The last name of the recipient.', 'give-tributes' ); ?>"></span>
				</label>
				<input
						class="give-input <?php echo( $ecard_last_required ? 'required' : '' ); ?>"
						type="text"
						name="give_tributes_ecard_notify[recipient][last_name][]"
						placeholder="<?php esc_attr_e( 'Recipient Last Name', 'give-tributes' ); ?>"
						id="give-tributes-ecard-notify-last-name-<?php echo $form_id; ?>"
						value=""
				/>
			</div>

			<div id="give-tributes-ecard-email-<?php echo $form_id; ?>" class="form-row form-row-wide form-row-responsive give_tributes_ecard_email">
				<label class="give-label" for="give-tributes-send-ecard-email-<?php echo $form_id; ?>">
					<?php _e( 'Email Address', 'give-tributes' ); ?>
					<?php
					$ecard_notify_email_required = give_field_is_required( 'give_tributes_ecard_email', $form_id );
					if ( $ecard_notify_email_required ): ?>
						<span class="give-required-indicator">*</span>
					<?php endif; ?>
					<span class="give-tooltip give-icon give-icon-question" data-tooltip="<?php esc_attr_e( 'This is the email address of the notification recipient.', 'give-tributes' ); ?>"></span>
				</label>
				<input
						class="give-input <?php echo( $ecard_notify_email_required ? ' required' : '' ); ?>"
						type="email"
						name="give_tributes_ecard_notify[recipient][email][]"
						placeholder="<?php esc_attr_e( 'Recipient Email Address', 'give-tributes' ); ?>"
						id="give-tributes-send-ecard-email-<?php echo $form_id; ?>"
						value=""
				/>
			</div>

		</div><!-- Give - Tributes eCard Fields End -->
	</div><!-- Give - Tributes eCard Notification list End -->
	<?php
	$ecard_notification_fields = ob_get_clean();

	return $ecard_notification_fields;
}

/**
 * Get Default Tribute Type.
 *
 * @since 1.4.0
 *
 * @param int $form_id
 *
 * @return string Default Tribute type.
 */
function get_default_tribute_type( $form_id ) {

	// Get Give Tribute option texts.
	$tributes     = json_decode( give_get_option( 'give_tributes_text' ) );
	$default_type = ! empty( $tributes[0] ) ? $tributes[0] : __( 'In Honor Of', 'give-tributes' );

	// Check if global tribute settings is enabled.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {
		$per_form_repeater = give_get_meta( $form_id, '_give_tributes_per_form__repeater', true );
		$tributes          = maybe_unserialize( $per_form_repeater );
		$default_type      = ! empty( $tributes[0]['_give_tributes_per_form_give_tributes_text'] ) ? $tributes[0]['_give_tributes_per_form_give_tributes_text'] : __( 'In Honor Of', 'give-tributes' );

	}

	return apply_filters( 'give_tribute_default_type', $default_type );
}

/**
 * Get Give Tributes Section Location hook.
 *
 * @since  1.0.0
 *
 * @param int $form_id Form ID.
 *
 * @return string $location_hook
 */
function give_tributes_get_section_location_hook( $form_id ) {

	if ( ! empty( $form_id ) ) {

		// Check if global tribute settings is enabled.
		if ( ! give_tributes_is_per_form_customized( $form_id ) ) {

			// Get Tribute Section Location hook.
			$location_hook = give_get_option( 'give_tributes_section_location', 'give_after_donation_levels' );

		} elseif ( give_tributes_is_per_form_customized( $form_id ) ) {
			// Per form customized.

			$location_hook = give_get_meta( $form_id, '_give_tributes_per_form_section_location', true );

			// Get Tribute Section Location hook.
			$location_hook = ! empty( $location_hook ) ? $location_hook : 'give_after_donation_levels';

		} else {

			// Get Tribute Section Location hook.
			$location_hook = 'give_after_donation_levels';
		}
	}// End if().

	$hook = ! empty( $location_hook ) ? $location_hook : 'give_after_donation_levels';

	return apply_filters( 'give_tributes_get_section_location_hook', $hook );
}

/**
 *  Notification Full address.
 *
 * @param int  $payment_id Donation ID.
 * @param bool $fullname   Whether or not to output the notification full name within the address.
 *
 * @return string $notification_full_address
 */
function give_tributes_notification_address( $payment_id, $fullname = true ) {

	$mail_card_address_1 = give_get_meta( $payment_id, '_give_tributes_mail_card_address_1', true );
	$mail_card_address_1 = ! empty( $mail_card_address_1 ) ? $mail_card_address_1 : '';
	$mail_card_address_2 = give_get_meta( $payment_id, '_give_tributes_mail_card_address_2', true );
	$mail_card_address_2 = ! empty( $mail_card_address_2 ) ? $mail_card_address_2 : '';
	$mail_card_city      = give_get_meta( $payment_id, '_give_tributes_mail_card_city', true );
	$mail_card_city      = ! empty( $mail_card_city ) ? $mail_card_city : '';
	$address_state       = give_get_meta( $payment_id, '_give_tributes_address_state', true );
	$address_state       = ! empty( $address_state ) ? $address_state : '';
	$mail_card_zipcode   = give_get_meta( $payment_id, '_give_tributes_mail_card_zipcode', true );
	$mail_card_zipcode   = ! empty( $mail_card_zipcode ) ? $mail_card_zipcode : '';
	$address_country     = give_get_meta( $payment_id, '_give_tributes_address_country', true );
	$address_country     = ! empty( $address_country ) ? $address_country : '';

	// Prepare Notification Full address.
	$notification_full_address = '';

	// Include fullname?
	if ( $fullname ) {
		$notification_full_address .= give_tribute_tag_notify_fullname( $payment_id ) . '<br>';
	}

	// Build address.
	if ( ! empty( $mail_card_address_1 ) ) {
		$notification_full_address .= $mail_card_address_1 . ', ';

		if ( ! empty( $mail_card_address_2 ) ) {
			$notification_full_address .= $mail_card_address_2;
		}
	}

	if ( ! empty( $mail_card_city ) ) {
		$notification_full_address .= '<br> ' . $mail_card_city . ', ';
	}

	if ( ! empty( $address_state ) ) {
		$notification_full_address .= $address_state . ' ';
	}

	if ( ! empty( $mail_card_zipcode ) ) {
		$notification_full_address .= $mail_card_zipcode . '<br> ';
	}

	if ( ! empty( $address_country ) ) {
		$notification_full_address .= give_get_country_name_by_key( $address_country );
	}

	return apply_filters( 'give_tributes_notification_address', $notification_full_address );
}

/**
 * Is per form enabled
 *
 * Returns true if Tributes is customized on the form.
 * Useful for checking if a form has tributes customized.
 *
 * @since 1.1.0
 *
 * @param int $form_id Form ID.
 *
 * @return bool
 */
function give_tributes_is_per_form_customized( $form_id ) {

	$per_form_customized = give_get_meta( $form_id, '_give_tributes_per_form_enable_disable', true );
	$per_form_customized = ! empty( $per_form_customized ) ? $per_form_customized : 'global';

	return apply_filters( 'give_tributes_is_per_form_customized', give_is_setting_enabled( $per_form_customized ) );
}

/**
 * Is Global enabled
 *
 * Returns true if Tributes is enable for Global.
 *
 * @since 1.3.4
 *
 * @param int $form_id Form ID.
 *
 * @return bool
 */
function give_tributes_is_per_form_global( $form_id ) {

	$per_form_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_enable_disable', true );
	$per_form_enable_disable = ! empty( $per_form_enable_disable ) ? $per_form_enable_disable : 'global';

	return apply_filters( 'give_tributes_is_per_form_customized', give_is_setting_enabled( $per_form_enable_disable, 'global' ) && give_is_setting_enabled( give_get_option( 'give_tributes_enable_disable' ) ) );
}

/**
 * Adds backwards compatibility with pre-version 1.1 users and the new {donor_message} tag.
 *
 * Will output the donor's message if it's present in payment meta but no tag is present within the template content.
 *
 * @since 1.1
 *
 * @param int $payment_id Payment ID.
 *
 * @return string|bool
 */
function give_tributes_v11_mail_card_donor_message_compat( $payment_id ) {

	$form_id         = give_get_payment_form_id( $payment_id );
	$default_content = give_tributes_mail_card_get_body_content( $form_id );

	$mail_card_personalized_message = give_get_meta( $payment_id, '_give_tributes_mail_card_personalized_message', true );
	$mail_card_personalized_message = ! empty( $mail_card_personalized_message ) ? $mail_card_personalized_message : '';


	if ( 0 === $payment_id ) {
		$mail_card_personalized_message = __( 'This is an example donor provided message.', 'give-tributes' );
	}

	// If missing the {donor_message}.
	if ( strpos( $default_content, '{donor_message}' ) !== false && ! empty( $mail_card_personalized_message ) ) {
		return false;
	}

	$personalized_message_container = "
		box-shadow: 0 0 0 1px #f3f3f3 !important;
	    border-radius: 3px !important;
	    background-color: rgb(246, 246, 246);
	    border: 1px solid #f6f6f6;
	    box-sizing: border-box;
	    margin-right:50px;
	";

	if ( ! empty( $mail_card_personalized_message ) ) : ?>
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td>
				</td>
			</tr>
			<tr style="<?php echo $personalized_message_container; ?>">
				<td align="left">
					<!-- Personalized message -->
					<table border="0" cellpadding="20" id="template_personalized_message">

						<tr>
							<td>
								<?php echo wpautop( $mail_card_personalized_message ); ?>
							</td>
						</tr>
					</table>
					<!-- End Personalized message -->
				</td>
			</tr>
		</table>

	<?php endif;
}

/**
 * Adds backwards compatibility with pre-version 1.1 users and the new {donor_message} tag.
 *
 * Will output the donor's message if it's present in payment meta but no tag is present within the template content.
 *
 * @since 1.1
 *
 * @param int $payment_id Payment ID.
 *
 * @return string|bool
 */
function give_tributes_v11_donor_message_compat( $payment_id ) {

	$form_id         = give_get_payment_form_id( $payment_id );
	$default_content = give_tributes_get_ecard_content( $form_id );

	$ecard_personalized_message = give_get_meta( $payment_id, '_give_tributes_ecard_personalized_message', true );
	$ecard_personalized_message = ! empty( $ecard_personalized_message ) ? $ecard_personalized_message : '';


	if ( 0 === $payment_id ) {
		$ecard_personalized_message = __( 'This is an example donor provided message.', 'give-tributes' );
	}

	// If missing the {donor_message}.
	if ( strpos( $default_content, '{donor_message}' ) !== false && ! empty( $ecard_personalized_message ) ) {
		return false;
	}

	$personalized_message_container = "
		box-shadow: 0 0 0 1px #f3f3f3 !important;
	    border-radius: 3px !important;
	    background-color: rgb(246, 246, 246);
	    border: 1px solid #f6f6f6;
	    padding: 20px;
	";

	$personalized_message_font = "
		color: #000000;
		font-size: 14px;
		font-family: 'Helvetica Neue',Helvetica,Arial,'Lucida Grande',sans-serif;
		line-height: 150%;
		text-align: left;
	";

	if ( ! empty( $ecard_personalized_message ) ) : ?>
		<tr>
			<td align="center" valign="top">
				<!-- Personalized message -->
				<table border="0" cellpadding="0" cellspacing="0" id="template_header" style="<?php echo $personalized_message_container; ?>">
					<tr>
						<td>
							<div id="give_tributes_ecard_personalized_message">
								<?php echo '<p style="' . $personalized_message_font . '">' . wpautop( $ecard_personalized_message ) . '</p>'; ?>
							</div>
						</td>
					</tr>
				</table>
				<!-- End Personalized message -->
			</td>
		</tr>
	<?php endif;
}

/**
 * Get the honoree notification method.
 *
 * @since 1.1.1
 *
 * @param integer     $form_id          Donation form ID.
 * @param string|null $selected_method  When the honoree notify method is set to donor choice,
 *                                      in that case, we may need to pass the method selected
 *                                      by the donor.
 *
 * @return string
 */
function give_tributes_get_notify_display_option( $form_id, $selected_method = null ) {

	// Return false, if donation form is id missing.
	if ( empty( $form_id ) ) {
		return false;
	}

	// Check if the tribute option type is global or not.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {

		$per_form_method = give_get_meta( $form_id, '_give_tributes_per_form_notify_display_option', true );

		// Get the notify method from the specific form setting.
		$notify_method = 'admin_choice' === $per_form_method ? give_get_meta( $form_id, '_give_tributes_per_form_notify_method', true ) : $per_form_method;

	} else {

		// Get the global setting for the notify honoree.
		$global_method = give_get_option( 'give_tributes_notify_display_option', 'donor_choice' );

		// Get the notify method from global setting.
		$notify_method = 'admin_choice' === $global_method ? give_get_option( 'give_tributes_notify_method' ) : $global_method;

	}

	// Get the honoree method selected by donor.
	if (
		'donor_choice' === $notify_method
		&& ! empty( $selected_method )
	) {

		// Return the donor choice.
		$notify_method = $selected_method;

	} elseif (
		! empty( $selected_method )
		&& in_array( $notify_method, array( 'send_mail_card', 'send_eCard' ), true )
	) {

		if ( false === give_tributes_is_method_enabled( $form_id, $notify_method ) ) {
			$notify_method = $selected_method;
		}
	}

	// Return honoree notification method.
	return give_clean( $notify_method );
}

/**
 * Check if the specific Notify method is enable or not.
 *
 * @since 1.1.1
 *
 * @param integer $form_id Donation form id.
 * @param string  $method  Notify method.
 *
 * @return bool
 */
function give_tributes_is_method_enabled( $form_id, $method ) {

	// If notification method is empty, return false.
	if ( empty( $method ) || empty( $form_id ) ) {
		return false;
	}

	// Is global options?
	$is_global = give_tributes_is_per_form_customized( $form_id );

	// If method is 'Mail a Card'.
	if ( 'send_mail_card' === $method ) {
		if ( $is_global ) {
			return give_is_setting_enabled( give_get_meta( $form_id, '_give_tributes_per_form_mail_a_card_enable_disable', true ) );
		} else {
			return give_is_setting_enabled( give_get_option( 'give_tributes_mail_a_card_enable_disable' ) );
		}
	} elseif ( 'send_eCard' === $method ) {

		// If method is 'eCards'.
		if ( $is_global ) {
			return give_is_setting_enabled( give_get_meta( $form_id, '_give_tributes_per_form_ecards_enable_disable', true ) );
		} else {
			return give_is_setting_enabled( give_get_option( 'give_tributes_ecards_enable_disable' ) );
		}
	}

	return false;
}

/**
 * Get to know if multiple receipts allowed for eCards or not?
 *
 * @since 1.2
 *
 * @param integer $form_id Donation id.
 *
 * @return bool
 */
function give_tributes_is_allow_multiple_receipts( $form_id ) {

	// Return false, if form id is empty.
	if ( empty( $form_id ) ) {
		return false;
	}

	// Get global multiple recipient option.
	$multiple_recipient = give_get_option( 'give_ecards_multiple_recipients', 'disabled' );

	// Check if global tribute settings is enabled.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {

		// Get the value from the per form donation setting.
		$multiple_recipient = give_get_meta( $form_id, '_give_tributes_per_form_ecards_multiple_recipients', true );
	}

	// Check if option is enabled or not.
	return apply_filters( 'give_tributes_allow_ecards_multiple_receipts', give_is_setting_enabled( $multiple_recipient ), $form_id );
}

/**
 * Get the all the notification receipt information from payment.
 *
 * This Function can be use where you want to get the eCards
 * notifications fields [first_name, last_name, full_name, email, messages] values.
 *
 * @since 1.2
 *
 * @param integer        $payment_id       Payment ID.
 * @param string         $field_name       Pass the field which you want to get
 *                                         like full_name, emails, personalized_message.
 * @param string         $separator        Separator between the values.
 * @param string | array $return_type      Pass the return type.
 *
 * @return string | array
 */
function give_tributes_ecards_notify_fields( $payment_id, $field_name, $separator = ', ', $return_type = '' ) {

	// Return false, if field name or payment id is missing.
	if ( empty( $payment_id ) || empty( $field_name ) ) {
		return false;
	}

	// If this payments has multiple receipts/notify user.
	$is_multiple_receipts = give_tributes_is_multiple_receipts_enabled( $payment_id );

	// Placeholder for the output string.
	$output_string = '';

	// Check field type.
	switch ( $field_name ) {
		case 'full_name':

			// Get the first name and last name.
			$first_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_first_name', true );
			$last_name  = give_get_meta( $payment_id, '_give_tributes_ecard_notify_last_name', true );

			// If it's multiple values.
			if ( $is_multiple_receipts ) {

				// Printing the name list.
				foreach ( $first_name as $key => $f_name ) {
					// Create the list.
					$output_string .= ucfirst( $f_name ) . ' ' . ucfirst( $last_name[ $key ] ) . $separator;
				}

			} else {

				// eCard notify Full name.
				if ( ! empty( $first_name ) ) {

					// Store first name.
					$output_string = ! empty( $first_name ) ? ucfirst( $first_name ) : '';

					// Do we have a last name? If so append it.
					if ( ! empty( $last_name ) ) {

						// Concatenate last name.
						$output_string .= ' ' . ucfirst( $last_name );
					}
				} else {

					// Fallback to honoree name if notify name is empty.
					$first_name    = give_get_meta( $payment_id, '_give_tributes_first_name', true );
					$last_name     = give_get_meta( $payment_id, '_give_tributes_last_name', true );
					$output_string = ucfirst( $first_name ) . ' ' . ucfirst( $last_name );
				}
			}
			break;
		case 'emails':

			// Get the list of emails for the specific payment id.
			$notify_email = give_get_meta( $payment_id, '_give_tributes_honoree_ecard_email', true );

			// If multiple notifications.
			if ( $is_multiple_receipts ) {

				// Loop all of the emails.
				foreach ( $notify_email as $email ) {
					// Create email lists.
					$output_string .= $email . $separator;
				}
			} else {
				// For single email.
				$output_string = ! empty( $notify_email ) ? $notify_email : 'n/a';
			}
			break;
		case 'personalized_message':

			// Mail a Card Notification message.
			$notify_message = give_get_meta( $payment_id, '_give_tributes_ecard_personalized_message', true );

			if ( $is_multiple_receipts ) {

				// Get all of the custom message.
				foreach ( $notify_message as $message ) {

					if ( empty( $message ) ) {
						$message = 'n/a';
					}
					// Concatenate messages.
					$output_string .= $message . $separator;
				}
			} else {
				// For single custom message.
				$output_string = ! empty( $notify_message ) ? $notify_message : 'n/a';
			}
			break;
	}

	// Check if separator is comma and it's array.
	if ( ', ' === $separator && true === $is_multiple_receipts ) {
		// Remove unnecessary comma from end of the string.
		$output_string = substr( $output_string, 0, - 2 );
	}

	// If the ARRAY values was requested.
	if ( ARRAY_A === $return_type && ! empty( $separator ) ) {

		// Explode values into array.
		return explode( $separator, $output_string );

	} elseif ( 'list' === $return_type && $is_multiple_receipts ) {

		// Remove blank values.
		$elements = array_filter( explode( $separator, $output_string ) );

		ob_start();
		?>
		<ol>
			<?php
			foreach ( $elements as $element ) {
				echo '<li>' . $element . '</li>';
			}
			?>
		</ol>
		<?php

		return ob_get_clean();
	}

	// Get the final value.
	return ! empty( $output_string ) ? give_clean( $output_string ) : $output_string;
}

/**
 * Get notification data by specific email.
 *
 * @since 1.2
 *
 * @param integer $payment_id Donation payment id.
 * @param string  $email      Pass the user email whom data you want.
 *
 * @return mixed
 */
function give_tributes_get_notify_data_by_email( $payment_id, $email = '' ) {

	// Get meta data from the payment.
	$notify_first_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_first_name', true );
	$notify_last_name  = give_get_meta( $payment_id, '_give_tributes_ecard_notify_last_name', true );
	$notify_email      = give_get_meta( $payment_id, '_give_tributes_honoree_ecard_email', true );
	$notify_message    = give_get_meta( $payment_id, '_give_tributes_ecard_personalized_message', true );

	// Check if multiple receipts or not.
	if ( give_tributes_is_multiple_receipts_enabled( $payment_id ) ) {

		foreach ( array_keys( $notify_first_name ) as $email_key ) {

			$notify_data[ $email_key ] = array(
				'first_name' => $notify_first_name[ $email_key ],
				'last_name'  => $notify_last_name[ $email_key ],
				'full_name'  => $notify_first_name[ $email_key ] . ' ' . $notify_last_name[ $email_key ],
				'email'      => $notify_email[ $email_key ],
				'message'    => $notify_message[ $email_key ],
			);
		}
	} else {
		// For single receipt payment.
		$notify_data = array(
			'first_name' => $notify_first_name,
			'last_name'  => $notify_last_name,
			'full_name'  => $notify_first_name . ' ' . $notify_last_name,
			'email'      => $notify_email,
			'message'    => $notify_message,
		);
	}

	// Get the notify information from the payment.
	return ! empty( $notify_data[ $email ] ) ? $notify_data[ $email ] : $notify_data;
}

/**
 * Get the HTML for the resend eCards popup.
 *
 * @since 1.2
 *
 * @param integer $payment_id   Payment ID.
 * @param string  $popup_type   Popup Type like 'resend' or 'preview'.
 * @param string  $is_edit_page Page type if report or edit payment donation page.
 *
 * @return bool|string
 */
function give_tributes_generate_popup_html( $payment_id, $popup_type = 'resend', $is_edit_page = 'false' ) {

	// If payment is not passed, return false.
	if ( empty( $payment_id ) ) {
		return false;
	}

	ob_start();
	?>
	<div class="resend-receipt give-tributes-popup" id="notification_payment-<?php echo intval( $payment_id ); ?>" data-popuptype="<?php echo esc_attr( $popup_type ); ?>">
		<span class="give-tributes-popup-btn-close dashicons dashicons-no-alt"></span>
		<div class="give-tributes-popup-inside">
			<p class="give-tributes-user-title"><?php echo 'resend' === $popup_type ? __( 'Which email should we resend?', 'give-tributes' ) : __( 'Which email do you want to preview?', 'give-tributes' ); ?></p>
			<div class="give-tributes-user-lists">
				<?php

				// Get receipt's full names from payment.
				$full_names = give_tributes_ecards_notify_fields( $payment_id, 'full_name', ', ', ARRAY_A );

				// Get receipt's emails from payment.
				$emails = give_tributes_ecards_notify_fields( $payment_id, 'emails', ', ', ARRAY_A );

				// Notification index.
				$notify_index = 0;

				// List out all the receipt person list.
				foreach ( $full_names as $key => $full_name ) {

					$input_type = 'resend' === $popup_type ? 'checkbox' : 'radio';
					$input_name = 'resend' === $popup_type ? 'give-tributes-notify-users[]' : 'give-tributes-preview-user' . intval( $payment_id );
					$is_checked = 'preview' === $popup_type ? ( checked( 0, $notify_index, false ) ) : '';
					?>
					<label for="<?php echo $popup_type; ?>_user_option_<?php echo intval( $payment_id ) . '_' . intval( $key + 1 ); ?>" class="give-tributes-user-label">
						<input type="<?php echo $input_type; ?>" name="<?php echo $input_name; ?>"
						       id="<?php echo $popup_type; ?>_user_option_<?php echo intval( $payment_id ) . '_' . intval( $key + 1 ); ?>" value="<?php echo $emails[ $key ]; ?>"
						       class="give-tributes-preview-user" <?php echo $is_checked; ?> />
						<?php echo $full_name . ' (' . $emails[ $key ] . ') '; ?>
					</label>
					<?php
					$notify_index ++;
				}
				?>
				<input type="hidden" name="is_edit_page" class="is_edit_page" value="<?php echo esc_attr( $is_edit_page ); ?>" />
				<input type="hidden" name="give_tributes_payment_id" class="give_tributes_payment_id" value="<?php echo intval( $payment_id ); ?>" />
				<div class="give-tributes-popup-footer">
					<input type="button" class="button button-primary tribute-ecard-btn" data-action="<?php echo $popup_type; ?>"
					       value="<?php echo 'resend' === $popup_type ? __( 'Send eCard', 'give-tributes' ) : __( 'Preview eCard', 'give-tributes' ); ?>" />
				</div>
			</div>
		</div>
	</div>
	<?php

	// Get the popup content.
	return ob_get_clean();
}

/**
 * Get the Payment ID or receipt data.
 *
 * @since 1.2
 *
 * @param integer|array $notification_details It can be notification person's informations or just a payment id.
 *
 * @return array
 */
function give_tributes_get_payment_id_or_data( $notification_details ) {

	// If the $receipt_data is array.
	$payment_id = is_array( $notification_details ) ? $notification_details['payment_id'] : $notification_details;

	return array(
		'notify_data' => give_tributes_get_notify_data_by_email( $notification_details['payment_id'], $notification_details['email'] ),
		'payment_id'  => intval( $payment_id ),
	);
}

/**
 * Check if the Payment ID contains multiple receipts/notify information or not.
 *
 * @since 1.2
 *
 * @param integer $payment_id Payment ID.
 * @param string  $default    Default value.
 *
 * @return bool
 */
function give_tributes_is_multiple_receipts_enabled( $payment_id, $default = 'enabled' ) {

	// Return false if payment id is not there.
	if ( empty( $payment_id ) ) {
		return false;
	}

	// Return if this payment holds multiple receipts or not.
	return give_is_setting_enabled( give_get_meta( $payment_id, '_give_tributes_ecard_multiple_recipients', true ), $default );
}

/**
 * Get the fragments from the the query string for preview ecard.
 *
 * @param integer $payment_id Donation payment ID.
 *
 * @return array
 */
function give_tributes_preview_ecard_fragments( $payment_id ) {

	// Explode the query string 'preview_id'.
	$get_query_fragments = explode( '-', $payment_id );

	// If explode has more than 1 array.
	if ( count( $get_query_fragments ) > 1 ) {

		// Get the payment id.
		$payment_id = $get_query_fragments[0];

		// Get the email address from the 'preview_id' arg.
		$email = isset( $get_query_fragments[1] ) ? sanitize_email( urldecode( $get_query_fragments[1] ) ) : '';
	}

	// Return payment_id and email in array.
	return array(
		'payment_id' => $payment_id,
		'email'      => ! empty( $email ) ? $email : '',
	);
}

/**
 * Get the URL for the eCards action URL.
 *
 * @since 1.2
 *
 * @param integer $payment_id  Payment ID.
 * @param string  $action_type eCards URL action type.
 *
 * @return bool|string
 */
function give_tributes_get_ecards_action_url( $payment_id, $action_type ) {

	// Return false, if the payment id or action type were not passed.
	if ( empty( $payment_id ) || empty( $action_type ) ) {
		return false;
	}

	$action_url = 'javascript:void(0);';

	if ( 'resend' === $action_type ) {

		// Get current page.
		$current_page = give_check_variable( $_GET['page'], 'isset_empty' );

		// Generate the url for the eCard preview.
		$action_url = esc_url( add_query_arg( array(
			'give_action'     => 'resend_ecard',
			'give-messages[]'    => 'resent-ecard',
			'preview_id'      => $payment_id,
			'ecard_sent_from' => $current_page,
		), home_url() ) );

	} elseif ( 'preview' === $action_type ) {

		// Generate the url for the eCard preview.
		$action_url = esc_url( add_query_arg( array(
			'give_action' => 'preview_ecard',
			'preview_id'  => $payment_id,
		), home_url() ) );

	}

	// Return ecards action url.
	return give_tributes_is_multiple_receipts_enabled( $payment_id ) ? 'javascript:void(0);' : $action_url;
}

/**
 * Give Tributes add address to support new address formatting, added in give version 1.8.14.
 *
 * @since 1.2
 * @since updated 1.2.1
 *
 * @param string $form_id Donation Form id in which it is being called.
 *
 * @return mixed
 */
function give_tributes_get_address_fields( $form_id ) {

	$selected_country  = give_get_country();
	$no_states_country = give_no_states_country_list();

	$state_exists  = ( ! empty( $selected_country ) && array_key_exists( $selected_country, $no_states_country ) ? true : false );
	$zipcode_class = ( ! empty( $state_exists ) ? 'form-row-wide' : 'form-row-last' );
	$zipcode_class .= ' give_tributes_adjust_zip';

	$states         = give_get_states( $selected_country );
	$selected_state = give_get_state();

	$state_label         = __( 'State', 'give-tributes' );
	$states_labels_array = give_get_states_label();

	// Check if $country code exists in the array key for states label.
	if ( array_key_exists( $selected_country, $states_labels_array ) ) {
		$state_label = $states_labels_array[ $selected_country ];
	}

	// Get the honoree notification method.
	$notify_choice = give_tributes_get_notify_display_option( $form_id );

	// Check if global tribute settings is enabled.
	$custom_message_enable_disable = 'disabled';
	$mail_card_message_length      = 255;
	if ( ! give_tributes_is_per_form_customized( $form_id ) && give_is_setting_enabled( give_get_option( 'give_tributes_enable_disable' ) ) ) {

		// Get global Mail a Card custom message enable/disable.
		$custom_message_enable_disable = give_get_option( 'give_tributes_custom_message_enable_disable', 'disabled' );

		// Get global Mail a Card custom message length.
		$mail_card_message_length = give_get_option( 'give_tributes_message_length', 255 );

	} elseif ( give_tributes_is_per_form_customized( $form_id ) ) {

		// Get Per-form Mail a Card custom message enable/disable.
		$custom_message_enable_disable = give_get_meta( $form_id, '_give_tributes_per_form_custom_message_enable_disable', true );
		$custom_message_enable_disable = ! empty( $custom_message_enable_disable ) ? $custom_message_enable_disable : 'disabled';

		// Get Per-form Mail a Card custom message length.
		$mail_card_message_length = give_get_meta( $form_id, '_give_tributes_per_form_message_length', true );
		$mail_card_message_length = ! empty( $mail_card_message_length ) ? $mail_card_message_length : 255;

	}

	// Required fields
	$country_required              = give_field_is_required( 'give_tributes_address_country', $form_id );
	$first_name_required           = give_field_is_required( 'give_tributes_mail_card_notify_first_name', $form_id );
	$last_name_required            = give_field_is_required( 'give_tributes_mail_card_notify_last_name', $form_id );
	$mail_card_address_1_required  = give_field_is_required( 'give_tributes_mail_card_address_1', $form_id );
	$mail_card_city_required       = give_field_is_required( 'give_tributes_mail_card_city', $form_id );
	$mail_card_state_required      = give_field_is_required( 'give_tributes_address_state', $form_id );
	$mail_card_zipcode_required    = give_field_is_required( 'give_tributes_mail_card_zipcode', $form_id );
	$personalized_message_required = give_field_is_required( 'give-tributes-mail-card-personalized-message', $form_id );

	ob_start();
	?>
	<div id="give-tributes-mail-card-fields-<?php echo $form_id; ?>" class="give_tributes_mail_card_fields"><!-- Give - Tributes Mail a Card Fields Start -->
		<h3 class="give-section-break give-tributes-legend"><?php ( 'donor_choice' === $notify_choice ) ? _e( 'Notification Details', 'give-tributes' ) : _e( 'Card Notification Details', 'give-tributes' ); ?></h3>

		<?php if ( 'disabled' !== $custom_message_enable_disable ) : ?>
			<p id="give-tributes-mail-card-personalized-message-<?php echo $form_id; ?>"
			   class="form-row form-row-wide form-row-responsive give_tributes_mail_card_personalized_message">
				<label class="give-label" for="give-tributes-mail-card-personalized-message-area-<?php echo $form_id; ?>">
					<?php _e( 'Personalized Message', 'give-tributes' ); ?>

					<?php if ( $personalized_message_required ): ?>
						<span class="give-required-indicator">*</span>
					<?php endif; ?>

					<span
							class="give-tooltip give-icon give-icon-question"
							data-tooltip="<?php esc_attr_e( 'This is the personalized notification message that is sent inside the card.', 'give-tributes' ); ?>">
								</span>
				</label>
				<textarea
						maxlength="<?php echo $mail_card_message_length; ?>"
						name="give-tributes-mail-card-personalized-message"
						id="give-tributes-mail-card-personalized-message-area-<?php echo $form_id; ?>"
						class="large-text <?php echo $personalized_message_required ? 'required' : ''; ?>"></textarea>
				<span
						id="give-tributes-mail-card-personalized-message-left-<?php echo $form_id; ?>"
						class="give-tributes-mail-card-personalized-message-left">
								<?php echo sprintf( __( '%s Characters left', 'give-tributes' ), $mail_card_message_length ); ?>
							</span>
			</p>
		<?php endif; ?>

		<p id="give-tributes-mail-card-notify-first-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-first form-row-responsive">
			<label class="give-label" for="give-tributes-mail-card-notify-first-name-<?php echo $form_id; ?>">
				<?php _e( 'First Name', 'give-tributes' ); ?>
				<?php if ( $first_name_required ) : ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>
				<span class="give-tooltip give-icon give-icon-question"
				      data-tooltip="<?php esc_attr_e( 'The first name of the recipient being notifed of your donation.', 'give-tributes' ); ?>"></span>
			</label>
			<input
					class="give-input <?php echo $first_name_required ? 'required' : ''; ?>"
					type="text"
					name="give_tributes_mail_card_notify_first_name"
					placeholder="<?php esc_attr_e( 'Recipient First Name', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-notify-first-name-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

		<p id="give-tributes-mail-card-notify-last-name-wrap-<?php echo $form_id; ?>" class="form-row form-row-last form-row-responsive">
			<label class="give-label" for="give-tributes-mail-card-notify-last-name-<?php echo $form_id; ?>">
				<?php _e( 'Last Name', 'give-tributes' ); ?>
				<?php if ( $last_name_required ) : ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>
				<span class="give-tooltip give-icon give-icon-question"
				      data-tooltip="<?php esc_attr_e( 'The last name of the recipient being notifed of your donation.', 'give-tributes' ); ?>"></span>
			</label>
			<input
					class="give-input <?php echo $last_name_required ? 'required' : ''; ?>"
					type="text"
					name="give_tributes_mail_card_notify_last_name"
					placeholder="<?php esc_attr_e( 'Recipient Last Name', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-notify-last-name-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

		<p id="give-tributes-mail-card-country-<?php echo $form_id; ?>"
		   class="form-row form-row-wide form-row-responsive give_tributes_mail_card_country">
			<label for="give_tributes_address_country_<?php echo $form_id; ?>">
				<?php _e( 'Country', 'give-tributes' ); ?>
				<?php if ( $country_required ) : ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>
				<span class="give-tooltip give-icon give-icon-question" data-tooltip="<?php esc_attr_e( 'The recipient\'s country.', 'give-tributes' ); ?>"></span>
			</label>
			<select
					name="give_tributes_address_country"
					id="give_tributes_address_country_<?php echo $form_id; ?>"
					class="select give-select <?php echo ( $country_required ) ? 'required' : ''; ?>">
				<?php foreach ( give_get_country_list() as $key => $country ) :
					if ( '' !== $key ) : ?>
						<option value="<?php echo $key; ?>" <?php echo selected( $key, $selected_country, false ); ?>><?php echo esc_html( $country ); ?></option>
						<?php
					endif;
				endforeach; ?>
			</select>
		</p>

		<p id="give-tributes-mail-card-address1-<?php echo $form_id; ?>"
		   class="form-row form-row-wide form-row-responsive give_tributes_mail_card_address1">
			<label class="give-label" for="give-tributes-mail-card-address1-<?php echo $form_id; ?>">
				<?php _e( 'Address Line 1', 'give-tributes' ); ?>

				<?php if ( $mail_card_address_1_required ): ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>

				<span
						class="give-tooltip give-icon give-icon-question"
						data-tooltip="<?php esc_attr_e( 'The recipient\'s mailing address.', 'give-tributes' ); ?>">
							</span>
			</label>
			<input
					class="give-input give_tributes_mail_card_address_1 <?php echo $mail_card_address_1_required ? 'required' : ''; ?>"
					type="text"
					name="give_tributes_mail_card_address_1"
					placeholder="<?php esc_attr_e( 'Recipient Address Line 1', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-address1-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

		<p id="give-tributes-mail-card-address2-<?php echo $form_id; ?>"
		   class="form-row form-row-responsive form-row-wide give_tributes_mail_card_address2">
			<label class="give-label" for="give-tributes-mail-card-address2-<?php echo $form_id; ?>">
				<?php _e( 'Address Line 2', 'give-tributes' ); ?>
				<span
						class="give-tooltip give-icon give-icon-question"
						data-tooltip="<?php esc_attr_e( 'Additional address information for the recipient.', 'give-tributes' ); ?>">
							</span>
			</label>
			<input
					class="give-input give_tributes_mail_card_address_2"
					type="text"
					name="give_tributes_mail_card_address_2"
					placeholder="<?php esc_attr_e( 'Recipient Address Line 2', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-address2-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

		<p id="give-tributes-mail-card-city-<?php echo $form_id; ?>"
		   class="form-row form-row-responsive give_tributes_mail_card_city form-row-wide">
			<label class="give-label" for="give-tributes-mail-card-city-<?php echo $form_id; ?>">
				<?php _e( 'City', 'give-tributes' ); ?>

				<?php if ( $mail_card_city_required ): ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>

				<span
						class="give-tooltip give-icon give-icon-question"
						data-tooltip="<?php esc_attr_e( 'The recipient\'s city.', 'give-tributes' ); ?>">
							</span>
			</label>
			<input
					class="give-input <?php echo $mail_card_city_required ? 'required' : ''; ?>"
					type="text"
					name="give_tributes_mail_card_city"
					placeholder="<?php esc_attr_e( 'Recipient City', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-city-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

		<p id="give-tributes-mail-card-state-<?php echo $form_id; ?>"
		   class="form-row form-row-responsive give_tributes_mail_card_state form-row-first <?php echo( ! empty( $state_exists ) ? 'give-hidden ' : ' ' ); ?>">
			<label class="give_tributes_address_state_label" for="give_tributes_address_state_<?php echo $form_id; ?>">
				<?php echo $state_label; ?>
				<?php if ( $mail_card_state_required ) : ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>
				<span
						class="give-tooltip give-icon give-icon-question"
						data-tooltip="<?php esc_attr_e( 'The recipient\'s state, province, or county.', 'give-tributes' ); ?>">
				</span>
			</label>
			<?php
			if ( ! empty( $states ) ) : ?>
				<select data-key="state" name="give_tributes_address_state" id="give_tributes_address_state_<?php echo $form_id; ?>" class="text give-input <?php echo $mail_card_state_required ? 'required' : ''; ?>">
					<?php foreach ( $states as $state_code => $state ) {
						echo '<option value="' . $state_code . '"' . selected( $state_code, $selected_state, false ) . '>' . $state . '</option>';
					} ?>
				</select>
			<?php else : ?>
				<input
						name="give_tributes_address_state"
						id="give_tributes_address_state_<?php echo $form_id; ?>"
						class="text give-input <?php echo $mail_card_state_required ? 'required' : ''; ?>"
						placeholder="<?php echo $state_label; ?>"
						type="text"
						value=""
				/>
			<?php endif; ?>
		</p>

		<p id="give-tributes-mail-card-zipcode-<?php echo $form_id; ?>"
		   class="form-row form-row-responsive give_tributes_mail_card_zipcode <?php echo $zipcode_class; ?>">
			<label class="give-label" for="give-tributes-mail-card-zipcode-<?php echo $form_id; ?>">
				<?php _e( 'Zip/Postal Code', 'give-tributes' ); ?>

				<?php if ( $mail_card_zipcode_required ): ?>
					<span class="give-required-indicator">*</span>
				<?php endif; ?>

				<span
						class="give-tooltip give-icon give-icon-question"
						data-tooltip="<?php esc_attr_e( 'The recipient\'s zip or postal code.', 'give-tributes' ); ?>">
							</span>
			</label>
			<input
					class="give-input <?php echo $mail_card_zipcode_required ? 'required' : ''; ?>"
					type="text"
					name="give_tributes_mail_card_zipcode"
					placeholder="<?php esc_attr_e( 'Recipient Zip/Postal Code', 'give-tributes' ); ?>"
					id="give-tributes-mail-card-zipcode-<?php echo $form_id; ?>"
					value=""
			/>
		</p>

	</div><!-- Give - Tributes Mail a Card Fields End -->
	<?php
	$mail_card_wrap = ob_get_clean();

	return $mail_card_wrap;
}

/**
 * Check whether Card creation enable/disable
 *
 * @since 1.3.4
 *
 * @param int $payment_id Payment Id.
 *
 * @return string
 */
function is_card_creation_enable( $payment_id ) {
	$card_creation = 'disabled';
	$form_id       = give_get_payment_form_id( $payment_id );

	// Disable Card creation if Payment Id OR Form id blank.
	if ( empty( $form_id ) || empty( $payment_id ) ) {
		return $card_creation;
	}

	// Get Tribute enable/disable for particular Donation.
	$gave_in_tribute = give_get_meta( $payment_id, '_give_tributes_accept', true );
	$gave_in_tribute = ! empty( $gave_in_tribute ) ? $gave_in_tribute : 'no';

	// Disable Card creation if Tribute option disable.
	if ( 'no' === $gave_in_tribute ) {
		return $card_creation;
	}

	$ecard_or_mailed = give_get_meta( $payment_id, '_give_tributes_would_to', true );
	$ecard_or_mailed = ! empty( $ecard_or_mailed ) ? $ecard_or_mailed : 'none';

	if ( 'send_mail_card' === $ecard_or_mailed ) {

		if ( give_tributes_is_per_form_customized( $form_id ) ) {

			$is_mail_card_enable = give_get_meta( $form_id, '_give_tributes_per_form_mail_a_card_enable_disable', true );
			$is_mail_card_enable = ! empty( $is_mail_card_enable ) ? $is_mail_card_enable : 'disabled';

			if ( ! give_is_setting_enabled( $is_mail_card_enable ) ) {
				return 'disabled';
			}

			$who_sends_the_card = give_get_meta( $form_id, '_give_tributes_per_form_who_sends_the_card', true );
			$who_sends_the_card = ! empty( $who_sends_the_card ) ? $who_sends_the_card : 'the_admin';

			if ( 'the_admin' === $who_sends_the_card ) {

				$card_creation = 'enabled';

			} else {

				// Get Mail a Card creation Enabled/Disabled.
				$card_creation = give_get_meta( $form_id, '_give_tributes_per_form_card_creation_enable_disable', true );
				$card_creation = ! empty( $card_creation ) ? $card_creation : 'disabled';
			}
		} elseif ( give_tributes_is_per_form_global( $form_id ) ) {

			$who_sends_the_card = give_get_option( 'give_tributes_who_sends_the_card', 'the_admin' );
			$card_creation      = give_get_option( 'give_tributes_card_creation_enable_disable', 'disabled' );

			if ( 'the_admin' === $who_sends_the_card ) {
				$card_creation = 'enabled';
			}
		}
	}

	return $card_creation;
}

/**
 * Check if current page is manual donation page.
 *
 * @return bool
 */
function give_tribute_is_manual_donation_page() {

	if ( isset( $_POST['action'] ) && 'give_md_check_form_setup' === $_POST['action'] && is_admin() ) {
		return true;
	}

	return false;
}

/**
 * Enqueue common JS which will be usable in admin and frontend both
 */
function give_tribute_enqueue_common_js() {

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_register_script( GIVE_TRIBUTES_SLUG . '-common', GIVE_TRIBUTES_PLUGIN_URL . 'assets/js/give-tributes-common' . $suffix . '.js', array( 'jquery' ), GIVE_TRIBUTES_VERSION,
		false );
	wp_enqueue_script( GIVE_TRIBUTES_SLUG . '-common' );
	wp_localize_script( GIVE_TRIBUTES_SLUG . '-common', 'give_tributes_common_vars', array(
		'give_tribute_characters_left'      => __( 'Characters left', 'give-tributes' ),
		'ajax_url'                          => admin_url( 'admin-ajax.php' ),
		'give_tribute_receipt_limit_exceed' => __( 'Sorry! You cannot add notify people more than 5.', 'give-tributes' ),
	) );
}

add_action( 'admin_enqueue_scripts', 'give_tribute_enqueue_common_js', 5 );
add_action( 'wp_enqueue_scripts', 'give_tribute_enqueue_common_js', 5 );
/**
 * Send eCard email when payment has been changed to complete.
 *
 * @since 1.1.1
 * @since 1.4.1 Changed hook priority and moved it here from Give_Tributes_Admin class.
 *
 * @param int    $payment_id Payment ID.
 * @param string $status     The new status.
 *
 * @return bool|null
 */
function send_ecard_when_payment_status_changed( $payment_id, $status, $old_status ) {

	// Return false, if there is no payment id.
	if ( ! isset( $payment_id ) ) {
		return false;
	}

	// Get last eCard sent date/time.
	$is_ecard_sent = give_get_meta( $payment_id, '_give_tributes_ecard_email_sent_date', true );
	$form_id       = give_get_payment_form_id( $payment_id );

	$notify_method = give_get_payment_meta( $payment_id, '_give_tributes_would_to', true );

	// If it's offline donation and the payment is published or completed.
	if ( ( 'publish' === $status || 'complete' === $status ) && empty( $is_ecard_sent ) && 'send_eCard' === $notify_method ) {

		// Don't send if payment was manually added
		// @TODO: remove once manual donations is integrated:
		// https://github.com/impress-org/give-tributes/issues/240
		$manually_added = give_get_meta( $payment_id, '_give_manually_added_donation', true );
		if ( $manually_added ) {
			return false;
		}

		if ( give_tributes_is_method_enabled( $form_id, 'send_eCard' ) ) {
			// Send eCard.
			give_tributes_ecard_email_receipt( $payment_id );
		}
	}
}

// Send eCard email when payment status changed.
add_action( 'give_update_payment_status', 'send_ecard_when_payment_status_changed', 1, 3 );

/**
 * List Tribute Mail a Card required fields.
 *
 * @since 1.5
 * @return array
 */
function __give_tribute_mail_card_required_fields() {
	$required_fields = array(
		'give_tributes_first_name',
		'give_tributes_last_name',
		'give_tributes_mail_card_notify_first_name',
		'give_tributes_mail_card_notify_last_name',
		'give_tributes_mail_card_address_1',
		'give_tributes_mail_card_city',
		'give_tributes_address_state',
		'give_tributes_address_country',
		'give_tributes_mail_card_zipcode',
		'give-tributes-mail-card-personalized-message',
	);

	return $required_fields;
}


/**
 * List Tribute eCard required fields.
 *
 * @since 1.5
 * @return array
 */
function __give_tribute_ecard_required_fields() {
	$required_fields = array(
		'give_tributes_ecard_notify_first_name',
		'give_tributes_ecard_last_name',
		'give_tributes_ecard_email',
		'give_tributes_ecard_notify_personalized_message',
	);

	return $required_fields;
}