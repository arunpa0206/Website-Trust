<?php
/**
 * Give BrainTree Gateway
 *
 * @package     Give
 * @copyright   Copyright (c) 2016, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.2
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class Give_Braintree_Gateway.
 *
 * @since 1.2
 */
class Give_Braintree_Gateway {

	/**
	 * Merchant ID Key.
	 *
	 * @var string
	 */
	private $merchant_id = '';

	/**
	 * Merchant Account ID Key.
	 *
	 * @var string
	 */
	private $merchant_account_id = '';

	/**
	 * Sandbox Public Key.
	 *
	 * @var string
	 */
	private $public_key = '';


	/**
	 * Private Key.
	 *
	 * @var string
	 */
	private $private_key = '';

	/**
	 * Give_Braintree_Gateway constructor.
	 */
	public function __construct() {

		if ( ! class_exists( 'Braintree_Base' ) && ! function_exists( 'requireDependencies' ) ) {
			// Include the sdk.
			$sdk = GIVE_BRAINTREE_PLUGIN_DIR . '/vendor/braintree/braintree_php/lib/Braintree.php';

			if ( file_exists( $sdk ) ) {
				require_once $sdk;
			}
		}

		$this->hooks();
		$this->give_get_braintree_keys();

	}

	/**
	 * Setup hooks.
	 */
	public function hooks() {

		add_action( 'give_gateway_braintree', array( $this, 'process_payment' ) );

		add_action( 'give_braintree_cc_form', array( $this, 'give_braintree_optional_billing_fields' ), 10, 1 );

		add_filter(
			'give_payment_details_transaction_id-braintree', array(
				$this,
				'give_braintree_link_transaction_id',
			), 10, 2
		);
	}

	/**
	 * Given a transaction ID, generate a link to the Braintree transaction ID details
	 *
	 * @param  string $transaction_id The Transaction ID
	 * @param  int    $payment_id The payment ID for this transaction
	 *
	 * @return string                 A link to the PayPal transaction details
	 */
	public function give_braintree_link_transaction_id( $transaction_id, $payment_id ) {

		if ( $transaction_id == $payment_id ) {
			return $transaction_id;
		}

		$base = 'https://';

		if ( 'test' == get_post_meta( $payment_id, '_give_payment_mode', true ) ) {
			$base .= 'sandbox.';
		}

		$base           .= 'braintreegateway.com/merchants/' . $this->merchant_id . '/transactions/';
		$transaction_url = '<a href="' . esc_url( $base . $transaction_id ) . '" target="_blank">' . $transaction_id . '</a>';

		return apply_filters( 'give_braintree_link_payment_details_transaction_id', $transaction_url );

	}

	/**
	 * Optional Billing Fields
	 *
	 * @param $form_id
	 *
	 * @return void
	 */
	function give_braintree_optional_billing_fields( $form_id ) {

		// Remove Address Fields if user has option enabled
		if ( ! give_get_option( 'braintree_collect_billing' ) ) {
			remove_action( 'give_after_cc_fields', 'give_default_cc_address_fields' );
		}

		// Ensure CC field is in place properly
		do_action( 'give_cc_form', $form_id );

	}

	/**
	 * Braintree Process Payment.
	 *
	 * @param array $payment_data Donation data.
	 */
	public function process_payment( $payment_data ) {

		// check the posted cc details.
		$cc = $this->check_cc_details( $payment_data );

		// check for errors before we continue to processing.
		if ( ! give_get_errors() ) {

			// Setup authentication.
			$this->give_braintree_setup_authentication();

			$payment_args = array(
				'price'           => $payment_data['price'],
				'give_form_title' => $payment_data['post_data']['give-form-title'],
				'give_form_id'    => intval( $payment_data['post_data']['give-form-id'] ),
				'give_price_id'   => isset( $payment_data['post_data']['give-price-id'] ) ? $payment_data['post_data']['give-price-id'] : '',
				'date'            => $payment_data['date'],
				'user_email'      => $payment_data['user_email'],
				'purchase_key'    => $payment_data['purchase_key'],
				'currency'        => give_get_currency(),
				'user_info'       => $payment_data['user_info'],
				'status'          => 'pending',
				'gateway'         => 'braintree',
			);

			$payment_id = give_insert_payment( $payment_args );

			$transaction = array(
				'orderId'           => $payment_id,
				'amount'            => $payment_data['price'],
				'merchantAccountId' => $this->merchant_account_id,
				'creditCard'        => array(
					'cardholderName'  => $cc['card_name'],
					'number'          => $cc['card_number'],
					'expirationMonth' => $cc['card_exp_month'],
					'expirationYear'  => $cc['card_exp_year'],
					'cvv'             => $cc['card_cvc'],
				),
				'options'           => array(),
			);

			$vault = give_get_option( 'braintree_storeInVaultOnSuccess' );

			if ( $vault ) {
				$transaction['options']['storeInVaultOnSuccess'] = true;
			}

			// If Vault is enabled. Lookup to see if we have an existing customer ID with this donor's email.
			$tokens = $this->get_vault_tokens( $payment_data );

			if ( isset( $tokens['customer_id'] ) && $vault ) {
				// Repeat customer.
				$transaction['customerId'] = $tokens['customer_id'];
				// Check for duplicate payment cards in vault.
				$dup_source = $this->duplicate_payment_source_check( $tokens['customer_id'], $tokens );

				// This CC has already been saved for the customer.
				if ( $dup_source ) {
					// Don't store this one in the vault.
					$transaction['options']['storeInVaultOnSuccess'] = false;
				}
			} else {
				// New customer.
				$transaction['customer'] = array(
					'firstName' => $payment_data['user_info']['first_name'],
					'lastName'  => $payment_data['user_info']['last_name'],
					'email'     => $payment_data['user_email'],
				);
			}

			// Are the billing fields enabled?
			$billing_fields = give_get_option( 'braintree_collect_billing' );
			if ( $billing_fields ) {
				$transaction['billing'] = array(
					'streetAddress'     => $payment_data['card_info']['card_address'],
					'extendedAddress'   => $payment_data['card_info']['card_address_2'],
					'locality'          => $payment_data['card_info']['card_city'],
					'region'            => $payment_data['card_info']['card_state'],
					'postalCode'        => $payment_data['card_info']['card_zip'],
					'countryCodeAlpha2' => $payment_data['card_info']['card_country'],
				);
			}

			$settlement = give_get_option( 'braintree_submitForSettlement' );
			if ( $settlement ) {
				$transaction['options']['submitForSettlement'] = true;
			}

			// Filter for other developers.
			$transaction = apply_filters( 'give_braintree_transaction_args', $transaction );

			// Try the Braintree sale.
			try {

				$result = Braintree_Transaction::sale( $transaction );

				// Successful result?
				if ( isset( $result->success ) && ! empty( $result->success ) ) {

					$this->update_vault_tokens( $result, $payment_data );
					give_update_payment_status( $payment_id, 'complete' );
					give_set_payment_transaction_id( $payment_id, $result->transaction->id );
					give_send_to_success_page();

				} elseif ( ! $result->success ) {

					// Handle API response errors.
					give_braintree_handle_transaction_errors( $result, $payment_id );

				}
			} catch ( Exception $e ) {

				// Log all exceptions.
				give_log_braintree_error( $e );

			}
		}
	}

	/**
	 * Get the Braintree API keys.
	 */
	public function give_get_braintree_keys() {

		if ( give_is_test_mode() ) {
			// Sandbox.
			$this->merchant_id         = trim( give_get_option( 'sandbox_braintree_merchantId' ) );
			$this->merchant_account_id = trim( give_get_option( 'sandbox_braintree_merchantAccountId' ) );
			$this->public_key          = trim( give_get_option( 'sandbox_braintree_publicKey' ) );
			$this->private_key         = trim( give_get_option( 'sandbox_braintree_privateKey' ) );
		} else {
			// LIVE.
			$this->merchant_id         = trim( give_get_option( 'braintree_merchantId' ) );
			$this->merchant_account_id = trim( give_get_option( 'braintree_merchantAccountId' ) );
			$this->public_key          = trim( give_get_option( 'braintree_publicKey' ) );
			$this->private_key         = trim( give_get_option( 'braintree_privateKey' ) );
		}
	}

	/**
	 * Setup Braintree authentication
	 */
	public function give_braintree_setup_authentication() {
		try {
			if ( give_is_test_mode() ) {
				Braintree_Configuration::environment( 'sandbox' );
			} else {
				Braintree_Configuration::environment( 'production' );
			}
			Braintree_Configuration::merchantId( $this->merchant_id );
			Braintree_Configuration::publicKey( $this->public_key );
			Braintree_Configuration::privateKey( $this->private_key );

		} catch ( Exception $e ) {

			give_log_braintree_error( $e );

		}
	}

	/**
	 * Get vault tokens from customer or user meta.
	 *
	 * Returns an array if successful containing customer ID and CC tokens.
	 *
	 * @param $payment_data
	 *
	 * @return bool|mixed
	 */
	public function get_vault_tokens( $payment_data ) {

		if ( class_exists( 'Give_Donor' ) && ! empty( $payment_data['user_email'] ) ) {

			$give_customer = new Give_Donor( $payment_data['user_email'] );
			$tokens        = $give_customer->get_meta( 'give_braintree_cc_tokens' );

		} elseif ( isset( $payment_data['user_info']['id'] ) && $payment_data['user_info']['id'] > 0 ) {

			// Update user meta.
			$tokens = get_user_meta( $payment_data['user_info']['id'], 'give_braintree_cc_tokens' );

		}

		if ( ! empty( $tokens ) ) {
			return $tokens;
		} else {
			return false;
		}
	}

	/**
	 * Support for Braintree's "Vault" feature
	 *
	 * @since 1.1
	 *
	 * @param $result
	 * @param $payment_data
	 */
	function update_vault_tokens( $result, $payment_data ) {

		// Customer meta: Save donor data in Braintree vault if user email present.
		if ( class_exists( 'Give_Donor' ) && ! empty( $payment_data['user_email'] ) ) {

			$customer = new Give_Donor( $payment_data['user_email'] );

			$tokens = $customer->get_meta( 'give_braintree_cc_tokens' );

			if ( empty( $tokens ) ) {
				$tokens = $this->set_vault_token_array( $result );
			}

			// Update customer meta.
			$customer->update_meta( 'give_braintree_cc_tokens', $tokens );

		} elseif ( isset( $payment_data['user_info']['id'] ) && $payment_data['user_info']['id'] > 0 ) {

			$tokens = get_user_meta( $payment_data['user_info']['id'], 'give_braintree_cc_tokens', true );

			if ( empty( $tokens ) ) {
				$tokens = $this->set_vault_token_array( $result );
			}

			// Update user meta.
			update_user_meta( $payment_data['user_info']['id'], 'give_braintree_cc_tokens', $tokens );

		}

	}

	/**
	 * Vault token array creation.
	 *
	 * @param $result
	 *
	 * @return array|bool
	 */
	function set_vault_token_array( $result ) {

		if ( ! isset( $result->transaction->customerDetails->id ) ) {
			return false;
		}

		if ( ! isset( $result->transaction->creditCardDetails->token ) ) {
			return false;
		}

		$tokens = array(
			'customer_id'    => $result->transaction->customerDetails->id,
			'customer_cards' => array( $result->transaction->creditCardDetails->token ),
		);

		return $tokens;

	}

	/**
	 * Check CC Details
	 *
	 * @param $payment_data
	 *
	 * @return array
	 */
	function check_cc_details( $payment_data ) {
		$keys = array(
			'card_number'    => __( 'credit card number', 'give-braintree' ),
			'card_exp_month' => __( 'expiration month', 'give-braintree' ),
			'card_exp_year'  => __( 'expiration year', 'give-braintree' ),
			'card_name'      => __( 'card holder name', 'give-braintree' ),
			'card_cvc'       => __( 'security code', 'give-braintree' ),
		);

		$cc_details = array();

		foreach ( $keys as $key => $desc ) {
			if ( ! isset( $_POST[ $key ] ) || empty( $_POST[ $key ] ) ) {
				give_set_error( 'bad_' . $key, sprintf( __( 'You must enter a valid %s.', 'give-braintree' ), $desc ) );
				give_send_back_to_checkout();
			} else {
				$data = give_clean( $_POST[ $key ] );
				switch ( $key ) {
					case 'card_exp_month':
						$data = str_pad( $data, 2, 0, STR_PAD_LEFT );
						break;
					case 'card_exp_year':
						if ( strlen( $data ) > 2 ) {
							$data = substr( $data, - 2 );
						}
						break;
				}
				$cc_details[ $key ] = $data;

			}
		}

		return $cc_details;
	}

	/**
	 * Check for duplicate payment source in Vault.
	 *
	 * @param int|string $customer_id
	 * @param array      $tokens
	 *
	 * @return bool Whether it's a dupe payment source or not.
	 */
	function duplicate_payment_source_check( $customer_id, $tokens ) {

		$found = false;

		try {
			$customer = Braintree_Customer::find( $customer_id );

			// Loop through CC results.
			foreach ( $customer->creditCards as $cc ) {

				// If CC token found in db, this is a duplicate payment method.
				if ( in_array( $cc->token, $tokens['customer_cards'] ) ) {

					return true;
				}
			}
		} catch ( Exception $e ) {
			give_log_braintree_error( $e );
		}

		return $found;
	}
}

return new Give_Braintree_Gateway();
