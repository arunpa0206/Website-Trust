<?php
/**
 * Give 2Checkout Settings
 *
 * @package     Give
 * @copyright   Copyright (c) 2016, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds the settings to the Payment Gateways section
 *
 * @param $settings
 *
 * @return array
 */
function give_twocheckout_register_settings( $settings ) {

	switch ( give_get_current_setting_section() ) {
		case '2checkout-gateway':
			$settings = array(
				array(
					'id'   => 'give_title_2checkout',
					'type' => 'title',
				),
				array(
					'name' => '<strong>' . __( '2Checkout Gateway', 'give-twocheckout' ) . '</strong>',
					'desc' => '<hr>',
					'type' => 'give_title',
					'id'   => 'give_title_twocheckout',
				),
				array(
					'id'   => 'twocheckout-sellerId',
					'name' => __( 'Account Number', 'give-twocheckout' ),
					'desc' => __( 'Please enter your 2Checkout account number.', 'give-twocheckout' ),
					'type' => 'text',
				),
				array(
					'id'   => 'twocheckout-public-key',
					'name' => __( 'API Publishable Key', 'give-twocheckout' ),
					'desc' => __( 'Please enter your 2Checkout API publishable key.', 'give-twocheckout' ),
					'type' => 'api_key',
				),
				array(
					'id'   => 'twocheckout-private-key',
					'name' => __( 'API Private Key', 'give-twocheckout' ),
					'desc' => __( 'Please enter your 2Checkout API private key.', 'give-twocheckout' ),
					'type' => 'api_key',
				),
				array(
					'id'   => 'twocheckout-api-username',
					'name' => __( 'API Username', 'give-twocheckout' ),
					'desc' => sprintf(
						__( 'Please enter your 2Checkout API username.<br> <a href="%s" target="_blank">Read more about how to create API username and password</a>.', 'give-twocheckout' ),
						'http://help.2checkout.com/articles/FAQ/How-to-create-an-API-only-Username'
					),
					'type' => 'text',
				),
				array(
					'id'   => 'twocheckout-api-password',
					'name' => __( 'API User Password', 'give-twocheckout' ),
					'desc' => __( 'Please enter your 2Checkout API user password.', 'give-twocheckout' ),
					'type' => 'api_key',
				),
				array(
					'id'   => 'give_title_2checkout',
					'type' => 'sectionend',
				),
			);
			break;
	}

	return $settings;
}
add_filter( 'give_get_settings_gateways', 'give_twocheckout_register_settings' );

/**
 * Register sections.
 *
 * @since  1.1.4
 * @access public
 *
 * @param array $sections List of sections.
 *
 * @return mixed
 */
function give_twocheckout_register_sections( $sections ) {
	$sections['2checkout-gateway'] = __( '2Checkout Settings', 'give-twocheckout' );

	return $sections;
}
add_filter( 'give_get_sections_gateways', 'give_twocheckout_register_sections' );
