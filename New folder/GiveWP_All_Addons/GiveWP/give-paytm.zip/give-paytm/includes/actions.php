<?php
/**
 * Print cc field in donation form conditionally.
 *
 * @since 1.0
 *
 * @param $form_id
 *
 * @return bool
 */
function give_paytm_cc_form_callback( $form_id ) {

	if ( give_is_setting_enabled( give_get_option( 'paytm_billing_details' ) ) ) {
		give_default_cc_address_fields( $form_id );

		return true;
	}

	return false;
}

add_action( 'give_paytm_cc_form', 'give_paytm_cc_form_callback' );
