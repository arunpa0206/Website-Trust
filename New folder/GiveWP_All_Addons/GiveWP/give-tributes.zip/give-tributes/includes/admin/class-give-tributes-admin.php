<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://givewp.com
 * @since      1.0.0
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/admin
 * @author     GiveWP <https://givewp.com>
 */
class Give_Tributes_Admin {

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since  1.0.0
	 *
	 */
	public function __construct() {

		// Enqueue Script and Style for Admin.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		// Add Give Tribute settings.
		add_filter( 'give-settings_get_settings_pages', array( $this, 'add_settings' ), 10, 1 );

		// Add Custom Tribute Options in General settings.
		add_action( 'give_admin_field_give_tributes_group_repeater', array( $this, 'group_repeater_callback' ), 10, 2 );

		// Add custom Preview button for "Mail a Card".
		add_action( 'give_admin_field_give_tributes_preview_mail_card_button', array( $this, 'preview_mail_card_button_callback' ), 10, 2 );

		// Add custom Preview button for "eCard".
		add_action( 'give_admin_field_give_tributes_preview_ecard_button', array( $this, 'preview_ecard_button_callback' ), 10, 2 );

		// Save Give Tributes repeater options save.
		add_action( 'init', array( $this, 'repeater_options_save' ) );

		// Per-Form Meta box settings.
		add_action( 'give_metabox_form_data_settings', array( $this, 'metabox_form_data_settings' ), 0, 1 );

		// Per-From General settings callback.
		add_filter( 'give_tributes_general_metabox_fields', array( $this, 'general_metabox_fields_callback' ), 10, 1 );

		// Per-From Mail a card settings callback.
		add_filter( 'give_tributes_mail_card_metabox_fields', array( $this, 'mail_card_metabox_fields_callback' ), 10, 1 );

		// Per-From eCard settings callback.
		add_filter( 'give_tributes_ecard_metabox_fields', array( $this, 'ecard_metabox_fields_callback' ), 10, 1 );

		// Include Tributes Report settings.
		add_filter( 'give-reports_get_settings_pages', array( $this, 'report_page' ) );

		// Mail Card report view.
		add_action( 'give_tributes_mail_card_reports', array( $this, 'mail_card_reports_view' ) );

		// Mail Card report view.
		add_action( 'give_tributes_donations_reports', array( $this, 'donations_reports_view' ) );

		// eCard report view.
		add_action( 'give_tributes_ecard_reports', array( $this, 'ecard_reports_view' ) );

		// eCard Preview email.
		add_action( 'init', array( $this, 'ecard_display_email_template_preview' ) );

		// Send Global Test eCard email.
		add_action( 'give_tributes_send_test_email', array( $this, 'global_send_test_ecard_email_receipt' ), 10, 1 );

		// Resend eCard email from Backend Report.
		add_action( 'init', array( $this, 'resend_ecard_email_receipt' ) );

		// Global Mail a Card Preview.
		add_action( 'init', array( $this, 'mail_card_preview' ) );

		// Ajax callback for sent Mail card.
		add_action( 'wp_ajax_give_tributes_sent_mail_card', array( $this, 'sent_mail_card' ) );

		// Ajax callback for sent undo Mail card.
		add_action( 'wp_ajax_give_tributes_undo_sent_mail_card', array( $this, 'undo_sent_mail_card' ) );

		// Mail a Card Notification HTML callback.
		add_action( 'give_tributes_mail_card_notification_html', array( $this, 'mail_card_notification_template' ), 10, 1 );

		// Download Card.
		add_action( 'init', array( $this, 'download_card' ) );

		// Give-Tributes details show on donation detail page.
		add_action( 'give_view_donation_details_billing_after', array( $this, 'tribute_payment_metabox' ), 10, 1 );

		// Give-Tributes add column on donation listing page.
		add_action( 'give_payments_table_columns', array( $this, 'table_column' ), 10, 1 );

		// Give-Tributes column show data.
		add_action( 'give_payments_table_column', array( $this, 'column_data' ), 9, 3 );

		// Ajax Call to Export Mail a Card CSV.
		add_action( 'wp_ajax_give_tributes_do_ajax_export', array( $this, 'do_ajax_export' ) );

		// Call Admin notice.
		add_action( 'admin_notices', array( $this, 'admin_notice' ), 10 );

		// call admin notice
		add_action( 'admin_notices', array( $this, 'action_notice' ), 10 );

		// Ajax callback for resending the eCard to notification.
		add_action( 'wp_ajax_give_tributes_resend_ecards', array( $this, 'give_tributes_resend_ecards' ) );

		// Add overlay div for give tribute popup.
		add_action( 'admin_footer', array( $this, 'give_tributes_popup_overlay' ), 10 );

		// Include the response when change the form.
		add_filter( 'give_md_check_form_setup_response', array( $this, 'give_tributes_include_response' ), 10, 2 );

		// Filter added for meta key map for import export section.
		add_filter( 'give_import_donations_options', array( $this, 'give_tributes_donations_options' ), 10, 1 );
		add_filter( 'give_import_after_import_payment', array( $this, 'give_tributes_import_tributes_data' ), 10, 3 );
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function enqueue_styles() {

		if ( give_is_admin_page() ) {

			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			wp_register_style( GIVE_TRIBUTES_SLUG, GIVE_TRIBUTES_PLUGIN_URL . 'assets/css/give-tributes-admin' . $suffix . '.css', array(), GIVE_TRIBUTES_VERSION, 'all' );
			wp_enqueue_style( GIVE_TRIBUTES_SLUG );
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function enqueue_scripts() {

		if ( give_is_admin_page() ) {

			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			wp_register_script( GIVE_TRIBUTES_SLUG, GIVE_TRIBUTES_PLUGIN_URL . 'assets/js/give-tributes-admin' . $suffix . '.js', array( 'jquery' ), GIVE_TRIBUTES_VERSION, false );
			wp_enqueue_script( GIVE_TRIBUTES_SLUG );
			wp_localize_script( 'give-tributes', 'give_tributes_admin_message', array(
				'mail_card_notification_success' => __( 'The card mailed notification email was successfully sent.', 'give-tributes' ),
				'mail_card_marked_success'       => __( 'You have successfully mark this card as mailed.', 'give-tributes' ),
				'mail_card_confirm_message'      => __( 'Do you want to mark this card as mailed?', 'give-tributes' ),
				'mail_card_with_notification'    => __( 'Do you want to mark this card as mailed and email the donor a notification?', 'give-tributes' ),
				'mail_card_undo_message'         => __( 'Do you want to unmark this card as sent?', 'give-tributes' ),
				'mail_card_undo_text'            => __( 'Undo', 'give-tributes' ),
				'mail_card_sent_text'            => __( 'Card Sent', 'give-tributes' ),
				'mail_card_undo_success'         => __( 'You have successfully unmarked this card as sent.', 'give-tributes' ),
				'mail_card_mark_as_sent'         => __( 'Mark as Sent', 'give-tributes' ),
				'dismiss_notice_text'            => __( 'Dismiss this notice.', 'give-tributes' ),
				'give_tributes_text_label'       => __( 'Tribute Text', 'give-tributes' ),
				'ecards_resends_confirm_message' => __( 'Are you sure you want to resend the eCard to', 'give-tributes' ),
				'ecards_option_is_not_selected'  => __( 'Please select at least one email.', 'give-tributes' ),
			) );

			// Pass nonce and some string(s) to the admin js script.
			wp_localize_script( 'give-tributes', 'give_tributes_js_data', array(
				'resend_ecards_nonce' => wp_create_nonce( 'resend_ecards_nonce' ),
				'ajax_url'            => admin_url( 'admin-ajax.php' ),
				'ajaxNonce'           => wp_create_nonce( 'give-tributes-secure-ajax' ),
				'ecard_preview_url'   => esc_url( add_query_arg( array(
					'give_action' => 'preview_ecard',
					'preview_id'  => '%payment_id%-%email%',
				), home_url() ) ),
			) );

		}
	}

	/**
	 * Add custom core plugin setting.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $settings Give Settings.
	 *
	 * @return array $settings Give Settings.
	 */
	function add_settings( $settings ) {

		$settings[] = include( GIVE_TRIBUTES_PLUGIN_DIR . '/includes/admin/class-give-tributes-settings.php' );

		return $settings;
	}

	/**
	 * It will list Tribute options repeater.
	 *
	 * @since   1.0.0
	 * @access  public
	 *
	 * @param   array  $value        Pass various value from Setting api array.
	 * @param   string $option_value Option value for button.
	 *
	 * @return void
	 */
	public function group_repeater_callback( $value, $option_value ) {

		// Return if value type is not set.
		if ( ! isset( $value['type'] ) ) {
			return;
		}

		$give_tribute_option_title = ! empty( $value['title'] ) ? $value['title'] : __( 'Tribute Options', 'give-tributes' );
		?>
		<tr valign="top <?php echo esc_attr( $value['id'] ); ?>" <?php echo ! empty( $value['wrapper_class'] ) ? 'class="' . $value['wrapper_class'] . '"' : '' ?>>
			<th><?php echo $give_tribute_option_title; ?></th>
			<td colspan="2">
				<div class="give-tribute-options-wrap">
					<ul class="give-checklist-fields give-tribute-option-list">
						<?php
						$give_tributes_option_text  = give_get_option( 'give_tributes_text' );
						$give_tributes_option_texts = ! empty( $give_tributes_option_text ) ? json_decode( $give_tributes_option_text ) : '';

						if ( empty( $give_tributes_option_texts ) ) {
							foreach ( $value['fields'] as $field_key => $field ) : ?>
								<li <?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>
										id="<?php echo 'give_tribute_text_option_' . $field_key; ?>"
									<?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>>

									<span class="give-drag-handle"><span class="dashicons dashicons-menu"></span></span>
									<div class="titledesc give-tribute-option-title">
										<span for="<?php echo esc_attr( $field['id'] ); ?>"><?php echo( $field['name'] ); ?></span>
									</div>
									<input
											name="<?php echo esc_attr( $field['id'] . '[]' ); ?>"
											id="<?php echo esc_attr( $field['id'] ) . '_' . $field_key; ?>"
											type="text"
											value="In honor of"
											placeholder="In honor of"
											class="give-tribute-input-field"
									/>
									<span class="dashicons dashicons-plus give-tribute-text-add-more"></span>
								</li>

								<?php if ( 0 === $field_key ) {
									$field_key = 1;
									?>
									<li <?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>
											id="<?php echo 'give_tribute_text_option_' . $field_key; ?>"
										<?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>>

										<span class="give-drag-handle"><span class="dashicons dashicons-menu"></span></span>
										<div class="titledesc give-tribute-option-title">
											<span for="<?php echo esc_attr( $field['id'] ); ?>"><?php echo( $field['name'] ); ?></span>
										</div>
										<input
												name="<?php echo esc_attr( $field['id'] . '[]' ); ?>"
												id="<?php echo esc_attr( $field['id'] ) . '_' . $field_key; ?>"
												type="text"
												value="In memory of"
												placeholder="In memory of"
												class="give-tribute-input-field"
										/>
										<span class="dashicons dashicons-trash"></span>
										<span class="dashicons dashicons-plus give-tribute-text-add-more"></span>
									</li>
								<?php } ?>

							<?php endforeach;
						} else {

							foreach ( $give_tributes_option_texts as $text_key => $give_tributes_text ) :

								foreach ( $value['fields'] as $field_key => $field ) : ?>

									<li <?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>
											id="<?php echo 'give_tribute_text_option_' . $text_key; ?>"
										<?php echo ! empty( $field['wrapper_class'] ) ? 'class="' . $field['wrapper_class'] . '"' : '' ?>>

										<span class="give-drag-handle"><span class="dashicons dashicons-menu"></span></span>
										<div class="titledesc give-tribute-option-title">
											<span for="<?php echo esc_attr( $field['id'] ); ?>"><?php echo( $field['name'] ); ?></span>
										</div>
										<input
												name="<?php echo esc_attr( $field['id'] . '[]' ); ?>"
												id="<?php echo esc_attr( $field['id'] ) . '_' . $text_key; ?>"
												type="text"
												value="<?php echo ( 0 === $text_key && empty( $give_tributes_text ) ) ? 'In honor of' : $give_tributes_text; ?>"
												placeholder="<?php echo ( 0 === $text_key ) ? 'In honor of' : ''; ?>"
												class="give-tribute-input-field"
										/>
										<span class="dashicons dashicons-trash"></span>
										<span class="dashicons dashicons-plus give-tribute-text-add-more"></span>
									</li>
									<?php
								endforeach;

							endforeach;
						} // End if().
						?>
					</ul>
				</div>
				<p class="give-field-description"><?php echo $value['description']; ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * It will list Tribute Preview button for Mail a card.
	 *
	 * @since   1.0.0
	 * @access  public
	 *
	 * @param   array  $value        Pass various value from Setting api array.
	 * @param   string $option_value Option value for button.
	 *
	 * @return void
	 */
	public function preview_mail_card_button_callback( $value, $option_value ) {
		?>
		<tr valign="top" <?php echo ! empty( $value['wrapper_class'] ) ? 'class="' . $value['wrapper_class'] . '"' : '' ?>>
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $value['id'] ); ?>"><?php echo $value['title']; ?></label>
			</th>
			<td class="give-forminp">
				<?php give_tributes_mail_card_preview_buttons_callback(); ?>
				<p class="give-field-description"><?php echo $value['desc']; ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * It will list Tribute Preview button for eCard.
	 *
	 * @since   1.0.0
	 * @access  public
	 *
	 * @param   array  $value        Pass various value from Setting api array.
	 * @param   string $option_value Option value for button.
	 *
	 * @return void
	 */
	public function preview_ecard_button_callback( $value, $option_value ) {
		?>
		<tr valign="top" <?php echo ! empty( $value['wrapper_class'] ) ? 'class="' . $value['wrapper_class'] . '"' : '' ?>>
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $value['id'] ); ?>"><?php echo $value['title']; ?></label>
			</th>
			<td class="give-forminp">
				<?php give_tributes_ecard_preview_buttons_callback(); ?>
				<p class="give-field-description"><?php echo $value['desc']; ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 *  Save global Give - Tribute text options.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return bool
	 */
	public function repeater_options_save() {

		// Return if nonce is not set.
		if ( empty( $_REQUEST['_give-save-settings'] ) || ! wp_verify_nonce( $_REQUEST['_give-save-settings'], 'give-save-settings' ) ) {
			return false;
		}

		// Get current section.
		if ( isset( $_GET['tab'] ) ) {
			$current_tab = sanitize_text_field( wp_unslash( $_GET['tab'] ) );
		}

		$current_tab           = ! empty( $current_tab ) ? $current_tab : '';
		$section               = give_get_current_setting_section();
		$give_tributes_section = ! empty( $section ) ? sanitize_text_field( $section ) : 'tributes-settings';

		// Return if Current tab is not tributes.
		if ( empty( $current_tab ) || 'tributes' !== $current_tab ) {
			return false;
		}

		// Return if current section is not give tributes general settings.
		if ( 'tributes-settings' !== $give_tributes_section ) {
			return false;
		}

		$give_tribute_option_texts = array();
		$give_tribute_texts        = isset( $_POST['give_tributes_text'] ) ? $_POST['give_tributes_text'] : array();
		$give_tribute_texts        = array_map( "trim", $give_tribute_texts );

		// Return if submitted donation's form data is empty.
		if ( ! empty( $give_tribute_texts ) && is_array( $give_tribute_texts ) ) {
			foreach ( $give_tribute_texts as $key => $give_tribute_text ) {
				if ( ! empty( $give_tribute_text ) ) {
					$give_tribute_option_texts[ $key ] = give_clean( $give_tribute_text );
				}
			}
		}

		$give_tribute_option_texts = array_intersect_key(
			$give_tribute_option_texts,
			array_unique(
				array_map( "strtolower", $give_tribute_option_texts )
			)
		);

		$give_tribute_option_texts = wp_json_encode( array_values( $give_tribute_option_texts ) );
		give_update_option( 'give_tributes_text', $give_tribute_option_texts );

		return true;
	}

	/**
	 * Register 'Tributes' section on edit donation form page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $settings section array.
	 *
	 * @return array $settings return the tributes sections array.
	 */
	public function metabox_form_data_settings( $settings ) {

		$give_tribute_id = 'give-tributes-metabox-setting-fields';

		// Appending the per form tribute options.
		$settings["{$give_tribute_id}_sub_fields"] = apply_filters( 'give_tributes_per_form_options', array(
			'id'         => "{$give_tribute_id}_sub_fields_general",
			'title'      => __( 'Tributes', 'give-tributes' ),
			'icon-html'  => '<span class="dashicons dashicons-awards"></span>',
			'fields'     => apply_filters( 'give_tributes_general_metabox_fields', array() ),
			'sub-fields' => array(
				array(
					'id'        => "{$give_tribute_id}_sub_fields_mail_card",
					'title'     => __( 'Mail a Card', 'give-tributes' ),
					'icon-html' => '<span class="dashicons dashicons-arrow-right-alt2"></span>',
					'fields'    => apply_filters( 'give_tributes_mail_card_metabox_fields', array() ),
				),
				array(
					'id'        => "{$give_tribute_id}_sub_fields_ecard",
					'title'     => __( 'eCards', 'give-tributes' ),
					'icon-html' => '<span class="dashicons dashicons-arrow-right-alt2"></span>',
					'fields'    => apply_filters( 'give_tributes_ecard_metabox_fields', array() ),
				),
			),
		) );

		return $settings;
	}

	/**
	 * Register Setting fields for 'Tributes' section in donation form edit page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $settings setting fields array.
	 *
	 * @return array
	 */
	public function general_metabox_fields_callback( $settings ) {
		// Fields prefix.
		$prefix = '_give_tributes_per_form_';

		$form_id = isset( $_GET['post'] ) ? $_GET['post'] : '';

		// Settings array for the donation form 'Tributes' section.
		$give_tribute_general_fields = array(

			array(
				'name'          => __( 'Tributes', 'give-tributes' ),
				'desc'          => __( 'This allows you to customize the Tributes settings for just this donation form. You can disable Tributes for just this form as well or simply use the global settings.', 'give-tributes' ),
				'id'            => $prefix . 'enable_disable',
				'wrapper_class' => 'give_tributes_enable_disable',
				'type'          => 'radio_inline',
				'default'       => 'global',
				'options'       => array(
					'global'   => __( 'Global Option', 'give-tributes' ),
					'enabled'  => __( 'Customize', 'give-tributes' ),
					'disabled' => __( 'Disable', 'give-tributes' ),
				),
			),
			array(
				'id'            => "{$prefix}_repeater",
				'name'          => __( 'Tribute Options', 'give-tributes' ),
				'type'          => 'group',
				'description'   => __( 'Add or edit tribute options. For example, "In honor of" or "In memory of".', 'give-tributes' ),
				'wrapper_class' => 'give_tributes_fields',
				'options'       => array(
					'add_button'    => __( 'Add Tribute', 'give-tributes' ),
					'header_title'  => __( 'Tribute', 'give-tributes' ),
					'remove_button' => '<span class="dashicons dashicons-no"></span>',
				),
				'fields'        => array(
					array(
						'name'          => __( 'Tribute Text', 'give-tributes' ),
						'id'            => $prefix . 'give_tributes_text',
						'type'          => 'text',
						'wrapper_class' => 'give_tributes_text',
					),
				),
			),
			array(
				'name'          => __( 'Fieldset Title', 'give-tributes' ),
				'id'            => $prefix . 'fieldset_title',
				'wrapper_class' => 'give_tributes_fields',
				'desc'          => __( 'Customize the text that displays inviting the donor to give a tribute.', 'give-tributes' ),
				'default'       => __( 'Dedicate this Donation', 'give-tributes' ),
				'placeholder'   => __( 'Dedicate this Donation', 'give-tributes' ),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Prepended Label', 'give-tributes' ),
				'desc'          => __( 'This enables the "Tribute Prepended Label" option that allows you to set a prepended label to customize how you address the honoree.', 'give-tributes' ),
				'id'            => $prefix . 'prepended_label_enable_disable',
				'wrapper_class' => 'give_tributes_fields',
				'type'          => 'radio_inline',
				'default'       => 'enabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Tribute Prepended Label', 'give-tributes' ),
				'id'            => $prefix . 'prepended_label',
				'wrapper_class' => 'give_tributes_fields give_tributes_prepended_wrap',
				'desc'          => __( 'This text appears before field labels and input placeholders asking for the honoree\'s information within your donation forms.', 'give-tributes' ),
				'default'       => __( 'Honoree', 'give-tributes' ),
				'placeholder'   => __( 'Honoree', 'give-tributes' ),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Last Name Field', 'give-tributes' ),
				'desc'          => __( 'This option customizes the "Last Name" field requirement for the honoree information.', 'give-tributes' ),
				'id'            => $prefix . 'tributes_honoree_last_name',
				'wrapper_class' => 'give_tributes_fields',
				'type'          => 'radio_inline',
				'options'       => array(
					'required'     => __( 'Required', 'give-tributes' ),
					'not_required' => __( 'Not Required', 'give-tributes' ),
				),
				'default'       => 'not_required',
			),
			array(
				'name'          => __( 'Notify Option', 'give-tributes' ),
				'desc'          => __( 'Control the donor\'s options for notifying the recipient of their tribute donation. Donor Chooses Method: This option will allow the donor to choose how he/she wants the recipient to be notified (most common). Admin Chooses Method: The admin (you) can choose the specific notification method "Mail a Card" or "eCard" without allowing the donor to choose. No Notification: Choose this option if the you don\'t want to provide the donor an option to notify the recipient (this is useful if you plan on handling notifications on your own).', 'give-tributes' ),
				'id'            => $prefix . 'notify_display_option',
				'wrapper_class' => 'give_tributes_fields',
				'type'          => 'radio_inline',
				'default'       => 'donor_choice',
				'options'       => array(
					'donor_choice' => __( 'Donor chooses method', 'give-tributes' ),
					'admin_choice' => __( 'Admin chooses method', 'give-tributes' ),
					'none'         => __( 'No notification', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Notify Method', 'give-tributes' ),
				'desc'          => __( 'Choose the method to notify the recipient of the donation made in tribute. Please ensure the option chosen is enabled.', 'give-tributes' ),
				'id'            => $prefix . 'notify_method',
				'wrapper_class' => 'give_tributes_fields give_tribute_notify_method_lists',
				'type'          => 'select',
				'default'       => 'send_mail_card',
				'options'       => array(
					'send_mail_card' => __( 'Mail a Card', 'give-tributes' ) . ' ' . ( give_is_setting_enabled( give_get_meta( $form_id, '_give_tributes_per_form_mail_a_card_enable_disable', true ) ) ? __( '(enabled)', 'give-tributes' ) : __( '(disabled)', 'give-tributes' ) ),
					'send_eCard'     => __( 'eCard', 'give-tributes' ) . ' ' . ( give_is_setting_enabled( give_get_meta( $form_id, '_give_tributes_per_form_ecards_enable_disable', true ) ) ? __( '(enabled)', 'give-tributes' ) : __( '(disabled)', 'give-tributes' ) ),
				),
			),
			array(
				'name'          => __( 'Tribute Section Location', 'give-tributes' ),
				'desc'          => __( 'Choose option to place tribute section in the location.', 'give-tributes' ),
				'id'            => $prefix . 'section_location',
				'wrapper_class' => 'give_tributes_fields',
				'type'          => 'select',
				'default'       => 'give_payment_mode_top',
				'options'       => array(
					'give_after_donation_levels'              => __( 'Below the donation level fields', 'give-tributes' ),
					'give_after_donation_amount'              => __( 'Below the top donation amount field', 'give-tributes' ),
					'give_payment_mode_top'                   => __( 'Above the payment options', 'give-tributes' ),
					'give_payment_mode_bottom'                => __( 'Below the payment options', 'give-tributes' ),
					'give_donation_form_before_personal_info' => __( 'Above the personal info fields', 'give-tributes' ),
					'give_donation_form_after_personal_info'  => __( 'Below the personal info fields', 'give-tributes' ),
					'give_donation_form_before_cc_form'       => __( 'Above the credit card fields', 'give-tributes' ),
					'give_donation_form_after_cc_form'        => __( 'Below the credit card fields', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Display Style', 'give-tributes' ),
				'desc'          => __( 'Customize the field that displays on the donation forms for the tributes options listed above.', 'give-tributes' ),
				'id'            => $prefix . 'display_style',
				'wrapper_class' => 'give_tributes_fields',
				'type'          => 'radio_inline',
				'default'       => 'radios',
				'options'       => array(
					'radios'   => __( 'Radios', 'give-tributes' ),
					'dropdown' => __( 'Dropdown', 'give-tributes' ),
					'buttons'  => __( 'Buttons', 'give-tributes' ),
				),
			),
			array(
				'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
				'type'  => 'docs_link',
				'url'   => 'http://docs.givewp.com/#',
				'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
			),
		);

		return array_merge( $settings, $give_tribute_general_fields );

	}

	/**
	 * Register Setting fields for 'Mail a card' section in donation form edit page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $settings setting fields array.
	 *
	 * @return array
	 */
	public function mail_card_metabox_fields_callback( $settings ) {
		// Fields prefix.
		$prefix = '_give_tributes_per_form_';

		// Settings array for the donation form 'Mail a Card' section.
		$give_tribute_mail_card_fields = array(
			array(
				'name'          => __( 'Mail a Card', 'give-tributes' ),
				'desc'          => __( 'Enable this feature if you would like to physically mail cards for tributes. This will enable an additional address fieldset within the donation form and a custom report for you to manage your mailed cards.', 'give-tributes' ),
				'id'            => $prefix . 'mail_a_card_enable_disable',
				'wrapper_class' => 'give_tributes_mail_a_card_enable_disable',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Custom  Message', 'give-tributes' ),
				'desc'          => __( 'Enable if you would like the donor to be able to provide a custom message for the mailed card.', 'give-tributes' ),
				'id'            => $prefix . 'custom_message_enable_disable',
				'wrapper_class' => 'give_tributes_custom_message_enable_disable mail_a_card_wrapper',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Who Sends the Card?', 'give-tributes' ),
				'desc'          => __( 'If you plan on mailing the cards yourself use "The Admin" option. If you would to donors to send the card themselves then select "The Donor". This will provide donors the ability to print and mail the card themselves.', 'give-tributes' ),
				'id'            => $prefix . 'who_sends_the_card',
				'wrapper_class' => 'give_tributes_who_sends_the_card mail_a_card_wrapper',
				'type'          => 'radio_inline',
				'default'       => 'the_admin',
				'options'       => array(
					'the_admin' => __( 'The Admin', 'give-tributes' ),
					'the_donor' => __( 'The Donor', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Message Length', 'give-tributes' ),
				'desc'          => __( 'Adjusts the number of allowed characters for the tributes message.', 'give-tributes' ),
				'id'            => $prefix . 'message_length',
				'wrapper_class' => 'give_tributes_message_length mail_a_card_wrapper',
				'type'          => 'give_tributes_number',
				'css'           => 'width:12em;',
				'default'       => 255,
				'callback'      => array( $this, 'number_call_back' ),
			),
			array(
				'name'          => __( 'Card Creation', 'give-tributes' ),
				'desc'          => __( 'Enable if you would like to generate a PDF card that can be easily printed and mailed.', 'give-tributes' ),
				'id'            => $prefix . 'card_creation_enable_disable',
				'wrapper_class' => 'give_tribute_donor_mailed mail_a_card_wrapper',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Card Layout', 'give-tributes' ),
				'desc'          => __( 'Choose a card layout option.', 'give-tributes' ),
				'id'            => $prefix . 'card_layout',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'select',
				'default'       => 'L',
				'options'       => array(
					'L' => __( 'Portrait Card', 'give-tributes' ),
					'P' => __( 'Landscape Card', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Card Sizes', 'give-tributes' ),
				'desc'          => __( 'Select which size of cards you would like generated.', 'give-tributes' ),
				'id'            => $prefix . 'card_sizes',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'multicheck',
				'default'       => array(
					'letter',
				),
				'options'       => array(
					'letter' => 'Letter (8.5 by 11 inches)',
					'a4'     => 'A4 (8.27 by 11.69 inches)',
					'a5'     => 'A5 (5.8 by 8.3 inches)',
					'a6'     => 'A6 (4.1 by 5.8 inches)',
				),
				'callback'      => array( $this, 'multicheck_call_back' ),
			),
			array(
				'name'          => __( 'Card Font', 'give-tributes' ),
				'desc'          => __( 'Choose a card font option for the Mail a Card content.', 'give-tributes' ),
				'id'            => $prefix . 'card_font',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'select',
				'default'       => 'helvetica',
				'options'       => array(
					'courier'   => __( 'Courier', 'give-tributes' ),
					'helvetica' => __( 'Helvetica', 'give-tributes' ),
					'times'     => __( 'Times New Roman', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Last Name Field', 'give-tributes' ),
				'desc'          => __( 'This option customizes the "Last Name" field requirement for the honoree information.', 'give-tributes' ),
				'id'            => $prefix . 'mail_card_last_name',
				'wrapper_class' => 'mail_a_card_wrapper give_tributes_card_creation_fields give_tribute_admin_mailed',
				'type'          => 'radio_inline',
				'options'       => array(
					'required'     => __( 'Required', 'give-tributes' ),
					'not_required' => __( 'Not Required', 'give-tributes' ),
				),
				'default'       => 'not_required',
			),
			array(
				'name'          => __( 'Special Characters', 'give-tributes' ),
				'id'            => $prefix . 'special_chars',
				'description'   => __( 'Characters not displaying correctly? Check to enable the DejaVu Sans font replacing Courier/Helvetica/Times New Roman. Enable this option if you have characters which do not display correctly (e.g. Greek characters, Japanese, Mandarin, etc.)', 'give-tributes' ),
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => 'Enabled',
					'disabled' => 'Disabled',
				),
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
			),
			array(
				'name'          => __( 'Card Graphic', 'give-tributes' ),
				'desc'          => __( 'Upload a graphic to display as the main card image.', 'give-tributes' ),
				'id'            => $prefix . 'card_graphic',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'media',
			),
			array(
				'name'          => __( 'Preview Card', 'give-tributes' ),
				'desc'          => __( 'Click to preview the card.', 'give-tributes' ),
				'id'            => $prefix . 'preview_mail_card_button',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'give_tributes_preview_mail_card_button',
				'callback'      => array( $this, 'preview_mail_card_button_metabox_callback' ),
			),
			array(
				'name'          => __( 'Card Content', 'give-tributes' ),
				'id'            => $prefix . 'card_content',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'desc'          => sprintf( /* translators: %s: emails tags list */
					__( 'Enter Content for the mailable card that is provided in addition to the donor\'s message if enabled. <br />Images and HTML are accepted.<br /><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br/>' . give_tribute_get_tag_list() ),
				'type'          => 'wysiwyg',
				'default'       => give_tributes_get_mail_card_default_content(),
			),
			array(
				'name'          => __( 'Card Back Graphic', 'give-tributes' ),
				'desc'          => __( 'Upload a graphic to display on the back of the card.', 'give-tributes' ),
				'id'            => $prefix . 'logo_graphic',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'type'          => 'media',
			),
			array(
				'name'          => __( 'Card Back Text', 'give-tributes' ),
				'desc'          => __( 'Customize the content that appears on the back of the card.', 'give-tributes' ),
				'id'            => $prefix . 'card_footer_text',
				'wrapper_class' => 'give_tributes_card_creation_fields mail_a_card_wrapper give_tribute_admin_mailed',
				'default'       => give_tributes_get_mail_card_default_back_text(),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Receipt Content', 'give-tributes' ),
				'id'            => $prefix . 'receipt_content_for_admin',
				'wrapper_class' => 'mail_a_card_wrapper give_tribute_admin_mailed',
				'desc'          => sprintf( /* translators: %s: emails tags list */
					__( 'This content will appear on the donation receipt page above the receipt.<br /> Images and HTML are accepted.<br /><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br/>' . give_tribute_get_tag_list() ),
				'type'          => 'wysiwyg',
				'default'       => give_tributes_default_mail_card_receipt_content( 'admin' ),
			),
			array(
				'name'          => __( 'Receipt Content', 'give-tributes' ),
				'id'            => $prefix . 'receipt_content_for_donor',
				'wrapper_class' => 'mail_a_card_wrapper give_tributes_card_creation_fields give_tribute_donor_mailed',
				'desc'          => sprintf( /* translators: %s: emails tags list */
					__( 'This content will appear on the donation receipt page above the receipt.<br /> Images and HTML are accepted.<br /><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br/>' . give_tribute_get_tag_list() ),
				'type'          => 'wysiwyg',
				'default'       => give_tributes_default_mail_card_receipt_content( 'donor' ),
			),
			array(
				'name'          => __( 'Card Mailed Email', 'give-tributes' ),
				'desc'          => __( 'Enable if you would like to email your donors when a card has been marked as sent.', 'give-tributes' ),
				'id'            => $prefix . 'card_mailed_email_enable_disable',
				'wrapper_class' => 'give_tribute_admin_mailed mail_a_card_wrapper',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Card Sent Email Subject', 'give-tributes' ),
				'desc'          => __( 'Enter the subject line for the card sent receipt email.', 'give-tributes' ),
				'id'            => $prefix . 'card_sent_email_subject',
				'wrapper_class' => 'give_tribute_admin_mailed card_mailed_email_fields mail_a_card_wrapper',
				'default'       => __( 'Card Sent Receipt', 'give-tributes' ),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Card Sent Email Heading', 'give-tributes' ),
				'desc'          => __( 'Enter the email heading for the card sent notification email.', 'give-tributes' ),
				'id'            => $prefix . 'card_sent_email_heading',
				'wrapper_class' => 'give_tribute_admin_mailed card_mailed_email_fields mail_a_card_wrapper',
				'default'       => __( 'Tribute Card Mailed', 'give-tributes' ),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Card Sent Email Body', 'give-tributes' ),
				'id'            => $prefix . 'give_tributes_card_sent_body',
				'wrapper_class' => 'give_tribute_admin_mailed card_mailed_email_fields mail_a_card_wrapper',
				'desc'          => sprintf( /* translators: %s: emails tags list */
					__( 'Enter the Content for the Card Sent Email Body.<br /> Images and HTML are accepted.<br /><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br/>' . give_tribute_get_tag_list() ),
				'type'          => 'wysiwyg',
				'default'       => give_tributes_get_mail_card_sent_notification_content(),
			),
			array(
				'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
				'type'  => 'docs_link',
				'url'   => 'http://docs.givewp.com/#',
				'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
			),
		);

		return array_merge( $settings, $give_tribute_mail_card_fields );

	}

	/**
	 * Register Setting fields for 'eCards' section in donation form edit page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $settings setting fields array.
	 *
	 * @return array
	 */
	public function ecard_metabox_fields_callback( $settings ) {
		// Fields prefix.
		$prefix = '_give_tributes_per_form_';

		// Settings array for the donation form 'eCards' section.
		$give_tribute_ecard_fields = array(
			array(
				'name'          => __( 'eCards', 'give-tributes' ),
				'desc'          => __( 'Enable eCards for when a donor gives with a tribute.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_enable_disable',
				'wrapper_class' => 'give_tributes_ecards_enable_disable',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Custom  Message', 'give-tributes' ),
				'desc'          => __( 'Enable if you would like the donor to be able to provide a custom message within the eCard.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_custom_message_enable_disable',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Message Length', 'give-tributes' ),
				'desc'          => __( 'Adjusts the number of allowed characters for the tributes message.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_message_length',
				'wrapper_class' => 'give_tributes_ecards_message_length give_tributes_ecard_fields',
				'type'          => 'give_tributes_number',
				'css'           => 'width:12em;',
				'default'       => 255,
				'callback'      => array( $this, 'number_call_back' ),
			),
			array(
				'name'          => __( 'eCard Email Subject', 'give-tributes' ),
				'id'            => $prefix . 'ecards_email_subject',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'desc'          => __( 'Enter the subject line for the eCard email. The template tags found below will work in this field.', 'give-tributes' ),
				'default'       => give_tributes_get_default_ecard_subject(),
				'placeholder'   => give_tributes_get_default_ecard_subject(),
				'type'          => 'text',
			),
			array(
				'name'          => __( 'Multiple eCard Recipients', 'give-tributes' ),
				'desc'          => __( 'Allow your donors to provide multiple notification names and emails for their dedicated donation. This will send a dedication email to each notification recipient the donor provides.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_multiple_recipients',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'radio_inline',
				'default'       => 'disabled',
				'options'       => array(
					'enabled'  => __( 'Enabled', 'give-tributes' ),
					'disabled' => __( 'Disabled', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Last Name Field', 'give-tributes' ),
				'desc'          => __( 'This option customizes the "Last Name" field requirement for the card recipient.', 'give-tributes' ),
				'id'            => $prefix . 'ecard_last_name',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'radio_inline',
				'default'       => 'not_required',
				'options'       => array(
					'required'     => __( 'Required', 'give-tributes' ),
					'not_required' => __( 'Not Required', 'give-tributes' ),
				),
			),
			array(
				'name'          => __( 'Logo Graphic', 'give-tributes' ),
				'desc'          => __( 'Upload a graphic to display at the top of the eCard.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_logo_graphic',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'media',
			),
			array(
				'name'          => __( 'eCard Header Graphic', 'give-tributes' ),
				'desc'          => __( 'Upload a graphic to display at the top of the eCard.', 'give-tributes' ),
				'id'            => $prefix . 'ecards_card_graphic',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'media',
			),
			array(
				'name'          => __( 'eCard Content', 'give-tributes' ),
				'id'            => $prefix . 'ecards_content',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'desc'          => sprintf( /* translators: %s: emails tags list */
					__( 'Enter Content for the eCard that is provided in addition to the donor\'s message if enabled. <br />Images and HTML are accepted. <br /><strong>Available template tags:</strong> %s', 'give-tributes' ), '<br/>' . give_tribute_get_tag_list() ),
				'type'          => 'wysiwyg',
				'default'       => give_tributes_get_ecard_default_content(),
			),
			array(
				'name'          => __( 'Preview eCard', 'give-tributes' ),
				'desc'          => __( 'Click the buttons to preview eCard and send eCard.', 'give-tributes' ),
				'id'            => $prefix . 'preview_ecard_button',
				'wrapper_class' => 'give_tributes_ecard_fields',
				'type'          => 'give_tributes_preview_ecard_button',
				'callback'      => array( $this, 'preview_ecard_button_metabox_callback' ),
			),
			array(
				'name'  => __( 'Give - Tributes Settings Docs Link', 'give-tributes' ),
				'type'  => 'docs_link',
				'url'   => 'http://docs.givewp.com/#',
				'title' => __( 'Give - Tributes Settings', 'give-tributes' ),
			),
		);

		return array_merge( $settings, $give_tribute_ecard_fields );

	}

	/**
	 * Callback function of "Preview Mail Card".
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $field fields data.
	 */
	public function preview_mail_card_button_metabox_callback( $field ) {

		global $thepostid, $post;

		// Get the Donation form id.
		$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;

		// Get the styles if passed with the field array.
		$field['style']         = isset( $field['style'] ) ? $field['style'] : '';
		$field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';

		// Get the option value by field and donation form id.
		$field['value'] = give_get_field_value( $field, $thepostid );

		// Generate name for option field.
		$field['name'] = isset( $field['name'] ) ? $field['name'] : $field['id'];

		?>
		<p class="give-field-wrap <?php echo esc_attr( $field['id'] ); ?>_field <?php echo esc_attr( $field['wrapper_class'] ); ?>">
			<label for="<?php echo give_get_field_name( $field ); ?>"><?php echo wp_kses_post( $field['name'] ); ?></label>
			<?php give_tributes_mail_card_preview_buttons_callback( $thepostid );
			echo give_get_field_description( $field );
			?>
		</p>
		<?php

	}

	/**
	 * Callback function of "Preview eCard".
	 *
	 * @since 1.0.0
	 *
	 * @param array $field fields data.
	 */
	public function preview_ecard_button_metabox_callback( $field ) {

		global $thepostid, $post;

		// Get the Donation form id.
		$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;

		// Get the styles if passed with the field array.
		$field['style']         = isset( $field['style'] ) ? $field['style'] : '';
		$field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';

		// Get the option value by field and donation form id.
		$field['value'] = give_get_field_value( $field, $thepostid );

		// Generate name for option field.
		$field['name'] = isset( $field['name'] ) ? $field['name'] : $field['id'];

		?>
		<p class="give-field-wrap <?php echo esc_attr( $field['id'] ); ?>_field <?php echo esc_attr( $field['wrapper_class'] ); ?>">
			<label for="<?php echo give_get_field_name( $field ); ?>"><?php echo wp_kses_post( $field['name'] ); ?></label>
			<?php give_tributes_ecard_preview_buttons_callback( $thepostid );
			echo give_get_field_description( $field );
			?>
		</p>
		<?php

	}

	/**
	 * Callback function of "Number".
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $field fields data.
	 */
	public function number_call_back( $field ) {

		global $thepostid, $post;

		// Get the Donation form id.
		$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;

		// Get the styles if passed with the field array.
		$field['style']         = isset( $field['style'] ) ? $field['style'] : '';
		$field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';

		// Get the option value by field and donation form id.
		$field['value'] = give_get_field_value( $field, $thepostid );

		// Generate name for option field.
		$field['name'] = isset( $field['name'] ) ? $field['name'] : $field['id'];

		?>
		<p class="give-field-wrap <?php echo esc_attr( $field['id'] ); ?>_field <?php echo esc_attr( $field['wrapper_class'] ); ?>">
			<label for="<?php echo give_get_field_name( $field ); ?>"><?php echo wp_kses_post( $field['name'] ); ?></label>
			<input type="number" style="<?php echo esc_attr( $field['style'] ); ?>"
			       name="<?php echo give_get_field_name( $field ); ?>"
			       id="<?php echo esc_attr( $field['id'] ); ?>"
			       value="<?php echo esc_attr( $field['value'] ); ?>" <?php echo give_get_custom_attributes( $field ); ?>/>
			<?php echo give_get_field_description( $field ); ?>
		</p>
		<?php

	}

	/**
	 * Callback function of "Metabox Multicheck".
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $field fields data.
	 */
	public function multicheck_call_back( $field ) {

		global $thepostid, $post;

		// Get the Donation form id.
		$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;

		// Get the styles if passed with the field array.
		$field['style']         = isset( $field['style'] ) ? $field['style'] : '';
		$field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';

		// Get the option value by field and donation form id.
		$field_value = give_get_field_value( $field, $thepostid );
		$field_value = ! empty( $field_value ) ? $field_value : array();

		// Generate name for option field.
		$field['name'] = isset( $field['name'] ) ? $field['name'] : $field['id'];

		echo '<fieldset class="give-field-wrap ' . esc_attr( $field['id'] ) . '_field ' . esc_attr( $field['wrapper_class'] ) . '"><span class="give-field-label">' . wp_kses_post( $field['name'] ) . '</span><legend class="screen-reader-text">' . wp_kses_post( $field['name'] ) . '</legend><ul class="give-tributes-multicheck">';
		foreach ( $field['options'] as $key => $value ) {
			$give_tribute_checked = '';
			if ( in_array( $key, $field_value, true ) ) {
				$give_tribute_checked = 'checked="checked"';
			}
			echo '<li><label><input
				name="' . esc_attr( $field['id'] ) . '[]"
				value="' . esc_attr( $key ) . '"
				type="checkbox"
				' . $give_tribute_checked . '
				/> ' . esc_html( $value ) . '</label>
		</li>';
		}
		echo '</ul>';

		echo give_get_field_description( $field );
		echo '</fieldset>';
	}

	/**
	 * Include Tribute report on admin settings.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $settings Settings array.
	 *
	 * @return array Settings.
	 */
	public function report_page( $settings ) {
		// Tributes.
		$settings[] = include( GIVE_TRIBUTES_PLUGIN_DIR . '/includes/admin/class-give-tributes-reports.php' );

		// Output.
		return $settings;
	}

	/**
	 * Renders the Reports Mail a Card Table.
	 *
	 * @since 1.0.0
	 *
	 * @uses  Give_Donor_Reports_Table::prepare_items()
	 * @uses  Give_Donor_Reports_Table::display()
	 *
	 * @return void
	 */
	function mail_card_reports_view() {
		include( GIVE_TRIBUTES_PLUGIN_DIR . '/includes/admin/class-give-tributes-mailcard-reports-table.php' );

		$give_table = new Give_Tributes_MailCard_Reports_Table();
		$give_table->prepare_items();
		$wp_rand = wp_rand( 1000, 10000 );
		update_option( 'give-tributes-check', $wp_rand );
		?>
		<div class="wrap give-reports-tributes-wrap">
			<?php
			/**
			 * Fires before the Mail a Card Report From.
			 *
			 * @since 1.0.0
			 */
			do_action( 'give_tributes_mail_card_report_table_top' );
			?>
			<form id="give-tributes-filter" method="get">
				<?php
				$give_table->display();
				?>
				<input type="hidden" name="post_type" value="give_forms"/>
				<input type="hidden" name="page" value="give-reports"/>
				<input type="hidden" name="tab" value="tributes"/>
				<input type="hidden" name="section" value="give-tributes-mail-card"/>
				<input type="hidden" name="check" value="<?php echo $wp_rand; ?>"/>
			</form>
			<?php

			/**
			 * Fires after the Mail a Card Report From.
			 *
			 * @since 1.0.0
			 */
			do_action( 'give_tributes_mail_card_report_table_bottom' );
			?>
		</div>
		<?php
	}

	/**
	 * Renders the Reports Tribute Donations Table.
	 *
	 * @since 1.0.0
	 *
	 * @uses  Give_Donor_Reports_Table::prepare_items()
	 * @uses  Give_Donor_Reports_Table::display()
	 *
	 * @return void
	 */
	function donations_reports_view() {
		include( GIVE_TRIBUTES_PLUGIN_DIR . '/includes/admin/class-give-tributes-donations-reports-table.php' );

		$give_table = new Give_Tributes_Donations_Reports_Table();
		$give_table->prepare_items();
		?>
		<div class="wrap give-reports-tributes-wrap">
			<?php
			/**
			 * Fires before the Tribute Donations Report From.
			 *
			 * @since 1.0.0
			 */
			do_action( 'give_tributes_donations_report_table_top' );
			?>
			<form id="give-tributes-filter" method="get">
				<?php
				$give_table->display();
				?>
				<input type="hidden" name="post_type" value="give_forms" />
				<input type="hidden" name="page" value="give-reports" />
				<input type="hidden" name="tab" value="tributes" />
				<input type="hidden" name="section" value="give-tributes-donations" />
			</form>
			<?php
			/**
			 * Fires after the Tribute Donations Report From.
			 *
			 * @since 1.0.0
			 */
			do_action( 'give_tributes_donations_report_table_bottom' );
			?>
		</div>
		<?php
	}

	/**
	 * Renders the Reports eCard Table.
	 *
	 * @since 1.0
	 * @uses  Give_Donor_Reports_Table::prepare_items()
	 * @uses  Give_Donor_Reports_Table::display()
	 * @return void
	 */
	function ecard_reports_view() {
		include( GIVE_TRIBUTES_PLUGIN_DIR . '/includes/admin/class-give-tributes-ecard-reports-table.php' );

		$give_table = new Give_Tributes_ECard_Reports_Table();
		$give_table->prepare_items();
		?>
		<div class="wrap give-reports-tributes-wrap">
			<?php
			/**
			 * Fires before the eCard Report From.
			 *
			 * @since 1.0.0
			 */
			do_action( 'give_tributes_ecard_report_table_top' );
			?>
			<form id="give-tributes-filter" method="get">
				<?php
				$give_table->display();
				?>
				<input type="hidden" name="post_type" value="give_forms" />
				<input type="hidden" name="page" value="give-reports" />
				<input type="hidden" name="tab" value="tributes" />
				<input type="hidden" name="section" value="give-tributes-ecard" />
			</form>
			<?php
			/**
			 * Fires after the eCard Report From.
			 *
			 * @since 1.0
			 */
			do_action( 'give_tributes_ecard_report_table_bottom' );
			?>
		</div>
		<?php
	}

	/**
	 * Displays the eCard email preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function ecard_display_email_template_preview() {

		if ( empty( $_GET['give_action'] ) ) {
			return;
		}

		if ( 'preview_ecard' !== $_GET['give_action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_give_settings' ) ) {
			return;
		}

		$payment_id = (int) isset( $_GET['preview_id'] ) ? $_GET['preview_id'] : 0;
		$form_id    = (int) isset( $_GET['form_id'] ) ? $_GET['form_id'] : 0;

		if ( ! empty( $payment_id ) && empty( $form_id ) ) {
			$form_id = give_get_payment_form_id( $payment_id );
		}

		// If payment id contains email inside it, then get it.
		$query_fragments = give_tributes_preview_ecard_fragments( $payment_id );

		// eCard Preview email header.
		echo give_tributes_preview_email_header();
		// Echo the email content.
		echo give_tribute_ecard_build_email( $query_fragments['payment_id'], $form_id, $query_fragments['email'] );

		exit;
	}

	/**
	 * Include Card Sent Notification Email Template.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id Payment ID.
	 */
	public function mail_card_notification_template( $payment_id ) {
		require( GIVE_TRIBUTES_PLUGIN_DIR . '/templates/mailCard/notification/notification.php' );
	}

	/**
	 * Trigger the sending of a Global Test eCard Email receipt.
	 *
	 * @since 1.0.0
	 *
	 * @param array $data Parameters sent from Settings page
	 *
	 * @return void
	 */
	public function global_send_test_ecard_email_receipt( $data ) {

		// Send a test eCard email for Global settings.
		give_tributes_ecard_email_receipt( $payment_id = 0, $data['form_id'] );

		// Remove the test email query arg.
		wp_redirect( remove_query_arg( 'give_action' ) );

		exit;

	}

	/**
	 * Resend eCard Email receipt.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function resend_ecard_email_receipt() {

		if ( empty( $_GET['give_action'] ) ) {
			return;
		}

		if ( 'resend_ecard' !== $_GET['give_action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_give_settings' ) ) {
			return;
		}

		if ( empty( $_GET['preview_id'] ) ) {
			return;
		}

		$payment_id = (int) isset( $_GET['preview_id'] ) ? $_GET['preview_id'] : 0;

		// Resend eCard email receipt.
		give_tributes_ecard_email_receipt( $payment_id );

		$give_tribute_message = '';
		if ( in_array( 'resent-ecard', give_get_admin_messages_key() ) ) {
			$give_tribute_message .= '&give-messages[]=resent-ecard';
		}

		// Get previous page slug.
		$email_sent_from = give_check_variable( $_GET['ecard_sent_from'], 'isset_empty' );

		if ( 'give-reports' === $email_sent_from ) {
			wp_redirect( admin_url( 'edit.php?post_type=give_forms&page=give-reports&tab=tributes&section=give-tributes-ecard' . $give_tribute_message ) );
		} else {
			wp_redirect( add_query_arg( 'id', $payment_id, admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details' . $give_tribute_message ) ) );
		}

		exit;
	}

	/**
	 * Displays the global Mail a Card preview.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function mail_card_preview() {

		if ( empty( $_GET['give_action'] ) ) {
			return;
		}

		if ( 'preview_mail_card' !== $_GET['give_action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_give_settings' ) ) {
			return;
		}

		// Get Payment ID.
		$payment_id = (int) isset( $_GET['preview_id'] ) ? $_GET['preview_id'] : 0;
		$form_id    = give_get_payment_form_id( $payment_id );

		// Per form customized?
		if ( give_tributes_is_per_form_customized( $form_id ) ) {
			$give_tributes_who_sends_the_card = give_get_meta( $form_id, '_give_tributes_per_form_who_sends_the_card', true );
			$give_tributes_card_creation      = give_get_meta( $form_id, '_give_tributes_per_form_card_creation_enable_disable', true );
		} else {
			$give_tributes_who_sends_the_card = give_get_option( 'give_tributes_who_sends_the_card' );
			$give_tributes_card_creation      = give_get_option( 'give_tributes_card_creation_enable_disable' );
		}


		if ( 'the_admin' !== $give_tributes_who_sends_the_card ) {
			$give_tributes_card_creation = ! empty( $give_tributes_card_creation ) ? $give_tributes_card_creation : '';

			// If Card creation disable then show global preview option for that donation.
			if ( empty( $give_tributes_card_creation ) || 'disabled' === $give_tributes_card_creation ) {
				$payment_id = 0;
			}
		}

		// Generate Mail a Card PDF.
		give_tributes_mail_card_pdf_generate( $payment_id, false );

		exit;
	}

	/**
	 * Ajax Call to set Mail a Card sent from the Report.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function sent_mail_card() {

		// Bailout, if this function is not triggered via AJAX.
		if ( ! check_ajax_referer( 'give-tributes-secure-ajax', 'security' ) ) {
			return;
		}

		// Bailout, if logged in user does not have proper access.
		if ( ! current_user_can( 'edit_give_payments' ) ) {
			return;
		}

		$payment_id = (int) ! empty( $_POST['payment_id'] ) ? absint( $_POST['payment_id'] ) : 0;
		$card_sent  = give_clean( $_POST['card_sent'] );
		$post_type  = get_post_type( $payment_id );

		// Bailout, if incorrect post type is used to send mail card.
		if ( 'give_payment' !== $post_type ) {
			return;
		}

		if ( 'true' === $card_sent ) {
			// Update Give - Tributes Mail a Card sent.
			if ( ! empty( $payment_id ) ) {
				give_update_payment_meta( $payment_id, '_give_tributes_card_sent', 'sent_card' );
			}

			// Card Sent Notification Email.
			give_tributes_mail_card_notification( $payment_id );
			echo 'card_sent_success';

		} else {
			// Update Give - Tributes Mail a Card sent.
			if ( ! empty( $payment_id ) ) {
				give_update_payment_meta( $payment_id, '_give_tributes_card_sent', 'sent_card' );
			}
			echo 'card_sent_failed';
		}

		give_die();
	}


	/**
	 * Ajax Call to undo Mail a Card sent from the Report.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function undo_sent_mail_card() {

		// Bailout, if this function is not triggered via AJAX.
		if ( ! check_admin_referer( 'give-tributes-secure-ajax', 'security' ) ) {
			return;
		}

		// Bailout, if logged in user does not have proper access.
		if ( ! current_user_can( 'edit_give_payments' ) ) {
			return;
		}

		$payment_id = (int) ! empty( $_POST['payment_id'] ) ? absint( $_POST['payment_id'] ) : 0;
		$post_type  = get_post_type( $payment_id );

		// Bailout, if incorrect post type is used undo the send mail card status.
		if ( 'give_payment' !== $post_type ) {
			return;
		}

		// Delete Give - Tributes Mail a Card sent.
		if ( ! empty( $payment_id ) ) {
			give_delete_meta( $payment_id, '_give_tributes_card_sent' );
		}// End if().

		give_die();
	}

	/**
	 * Download Card from Card sent notification receipt.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function download_card() {

		if ( empty( $_GET['give_action'] ) ) {
			return;
		}

		if ( 'download_card' !== $_GET['give_action'] ) {
			return;
		}

		if ( empty( $_GET['purchase_key'] ) ) {
			return;
		}

		if ( empty( $_GET['payment_id'] ) ) {
			return;
		}

		// Get Payment ID.
		$payment_id = (int) isset( $_GET['payment_id'] ) ? $_GET['payment_id'] : 0;

		// Bail out if Payment purchase key does not match.
		if ( $_GET['purchase_key'] != give_get_payment_key( $payment_id ) ) {
			return;
		}

		// Generate Mail a Card for Download.
		give_tributes_mail_card_pdf_generate( $payment_id, true );

		exit;
	}

	/**
	 * Show Tributes information on the donation details page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param int $payment_id Donation ID.
	 */
	public function tribute_payment_metabox( $payment_id ) {

		$payment = new Give_Payment( $payment_id );
		$form_id = $payment->form_id;

		$gave_in_tribute = give_get_meta( $payment_id, '_give_tributes_accept', true );
		$gave_in_tribute = ! empty( $gave_in_tribute ) ? $gave_in_tribute : 'no';
		$ecard_or_mailed = give_get_meta( $payment_id, '_give_tributes_would_to', true );
		$ecard_or_mailed = ! empty( $ecard_or_mailed ) ? $ecard_or_mailed : 'none';

		$honoree_first_name = give_get_meta( $payment_id, '_give_tributes_first_name', true );
		$honoree_last_name  = give_get_meta( $payment_id, '_give_tributes_last_name', true );

		// Prepare Honoree Full name.
		if ( ! empty( $honoree_first_name ) || ! empty( $honoree_last_name ) ) {
			$honoree_full_name = $honoree_first_name . ' ' . $honoree_last_name;
		} else {
			$honoree_full_name = '';
		}

		// Tribute type.
		$type = give_get_meta( $payment_id, '_give_tributes_type', true );
		$type = ! empty( $type ) ? ucfirst( $type ) : __( 'In honor of', 'give-tributes' );

		/* Mail a card Fields value start. */

		$mail_card_notify_first_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_first_name', true );
		$mail_card_notify_first_name = ! empty( $mail_card_notify_first_name ) ? ucfirst( $mail_card_notify_first_name ) : '';

		$mail_card_notify_last_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_last_name', true );
		$mail_card_notify_last_name = ! empty( $mail_card_notify_last_name ) ? ucfirst( $mail_card_notify_last_name ) : '';

		// Mail a Card notify Full name.
		if ( ! empty( $mail_card_notify_first_name ) || ! empty( $mail_card_notify_last_name ) ) {
			$mail_card_notify_full_name = $mail_card_notify_first_name . ' ' . $mail_card_notify_last_name;
		} else {
			$mail_card_notify_full_name = '';
		}

		// Mail a Card Notification message.
		$mail_card_personalized_message = give_get_meta( $payment_id, '_give_tributes_mail_card_personalized_message', true );
		$mail_card_personalized_message = ! empty( $mail_card_personalized_message ) ? $mail_card_personalized_message : __( 'None provided', 'give-tributes' );

		// Honoree Full address.
		$notification_full_address = give_tributes_notification_address( $payment_id, false );

		// Get Card creation enable/disabled.
		$card_creation = is_card_creation_enable( $payment_id );

		// Card Option.
		if ( give_is_setting_enabled( $card_creation ) ) {
			$card_option = sprintf(
				'<a target="_blank" id="%1$s" class="give_tributes_print_card" href="%2$s">%3$s</a>',
				$payment_id,
				esc_url( add_query_arg( array(
					'give_action' => 'preview_mail_card',
					'preview_id'  => $payment_id,
				), home_url() ) ),
				__( 'Print Card', 'give-tributes' )
			);
		} else {
			$card_option = __( 'Disabled', 'give-tributes' );
		}

		// Card Sent.
		if ( give_is_setting_enabled( $card_creation ) ) {

			if ( give_tributes_is_per_form_customized( $form_id ) ) {
				$card_mailed_notice = give_get_meta( $form_id, '_give_tributes_per_form_card_mailed_email_enable_disable', true );
			} else {
				$card_mailed_notice = give_get_option( 'give_tributes_card_mailed_email_enable_disable', 'disabled' );
			}

			$card_mailed_class = ( give_is_setting_enabled( $card_mailed_notice ) ) ? 'card_mailed_enabled' : 'card_mailed_disabled';

			$card_sent = give_get_meta( $payment_id, '_give_tributes_card_sent', true );

			$card_sent_output = '<span class="give-tributes-card-sent-wrap">';

			if ( empty( $card_sent ) || 'sent_card' !== $card_sent ) {
				$card_sent_output .= sprintf(
					/** translators: 1. CSS Classes 2. Donation ID 3. Button Text */
					'<a href="javascript:void(0);" class="%1$s" id="%2$s"><span class="dashicons dashicons-email-alt" style="padding-top:3px;"></span>%3$s</a>',
					"button button-small give-admin-button give_tribute_card_sent card_sent_{$payment_id} {$card_mailed_class}",
					$payment_id,
					__( 'Mark as Sent', 'give-tributes' )
				);
			} else {
				$card_sent_output .= sprintf(
					'<span class="card-sent-text-wrap">%1$s - </span><a href="javascript:void(0);" class="%2$s" id="%3$s">%4$s</a>',
					__( 'Card Sent', 'give-tributes' ),
					"give_tribute_card_sent_undo card_sent_undo_{$payment_id} {$card_mailed_class}",
					$payment_id,
					__( 'Undo', 'give-tributes' )
				);
			}
			$card_sent_output .= '</span>';


		} else {
			$card_sent_output = 'n/a';
		}

		/* Mail a card Fields value end. */

		// eCard Email sent date.
		$give_ecard_email_sent_date = give_get_meta( $payment_id, '_give_tributes_ecard_email_sent_date', true );
		$give_ecard_email_sent_date = ! empty( $give_ecard_email_sent_date ) ? $give_ecard_email_sent_date : $payment->date;

		// eCard Options.
		$ecard_options = give_tributes_prepare_ecard_actions( $payment_id );

		/* eCard Fields value end. */

		if ( 'no' !== $gave_in_tribute ) : ?>
			<div id="give-tributes-details" class="postbox">
				<h3 class="hndle"><?php _e( 'Tributes', 'give-tributes' ); ?></h3>

				<div class="inside" style="margin-top:0;">
					<?php if ( 'send_mail_card' === $ecard_or_mailed ) : ?>
						<div id="give-tributes-mail-card-details">
							<div class="give-tributes-details">
								<div class="data column-container">
									<div class="column">
										<div class="give-tributes-wrap-honoree-name">
											<p>
												<strong><?php _e( 'Honoree Name', 'give-tributes' ); ?></strong><br>
												<?php echo $honoree_full_name; ?>
											</p>
										</div>
										<div class="give-tributes-type-wrap">
											<p>
												<strong><?php _e( 'Tribute Type', 'give-tributes' ); ?></strong><br>
												<?php echo $type; ?>
											</p>
										</div>
										<div class="give-tributes-notification-wrap">
											<p>
												<strong><?php _e( 'Notification Message', 'give-tributes' ); ?></strong><br>
												<?php echo $mail_card_personalized_message; ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-notification-method-wrap">
											<p>
												<strong><?php _e( 'Notification Method', 'give-tributes' ); ?></strong><br>
												<?php _e( 'Mail a Card', 'give-tributes' ); ?>
											</p>
										</div>
										<div class="give-tributes-honoree-address-wrap">
											<p>
												<strong><?php _e( 'Notification Address', 'give-tributes' ); ?></strong><br>
												<?php echo $notification_full_address; ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-notification-name-wrap">
											<p>
												<strong><?php _e( 'Notification Name', 'give-tributes' ); ?></strong><br>
												<?php echo $mail_card_notify_full_name; ?>
											</p>
										</div>
										<div class="give-tributes-wrap-mail-card-option">
											<p>
												<strong><?php _e( 'Card Actions', 'give-tributes' ); ?></strong><br>
												<?php echo give_is_setting_enabled( $card_creation ) ? $card_option . ' | ' . $card_sent_output : $card_option; ?>
											</p>
										</div>
										<div class="give-tributes-view-maill-card-report-wrap">
											<p>
												<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=give_forms&page=give-reports&tab=tributes&section=give-tributes-mail-card' ) ); ?>"><?php echo __( 'View Mail a Card Report', 'give-tributes' ); ?>
													&raquo;</a>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /#give-tributes-mail-card-details -->
					<?php endif; ?>

					<?php if ( 'send_eCard' === $ecard_or_mailed ) : ?>
						<div id="give-tributes-ecard-details">
							<div class="give-tributes-details">
								<div class="data column-container">
									<div class="column">
										<div class="give-tributes-wrap-honoree-name">
											<p>
												<strong><?php _e( 'Honoree Name', 'give-tributes' ); ?></strong><br>
												<?php echo $honoree_full_name; ?>
											</p>
										</div>
										<div class="give-tributes-notification-name-wrap">
											<p>
												<strong><?php _e( 'Notification Names', 'give-tributes' ); ?></strong><br>
												<?php echo give_tributes_ecards_notify_fields( $payment_id, 'full_name', '<br />', 'list' ); ?>
											</p>
										</div>
										<div class="give-tributes-notification-wrap">
											<p>
												<strong><?php _e( 'Notification Message', 'give-tributes' ); ?></strong><br>
												<?php echo give_tributes_ecards_notify_fields( $payment_id, 'personalized_message', '<br />', 'list' ); ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-notification-method-wrap">
											<p>
												<strong><?php _e( 'Notification Method', 'give-tributes' ); ?></strong><br>
												<?php _e( 'eCard', 'give-tributes' ); ?>
											</p>
										</div>
										<div class="give-tributes-email-address-wrap">
											<p>
												<strong><?php _e( 'Notification Emails', 'give-tributes' ); ?></strong><br>
												<?php echo give_tributes_ecards_notify_fields( $payment_id, 'emails', '<br />', 'list' ); ?>
											</p>
										</div>
										<div class="give-tributes-ecard-email-sent-wrap">
											<p>
												<strong><?php _e( 'Date/Time eCard Sent', 'give-tributes' ); ?></strong><br>
												<?php echo $give_ecard_email_sent_date; ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-type-wrap">
											<p>
												<strong><?php _e( 'Tribute Type', 'give-tributes' ); ?></strong><br>
												<?php echo $type; ?>
											</p>
										</div>
										<div class="give-tributes-ecard-options-wrap">
											<p>
												<strong><?php _e( 'eCard Options', 'give-tributes' ); ?></strong><br>
												<?php echo $ecard_options; ?>
											</p>
											<?php
											// Render resend eCard popup.
											echo give_tributes_generate_popup_html( $payment_id, 'resend', 'true' );

											// Render preview eCard popup.
											echo give_tributes_generate_popup_html( $payment_id, 'preview', 'true' );
											?>

										</div>
										<div class="give-tributes-view-ecard-report-wrap">
											<p>
												<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=give_forms&page=give-reports&tab=tributes&section=give-tributes-ecard' ) ); ?>"><?php _e( 'View eCards Report', 'give-tributes' ); ?>
													&raquo;</a>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /#give-tributes-ecard-details -->
					<?php endif; ?>

					<?php if ( 'send_mail_card' !== $ecard_or_mailed && 'send_eCard' !== $ecard_or_mailed ) : ?>
						<div id="give-tributes-general-details">
							<div class="give-tributes-details">
								<div class="data column-container">
									<div class="column">
										<div class="give-tributes-wrap-honoree-name">
											<p>
												<strong><?php _e( 'Honoree Name', 'give-tributes' ); ?></strong><br>
												<?php echo $honoree_full_name; ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-type-wrap">
											<p>
												<strong><?php _e( 'Tribute Type', 'give-tributes' ); ?></strong><br>
												<?php echo $type; ?>
											</p>
										</div>
									</div>
									<div class="column">
										<div class="give-tributes-notification-method-wrap">
											<p>
												<strong><?php _e( 'Notification Method', 'give-tributes' ); ?></strong><br>
												<?php _e( 'No', 'give-tributes' ); ?>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /#give-tributes-general-details -->
					<?php endif; ?>
				</div>
				<!-- /.inside -->
			</div>
			<!-- /#give-tributes-details -->
			<?php
		endif;
	}

	/**
	 * Add new Tribute Column.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $columns Retrieve all columns.
	 *
	 * @return array
	 */
	public function table_column( $columns ) {
		unset( $columns['details'] );
		unset( $columns['details'] );

		$columns['tribute'] = __( 'Tribute', 'give-tributes' );
		$columns['details'] = __( 'Details', 'give-tributes' );

		return $columns;
	}

	/**
	 * Show Tribute information.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $value
	 * @param int    $payment_id
	 * @param string $column_name
	 *
	 * @return string
	 */
	public function column_data( $value, $payment_id, $column_name ) {

		if ( 'tribute' === $column_name ) {

			// Get Give-Tribute accept/reject.
			$give_tributes_accept = give_get_meta( $payment_id, '_give_tributes_accept', true );

			if ( empty( $give_tributes_accept ) ) {
				// Tributes not enabled for this donation form.
				$value = __( 'n/a', 'give-tributes' );
			} elseif ( ! empty( $give_tributes_accept ) && 'yes' === $give_tributes_accept ) {
				// Donor opted-in to giving in tribute.
				$value = __( 'Yes', 'give-tributes' );
			} elseif ( ! empty( $give_tributes_accept ) && 'no' === $give_tributes_accept ) {
				// Donor did not opt-in to giving in tribute.
				$value = __( 'No', 'give-tributes' );
			}

		}

		return $value;
	}



	/**
	 * Register Give-Tribute action notices.
	 *
	 * @since 1.0.0
	 */
	public function action_notice() {
		// Bailout.
		if ( ! is_admin() ) {
			return;
		}

		if ( isset( $_GET['tab'] ) && 'tributes' === $_GET['tab']
		     && isset( $_GET['post_type'] ) && 'give_forms' === $_GET['post_type']
		     && isset( $_GET['page'] ) && 'give-reports' === $_GET['page']
		) // Bulk action notices.
		{
			if (
				isset( $_GET['action'] ) &&
				! empty( $_GET['action'] )
			) {
				// Add payment bulk notice.
				if (
					isset( $_GET['payment'] ) &&
					! empty( $_GET['payment'] )
				) {

					$payment_count = isset( $_GET['payment'] ) ? count( $_GET['payment'] ) : 0;

					switch ( $_GET['action'] ) {
						case 'tributes_mark_and_send_card':
							Give()->notices->register_notice( array(
								'id'          => 'bulk_action_tribute_send_card',
								'type'        => 'updated',
								'description' => _n(
									'Tributes card mailed and status updated successfully.',
									'Tributes cards mailed and statuses updated successfully.',
									$payment_count,
									'give-tributes'
								),
								'show'        => true,
							) );
							break;
						case 'tributes_send_card':
							Give()->notices->register_notice( array(
								'id'          => 'bulk_action_tribute_tributes_mark_and_send_card',
								'type'        => 'updated',
								'description' => _n(
									'Tributes card mailed successfully.',
									'Tributes cards mailed successfully.',
									$payment_count,
									'give-tributes'
								),
								'show'        => true,
							) );
							break;
						case 'tributes_send_card_undo':
							Give()->notices->register_notice( array(
								'id'          => 'bulk_action_tribute_send_card_undo',
								'type'        => 'updated',
								'description' => _n(
									'Tributes card unmark as send.',
									'Tributes cards unmark as send.',
									$payment_count,
									'give-tributes'
								),
								'show'        => true,
							) );
							break;
					}
				}
			}
		}
	}

	/**
	 * Register Give-Tribute admin notices.
	 *
	 * @since 1.0.0
	 */
	public function admin_notice() {

		// Bailout.
		if ( ! is_admin() ) {
			return;
		}

		// Admin email.
		$admin_email = get_bloginfo( 'admin_email' );

		// Add get all the messages notices.
		$message_notices = give_get_admin_messages_key();

		// check if give messages notices is empty then Bailout..
		if ( empty( $message_notices ) ) {
			return;
		}

		foreach ( $message_notices as $message_notice ) {
			switch ( $message_notice ) {
				case 'sent-tribute-test-email' :
					if ( current_user_can( 'manage_give_settings' ) ) {
						Give()->notices->register_notice( array(
							'id'          => 'give-sent-test-email',
							'type'        => 'updated',
							'description' => __( 'The test email has been sent to ' . $admin_email . '.', 'give-tributes' ),
							'show'        => true,
						) );
					}
					break;
				case 'resent-ecard' :
					// Tribute show eCard error.
					if ( current_user_can( 'view_give_reports' ) ) {
						Give()->notices->register_notice( array(
							'id'          => 'give-payment-sent',
							'type'        => 'updated',
							'description' => __( 'The eCard email receipt has been resent.', 'give-tributes' ),
							'show'        => true,
						) );
					}
					break;
			}
		}
	}

	/**
	 * Ajax Callback for resending the email to multiple users.
	 *
	 * @since 1.2
	 */
	public function give_tributes_resend_ecards() {

		// Check nonce.
		check_ajax_referer( 'resend_ecards_nonce', 'nonce' );

		if ( empty( $_POST['emails'] ) || empty( $_POST['payment_id'] ) ) {
			give_die( __( 'No email or payment provided.', 'give-tributes' ) );
		}

		// Get emails.
		$emails = $_POST['emails'];

		// Get the payment id.
		$payment_id = intval( $_POST['payment_id'] );

		// Generate eCard email.
		give_tributes_ecard_email_receipt( $payment_id, $form_id = 0, $emails );

		// Placeholder for the redirect URL.
		$redirect_to = '';

		// Create success url
		if ( isset( $_POST['is_edit_page'] ) && 'true' !== $_POST['is_edit_page'] ) {
			$redirect_to = admin_url( 'edit.php?post_type=give_forms&page=give-reports&tab=tributes&section=give-tributes-ecard&give-messages[]=resent-ecard' );
		} else {
			$redirect_to = add_query_arg( 'id', $payment_id, admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details&give-messages[]=resent-ecard' ) );
		}

		// Send data back to jquery.
		wp_send_json( array(
			'result'   => 'success',
			'message'  => __( 'Email sent successfully!', 'give-tributes' ),
			'redirect' => $redirect_to,
		) );

		// give_die.
		give_die();
	}

	/**
	 * Add Give Tributes popup overlay to the footer in wp-admin.
	 *
	 * @since 1.2
	 */
	public function give_tributes_popup_overlay() {
		global $pagenow;

		if ( ! isset( $_GET['page'] ) || ! isset( $_GET['post_type'] ) ) {
			return;
		}

		// Add HTML, If it is Report page or payment details page.
		if (
			( $pagenow == 'edit.php' )
			&& ( 'give_forms' === $_GET['post_type'] )
			&& ( 'give-payment-history' === $_GET['page'] || 'give-reports' === $_GET['page'] )
		) {
			?>
			<div class="give-tributes-popup-backdark"></div>
			<?php
		}
	}

	/**
	 * Include the tribute html withing the form.
	 *
	 * @since 1.5
	 *
	 * @param array   $response Response
	 * @param integer $form_id  Donation Form ID.
	 *
	 * @return array $response
	 */
	public function give_tributes_include_response( $response, $form_id ) {

		if ( ! empty( $form_id ) ) {

			$tribute_admin = new Give_Tributes_Public();
			ob_start();
			echo $tribute_admin->dedicate_donation( $form_id );
			$response['tribute_html'] = ob_get_clean();
		}

		return $response;
	}

	/**
	 * Function is used to inject tributes meta option in import dropddown.
	 *
	 * @since   1.5.1
	 *
	 * @param array options array
	 *
	 * @return  array of options.
	 */
	public function give_tributes_donations_options( $options ) {
		$tributes_options =
			array(
				'_give_tributes_first_name'                     => __( 'Honoree First Name', 'give-tributes' ),
				'_give_tributes_last_name'                      => __( 'Honoree Last Name', 'give-tributes' ),
				'_give_tributes_mail_card_notify_first_name'    => __( 'Notification First Name', 'give-tributes' ),
				'_give_tributes_mail_card_notify_last_name'     => __( 'Notification Last Name', 'give-tributes' ),
				'_give_tributes_would_to'                       => __( 'Notification Method', 'give-tributes' ),
				'_give_tributes_type'                           => __( 'Tribute Type', 'give-tributes' ),
				'_give_tributes_mail_card_personalized_message' => __( 'Tribute Personalized Message', 'give-tributes' ),
				'_give_tributes_mail_card_address_1'            => __( 'Tribute Email/Address', 'give-tributes' ),
				'_give_tributes_accept'                         => __( 'Tribute Accept', 'give-tributes' ),
				'_give_tributes_ecard_email_sent_date'          => __( 'Date/Time eCard Sent', 'give-tributes' ),
			);

		return array_merge( $options, $tributes_options );
	}

	/**
	 * Function is used to import tributes meta data to payment
	 *
	 * @since   1.5.1
	 *
	 * @param object $payment      payment object
	 * @param array  $payment_data payment data
	 * @param array  $data         donation meta
	 */
	public function give_tributes_import_tributes_data( $payment, $payment_data, $data ) {

		if ( ! empty( $data['_give_tributes_first_name'] ) ) {
			$payment->update_meta( '_give_tributes_first_name', $data['_give_tributes_first_name'] );
			$payment->update_meta( '_give_tributes_accept', 'yes' );
		}
		if ( 'eCard' === $data['_give_tributes_would_to'] ) {
			$receipt_fname    = '_give_tributes_ecard_notify_first_name';
			$receipt_lname    = '_give_tributes_ecard_notify_last_name';
			$personal_message = '_give_tributes_ecard_personalized_message';
			$address          = '_give_tributes_honoree_ecard_email';
			if ( ! empty( $data['tribute_date_time'] ) ) {
				$payment->update_meta( '_give_tributes_ecard_email_sent_date', $data['tribute_date_time'] );
			}
			$data['_give_tributes_would_to'] = 'send_eCard';
		} else {
			$receipt_fname                   = '_give_tributes_mail_card_notify_first_name';
			$receipt_lname                   = '_give_tributes_mail_card_notify_last_name';
			$personal_message                = '_give_tributes_mail_card_personalized_message';
			$address                         = '_give_tributes_mail_card_address_1';
			$data['_give_tributes_would_to'] = 'send_mail_card';
		}
		if ( ! empty( $data['_give_tributes_last_name'] ) ) {
			$payment->update_meta( '_give_tributes_last_name', $data['_give_tributes_last_name'] );
		}
		if ( ! empty( $data['_give_tributes_mail_card_notify_first_name'] ) ) {

			$payment->update_meta( $receipt_fname, $data['_give_tributes_mail_card_notify_first_name'] );
		}
		if ( ! empty( $data['_give_tributes_mail_card_notify_last_name'] ) ) {
			$payment->update_meta( $receipt_lname, $data['_give_tributes_mail_card_notify_last_name'] );
		}
		if ( ! empty( $data['_give_tributes_would_to'] ) ) {
			$payment->update_meta( '_give_tributes_would_to', $data['_give_tributes_would_to'] );
		}
		if ( ! empty( $data['_give_tributes_type'] ) ) {
			$payment->update_meta( '_give_tributes_type', $data['_give_tributes_type'] );
		}
		if ( ! empty( $data['_give_tributes_mail_card_personalized_message'] ) ) {
			$payment->update_meta( $personal_message, $data['_give_tributes_mail_card_personalized_message'] );
		}
		if ( ! empty( $data['_give_tributes_mail_card_address_1'] ) ) {
			$payment->update_meta( $address, $data['_give_tributes_mail_card_address_1'] );
		}
		if ( ! empty( $data['_give_tributes_accept'] ) ) {
			$payment->update_meta( '_give_tributes_accept', $data['_give_tributes_accept'] );
		}
	}
}

