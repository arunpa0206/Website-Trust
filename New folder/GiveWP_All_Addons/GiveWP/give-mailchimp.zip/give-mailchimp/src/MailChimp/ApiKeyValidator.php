<?php

namespace GiveMailChimp\MailChimp;

use Give_Notices;
use GiveMailChimp\MailChimp\Exceptions\InvalidMailChimpApiKeyException;
use GiveMailChimp\MailChimp\Repositories\ApiKey;

/**
 * Class ApiKeyValidator
 *
 * @package GiveMailChimp\MailChimp
 * @since 1.5.0
 */
class ApiKeyValidator {
	/**
	 * Validate mailchimp api key.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public function handle() {
		$apiKey           = give_clean( $_POST[ ApiKey::MAILCHIMP_API_OPTION_KEY ] );
		$apiKeyRepository = new ApiKey( $apiKey );

		try {
			$this->canUseForApiRequest( $apiKeyRepository );
		} catch ( InvalidMailChimpApiKeyException $e ) {
			unset( $_POST['give_mailchimp_api'] );
			give_delete_option( 'give_mailchimp_api' );

			/* @var Give_Notices $noticeClass */
			$noticeClass = give( 'notices' );
			$noticeClass->register_notice(
				[
					'id'          => 'give-invalid-mailchimp-apikey',
					'description' => sprintf(
						'<strong>%1$s</strong>. <a href="%2$s" target="_blank">%3$s</a>',
						esc_html__(
							'You added a invalid Mailchimp api key. Try again or use another Mailchimp Api key.',
							'give-mailchimp'
						),
						admin_url( 'edit.php?post_type=give_forms&page=give-tools&tab=logs' ),
						esc_html__( 'Check logs for more information.', 'give-mailchimp' )
					),
					'type'        => 'warning',
				]
			);
		}
	}

	/**
	 * Return whether or not api key can be used for request.
	 *
	 * @since 1.5.0
	 *
	 * @see https://mailchimp.com/developer/marketing/api/ping/
	 *
	 * @param  ApiKey  $apiKeyRepository
	 *
	 * @return bool
	 * @throws InvalidMailChimpApiKeyException
	 */
	public function canUseForApiRequest( ApiKey $apiKeyRepository ) {
		if ( ! $apiKeyRepository->isValidApiKey() ) {
			return false;
		}

		$configuration = new Configuration( $apiKeyRepository );
		$url           = trailingslashit( $configuration->getApiUrl() ) . 'ping';

		$httpQuery = [
			'timeout'     => $configuration->requestTimeout,
			'blocking'    => true,
			'httpversion' => '1.1',
			'sslverify'   => false,
			'headers'     => [
				'content-type'  => 'application/json',
				'Authorization' => 'Basic ' . $configuration->getStringForBasicAuthorization(),
			],
		];

		$response   = wp_remote_get( $url, $httpQuery );
		$statusCode = absint( wp_remote_retrieve_response_code( $response ) );

		if ( 200 === $statusCode ) {
			return true;
		}

		if ( is_wp_error( $response ) ) {
			throw new InvalidMailChimpApiKeyException( $response->get_error_message(), $statusCode );
		}

		throw new InvalidMailChimpApiKeyException( 'Please provide a valid mailchimp api key.', $statusCode );
	}
}
