<?php

namespace GiveMailChimp\Migrations\Contracts;

/**
 * Class Migration
 *
 * @package GiveMailChimp\Migrations
 * @since 1.5.0
 */
abstract class Migration extends \Give\Framework\Migrations\Contracts\Migration {
	/**
	 * Return migration source
	 *
	 * @since 2.10.0
	 *
	 * @return string
	 */
	public static function source() {
		return esc_html__( 'Give MailChimp Addon', 'give-mailchimp' );
	}
}
