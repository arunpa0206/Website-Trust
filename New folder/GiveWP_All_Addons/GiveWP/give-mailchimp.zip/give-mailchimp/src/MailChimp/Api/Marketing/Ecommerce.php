<?php

namespace GiveMailChimp\MailChimp\Api\Marketing;

use GiveMailChimp\MailChimp\ApiClient;
use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;

/**
 * Class Repository
 * @package GiveMailChimp\MailChimp\Marketing\Ecommerce
 * @since 1.5.0
 */
class Ecommerce {

	private $apiClient;

	/**
	 * Repository constructor.
	 *
	 * @since 1.5.0
	 *
	 * @param  ApiClient  $apiClient
	 */
	public function __construct( ApiClient $apiClient ) {
		$this->apiClient = $apiClient;
	}

	/**
	 * Add new order to MailChimp Ecommerce
	 *
	 * @since 1.5.0
	 *
	 * @param  array  $order
	 *
	 * @return array
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function addOrder( $order ) {
		try {
			return $this->apiClient->post(
				"ecommerce/stores/{$this->getStoreId()}/orders",
				$order
			)->getResponseBody();
		} catch ( ApiException $e ) {
			throw $e;
		} catch ( RequestException $e ) {
			throw $e;
		} catch ( MailchimpApiKeyDoesNotExistException $e ) {
			throw $e;
		}
	}

	/**
	 * Delete order from MailChimp Ecommerce
	 *
	 * @since 1.5.0
	 *
	 * @param  string|int  $orderId
	 *
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function deleteOrder( $orderId ) {
		try {
			$this->apiClient->delete( "ecommerce/stores/{$this->getStoreId()}/orders/{$orderId}" )
							->getResponseBody();
		} catch ( ApiException $e ) {
			throw $e;
		} catch ( RequestException $e ) {
			throw $e;
		} catch ( MailchimpApiKeyDoesNotExistException $e ) {
			throw $e;
		}
	}

	/**
	 * Get store url.
	 *
	 * @since 1.5.0
	 * @return string
	 */
	protected function getStoreId() {
		return md5( home_url() );
	}
}
