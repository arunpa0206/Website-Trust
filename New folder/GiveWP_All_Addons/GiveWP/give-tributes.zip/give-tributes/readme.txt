=== Give - Tributes ===
Contributors: givewp
Donate link: https://givewp.com
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, tributes
Requires at least: 4.8
Tested up to: 5.5
Stable tag: 1.5.8
Requires Give: 2.6.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Allow donors to give to your Cause via customizable tributes like "In honor of" or "In memory of". Send eCards and produce customizable mailable cards.

== Description ==

This plugin requires the Give plugin activated to function properly. When activated, it adds a Tributes functionality to your donation forms.

== Installation ==

For instructions installing Give add-ons please see: https://givewp.com/documentation/core/how-to-install-and-activate-give-add-ons/

= Minimum Requirements =

* WordPress 4.8 or greater
* PHP version 5.3 or greater
* MySQL version 5.0 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==

= 1.5.8: August 14th, 2020 =
* Fix: Resolved a jQuery issue with WordPress 5.5 where the donor was unable to select different payment methods.

= 1.5.7: June 16th, 2020 =
* New: Added support for the upcoming release of GiveWP 2.7.0 and the new donation form template.

= 1.5.6: December 10th, 2019 =
* Fix: Some image sizes would not be full-bleed in the PDF Mail a Card design. This update includes a fix to ensure that they display fully without having margins.

= 1.5.5: November 26th, 2019 =
* Fix: The personalized message from donor's on eCards were not showing for admins in the preview mode when multiple recipients are enabled.

= 1.5.4: June 4th, 2019 =
* Fix: Improved security for ajax requests by applying nonce and role based access measures. This version requires the latest version of GiveWP Core to update.

= 1.5.3: May 7th, 2019 =
* New: Improved how donations with tribute data be exported or imported into GiveWP via the import / export tools. Previously a small set of Tributes fields were available for export and NO fields were available to select during import. We have added the missing Tributes fields to the donations export screen and also made those fields selectable in the donation import screen.

= 1.5.2: December 6th, 2018 =
* Fix: Utilize only AJAX validation rather than HTML5 based validation methods for hidden fields. This resolves a browser limitation issue for hidden fields attempting to be validated when the donor has not chosen the option.

= 1.5.1: November 28th, 2018 =
* Tweak: The donor's full name is now displayed in the {tribute_info} tag rather than just the first name.
* Fix: Ensure the required asterisk on honoree email appears when floating are labels applied to the donation form.
* Fix: Ensure capitalization isn't stripped from the Tributes Options text in the eCard email message text.
* Fix: The Tributes email field now properly validates that the email input is properly formatted.

= 1.5.0: July 10th, 2018 =
* New: Added support for Tribute exports to the Give Core CSV exporter.
* New: Added multiple message support to notices within wp-admin.
* New: The tribute options text is now sortable in Tributes settings section within wp-admin.
* New: Added bulk options to the Tributes list table in wp-admin.
* Tweak: Removed the "#" from the tributes' donation list to match other list screens in wp-admin.
* Tweak: If the plugin's minimum requirements are not met the plugin will no longer deactivate but rather be active but not able to be used until requirements are met.
* Fix: Required fields within the Tributes section can now be programatically set to not required.
* Fix: When a donor gave multiple times the name that was originally associated with the donor's email address was the one that is passed to the {donor_fullname} template tag regardless if a different name was submitted with the donation.

= 1.4.2: May 2nd, 2018 =
* Tweak: Updated deprecated actions in Give Core 2.1+ - please update Give Core to the latest version!

= 1.4.1: February 15th, 2018 =
* New: The plugin is now integrated with Manual Donations so you can easily record and send out dedication emails and eCards manually!
* Fix: Tributes ecard not sending properly for PayPal Standard transaction.

= 1.4: January 31st, 2018 =
* New: Refactored code base to follow directory and file structuring of other Give add-ons.
* New: Revamped the UI for adding tribute types within the global settings screen.
* Fix: Tribute notification email sent to admin when a new donation added using the Manual Donations add-on.
* Fix: Resolved incorrect output of the {tribute_info} email tag.
* Fix: Removed the first "delete" option from the UI when multi-recipients are enabled for eCard. The first notification email is required therefore the option to remove should not be available to donors.

= 1.3.6: January 18th, 2018 =
* Fix: In Give 2.0 the per form tribute options were not displaying properly. That's been fixed so now you can customize Tributes per form.

= 1.3.5: January 17th, 2018 =
* Tweak: 2.0 is now minimum version requirement to run this add-on.
* Fix: Tributes eCards were not sending properly for offsite gateways such as PayPal Standard.

= 1.3.4: January 9th, 2018 =
* Tweak: Added some minor UI improvements to wp-admin.
* Tweak: Removed unecessary code for checking PHP version since Give core now handles that environment check.
* Tweak: Minor updates for the upcoming Give 2.0 release.
* Tweak: The {amount} email tag used in the Tributes add-on now excludes the fee amount. This is a compatibility fix with the fee recovery add-on.
* Fix: Preventing timeouts from happening when attempting to preview a PDF Mail a Card without having set a card graphic. The placeholder graphic would not load causing the error.
* Fix: There was a bug preventing "Mail a Card" recipient's last names to not get saved to the database properly.
* Fix: The email subject column would appear empty if the settings were never saved. There is now a default subject that displays.
* Fix: There was an incorrect redirect within wp-admin that would incorrectly take admins to the reports page rather than staying on the same page after they resend the eCard.

= 1.3.3: December 28th, 2017 =
* Tweak: The plugin now obeys it's own constants. This is useful for non-default WP setups. For instance, when plugins are placed in another directory.
* Tweak: Minor updates for the upcoming Give 2.0 release.
* Fix: A PHP warning would display if debug was turned on when viewing the eCard email.
* Fix: Zip code field is not full width when selecting a country that doesn't have a state field.
* Fix: The "Mail a Card" option was not sending the correct information when using the {tribute_info} tag in the "New Donation" email sent to admins.

= 1.3.2: December 21st, 2017 =
* Fix: There was an issue with "Reveal" display type forms not displaying the dedication fieldset properly when its placement was inside the hidden form elements. Now the fieldset appears as expected when the click to reveal button is pressed.

= 1.3.1: December 14th, 2017 =
* Fix: Resolved incorrect PHP usage which caused an error on plugin activation.

= 1.3: December 14th, 2017 =
* New: The "Last Name" field for the Honoree, eCard Recipient(s), and Mail a Card recipient can now be marked as "not required". Previously these fields were required and many times the donor does not have or want to provide the last names for the dedication.
* Tweak: Address fieldset improved by displaying the "City" field before "State/Province" field as is expected user experience when completing the form.
* Fix: A bug where saving any other settings panel would cause the tributes repeater field to be overwritten.
* Fix: The dedication type would only output "In honor of" on the donation confirmation page when the donor may have given using a different tribute type.
* Fix: The {tribute_info} email tag was not rendering properly for eCard notifications.
* Fix: The JS for showing and hiding the dedication fieldset for forms with modal mode was incorrectly written. It has been optimized and is now less prone to conflicts with other plugins.

= 1.2: October 17th, 2017 =
* New: You now have the ability to allow donors to specify multiple email notification recipients for eCards and allow them to provide a personal message to each. This will give your donors more flexibility with their dedications should they prefer to send eCards to more than on person.
* New: Admins can now have the ability to control the "Notify the honoree" option. This means you can now control the donor's options for notifying the recipient of their tribute donation. The "Donor Chooses Method" (default): This option will allow the donor to choose how he/she wants the recipient to be notified (most common). The "Admin Chooses Method": The admin (you) can choose the specific notification method "Mail a Card" or "eCard" without allowing the donor to choose. No Notification: Choose this option if the you don't want to provide the donor an option to notify the recipient (this is useful if you plan on handling notifications on your own).
* New: Added the {send_tribute_info} email tag for admin notification email purposes.
* Fix: AJAX optimizations made for higher traffic sites.
* Fix: Improved support for the "Reveal" display method.
* Fix: When the a donation form is embedded on a post or page the Dedication options for the last form would not appear correctly.
* Fix: Per form customized eCards would not send the subject line properly to notification recipients.
* Fix: The dedication field now does not appear above the recurrion options for a donation form.
* Fix: Certain currency characters were having display issues within the Mail a Card PDF output and would appear as "?" rather than the correct symbol.

= 1.1: September 5th, 2017 =
* New: Added additional section for the dedication notification to specify a separate first and last name apart from the tributee to account for cases such as "In memory of" where the person being dedicated may be deceased and the notifier is a separate party.
* New: Added a new option to hide the prepended label in the backend.
* New: Added "Dedication" items to the donation receipt table.
* Tweak: Certain fields like the raw eCard and Mail card content are no longer saved to the payment meta and rather now created dynamically based off the current settings.
* Tweak: Improved various tag's output like the donor's first and last names.
* Tweak: Heavily optimized and refactored the codebase.
* Tweak: Updated CSS to ensure no bullet points or margins are inappropriately applied to Tributes lists with some themes'.
* Fix: Updated JS to ensure no deprecated methods are in use.

= 1.0.0 =
* Initial plugin release. Yippee!
