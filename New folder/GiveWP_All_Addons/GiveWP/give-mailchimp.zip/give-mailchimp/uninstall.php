<?php
/**
 * Uninstall Give MailChimp
 *
 * @package     GiveMailChimp
 * @subpackage  Uninstall
 * @unreleased
 */

// Exit if accessed directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$giveMailchimpSettingIds = [
	'give_mailchimp_api',
	'give_mailchimp_double_opt_in',
	'give_mailchimp_show_checkout_signup',
	'give_mailchimp_checked_default',
	'give_mailchimp_label',

];

$giveSettings = get_option( 'give_settings' );

foreach ( $giveMailchimpSettingIds as $id ) {
	if ( ! isset( $giveSettings[ $id ] ) ) {
		unset( $giveSettings[ $id ] );
	}
}

update_option( 'give_settings', $giveSettings );

// @todo: remove transients
