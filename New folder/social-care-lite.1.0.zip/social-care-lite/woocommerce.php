<?php get_header(); ?>
<div class="container">
    	<div class="sc_innerpage_wrap">
			<?php woocommerce_content(); ?>
		</div><!-- sc_innerpage_wrap -->
</div><!-- container -->     
<?php get_footer(); ?>