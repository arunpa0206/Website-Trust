<?php
/**
 * Give Tributes eCards Email Body.
 *
 * {ecard_email} is replaced by the content entered in either the global settings located: Donations > Settings > Tributes > eCards or under per form settings.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/templates/ecard
 * @author     GiveWP <https://givewp.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
{ecard_email}
