<?php
namespace GivePayPalPro\PaymentGateways\PayPalProPayFlow;

use Give\PaymentGateways\PaymentGateway;

/**
 * Class PayPalProPayFlow
 * @package GivePayPalPro\PaymentGateways\PayPalProPayFlow
 *
 * @since 1.2.3
 */
class PayPalProPayFlow implements PaymentGateway {
	const GATEWAY_ID = 'paypalpro_payflow';

	/**
	 * @inheritDoc
	 */
	public function getId() {
		return self::GATEWAY_ID;
	}

	/**
	 * @inheritDoc
	 */
	public function getName() {
		return esc_html__( 'PayPal Payments Pro', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getPaymentMethodLabel() {
		return esc_html__( 'Credit Card', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getOptions() {
		return [
			[
				'id'   => 'give_title_paypal_pro',
				'type' => 'title',
				'desc' => '<p style="padding: 15px;border-radius: 5px;border: 1px solid #7e8993;margin-top: 2em;">' . sprintf( __( 'This gateway is the preferred PayPal integration. It supports single and recurring donations. If you would to use this method you will need to have an active PayPal Payments Pro account. <a href="%s" target="_blank">Learn</a> which account type you currently have.', 'give-paypal-pro' ), 'http://docs.givewp.com/add-on-paypal-nvp' ) . '</p>',
			],
			[
				'name'        => __( 'PayPal Partner ID', 'give-paypal-pro' ),
				'type'        => 'text',
				'description' => __( 'The ID provided to you by the authorized PayPal Reseller who registered you for the Payflow SDK. If you purchased your account directly from PayPal, use PayPal or leave blank.', 'give-paypal-pro' ),
				'default'     => 'PayPal',
				'id'          => 'payflow_paypal_partner',
			],
			[
				'name'        => __( 'PayPal Vendor ID', 'give-paypal-pro' ),
				'type'        => 'text',
				'description' => __( 'Your merchant login ID that you created when you registered for the account.', 'give-paypal-pro' ),
				'default'     => '',
				'id'          => 'payflow_paypal_vendor',
			],
			[
				'name'        => __( 'PayPal User', 'give-paypal-pro' ),
				'type'        => 'text',
				'description' => __( 'If you set up one or more additional users on the account, this value is the ID of the user authorized to process transactions. Otherwise, leave this field blank.', 'give-paypal-pro' ),
				'default'     => '',
				'id'          => 'payflow_paypal_user',
			],
			[
				'name'        => __( 'PayPal Password', 'give-paypal-pro' ),
				'type'        => 'password',
				'description' => __( 'The password that you defined while registering for the account.', 'give-paypal-pro' ),
				'id'          => 'payflow_paypal_password',
				'default'     => '',
			],
			[
				'name' => __( 'Collect Billing Details', 'give-paypal-pro' ),
				'desc' => __( 'This option enables the billing details section for PayPal which requires the donor to fill in their address to complete a donation. These fields are not required by PayPal to process the transaction.', 'give-paypal-pro' ),
				'id'   => 'payflow_collect_billing',
				'type' => 'checkbox',
			],
			[
				'id'      => 'paypal_payflow_invoice_prefix',
				'name'    => esc_html__( 'Invoice ID Prefix', 'give-paypal-pro' ),
				'desc'    => esc_html__( 'Please enter a prefix for your invoice numbers. If you use your PayPal account for multiple stores ensure this prefix is unique as PayPal will not allow orders with the same invoice number.', 'give-paypal-pro' ),
				'type'    => 'text',
				'default' => 'GIVE-',
			],
			[
				'id'   => 'give_title_paypal_pro',
				'type' => 'sectionend',
			],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function boot() {}
}
