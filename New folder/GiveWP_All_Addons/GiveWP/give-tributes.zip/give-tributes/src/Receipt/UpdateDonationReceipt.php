<?php
namespace GiveTributes\Receipt;

use Give\Receipt\DonationReceipt;
use Give\Receipt\Section;
use Give\Receipt\UpdateReceipt;

/**
 * Class UpdateDonationReceipt
 *
 * @package GiveTributes\Receipt
 * @since 1.5.7
 */
class UpdateDonationReceipt extends UpdateReceipt{

	/**
	 * Apply changes on donation receipt.
	 *
	 * @since 1.5.7
	 */
	public function apply() {
		$giveAsTribute = give_get_meta( $this->receipt->donationId, '_give_tributes_accept', true );

		// Do not add line item if tribute is disabled.
		if ( empty( $giveAsTribute ) || 'no' === $giveAsTribute ) {
			return;
		}

		/* @var Section $section */
		$section = $this->receipt[DonationReceipt::ADDITIONALINFORMATIONSECTIONID];

		$section->addLineItem([
			'id' => 'tribute',
			'label' => esc_html__( 'Dedication', 'give-tributes' ),
			'value' => $this->getTributeLineItemValue()
		]);
	}

	/**
	 * Get tribute line item value.
	 *
	 * @return string
	 * @since 1.5.7
	 */
	private function getTributeLineItemValue() {
		ob_start();

		$ecard_or_mailed = give_get_meta( $this->receipt->donationId, '_give_tributes_would_to', true );

		// Prepare Honoree Full name.
		$honoree_first_name = give_get_meta( $this->receipt->donationId, '_give_tributes_first_name', true );
		$honoree_first_name = ! empty( $honoree_first_name ) ? ucfirst( $honoree_first_name ) : '';

		$honoree_last_name  = give_get_meta( $this->receipt->donationId, '_give_tributes_last_name', true );
		$honoree_last_name  = ! empty( $honoree_last_name ) ? ucfirst( $honoree_last_name ) : '';

		$honoree_full_name = trim( $honoree_first_name . ' ' . $honoree_last_name );

		$notification_method = $notify_full_name = $notify_address = '';

		if ( 'send_eCard' === $ecard_or_mailed ) {

			if ( give_tributes_is_multiple_receipts_enabled( $this->receipt->donationId ) ) {
				$notify_full_name = give_tributes_ecards_notify_fields( $this->receipt->donationId, 'full_name', ', ', ARRAY_A );
				$notify_address   = give_tributes_ecards_notify_fields( $this->receipt->donationId, 'emails', ', ', ARRAY_A );
			} else {
				$notify_full_name = give_tributes_ecards_notify_fields( $this->receipt->donationId, 'full_name', '<br/>' );
				$notify_address   = give_tributes_ecards_notify_fields( $this->receipt->donationId, 'emails', '<br/>' );
			}

			// Notification method.
			$notification_method = __( 'eCard', 'give-tributes' );

		} elseif ( 'send_mail_card' === $ecard_or_mailed ) {

			$mail_card_notify_first_name = give_get_meta( $this->receipt->donationId, '_give_tributes_mail_card_notify_first_name', true );
			$mail_card_notify_first_name = ! empty( $mail_card_notify_first_name ) ? ucfirst( $mail_card_notify_first_name ) : '';

			$mail_card_notify_last_name = give_get_meta( $this->receipt->donationId, '_give_tributes_mail_card_notify_last_name', true );
			$mail_card_notify_last_name = ! empty( $mail_card_notify_last_name ) ? ucfirst( $mail_card_notify_last_name ) : '';

			// Mail a Card notify Full name.
			$notify_full_name = trim( $mail_card_notify_first_name . ' ' . $mail_card_notify_last_name );

			// Notification method.
			$notification_method = __( 'Mail a Card', 'give-tributes' );

			// Notify Honoree.
			$notify_address = give_tributes_notification_address( $this->receipt->donationId, false );

		}// End if().

		?>
		<div id="give-tribute-dedication-information">
			<p><strong><?php echo give_get_meta( $this->receipt->donationId, '_give_tributes_type', true ); ?></strong></p>
			<p><?php echo $honoree_full_name; ?></p>

			<?php if ( 'none' !== $ecard_or_mailed ) : ?>
				<p><strong><?php _e( 'Notification', 'give-tributes' ); ?></strong></p>
				<p><?php echo $notification_method; ?></p>

				<?php // If it has multiple notify receipts. ?>
				<?php if ( give_tributes_is_multiple_receipts_enabled( $this->receipt->donationId ) ) : ?>
					<ul>
						<?php
						if ( ! empty( $notify_full_name ) ) {
							// List out the the persons to be notified.
							foreach ( $notify_full_name as $index => $full_name ) {
								printf(
									'<li>%1$s - <a href="mailto:%2$s">%2$s</a></li>',
									$full_name,
									$notify_address[ $index ]
								);
							}
						}
						?>
					</ul>
				<?php else :
					printf(
						'<p>%1$s</p><p>%2$s</p>',
						$notify_full_name,
						$notify_address
					);
				endif; ?>

			<?php endif; ?>
		</div>
		<?php

		return ob_get_clean();
	}
}
