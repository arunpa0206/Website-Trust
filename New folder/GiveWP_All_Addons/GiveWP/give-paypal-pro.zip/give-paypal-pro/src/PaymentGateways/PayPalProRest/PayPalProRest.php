<?php
namespace GivePayPalPro\PaymentGateways\PayPalProRest;

use Give\PaymentGateways\PaymentGateway;

/**
 * Class PayPalProRest
 * @package GivePayPalPro\PaymentGateways\PayPalProRest
 *
 * @since 1.2.3
 */
class PayPalProRest implements PaymentGateway {
	const GATEWAY_ID = 'paypalpro_rest';

	/**
	 * @inheritDoc
	 */
	public function getId() {
		return self::GATEWAY_ID;
	}

	/**
	 * @inheritDoc
	 */
	public function getName() {
		return esc_html__( 'PayPal Website Payments Pro (REST API)', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getPaymentMethodLabel() {
		return esc_html__( 'Credit Card', 'give-paypal-pro' );
	}

	/**
	 * @inheritDoc
	 */
	public function getOptions() {
		return [
			[
				'id'   => 'give_title_paypal_pro_rest',
				'type' => 'title',
				'desc' => '<p style="padding: 15px;border-radius: 5px;border: 1px solid #7e8993;margin-top: 2em;">' . sprintf( __( 'This gateway supports single donations, and recurring donations for accounts that have DPRP enabled. To enable DPRP on your account you have to contact PayPal Support directly. This method communicates with PayPal more quickly than the NVP method. <a href="%s" target="_blank">Learn</a> which account type you currently have.', 'give-paypal-pro' ), 'http://docs.givewp.com/add-on-paypal-nvp' ) . '</p>',
			],
			[
				'id'   => 'live_paypal_api_client_id',
				'name' => __( 'Live REST API Client ID', 'give-paypal-pro' ),
				'desc' => __( 'Enter your live REST API Client ID', 'give-paypal-pro' ),
				'type' => 'text',
				'size' => 'regular',
			],
			[
				'id'   => 'live_paypal_api_secret',
				'name' => __( 'Live REST API Secret', 'give-paypal-pro' ),
				'desc' => __( 'Enter your live REST API Secret', 'give-paypal-pro' ),
				'type' => 'api_key',
				'size' => 'regular',
			],
			[
				'id'   => 'sandbox_paypal_api_client_id',
				'name' => __( 'Sandbox REST API Client ID', 'give-paypal-pro' ),
				'desc' => __( 'Enter your Sandbox REST API Client ID', 'give-paypal-pro' ),
				'type' => 'text',
				'size' => 'regular',
			],
			[
				'id'   => 'sandbox_paypal_api_secret',
				'name' => __( 'Sandbox REST API Secret', 'give-paypal-pro' ),
				'desc' => __( 'Enter your Sandbox REST API Secret', 'give-paypal-pro' ),
				'type' => 'api_key',
				'size' => 'regular',
			],
			[
				'id'   => 'paypal_rest_collect_billing',
				'name' => __( 'Collect Billing Details', 'give-paypal-pro' ),
				'desc' => __( 'This option enables the billing details section for PayPal which requires the donor to fill in their address to complete a donation. These fields are not required by PayPal to process the transaction.', 'give-paypal-pro' ),
				'type' => 'checkbox',
			],
			[
				'id'      => 'paypal_rest_invoice_prefix',
				'name'    => esc_html__( 'Invoice ID Prefix', 'give-paypal-pro' ),
				'desc'    => esc_html__( 'Please enter a prefix for your invoice numbers. If you use your PayPal account for multiple stores ensure this prefix is unique as PayPal will not allow orders with the same invoice number.', 'give-paypal-pro' ),
				'type'    => 'text',
				'default' => 'GIVE-',
			],
			[
				'id'   => 'give_title_paypal_pro_rest',
				'type' => 'sectionend',
			],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function boot() {}
}
