<?php
/**
 * Give Twocheckout helper functions
 *
 * @package     Give
 * @copyright   Copyright (c) 2016, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *
 * 2Checkout uses it's own credit card form because the card details are tokenized.
 *
 * We don't want the name attributes to be present on the fields in order to prevent them from getting posted to the
 * server
 *
 * @access      public
 * @since       1.0
 *
 * @param      $form_id
 * @param bool $echo
 *
 * @return string
 */
function give_twocheckout_credit_card_form( $form_id, $echo = true ) {

	ob_start();

	do_action( 'give_before_cc_fields', $form_id ); ?>

    <fieldset id="give_cc_fields-<?php echo $form_id ?>" class="give-do-validate">

        <legend><?php esc_html_e( 'Credit Card Info', 'give-twocheckout' ); ?></legend>

		<?php if ( is_ssl() ) : ?>
            <div id="give_secure_site_wrapper-<?php echo $form_id ?>">
                <span class="give-icon padlock"></span>
                <span><?php esc_html_e( 'This is a secure SSL encrypted payment.', 'give-twocheckout' ); ?></span>
            </div>
		<?php endif; ?>

        <input id="twocheckout-token-<?php echo $form_id ?>" class="twocheckout-token" name="token" type="hidden"
               value="">

        <p id="give-card-number-wrap-<?php echo $form_id ?>" class="form-row form-row-two-thirds">
            <label for="card_number" class="give-label">
				<?php esc_html_e( 'Card Number', 'give-twocheckout' ); ?>
                <span class="give-required-indicator">*</span>
                <span class="give-tooltip give-icon give-icon-question"
                      data-tooltip="<?php esc_attr_e( 'The (typically) 16 digits on the front of your credit card.', 'give-twocheckout' ); ?>"></span>
                <span class="card-type"></span>
            </label>
            <input type="tel" autocomplete="off" id="card_number-<?php echo $form_id ?>" required
                   class="card-number give-input required"
                   placeholder="<?php esc_attr_e( 'Card number', 'give-twocheckout' ); ?>"/>
        </p>

        <p id="give-card-cvc-wrap-<?php echo $form_id ?>" class="form-row form-row-one-third">
            <label for="card_cvc" class="give-label">
				<?php esc_html_e( 'CVC', 'give-twocheckout' ); ?>
                <span class="give-required-indicator">*</span>
                <span class="give-tooltip give-icon give-icon-question"
                      data-tooltip="<?php esc_attr_e( 'The 3 digit (back) or 4 digit (front) value on your card.', 'give-twocheckout' ); ?>"></span>
            </label>
            <input type="tel" size="4" autocomplete="off" id="card_cvc-<?php echo $form_id ?>" required
                   class="card-cvc give-input required"
                   placeholder="<?php esc_attr_e( 'Security code', 'give-twocheckout' ); ?>"/>
        </p>

	    <p id="give-card-name-wrap-<?php echo $form_id ?>" class="form-row form-row-two-thirds">
		    <label for="card_name" class="give-label">
			    <?php esc_html_e( 'Cardholder Name', 'give-twocheckout' ); ?>
			    <span class="give-required-indicator">*</span>
			    <span class="give-tooltip give-icon give-icon-question"
			          data-tooltip="<?php esc_attr_e( 'The name of the credit card account holder.', 'give-twocheckout' ); ?>"></span>
		    </label>
		    <input type="text" autocomplete="off" id="card_name-<?php echo $form_id ?>" required
		           class="card-name give-input required"
		           placeholder="<?php esc_attr_e( 'Cardholder Name', 'give-twocheckout' ); ?>" />
	    </p>

		<?php do_action( 'give_before_cc_expiration' ); ?>

        <p class="card-expiration form-row form-row-one-third">
            <label for="card_expiry" class="give-label">
				<?php esc_html_e( 'Expiration (MM/YY)', 'give-twocheckout' ); ?>
                <span class="give-required-indicator">*</span>
                <span class="give-tooltip give-icon give-icon-question"
                      data-tooltip="<?php esc_attr_e( 'The date your credit card expires, typically on the front of the card.', 'give-twocheckout' ); ?>"></span>
            </label>
            <input type="hidden" id="card_exp_month-<?php echo $form_id ?>" class="card-expiry-month"/>
            <input type="hidden" id="card_exp_year-<?php echo $form_id ?>" class="card-expiry-year"/>
            <input type="tel" autocomplete="off" id="card_expiry-<?php echo $form_id ?>" required
                   class="card-expiry give-input required"
                   placeholder="<?php esc_attr_e( 'MM / YY', 'give-twocheckout' ); ?>"/>
        </p>

		<?php do_action( 'give_after_cc_expiration', $form_id ); ?>

    </fieldset>
	<?php

	do_action( 'give_after_cc_fields', $form_id );

	$form = ob_get_clean();

	if ( false !== $echo ) {
		echo $form;
	}

	return $form;
}

add_action( 'give_twocheckout_cc_form', 'give_twocheckout_credit_card_form' );

/**
 * Modily the gateway id in Give Report sections
 *
 * @since 1.0.3
 *
 * @param array $gateways list
 *
 * @return array $gateways list
 */
function give_twocheckout_report_gateway_list( $gateways ) {

	if (
		is_admin()
		&& ! empty( $_GET['post_type'] ) && 'give_forms' === $_GET['post_type']
		&& ! empty( $_GET['page'] ) && 'give-reports' === $_GET['page']
		&& ! empty( $_GET['tab'] ) && 'gateways' === $_GET['tab']
	) {

		if ( ! empty( $gateways['twocheckout'] ) ) {
			// Format: ID => Name
			$gateways['2checkout'] = $gateways['twocheckout'];
			unset( $gateways['twocheckout'] );
		}
	}

	return $gateways;
}

add_filter( 'give_payment_gateways', 'give_twocheckout_report_gateway_list' );

/**
 * Load Transaction-specific admin javascript.
 *
 * Allows the user to refund non-recurring donations.
 *
 * @since  1.1
 *
 * @param int $payment_id
 */
function give_twocheckout_admin_payment_js( $payment_id = 0 ) {

	$gateway = give_get_payment_gateway( $payment_id );

	if ( '2checkout' !== strtolower( $gateway ) ) {
		return;
	}

	$sale_id = give_get_meta( $payment_id, '_give_payment_transaction_id', true );
	if ( empty( $sale_id ) ) {
		return;
	}
	?>
	<script type="text/javascript">
		jQuery( document ).ready( function ( $ ) {
			$( 'select[name=give-payment-status]' ).change( function () {
				if ( 'refunded' === $( this ).val() ) {
					$( this ).parent().parent().append( '<p class="give-twocheckout-refund"><input type="checkbox" id="give_refund_in_twocheckout" name="give_refund_in_twocheckout" value="1"/><label for="give_refund_in_twocheckout"><?php esc_html_e( 'Refund Charge in 2Checkout?', 'give-twocheckout' ); ?></label></p>' );
				} else {
					$( '.give-twocheckout-refund' ).remove();
				}
			} );
		} );
	</script>
	<?php

}

add_action( 'give_view_donation_details_before', 'give_twocheckout_admin_payment_js', 100 );

/**
 * 2Checkout Licensing
 */
function give_add_2checkout_licensing() {
	if ( class_exists( 'Give_License' ) ) {
		new Give_License( GIVE_TWOCHECKOUT_PLUGIN_FILE, '2Checkout Gateway', GIVE_TWOCHECKOUT_VERSION, 'WordImpress', '2checkout_license_key' );
	}
}

add_action( 'plugins_loaded', 'give_add_2checkout_licensing' );

/**
 * Registers the gateway.
 *
 * @param array $gateways List of payment gateways.
 *
 * @return mixed
 */
function give_register_twocheckout_gateway( $gateways ) {

	// Format: ID => Name.
	$gateways['twocheckout'] = array(
		'admin_label'    => __( '2Checkout', 'give-twocheckout' ),
		'checkout_label' => __( 'Credit Card', 'give-twocheckout' ),
	);

	return $gateways;
}

add_filter( 'give_payment_gateways', 'give_register_twocheckout_gateway' );
