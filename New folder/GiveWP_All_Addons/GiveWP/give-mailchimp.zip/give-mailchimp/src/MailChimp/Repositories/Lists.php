<?php

namespace GiveMailChimp\MailChimp\Repositories;

use GiveMailChimp\MailChimp\Exceptions\ApiException;
use GiveMailChimp\MailChimp\Exceptions\MailchimpApiKeyDoesNotExistException;
use GiveMailChimp\MailChimp\Exceptions\RequestException;
use stdClass;

/**
 * Class Lists
 *
 * @package GiveMailChimp\MailChimp\Repositories
 * @since 1.5.0
 */
class Lists {
	const LISTS_DATA_OPTION_KEY      = 'give_mailchimp_list_data';
	private $transientExpirationTime = WEEK_IN_SECONDS;

	/**
	 * @var \GiveMailChimp\MailChimp\Api\Marketing\Lists
	 */
	private $listApiClient;

	/**
	 * Lists constructor.
	 *
	 * @param  \GiveMailChimp\MailChimp\Api\Marketing\Lists  $listApiClient
	 */
	public function __construct( \GiveMailChimp\MailChimp\Api\Marketing\Lists $listApiClient ) {
		$this->listApiClient = $listApiClient;
	}

	/**
	 * @since 1.5.0
	 * @return stdClass
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function getAllLists() {
		$listsData = get_transient( self::LISTS_DATA_OPTION_KEY );

		if ( $listsData ) {
			return $listsData;
		}

		$bodyArguments = [
			/**
			 * Filter list item count which you want to get from mailchimp
			 *
			 * @since 1.4.2
			 */
			'count' => apply_filters( 'give_mailchimp_api_list_item_count', 500 ),
		];

		$data = $this->listApiClient->getAllLists( $bodyArguments );

		$this->updateLists( $data );

		return $data;
	}

	/**
	 * @since 1.5.0
	 * @return array
	 * @throws ApiException|RequestException|MailchimpApiKeyDoesNotExistException
	 */
	public function getAllListsTitles() {
		$listData = $this->getAllLists();

		if ( ! $listData->total_items ) {
			return [];
		}

		return wp_list_pluck( $listData->lists, 'name', 'id' );
	}

	/**
	 * @since 1.5.0
	 *
	 * @param  stdClass  $listsData
	 *
	 * @return bool
	 */
	public function updateLists( $listsData ) {
		return set_transient( self::LISTS_DATA_OPTION_KEY, $listsData, $this->transientExpirationTime );
	}

	/**
	 * @since 1.5.0
	 */
	public function deleteListsData() {
		return delete_transient( self::LISTS_DATA_OPTION_KEY );
	}
}
