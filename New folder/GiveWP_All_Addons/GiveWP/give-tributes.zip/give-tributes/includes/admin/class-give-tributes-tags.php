<?php
/**
 * Give Tribute API for creating Tribute template tags
 *
 * Email tags are wrapped in { }
 *
 * A few examples:
 *
 * {name}
 * {sitename}
 *
 *
 * To replace tags in content, use: give_do_tribute_tags( $content, payment_id );
 *
 * To add tags, use: give_add_tribute_tag( $tag, $description, $func ). Be sure to wrap give_add_tribute_tag()
 * in a function hooked to the 'give_tribute_tags' action.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/admin
 * @author     GiveWP <https://givewp.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Give_Tributes_Tags.
 */
class Give_Tributes_Tags {

	/**
	 * Container for storing all tags.
	 *
	 * @since  1.0.0
	 * @access private
	 *
	 * @var Give_Tributes_Tags tags.
	 */
	private static $tags;

	/**
	 * Payment ID.
	 *
	 * @since  1.0.0
	 * @access private
	 *
	 * @var Give_Tributes_Tags Payment ID.
	 */
	private $payment_id;

	/**
	 * User's email address.
	 *
	 * @since  1.2
	 * @access private
	 *
	 * @var string
	 */
	private $email;

	/**
	 * Add an tribute tag.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string   $tag         Tribute tag to be replace in template.
	 * @param string   $description Tribute tag description text.
	 * @param callable $func        Hook to run when tribute tag is found.
	 */
	public static function add( $tag, $description, $func ) {
		if ( is_callable( $func ) ) {
			self::$tags[ $tag ] = array(
				'tag'         => $tag,
				'description' => $description,
				'func'        => $func,
			);
		}
	}

	/**
	 * Remove an tribute tag.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $tag Tribute tag to remove hook from.
	 */
	public function remove( $tag ) {
		unset( self::$tags[ $tag ] );
	}

	/**
	 * Check if $tag is a registered tribute tag.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $tag Tribute tag that will be searched.
	 *
	 * @return bool
	 */
	public function tribute_tag_exists( $tag ) {
		return array_key_exists( $tag, self::$tags );
	}

	/**
	 * Returns a list of all tribute tags.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return array
	 */
	public static function get_tags() {
		return self::$tags;
	}

	/**
	 * Search content for tribute tags and filter tribute tags through their hooks.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $content    Content to search for tribute tags.
	 * @param int    $payment_id The payment id.
	 * @param string $email      User's Email address.
	 *
	 * @return string Content with tribute tags filtered out.
	 */
	public function do_tags( $content, $payment_id, $email = '' ) {

		// Check if there is at least one tag added.
		if ( empty( self::$tags ) || ! is_array( self::$tags ) ) {
			return $content;
		}

		// Get the payment id.
		$this->payment_id = $payment_id;

		// Store email address temporary.
		$this->email = ! empty( $email ) ? $email : null;

		$new_content = preg_replace_callback( '/{([A-z0-9\-\_]+)}/s', array( $this, 'do_tag' ), $content );

		$this->payment_id = null;
		$this->email      = null;

		return $new_content;
	}

	/**
	 * Do a specific tag, this function should not be used. Please use give_tribute_do_tags instead.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param array $m tribute tags.
	 *
	 * @return mixed
	 */
	public function do_tag( $m ) {

		// Get tag.
		$tag = $m[1];

		// Return tag if tag not set.
		if ( ! $this->tribute_tag_exists( $tag ) ) {
			return $m[0];
		}

		// If it has multiple receipts and if it's match the tags.
		if ( in_array( $tag, array( 'notify_name', 'notify_fullname', 'donor_message' ), true ) ) {

			// Store values into array for process ahead.
			$receipt_data = array(
				'email'      => $this->email,
				'payment_id' => $this->payment_id,
			);
		} else {
			$receipt_data = $this->payment_id;
		}

		return call_user_func( self::$tags[ $tag ]['func'], $receipt_data, $tag );
	}

}

/**
 * Add an tribute tag.
 *
 * @since  1.0.0
 *
 * @param string   $tag         Email tag to be replace in tribute.
 * @param string   $description Description of the tribute tag added.
 * @param callable $func        Hook to run when tribute tag is found.
 */
function give_tribute_add_tag( $tag, $description, $func ) {
	Give_Tributes_Tags::add( $tag, $description, $func );
}

/**
 * Remove an tribute tag.
 *
 * @since 1.0.0
 *
 * @param string $tag Tribute tag to remove hook from.
 */
function give_tribute_remove_tag( $tag ) {
	$give_tribute = new Give_Tributes_Tags();
	$give_tribute->remove( $tag );
}

/**
 * Check if $tag is a registered tribute tag.
 *
 * @since 1.0.0
 *
 * @param string $tag Tribute tag that will be searched.
 *
 * @return bool
 */
function give_tribute_tag_exists( $tag ) {
	$give_tribute = new Give_Tributes_Tags();

	return $give_tribute->tribute_tag_exists( $tag );
}

/**
 * Get all tribute tags.
 *
 * @since 1.0.0
 *
 * @return array
 */
function give_tribute_get_tags() {
	return Give_Tributes_Tags::get_tags();
}

/**
 * Get a formatted HTML list of all available tribute tags.
 *
 * @since 1.0.0
 *
 * @return string
 */
function give_tribute_get_tag_list() {

	// Get all tribute tags.
	$tags = give_tribute_get_tags();

	ob_start();
	if ( count( $tags ) > 0 ) : ?>
		<div class="give-tribute-tags-wrap">
			<?php foreach ( $tags as $key => $tag ) : ?>
				<span class="give_<?php echo $tag['tag']; ?>_tag">
					<code>{<?php echo $tag['tag']; ?>}</code>
					- <?php echo $tag['description']; ?>
				</span>
			<?php endforeach; ?>
		</div>
	<?php
	endif;

	// Return the list.
	return ob_get_clean();
}

/**
 * Search content for tribute tags and filter tribute tags through their hooks.
 *
 * @param string $content    Content to search for tribute tags.
 * @param int    $payment_id The payment id.
 * @param string $email      Pass user's email address.
 *
 * @since 1.0.0
 *
 * @return string Content with tribute tags filtered out.
 */
function give_tribute_do_tags( $content, $payment_id, $email = '' ) {
	$give_tribute = new Give_Tributes_Tags();

	// Replace all tags.
	$content = $give_tribute->do_tags( $content, $payment_id, $email );

	$content = apply_filters( 'give_tribute_template_tags', $content, give_get_payment_meta( $payment_id ), $payment_id );

	// Return content.
	return $content;
}

/**
 * Load tribute tags.
 *
 * @since 1.0
 */
function give_tribute_load_tags() {
	/**
	 * Fires when loading tribute tags.
	 *
	 * Allows you to add new tribute tags.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_add_tags' );
}

add_action( 'init', 'give_tribute_load_tags', - 999 );

/**
 * Add default Give Tribute template tags.
 *
 * @since 1.0.0
 */
function give_tribute_setup_tags() {

	// Setup default tags array.
	$tribute_tags = array(
		array(
			'tag'         => 'donation',
			'description' => __( 'The donation form name, and the donation level (if applicable).', 'give-tributes' ),
			'function'    => 'give_tribute_tag_donation',
		),
		array(
			'tag'         => 'amount',
			'description' => __( 'The total donation amount with currency sign.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_amount',
		),
		array(
			'tag'         => 'form_title',
			'description' => __( 'The donation form name.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_form_title',
		),
		array(
			'tag'         => 'donor_name',
			'description' => __( 'The donor\'s first name.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_donor_name',
		),
		array(
			'tag'         => 'donor_fullname',
			'description' => __( 'The donor\'s full name, first and last.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_donor_fullname',
		),
		array(
			'tag'         => 'donor_email',
			'description' => __( 'The donor\'s email address.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_donor_email',
		),
		array(
			'tag'         => 'donor_message',
			'description' => __( 'The personalized message added by the Donor. If the donor did not provide a message no content will appear.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_donor_message',
		),
		array(
			'tag'         => 'tribute',
			'description' => __( 'The tribute choice given by the donor.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_type',
		),
		array(
			'tag'         => 'honoree_name',
			'description' => __( 'The first name of the honoree.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_honoree_name',
		),
		array(
			'tag'         => 'honoree_fullname',
			'description' => __( 'The full name of the honoree.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_honoree_fullname',
		),
		array(
			'tag'         => 'notify_name',
			'description' => __( 'The first name of the person being notified of the tribute.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_notify_name',
		),
		array(
			'tag'         => 'notify_fullname',
			'description' => __( 'The full name of the person being notified of the tribute.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_notify_fullname',
		),
		array(
			'tag'         => 'card_address',
			'description' => __( 'The address of the honoree.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_card_address',
		),
		array(
			'tag'         => 'sitename',
			'description' => __( 'The name of your site.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_sitename',
		),
		array(
			'tag'         => 'download_card',
			'description' => __( 'The PDF Download link.', 'give-tributes' ),
			'function'    => 'give_tribute_tag_download_card',
		),

	);

	// Apply give_tribute_tags filter.
	$tribute_tags = apply_filters( 'give_tribute_tags', $tribute_tags );

	// Add tribute tags.
	foreach ( $tribute_tags as $tribute_tag ) {
		give_tribute_add_tag( $tribute_tag['tag'], $tribute_tag['description'], $tribute_tag['function'] );
	}

}

add_action( 'give_tribute_add_tags', 'give_tribute_setup_tags' );

/**
 * Tribute template tag: {donor_name}
 *
 * The donor's first name.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string name
 */
function give_tribute_tag_donor_name( $payment_id ) {

	// No payment_id = preview.
	if ( empty( $payment_id ) ) {
		return __( 'John', 'give-tributes' );
	}

	$payment = new Give_Payment( $payment_id );
	$donor   = new Give_Donor( $payment->customer_id );

	$first_name = explode( ' ', $donor->name );

	// Get first name from payment data.
	if ( ! empty( $payment->first_name ) ) {
		$first_name[0] = $payment->first_name;
	}

	return isset( $first_name[0] ) ? $first_name[0] : '';

}

/**
 * Tribute template tag: {donor_fullname}
 *
 * The donor's full name, first and last.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $name full name.
 */
function give_tribute_tag_donor_fullname( $payment_id ) {
	// No payment_id = preview.
	if ( empty( $payment_id ) ) {
		return __( 'John Doe', 'give-tributes' );
	}

	$payment    = new Give_Payment( $payment_id );
	$first_name = isset( $payment->first_name ) ? trim( $payment->first_name ) : '';
	$last_name  = isset( $payment->last_name ) ? trim( $payment->last_name ) : '';

	$name = $first_name . ' ' . $last_name;

	return $name;
}

/**
 * Tribute template tag: {donor_email}
 *
 * The donor's email.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string email.
 */
function give_tribute_tag_donor_email( $payment_id ) {
	$payment = new Give_Payment( $payment_id );

	return ! empty( $payment->email ) ? $payment->email : get_bloginfo( 'admin_email' );
}

/**
 * Tribute template tag: {form_title}
 *
 * Output the donation form name.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $form_title
 */
function give_tribute_tag_form_title( $payment_id ) {
	$payment      = new Give_Payment( $payment_id );
	$payment_meta = $payment->payment_meta;

	return isset( $payment_meta['form_title'] ) ? strip_tags( $payment_meta['form_title'] ) : __( 'Sample Donation Form Title - Sample Donation Level', 'give-tributes' );

}

/**
 * Tribute template tag: {sitename}
 *
 * The name of the site.
 *
 * @param int $payment_id Payment ID.
 *
 * @return string sitename
 */
function give_tribute_tag_sitename( $payment_id ) {
	return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
}

/**
 * Tribute template tag: {download_card}
 *
 * The name of the site.
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $formatted_download_url
 */
function give_tribute_tag_download_card( $payment_id ) {

	// Check if Payment id is empty then return blank Download link.
	if ( empty( $payment_id ) ) {
		return '';
	}

	$download_url = esc_url(
		add_query_arg(
			array(
				'give_action'  => 'download_card',
				'purchase_key' => give_get_payment_key( $payment_id ),
				'payment_id'   => $payment_id,
			), home_url()
		)
	);

	$formatted_download_url = sprintf( '<a href="%1$s">%2$s</a>', $download_url, __( 'Download the Card', 'give-tributes' ) . ' &raquo;' );

	return $formatted_download_url;
}

/**
 * Tribute template tag: {donation}
 *
 * Output the donation form name, and the donation level (if applicable).
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $form_title
 */
function give_tribute_tag_donation( $payment_id ) {
	$payment     = new Give_Payment( $payment_id );
	$level_title = give_has_variable_prices( $payment->form_id );
	$separator   = $level_title ? '-' : '';
	$args        = array(
		'only_level' => false,
		'separator'  => $separator,
	);
	$form_title  = strip_tags( give_get_donation_form_title( $payment, $args ) );

	return ! empty( $form_title ) ? $form_title : __( 'Sample Donation Form Title', 'give-tributes' );

}

/**
 * Tribute template tag: {tribute}
 *
 * Output the donation form tribute (if applicable).
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $type
 */
function give_tribute_tag_type( $payment_id ) {

	// Give Tribute type.
	$type = give_get_meta( $payment_id, '_give_tributes_type', true );

	return ! empty( $type ) ? $type : __( 'in honor of', 'give-tributes' );

}

/**
 * Tribute template tag: {honoree_name}
 *
 * Output the donation Honoree name (if applicable).
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $honoree_name
 */
function give_tribute_tag_honoree_name( $payment_id ) {

	// Honoree First name.
	$honoree_first_name = give_get_meta( $payment_id, '_give_tributes_first_name', true );
	$honoree_first_name = ! empty( $honoree_first_name ) ? $honoree_first_name : '';

	// Prepare Honoree Full name.
	if ( ! empty( $honoree_first_name ) ) {
		$honoree_name = $honoree_first_name;
	} else {
		$honoree_name = '';
	}

	return ! empty( $honoree_name ) ? ucfirst( $honoree_name ) : 'HonoreeFirstName';
}

/**
 * Tribute template tag: {notify_name}
 *
 * Output the donation Notify name (if applicable).
 *
 * @since 1.0.0
 *
 * @param array|integer $receipt_data Payment ID.
 *
 * @return string $notify_name
 */
function give_tribute_tag_notify_name( $receipt_data ) {

	// Get the payment id or receipt data according to argument.
	$payment_data = give_tributes_get_payment_id_or_data( $receipt_data );

	// Get the payment id.
	$payment_id = $payment_data['payment_id'];

	// Get the receipt data.
	$notify_data = $payment_data['notify_data'];

	$ecard_or_mailed = give_get_meta( $payment_id, '_give_tributes_would_to', true );
	$notify_name     = '';

	// If the notification method is eCard.
	if ( 'send_eCard' === $ecard_or_mailed ) {

		// If the receipt_data is not only payment id.
		if ( ! empty( $notify_data ) ) {

			// Get the notify person's first name.
			$notify_name = ! empty( $notify_data['first_name'] ) ? ucfirst( $notify_data['first_name'] ) : '';
		} else {

			$notify_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_first_name', true );
			$notify_name = ! empty( $notify_name ) ? ucfirst( $notify_name ) : '';
		}
	} elseif ( 'send_mail_card' === $ecard_or_mailed ) {
		$notify_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_first_name', true );
		$notify_name = ! empty( $notify_name ) ? ucfirst( $notify_name ) : '';
	}

	return ! empty( $notify_name ) ? ucfirst( $notify_name ) : 'NotifyFirstName';
}

/**
 * Tribute template tag: {notify_fullname}
 *
 * Output the donation Notify Full name (if applicable).
 *
 * @since 1.0.0
 *
 * @param array|integer $receipt_data Payment ID.
 *
 * @return string $notify_full_name
 */
function give_tribute_tag_notify_fullname( $receipt_data ) {

	// Get the payment id or receipt data according to argument.
	$payment_data = give_tributes_get_payment_id_or_data( $receipt_data );

	// Get the payment id.
	$payment_id = $payment_data['payment_id'];

	$ecard_or_mailed  = give_get_meta( $payment_id, '_give_tributes_would_to', true );
	$notify_full_name = '';

	if ( 'send_eCard' === $ecard_or_mailed ) {

		if ( ! empty( $payment_data['notify_data'] ) ) {

			// Get the notify person's first name.
			$notify_full_name = $payment_data['notify_data']['full_name'];

		} else {

			$ecard_notify_first_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_first_name', true );
			$ecard_notify_first_name = ! empty( $ecard_notify_first_name ) ? ucfirst( $ecard_notify_first_name ) : '';

			$ecard_notify_last_name = give_get_meta( $payment_id, '_give_tributes_ecard_notify_last_name', true );
			$ecard_notify_last_name = ! empty( $ecard_notify_last_name ) ? ucfirst( $ecard_notify_last_name ) : '';

			// eCard notify Full name.
			if ( ! empty( $ecard_notify_first_name ) || ! empty( $ecard_notify_last_name ) ) {
				$notify_full_name = $ecard_notify_first_name . ' ' . $ecard_notify_last_name;
			}
		}
	} elseif ( 'send_mail_card' === $ecard_or_mailed ) {

		$mail_card_notify_first_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_first_name', true );
		$mail_card_notify_first_name = ! empty( $mail_card_notify_first_name ) ? ucfirst( $mail_card_notify_first_name ) : '';

		$mail_card_notify_last_name = give_get_meta( $payment_id, '_give_tributes_mail_card_notify_last_name', true );
		$mail_card_notify_last_name = ! empty( $mail_card_notify_last_name ) ? ucfirst( $mail_card_notify_last_name ) : '';

		// Mail a Card notify Full name.
		if ( ! empty( $mail_card_notify_first_name ) || ! empty( $mail_card_notify_last_name ) ) {
			$notify_full_name = $mail_card_notify_first_name . ' ' . $mail_card_notify_last_name;
		}
	}

	return ! empty( $notify_full_name ) ? $notify_full_name : 'NotifyFirst NotifyLast';
}

/**
 * Tribute template tag: {donor_message}
 *
 * Output the donor message (if applicable).
 *
 * @since 1.1.0
 *
 * @param int|array $receipt_data Payment ID.
 *
 * @return string $donor_message_html
 */
function give_tribute_tag_donor_message( $receipt_data ) {

	// Get the payment id or receipt data according to argument.
	$payment_data = give_tributes_get_payment_id_or_data( $receipt_data );

	// Get the payment id.
	$payment_id = $payment_data['payment_id'];

	$ecard_or_mailed  = give_get_meta( $payment_id, '_give_tributes_would_to', true );
	$notify_full_name = '';

	$ecard_or_mailed           = give_get_meta( $payment_id, '_give_tributes_would_to', true );
	$donor_message_style       = apply_filters( 'give_tributes_donor_message_style', 'box-shadow: 0 0 0 1px #f3f3f3 !important;border-radius: 3px !important;background-color: rgb(246, 246, 246);border: 1px solid #f6f6f6;padding: 20px;margin:25px auto;', $payment_id );
	$personalized_message_font = apply_filters( 'give_tribute_personalized_message_font', "color: #000000; font-family: 'Helvetica Neue', Helvetica, Arial,'Lucida Grande', sans-serif; line-height: 150%; text-align: left; ", $payment_id );
	
	// eCard or Mail a Card?
	if ( 'send_eCard' === $ecard_or_mailed ) {

		// Check if the notification data is not blank.
		if ( ! empty( $payment_data['notify_data'] ) ) {

			if ( ! empty( $payment_data['notify_data']['message'] ) ) {
				// Donor message.
				$personalized_message = maybe_unserialize( $payment_data['notify_data']['message'] );
			}
		} else {
			$personalized_message = give_get_meta( $payment_id, '_give_tributes_ecard_personalized_message', true );
		}
	} elseif ( 'send_mail_card' === $ecard_or_mailed ) {
		$personalized_message      = give_get_meta( $payment_id, '_give_tributes_mail_card_personalized_message', true );
		$donor_message_style       = '';
		$personalized_message_font = '';
	}

	$personalized_message = ! empty( $personalized_message ) ? $personalized_message : '';

	// Is this a preview? If so, set example content.
	if ( isset( $_GET['give_action'] ) && 'preview_ecard' === $_GET['give_action'] && empty( $payment_id ) ) {
		$personalized_message = __( 'This is an example message which will be replaced with the message that is left by the donor.', 'give-tributes' );
	}

	ob_start();

	if ( ! empty( $personalized_message ) ) :
	?>
		<table border="0" cellpadding="0" cellspacing="0" id="template_header" style="<?php echo $donor_message_style; ?>">
			<tr>
				<td>
					<div id="give_tributes_ecard_personalized_message">
						<p style="font-size:13px;font-style:italic; margin:0;padding:0;"><?php echo apply_filters( 'give_tributes_donor_message_header_content', __( 'Message from the donor:', 'give-tributes' ), $payment_id ); ?></p>
						<p style="<?php echo $personalized_message_font; ?>"><?php echo $personalized_message; ?></p>
					</div>
				</td>
			</tr>
		</table>
	<?php
	endif;

	$donor_message_html = ob_get_clean();

	return apply_filters( 'give_tribute_donor_message', $donor_message_html, $payment_id );
}

/**
 * Tribute template tag: {honoree_fullname}
 *
 * Output the donation Honoree Full name (if applicable).
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $honoree_full_name
 */
function give_tribute_tag_honoree_fullname( $payment_id ) {

	// Honoree First name.
	$honoree_first_name = give_get_meta( $payment_id, '_give_tributes_first_name', true );
	$honoree_first_name = ! empty( $honoree_first_name ) ? $honoree_first_name : '';

	// Honoree last name.
	$honoree_last_name = give_get_meta( $payment_id, '_give_tributes_last_name', true );
	$honoree_last_name = ! empty( $honoree_last_name ) ? $honoree_last_name : '';

	// Prepare Honoree Full name.
	if ( ! empty( $honoree_first_name ) || ! empty( $honoree_last_name ) ) {
		$honoree_full_name = $honoree_first_name . ' ' . $honoree_last_name;
	} else {
		$honoree_full_name = '';
	}

	return ! empty( $honoree_full_name ) ? ucfirst( $honoree_full_name ) : 'HonoreeFirst HonoreeLast';
}

/**
 * Tribute template tag: {card_address}
 *
 * Output the donation Tribute address (if applicable).
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $honoree_full_address
 */
function give_tribute_tag_card_address( $payment_id ) {

	$honoree_full_address = give_tributes_notification_address( $payment_id, false );

	return ! empty( $honoree_full_address ) ? '<em>' . $honoree_full_address . '</em>' : '';

}

/**
 * Tribute template tag: amount.
 *
 * The total amount of the donation given.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string amount
 */
function give_tribute_tag_amount( $payment_id ) {
	$payment = new Give_Payment( $payment_id );

	$payment_total = $payment->total;

	// Assign default Payment total if empty.
	if ( empty( $payment->total ) ) {
		$payment_total = 10.50;
	}

	// Use Donation amount if exist.
	$donation_amount = give_get_meta( $payment_id, '_give_fee_donation_amount', true );
	if ( ! empty( $donation_amount ) ) {
		$payment_total = $donation_amount;
	}

	$give_amount = give_currency_filter( give_format_amount( $payment_total ), array( 'currency_code' => $payment->currency ) );

	return $give_amount;
}
