<?php
/**
 * Upgrade Functions
 *
 * @package     Give - Mollie
 * @subpackage  Admin/Upgrades
 * @copyright   Copyright (c) 2018, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.1.1
 *
 * NOTICE: When adding new upgrade notices, please be sure to put the action into the upgrades array during install: /includes/install.php @ Appox Line 156
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Display Upgrade Notices
 *
 * @param Give_Updates $give_updates Object of Give Updates Class.
 *
 * @since 1.1.1
 *
 * @return void
 */
function give_mollie_show_upgrade_notices( $give_updates ) {

	$give_updates->register(
		array(
			'id'       => 'give_mollie_v111_price_id',
			'version'  => '1.1.1',
			'callback' => 'give_mollie_v111_price_id_callback',
		)
	);

}

add_action( 'give_register_updates', 'give_mollie_show_upgrade_notices' );

/**
 * Fix Give Mollie Price ID.
 *
 * @since 1.1.1
 */
function give_mollie_v111_price_id_callback() {

	$give_updates = Give_Updates::get_instance();

	// form query
	$donations = new WP_Query( array(
			'paged'          => $give_updates->step,
			'status'         => give_get_payment_statuses(),
			'order'          => 'ASC',
			'post_type'      => array( 'give_payment' ),
			'posts_per_page' => 20,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'     => '_give_payment_gateway',
					'value'   => 'mollie',
					'compare' => '=',
				),
			),
		)
	);

	if ( $donations->have_posts() ) {

		$give_updates->set_percentage( $donations->found_posts, ( $give_updates->step * 20 ) );

		while ( $donations->have_posts() ) {
			$donations->the_post();

			$payment_id = get_the_ID();

			$price_id = give_get_meta( $payment_id, '_give_payment_price_id', true );
			$form_id  = give_get_meta( $payment_id, '_give_payment_form_id', true );
			$price    = give_get_meta( $payment_id, '_give_payment_total', true );
			$price    = give_maybe_sanitize_amount( $price );

			// Check if Price id is empty then set proper price id.
			if ( empty( $price_id ) ) {
				$price_id = give_get_price_id( $form_id, $price );
				give_update_meta( $payment_id, '_give_payment_price_id', $price_id );
			}

		}

		/* Restore original Post Data */
		wp_reset_postdata();

	} else {
		// The Update Ran.
		give_set_upgrade_complete( 'give_mollie_v111_price_id' );
	}

}



