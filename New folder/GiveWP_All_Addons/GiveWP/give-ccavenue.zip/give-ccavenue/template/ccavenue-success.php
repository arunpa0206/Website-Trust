<?php
/**
 * Process CCAvenue response.
 *
 * @since 1.0
 */
use Kishanio\CCAvenue\Payment as CCAvenueClient;
use Kishanio\CCAvenue\Utils as CCAvenueUtils;

$merchant = give_ccavenue_get_merchant_credentials();
$ccavenue = new CCAvenueClient( $merchant['merchant_id'], $merchant['working_key'], home_url( $_SERVER['REQUEST_URI'] ) );
$utils    = new CCAvenueUtils( $ccavenue );
$response = wp_parse_args( $utils->decrypt( $_REQUEST['encResp'], $merchant['working_key'] ) );


if ( isset( $response['order_status'] ) ) {
	switch ( $response['order_status'] ) {
		// Success
		case 'Success':
			give_ccavenue_process_success_payment( absint( $_REQUEST['orderNo'] ), $response );
			break;

		// Failure.
		case 'Aborted':
		case 'Failure':
			give_ccavenue_process_failed_payment( absint( $_REQUEST['orderNo'] ), $response );
			break;

		// Error.
		default:
			give_ccavenue_process_pending_payment( absint( $_REQUEST['orderNo'] ), $response );
	}
} else {
	wp_redirect( home_url() );
	exit();
}

