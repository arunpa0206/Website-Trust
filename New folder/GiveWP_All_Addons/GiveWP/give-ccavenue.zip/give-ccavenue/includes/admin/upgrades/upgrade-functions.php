<?php
/**
 * Upgrade Functions
 *
 * @package    Give-CCAvenue
 * @subpackage Admin/Upgrades
 * @copyright  Copyright (c) 2018, GiveWP
 * @license    https://opensource.org/licenses/gpl-license GNU Public License
 * @since      1.0.3
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Perform automatic database upgrades when necessary.
 *
 * @since  1.0.3
 *
 * @return void
 */
function give_ccavenue_do_automatic_upgrades() {

	$did_upgrade           = false;
	$give_ccavenue_version = preg_replace( '/[^0-9.].*/', '', get_option( 'give_ccavenue_version' ) );

	if ( ! $give_ccavenue_version ) {
		// 1.0.0 is the first version to use this option so we must add it.
		$give_ccavenue_version = '1.0.0';
	}

	switch ( true ) {

		case version_compare( $give_ccavenue_version, '1.0.3', '<' ):

			// Delete phone number field settings from options table.
			give_delete_option( 'ccavenue_phone_field' );

			// Add backward compatibility for CCAvenue Payment Method Label.
			$ccavenue_checkout_label = give_get_option( 'ccavenue_payment_method_label' );
			if ( ! empty( $ccavenue_checkout_label ) ) {
				$gateways             = give_get_option( 'gateways_label' );
				$gateways['ccavenue'] = $ccavenue_checkout_label;

				// Update to new setting and delete deprecated setting.
				give_update_option( 'gateways_label', $gateways );
				give_delete_option( 'ccavenue_payment_method_label' );
			}

			$did_upgrade = true;
			break;
	}

	// If automatic upgrade completed successfully, then proceed with updating version in db.
	if ( $did_upgrade ) {
		update_option( 'give_ccavenue_version', preg_replace( '/[^0-9.].*/', '', GIVE_CCAVENUE_VERSION ), false );
	}
}

add_action( 'admin_init', 'give_ccavenue_do_automatic_upgrades' );
add_action( 'give_upgrades', 'give_ccavenue_do_automatic_upgrades' );


