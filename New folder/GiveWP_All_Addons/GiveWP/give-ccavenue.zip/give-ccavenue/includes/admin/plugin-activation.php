<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Show plugin action links.
add_filter( 'plugin_action_links_' . GIVE_CCAVENUE_BASENAME, 'give_ccavenue_plugin_action_links' );

/**
 * Plugins row action links
 *
 * @since 1.0
 *
 * @param array $actions An array of plugin action links.
 *
 * @return array An array of updated action links.
 */
function give_ccavenue_plugin_action_links( $actions ) {
	$new_actions = array(
		'settings' => sprintf(
			'<a href="%1$s">%2$s</a>',
			admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=ccavenue' ),
			esc_html__( 'Settings', 'give-ccavenue' )
		),
	);

	return array_merge( $new_actions, $actions );
}


/**
 * Plugin row meta links
 *
 * @since 1.0
 *
 * @param array $plugin_meta An array of the plugin's metadata.
 * @param string $plugin_file Path to the plugin file, relative to the plugins directory.
 *
 * @return array
 */
function give_ccavenue_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( GIVE_CCAVENUE_BASENAME !== $plugin_file ) {
		return $plugin_meta;
	}

	$new_meta_links = array(
		sprintf(
			'<a href="%1$s" target="_blank">%2$s</a>',
			esc_url(
				add_query_arg(
					array(
						'utm_source'   => 'plugins-page',
						'utm_medium'   => 'plugin-row',
						'utm_campaign' => 'admin',
					), 'http://docs.givewp.com/addon-ccavenue'
				)
			),
			esc_html__( 'Documentation', 'give-ccavenue' )
		),
		sprintf(
			'<a href="%1$s" target="_blank">%2$s</a>',
			esc_url(
				add_query_arg(
					array(
						'utm_source'   => 'plugins-page',
						'utm_medium'   => 'plugin-row',
						'utm_campaign' => 'admin',
					), 'https://givewp.com/addons/'
				)
			),
			esc_html__( 'Add-ons', 'give-ccavenue' )
		),
	);

	return array_merge( $plugin_meta, $new_meta_links );
}

add_filter( 'plugin_row_meta', 'give_ccavenue_plugin_row_meta', 10, 2 );
