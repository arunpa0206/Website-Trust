<?php
/**
 * Plugin Name: Give - 2Checkout Gateway
 * Plugin URI:  https://givewp.com/addons/2checkout-gateway/
 * Description: Give add-on gateway for 2Checkout.
 * Version:     1.1.5
 * Author:      GiveWP
 * Author URI:  https://givewp.com
 * Text Domain: give-twocheckout
 * Domain Path: /languages
 *
 * @package: Give
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Give_Twocheckout
 */
final class Give_Twocheckout {

	/** Singleton *************************************************************/

	/**
	 * Give_Twocheckout instance
	 *
	 * @access private
	 * @since  1.0
	 *
	 * @var    Give_Twocheckout The one true Give_Twocheckout
	 */
	private static $instance;

	/**
	 * The ID
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @var    string
	 */
	public $id = 'give-twocheckout';

	/**
	 * The basename
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @var    string
	 */
	public $basename;

	/**
	 * The admin form
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @var    string Setup objects for each class
	 */
	public $admin_form;

	/**
	 * Notices (array)
	 *
	 * @since 1.1.2
	 *
	 * @var array
	 */
	public $notices = array();

	/**
	 * Main Give_Twocheckout Instance
	 *
	 * Insures that only one instance of Give_Twocheckout exists in memory at any one
	 * time. Also prevents needing to define globals all over the place.
	 *
	 * @staticvar array $instance
	 * @return Give_Twocheckout
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
			self::$instance->setup();
		}

		return self::$instance;
	}

	/**
	 * Give_Twocheckout constructor.
	 *
	 * @since 1.1.2
	 */
	public function setup() {

		// Define Globals.
		$this->define_globals();

		// Check environment before proceeding further.
		add_action( 'admin_init', array( $this, 'check_environment' ) );
		// Good Environment, then proceed to init hooks.
		add_action( 'give_init', array( $this, 'init_hooks' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );

	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.2
	 */
	public function init_hooks() {

		if ( ! $this->get_environment_warning() ) {
			return;
		}

		// Load required files.
		$this->includes();

		$this->init();
	}

	/**
	 * Defines all the globally used constants
	 *
	 * @since 1.0
	 * @return void
	 */
	private function define_globals() {

		if ( ! defined( 'GIVE_TWOCHECKOUT_VERSION' ) ) {
			define( 'GIVE_TWOCHECKOUT_VERSION', '1.1.5' );
		}
		if ( ! defined( 'GIVE_TWOCHECKOUT_MIN_GIVE_VERSION' ) ) {
			define( 'GIVE_TWOCHECKOUT_MIN_GIVE_VERSION', '2.4.0' );
		}
		if ( ! defined( 'GIVE_TWOCHECKOUT_PLUGIN_FILE' ) ) {
			define( 'GIVE_TWOCHECKOUT_PLUGIN_FILE', __FILE__ );
		}
		if ( ! defined( 'GIVE_TWOCHECKOUT_PLUGIN_DIR' ) ) {
			define( 'GIVE_TWOCHECKOUT_PLUGIN_DIR', plugin_dir_path( GIVE_TWOCHECKOUT_PLUGIN_FILE ) );
		}
		if ( ! defined( 'GIVE_TWOCHECKOUT_PLUGIN_URL' ) ) {
			define( 'GIVE_TWOCHECKOUT_PLUGIN_URL', plugin_dir_url( GIVE_TWOCHECKOUT_PLUGIN_FILE ) );
		}
		if ( ! defined( 'GIVE_TWOCHECKOUT_BASENAME' ) ) {
			define( 'GIVE_TWOCHECKOUT_BASENAME', plugin_basename( GIVE_TWOCHECKOUT_PLUGIN_FILE ) );
		}

	}

	/**
	 * Initialize.
	 */
	public function init() {

		// Load TextDomain.
		load_plugin_textdomain( 'give-twocheckout', false, dirname( GIVE_TWOCHECKOUT_BASENAME ) . '/languages' );

		// Class Instances.
		$this->payments = new Give_Twocheckout_Payments();

		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'give_after_cc_fields', array( $this, 'errors_div' ) );
	}

	/**
	 * Check the server environment.
	 *
	 * The backup sanity check, in case the plugin is activated in a weird way,
	 * or the environment changes after activation.
	 *
	 * @since 1.2
	 */
	public function check_environment() {
		// Flag to check whether plugin file is loaded or not.
		$is_working = true;

		// Load plugin helper functions.
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . '/wp-admin/includes/plugin.php';
		}

		/* Check to see if Give is activated, if it isn't deactivate and show a banner. */
		// Check for if give plugin activate or not.
		$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

		if ( empty( $is_give_active ) ) {
			// Show admin notice.
			$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - 2Checkout gateway to activate.', 'give-twocheckout' ), 'https://givewp.com' ) );
			$is_working = false;
		}

		return $is_working;
	}

	/**
	 * Check plugin for Give environment.
	 *
	 * @since  1.1.2
	 * @access public
	 *
	 * @return bool
	 */
	public function get_environment_warning() {
		// Flag to check whether plugin file is loaded or not.
		$is_working = true;

		// Verify dependency cases.
		if (
			defined( 'GIVE_VERSION' )
			&& version_compare( GIVE_VERSION, GIVE_TWOCHECKOUT_MIN_GIVE_VERSION, '<' )
		) {

			/* Min. Give. plugin version. */
			// Show admin notice.
			$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> core version %s for the Give - 2Checkout gateway to activate.', 'give-twocheckout' ), 'https://givewp.com', GIVE_TWOCHECKOUT_MIN_GIVE_VERSION ) );

			$is_working = false;
		}

		return $is_working;
	}

	/**
	 * Plugin Scripts
	 */
	public function scripts() {
		wp_register_script( 'give-twocheckout-tokenization', 'https://www.2checkout.com/checkout/api/2co.min.js', array( 'jquery' ) );
		wp_enqueue_script( 'give-twocheckout-tokenization' );
		wp_register_script( 'give-twocheckout-js', GIVE_TWOCHECKOUT_PLUGIN_URL . '/assets/js/give-twocheckout.js', array(
			'jquery',
			'give-twocheckout-tokenization',
		) );
		wp_enqueue_script( 'give-twocheckout-js' );

		wp_localize_script( 'give-twocheckout-js', 'give_twocheckout_js', array(
			'sellerId'           => give_get_option( 'twocheckout-sellerId' ),
			'publishableKey'     => give_get_option( 'twocheckout-public-key' ),
			'env'                => 'production',
			'api_error'          => esc_html__( 'Your payment could not be recorded. Please try again.', 'give-twocheckout' ),
			'keys_error'         => esc_html__( 'Incorrect API account number or keys. Check the plugin settings.', 'give-twocheckout' ),
			'card_details_error' => esc_html__( 'The donation could not be completed because there was invalid information submitted for payment. Please check your payment information and try again.', 'give-twocheckout' ),
			'error'              => esc_html__( 'Error', 'give-twocheckout' ),
		) );
	}

	/**
	 * Add an errors div
	 *
	 * @access      public
	 * @since       1.0
	 * @return      void
	 */
	public function errors_div() {
		echo '<div id="give-twocheckout-errors"></div>';
	}

	/**
	 * Include all files
	 *
	 * @since 1.0
	 * @return void
	 */
	private function includes() {
		self::includes_general();
		self::includes_admin();
	}

	/**
	 * Load general files
	 *
	 * @return void
	 */
	private function includes_general() {
		$files = array(
			'class-twocheckout-payments.php',
			'give-twocheckout-helpers.php',
		);

		foreach ( $files as $file ) {
			require( sprintf( '%s/includes/%s', untrailingslashit( GIVE_TWOCHECKOUT_PLUGIN_DIR ), $file ) );
		}
	}

	/**
	 * Load admin files
	 *
	 * @return void
	 */
	private function includes_admin() {
		if ( is_admin() ) {
			$files = array(
				'give-twocheckout-activation.php',
				'give-twocheckout-settings.php',
			);

			foreach ( $files as $file ) {
				require( sprintf( '%s/includes/admin/%s', untrailingslashit( GIVE_TWOCHECKOUT_PLUGIN_DIR ), $file ) );
			}
		}
	}

	/**
	 * Allow this class and other classes to add notices.
	 *
	 * @since 1.1.2
	 *
	 * @param $slug
	 * @param $class
	 * @param $message
	 */
	public function add_admin_notice( $slug, $class, $message ) {
		$this->notices[ $slug ] = array(
			'class'   => $class,
			'message' => $message,
		);
	}

	/**
	 * Display admin notices.
	 *
	 * @since 1.1.2
	 */
	public function admin_notices() {

		$allowed_tags = array(
			'a'      => array(
				'href'  => array(),
				'title' => array(),
				'class' => array(),
				'id'    => array(),
			),
			'br'     => array(),
			'em'     => array(),
			'span'   => array(
				'class' => array(),
			),
			'strong' => array(),
		);

		foreach ( (array) $this->notices as $notice_key => $notice ) {
			echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
			echo wp_kses( $notice['message'], $allowed_tags );
			echo '</p></div>';
		}

	}

}

/**
 * The main function responsible for returning the one true Give_Twocheckout
 * Instance to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * @since 1.0
 * @return bool|Give_Twocheckout
 */
function Give_Twocheckout() {
	return Give_Twocheckout::instance();
}

require_once 'vendor/autoload.php';
Give_Twocheckout();
