<?php
/**
 * BrainTree Helper Functions
 *
 * @package     Give
 * @copyright   Copyright (c) 2016, GiveWP
 * @license     https://opensource.org/licenses/gpl-license GNU Public License
 * @since       1.1
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handle Braintree API Transaction errors.
 *
 * @param $result Braintree\Result\Error
 * @param $payment_id
 *
 *@since 1.1
 *
 */
function give_braintree_handle_transaction_errors( $result, $payment_id ) {

	// Transaction errors from declined payments, etc.
	if ( isset( $result->transaction->processorResponseCode ) && $result->transaction->processorResponseCode > 0 ) {

		give_set_error( 'braintree_error', __( 'There was a problem processing your credit card. Please review your payment information and try again.', 'give-braintree' ) );
		// Log with DB.
		give_record_gateway_error( __( 'Braintree Error', 'give-braintree' ), sprintf( __( 'An error happened while processing a donation.<br><br>Details: %1$s <br><br>Code: %2$s', 'give-braintree' ), $result->transaction->processorResponseText, $result->transaction->processorResponseCode ) );

	} else {
		// Errors returned by Braintree API
		// @see https://developers.braintreepayments.com/reference/general/validation-errors/overview/php
		foreach ( $result->errors->deepAll() as $error ) {

			give_set_error( 'braintree_error', sprintf(
				__( '%s #%s - %s', 'give-braintree' ),
				$error->attribute,
				$error->code,
				$error->message
			) );

			// Log with DB.
			give_record_gateway_error( __( 'Braintree Error', 'give-braintree' ), sprintf( __( 'An error happened while processing a donation.<br><br>Details: %1$s <br><br>Code: %2$s', 'give-braintree' ), $error->message, $error->attribute ) );

		}
	}

	// Mark payment as failed.
	give_update_payment_status( $payment_id, 'failed' );

	// Send donor on back.
	give_send_back_to_checkout( '?payment-mode=braintree' );
}


/**
 * Log Braintree exception.
 *
 * @see   https://developers.braintreepayments.com/reference/general/exceptions/php
 *
 * @since 1.1
 *
 * @param $exception Braintree_Exception|Exception
 */
function give_log_braintree_error( $exception ) {

	$generic_message = __( 'An error occurred during processing of the donation.', 'give-braintree' );

	switch ( $exception ) {

		case ( $exception instanceof Braintree_Exception_Authentication ):
			$error_message = sprintf( __( 'A gateway authentication issue occurred while processing this donation. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_Configuration ):
			$error_message = sprintf( __( 'A gateway configuration issue occurred while processing this donation. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_Authorization ):
			$error_message = sprintf( __( 'A gateway authorization issue occurred while processing this donation. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_DownForMaintenance ):
			$error_message = sprintf( __( 'The payment gateway is down for maintenance at this time. Please try your donation again in a few hours. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_SSLCertificate ):
			$error_message = sprintf( __( 'The payment gateway could not verify this site\'s SSL certificate. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_Unexpected ):
			$error_message = __( 'An error occurred at payment gateway while processing your donation. Please try again.', 'give-braintree' );
			break;
		case ( $exception instanceof Braintree_Exception_ServerError ):
			$error_message = __( 'An error occurred at payment gateway while processing your donation. Please try again.', 'give-braintree' );
			break;
		case ( $exception instanceof Braintree_Exception_InvalidSignature ):
			$error_message = sprintf( __( 'The payment gateway returned an invalid signature response. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_NotFound ):
			$error_message = sprintf( __( 'The record you are trying to locate could not be found. Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		case ( $exception instanceof Braintree_Exception_ForgedQueryString ):
			$error_message = $generic_message . ' ' . sprintf( __( 'Details: %s', 'give-braintree' ), $exception->getMessage() );
			break;
		default:
			$error_message = $generic_message . ' ' . __( 'Please try again.', 'give-braintree' );

	}

	// Log with DB.
	give_record_gateway_error( __( 'Braintree Error', 'give-braintree' ), sprintf( __( 'An error happened while processing a donation.<br><br>Details: %1$s <br><br>Code: %2$s', 'give-braintree' ), $exception->getMessage(), $exception->getCode() ) );

	// Display error for user.
	give_set_error( 'braintree_error', $error_message );

	// Send em' on back
	give_send_back_to_checkout( '?payment-mode=braintree' );

}