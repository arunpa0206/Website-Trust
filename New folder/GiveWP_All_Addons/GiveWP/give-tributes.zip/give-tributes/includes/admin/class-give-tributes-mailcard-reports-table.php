<?php
/**
 * Give Tribute Mail a Card Report Table Class.
 *
 * @package     Give_Tributes
 * @subpackage  Give_Tributes/admin
 * @since       1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded.
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Give_Tributes_MailCard_Reports_Table Class
 *
 * Renders the Mail a Card Report table.
 *
 * @since 1.0
 */
class Give_Tributes_MailCard_Reports_Table extends WP_List_Table {

	/**
	 * Number of items per page.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $per_page = 30;

	/**
	 * Number of items found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $count = 0;

	/**
	 * Total items.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $total = 0;

	/**
	 * Number of donations found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $total_count = 0;

	/**
	 * Number of unsent Mail a Card donations found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $unsent_card_count = 0;

	/**
	 * Number of sent Mail a Card donations found.
	 *
	 * @var int
	 * @since 1.0.0
	 */
	public $sent_card_count = 0;

	/**
	 * Get things started.
	 *
	 * @since 1.0.0
	 * @see   WP_List_Table::__construct()
	 */
	public function __construct() {

		// Set parent defaults.
		parent::__construct( array(
			'singular' => __( 'Mail a Card', 'give-tributes' ),     // Singular name of the listed records.
			'plural'   => __( 'Mail Cards', 'give-tributes' ),    // Plural name of the listed records.
			'ajax'     => false,// Does this table support ajax?
		) );

		$this->process_bulk_action();
		$this->get_tributes_mail_card_counts();
	}
	/**
	 * Remove default search field in favor for repositioned location.
	 *
	 * Reposition the search field.
	 *
	 * @since       1.0.0
	 * @access      public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return false
	 */
	public function search_box( $text, $input_id ) {
		return false;
	}

	/**
	 * Retrieve the view types
	 *
	 * @access public
	 * @since  1.0
	 * @return array $views All the views available
	 */
	public function get_filter_mail_card_views() {

		$current           = isset( $_GET['mail_card_status'] ) ? $_GET['mail_card_status'] : '';
		$total_count       = '&nbsp;<span class="count">(' . $this->total_count . ')</span>';
		$unsent_card_count = '&nbsp;<span class="count">(' . $this->unsent_card_count . ')</span>';
		$sent_card_count   = '&nbsp;<span class="count">(' . $this->sent_card_count . ')</span>';

		$views = array(
			'all'          => sprintf( '<a href="%s"%s>%s</a>', remove_query_arg( array(
				'mail_card_status',
				'paged',
			) ), $current === 'all' || $current == '' ? ' class="current"' : '', __( 'All', 'give-tributes' ) . $total_count ),
			'unsent_cards' => sprintf( '<a href="%s"%s>%s</a>', esc_url( add_query_arg( array(
				'mail_card_status' => 'unsent_cards',
				'paged'            => false,
			) ) ), $current === 'unsent_cards' ? ' class="current"' : '', __( 'Unsent Cards', 'give-tributes' ) . $unsent_card_count ),
			'sent_cards'   => sprintf( '<a href="%s"%s>%s</a>', esc_url( add_query_arg( array(
				'mail_card_status' => 'sent_cards',
				'paged'            => false,
			) ) ), $current === 'sent_cards' ? ' class="current"' : '', __( 'Sent Cards', 'give-tributes' ) . $sent_card_count ),
		);

		return apply_filters( 'give_tributes_mail_card_table_views', $views );
	}

	/**
	 * Show the search field.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @param string $text     Label for the search box.
	 * @param string $input_id ID of the search box.
	 *
	 * @return void
	 */
	public function give_search_box( $text, $input_id ) {
		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['order'] ) ) {
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
		}
		?>
		<p class="search-box donor-search" role="search">
			<label class="screen-reader-text" for="<?php echo $input_id ?>"><?php echo $text; ?>:</label>
			<input type="search" id="<?php echo $input_id ?>" name="s" value="<?php _admin_search_query(); ?>" />
			<?php submit_button( $text, 'button', false, false, array(
				'ID' => 'search-submit',
			) ); ?>
		</p>
		<?php
	}


	/**
	 * This function renders most of the columns in the list table.
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @param array  $tributes_data Contains all the data of the tribute payment.
	 * @param string $column_name   The name of the column.
	 *
	 * @return string Column Name
	 */
	public function column_default( $tributes_data, $column_name ) {

		$single_donation_url = esc_url( add_query_arg( 'id', $tributes_data['id'], admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details' ) ) );
		$form_id             = give_get_payment_form_id( $tributes_data['id'] );

		switch ( $column_name ) {

			case 'donations' :
				$value = sprintf( '<a href="%1$s" data-tooltip="%2$s">%3$s</a>&nbsp;%4$s&nbsp;%5$s<br>', $single_donation_url, sprintf( esc_attr__( 'View Donation %s', 'give-tributes' ), $tributes_data['id'] ), $tributes_data['id'], __( 'by', 'give-tributes' ), $this->get_donor( $tributes_data ) );
				$value .= $this->get_donor_email( $tributes_data );
				break;
			case 'honoree_name' :
				$value = $tributes_data['honoree_name'];
				break;
			case 'notify_name' :
				$value = $tributes_data['notify_name'];
				break;
			case 'notify_address' :
				$value = $tributes_data['notify_address'];
				break;
			case 'print_card' :
				if ( give_is_setting_enabled( $tributes_data['honoree_card_enabled'] ) ) {
					$value = sprintf(
						'<a target="_blank" id="%1$s" class="give_tributes_print_card" href="%2$s">%3$s</a>',
						$tributes_data['id'],
						esc_url( add_query_arg( array(
							'give_action' => 'preview_mail_card',
							'preview_id'  => $tributes_data['id'],
						), home_url() ) ),
						__( 'Print Card', 'give-tributes' )
					);
				} else {
					$value = __( 'Disabled', 'give-tributes' );
				}
				break;
			case 'card_sent' :
				if ( give_is_setting_enabled( $tributes_data['honoree_card_enabled'] ) ) {

					if ( give_tributes_is_per_form_customized( $form_id ) ) {
						$card_mailed_notice = give_get_meta( $form_id, '_give_tributes_per_form_card_mailed_email_enable_disable', true );
					} else {
						$card_mailed_notice = give_get_option( 'give_tributes_card_mailed_email_enable_disable', 'disabled' );
					}

					$card_mailed_class = ( 'enabled' === $card_mailed_notice ) ? 'card_mailed_enabled' : 'card_mailed_disabled';

					$give_tributes_card_sent = give_get_meta( $tributes_data['id'], '_give_tributes_card_sent', true );

					if ( empty( $give_tributes_card_sent ) || 'sent_card' !== $give_tributes_card_sent ) {
						$value = '<a href="javascript:void(0);" class="button alignleft give-admin-button give_tribute_card_sent card_sent_' . $tributes_data['id'] . ' ' . $card_mailed_class . '" id="' . $tributes_data['id'] . '"><span class="dashicons dashicons-email-alt"></span>' . __( 'Mark as Sent', 'give-tributes' ) . '</a>';
					} else {
						$value = '<span class="alignleft">' . __( 'Card Sent', 'give-tributes' ) . ' - </span> <a href="javascript:void(0);" class="alignleft give_tribute_card_sent_undo card_sent_undo_' . $tributes_data['id'] . ' ' . $card_mailed_class . '" id="' . $tributes_data['id'] . '">' . __( 'Undo', 'give-tributes' ) . '</a>';
					}// End if().
				} else {
					$value = 'n/a';
				}
				break;
			default:
				$value = isset( $tributes_data[ $column_name ] ) ? $tributes_data[ $column_name ] : null;
				break;
		}// End switch().

		return apply_filters( "give_tributes_mail_card_report_column_{$column_name}", $value, $tributes_data['id'] );
	}

	/**
	 * Retrieve the table columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array $columns Array of all the list table columns.
	 */
	public function get_columns() {
		$columns = array(
			'cb'             => '<input type="checkbox" />', // Render a checkbox instead of text.
			'donations'      => __( 'Donation', 'give-tributes' ),
			'honoree_name'   => __( 'Honoree Name', 'give-tributes' ),
			'notify_name'    => __( 'Notification Name', 'give-tributes' ),
			'notify_address' => __( 'Notification Address', 'give-tributes' ),
			'print_card'     => __( 'Card', 'give-tributes' ),
			'card_sent'      => __( 'Card Sent', 'give-tributes' ),
		);

		/**
		 * Filter to add columns  in tribute mail card page
		 *
		 * @since  1.0.0
		 *
		 * @param array $columns Array of all the list table columns.
		 *
		 * @return array $columns Array of all the list table columns.
		 */
		return apply_filters( 'give_tributes_mail_card_report_columns', $columns );
	}

	/**
	 * Get checkbox html.
	 *
	 * @param object Tribute Contains all the data for the checkbox column.
	 *
	 * @access public
	 * @since  1.5.0
	 *
	 * @return string Displays a checkbox.
	 */
	public function column_cb( $payment ) {
		return sprintf( '<input type="checkbox" name="%1$s[]" value="%2$s" />', 'payment', $payment['id'] );
	}

	/**
	 * Retrieve the bulk actions
	 *
	 * @access public
	 * @since  1.5.0
	 *
	 * @return array $actions Array of the bulk actions
	 */
	public function get_bulk_actions() {
		$actions = array(
			'tributes_mark_and_send_card' => __( 'Send Card and Mark', 'give-tributes' ),
			'tributes_send_card_undo'     => __( 'Undo Send Card', 'give-tributes' ),
			'tributes_send_card'          => __( 'Send Card', 'give-tributes' ),
		);

		/**
		 * Filter to add/remove bulk action option in tribute send a card page
		 *
		 * @since 1.5.0
		 *
		 * @param array $actions List of action.
		 *
		 * @return array $actions List of action.
		 */
		return (array) apply_filters( 'give_tributes_send_card_table_bulk_actions', $actions );
	}

	/**
	 * Process the bulk actions
	 *
	 * @access public
	 * @since  1.5.0
	 *
	 * @return void
	 */
	public function process_bulk_action() {
		$ids     = isset( $_GET['payment'] ) ? $_GET['payment'] : false;
		$action  = $this->current_action();
		$process = false;

		if ( ! is_array( $ids ) ) {
			$ids = array( $ids );
		}

		if ( empty( $action ) ) {
			return;
		}

		$already_save = get_option( 'give-tributes-check' );
		if ( isset( $_GET['check'] ) && sanitize_text_field( $_GET['check'] ) !== $already_save ) {
			return;
		}

		foreach ( $ids as $id ) {
			// Detect when a bulk action is being triggered.
			switch ( $this->current_action() ) {
				case 'tributes_send_card':

					$form_id = give_get_payment_form_id( $id );
					if ( give_tributes_is_per_form_customized( $form_id ) ) {
						$card_mailed_notice = give_get_meta( $form_id, '_give_tributes_per_form_card_mailed_email_enable_disable', true );
					} else {
						$card_mailed_notice = give_get_option( 'give_tributes_card_mailed_email_enable_disable', 'disabled' );
					}

					if ( give_is_setting_enabled( $card_mailed_notice ) ) {

						// Card Sent Notification Email.
						give_tributes_mail_card_notification( $id );
					}
					$process = true;
					break;
				case 'tributes_mark_and_send_card':

					$form_id = give_get_payment_form_id( $id );
					if ( give_tributes_is_per_form_customized( $form_id ) ) {
						$card_mailed_notice = give_get_meta( $form_id, '_give_tributes_per_form_card_mailed_email_enable_disable', true );
					} else {
						$card_mailed_notice = give_get_option( 'give_tributes_card_mailed_email_enable_disable', 'disabled' );
					}

					if ( give_is_setting_enabled( $card_mailed_notice ) ) {

						// Card Sent Notification Email.
						give_tributes_mail_card_notification( $id );
					}

					give_update_payment_meta( $id, '_give_tributes_card_sent', 'sent_card' );
					$process = true;
					break;
				case 'tributes_send_card_undo':
					give_delete_meta( $id, '_give_tributes_card_sent' );
					$process = true;
					break;
			}
		}

		if ( $process ) {
			delete_option( 'give-tributes-check' );
		}
	}

	/**
	 * Generate the table navigation above or below the table.
	 *
	 * @since  1.0.0
	 * @access protected
	 *
	 * @param string $which Position.
	 */
	protected function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			wp_nonce_field( 'bulk-' . $this->_args['plural'] );
			$this->give_tribute_mail_card_status_views();
		}
		?>
		<div class="tablenav <?php echo esc_attr( $which ); ?>">

			<?php if ( $this->has_items() ): ?>
				<div class="alignleft actions bulkactions">
					<?php $this->bulk_actions( $which ); ?>
				</div>
			<?php endif;
			$this->extra_tablenav( $which );
			$this->pagination( $which );
			?>

			<br class="clear"/>
		</div>
		<?php
	}

	/**
	 * Get the sortable columns.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array Array of all the sortable columns.
	 */
	public function get_sortable_columns() {
		return array(
			'honoree_name' => array( 'honoree_name', true ),
			'donations'    => array( 'id', true ),
		);
	}

	/**
	 * Retrieve the current page number.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return int Current page number
	 */
	public function get_paged() {
		return isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : null;
	}

	/**
	 * Retrieves the search query string.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return mixed string If search is present, false otherwise
	 */
	public function get_search() {
		return ! empty( $_GET['s'] ) ? urldecode( give_clean( $_GET['s'] ) ) : false;
	}

	/**
	 * Retrieve all the data for all the payments.
	 *
	 * @access public
	 * @since  1.0.0
	 * @return array  objects in array containing all the data for the payments
	 */
	public function payments_data() {

		$per_page         = $this->per_page;
		$order            = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby          = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';
		$mail_card_status = isset( $_GET['mail_card_status'] ) ? sanitize_text_field( $_GET['mail_card_status'] ) : 'any';

		$meta_query_array = array();
		if ( 'unsent_cards' === $mail_card_status ) {
			$meta_query_array['key']     = '_give_tributes_card_sent';
			$meta_query_array['compare'] = 'NOT EXISTS';
		} elseif ( 'sent_cards' === $mail_card_status ) {
			$meta_query_array['key']     = '_give_tributes_card_sent';
			$meta_query_array['value']   = 'sent_card';
			$meta_query_array['compare'] = 'LIKE';
		}

		$args = array(
			'output'     => 'payments',
			'number'     => $per_page,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'meta_key'   => $meta_key = ( 'honoree_name' === $orderby ) ? '_give_tributes_last_name' : '',
			'orderby'    => $orderby = ( 'honoree_name' === $orderby ) ? 'meta_value' : $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_mail_card',
					'compare' => '=',
				),
				$meta_query_array,
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();

	}

	/**
	 * Setup the final data for the table
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @uses   Give_Donor_Reports_Table::get_columns()
	 * @uses   WP_List_Table::get_sortable_columns()
	 *
	 * @return void
	 */
	public function prepare_items() {

		$columns  = $this->get_columns();
		$hidden   = array(); // No hidden columns.
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );

		$this->items = $this->reports_data();

		$payments = $this->give_tribute_mailcard_query();

		$mail_card_status = isset( $_GET['mail_card_status'] ) ? $_GET['mail_card_status'] : 'any';

		switch ( $mail_card_status ) {
			case 'any':
				$this->total = count( $payments );
				break;
			case 'unsent_cards':
				$this->total = $this->unsent_card_count;
				break;
			case 'sent_cards':
				$this->total = $this->sent_card_count;
				break;
			default:
				$this->total = count( $payments );
				break;
		}

		$this->set_pagination_args( array(
			'total_items' => $this->total,
			'per_page'    => $this->per_page,
			'total_pages' => ceil( $this->total / $this->per_page ),
		) );
	}

	/**
	 * Retrieve the Mail a Card counts
	 *
	 * @access public
	 * @since  1.0
	 * @return void
	 */
	public function get_tributes_mail_card_counts() {

		$mail_card_unsent_count = $this->give_tribute_mailcard_card_unsent_query();
		$mail_card_sent_count   = $this->give_tribute_mailcard_card_sent_query();
		$mail_card_total_count  = $mail_card_unsent_count + $mail_card_sent_count;

		$this->sent_card_count   = $mail_card_sent_count;
		$this->unsent_card_count = $mail_card_unsent_count;
		$this->total_count       = $mail_card_total_count;
	}

	/**
	 * Display the list of views available on this table.
	 *
	 * @since  1.0
	 * @access public
	 */
	public function give_tribute_mail_card_status_views() {
		$views = $this->get_filter_mail_card_views();
		/**
		 * Filters the list of available list table views.
		 *
		 * The dynamic portion of the hook name, `$this->screen->id`, refers
		 * to the ID of the current screen, usually a string.
		 *
		 * @since 1.0.0
		 *
		 * @param array $views An array of available list table views.
		 */
		$views = apply_filters( "views_{$this->screen->id}", $views );

		if ( empty( $views ) ) {
			return;
		}

		$this->screen->render_screen_reader_content( 'heading_views' );

		echo "<ul class='subsubsub'>\n";
		foreach ( $views as $class => $view ) {
			$views[ $class ] = "\t<li class='$class'>$view";
		}
		echo implode( " |</li>\n", $views ) . "</li>\n";
		echo '</ul>';
	}


	/**
	 * Retrieve all the data for Mail a Card.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array  objects in array containing all the data for the payments.
	 */
	public function give_tribute_mailcard_query() {
		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$mail_card_status = isset( $_GET['mail_card_status'] ) ? sanitize_text_field( $_GET['mail_card_status'] ) : 'any';

		$meta_query_array = array();
		if ( 'unsent_cards' === $mail_card_status ) {
			$meta_query_array['key']     = '_give_tributes_card_sent';
			$meta_query_array['compare'] = 'NOT EXISTS';
		} elseif ( 'sent_cards' === $mail_card_status ) {
			$meta_query_array['key']     = '_give_tributes_card_sent';
			$meta_query_array['value']   = 'sent_card';
			$meta_query_array['compare'] = 'LIKE';
		}

		$args = array(
			'output'     => 'payments',
			'number'     => - 1,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_mail_card',
					'compare' => '=',
				),
				$meta_query_array,
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return $p_query->get_payments();
	}

	/**
	 * Retrieve all the card sent data for Mail a Card.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return int  Count of sent mail a card.
	 */
	public function give_tribute_mailcard_card_sent_query() {
		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => - 1,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_mail_card',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_card_sent',
					'value'   => 'sent_card',
					'compare' => 'LIKE',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return count( $p_query->get_payments() );
	}

	/**
	 * Retrieve all the card unsent data for Mail a Card.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return int Count of unsent mail a card.
	 */
	public function give_tribute_mailcard_card_unsent_query() {
		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'id';

		$args = array(
			'output'     => 'payments',
			'number'     => - 1,
			'page'       => isset( $_GET['paged'] ) ? $_GET['paged'] : null,
			'orderby'    => $orderby,
			'order'      => $order,
			'status'     => give_get_payment_status_keys(),
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key'     => '_give_tributes_accept',
					'value'   => 'yes',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_would_to',
					'value'   => 'send_mail_card',
					'compare' => '=',
				),
				array(
					'key'     => '_give_tributes_card_sent',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		$p_query = new Give_Payments_Query( $args );

		return count( $p_query->get_payments() );
	}

	/**
	 * Build all the reports data.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @return array $reports_data All the data for donor reports
	 */
	public function reports_data() {

		$data = array();

		$payments = $this->payments_data();

		if ( $payments ) {

			$this->count = count( $payments );

			foreach ( $payments as $payment ) {

				$user_id            = ! empty( $payment->user_id ) ? absint( $payment->user_id ) : 0;
				$honoree_first_name = give_get_meta( $payment->ID, '_give_tributes_first_name', true );
				$honoree_first_name = ! empty( $honoree_first_name ) ? $honoree_first_name : '';

				$honoree_last_name = give_get_meta( $payment->ID, '_give_tributes_last_name', true );
				$honoree_last_name = ! empty( $honoree_last_name ) ? $honoree_last_name : '';

				// Prepare Honoree Full name.
				if ( ! empty( $honoree_first_name ) || ! empty( $honoree_last_name ) ) {
					$honoree_full_name = $honoree_first_name . ' ' . $honoree_last_name;
				} else {
					$honoree_full_name = '';
				}

				// Notify Name.
				$notify_first_name = give_get_meta( $payment->ID, '_give_tributes_mail_card_notify_first_name', true );
				$notify_last_name  = give_get_meta( $payment->ID, '_give_tributes_mail_card_notify_last_name', true );

				// Prepare Honoree Full name.
				if ( ! empty( $notify_first_name ) ) {
					$notify_full_name = $notify_first_name;

					// Do we have a last name? If so append it.
					if ( ! empty( $notify_last_name ) ) {
						$notify_full_name .= ' ' . $notify_last_name;
					}

				} else {
					// Fallback to honoree name if notify name is empty.
					$honoree_notify_first_name = give_get_meta( $payment->ID, '_give_tributes_first_name', true );
					$honoree_notify_last_name  = give_get_meta( $payment->ID, '_give_tributes_last_name', true );
					$notify_full_name          = $honoree_notify_first_name . ' ' . $honoree_notify_last_name;
				}

				// Give Tribute Type.
				$tribute_type = give_get_meta( $payment->ID, '_give_tributes_type', true );

				// Honoree Full address.
				$notify_full_address = give_tributes_notification_address( $payment->ID, false );

				// Get Card creation enable/disabled.
				$card_creation = is_card_creation_enable( $payment->ID );

				$data[] = array(
					'id'                   => $payment->ID,
					'user_id'              => $user_id,
					'email'                => $payment->email,
					'honoree_name'         => $honoree_full_name,
					'notify_name'          => $notify_full_name,
					'notify_address'       => $notify_full_address,
					'honoree_card_enabled' => $card_creation,
					'honoree_type'         => $tribute_type,
				);
			}// End foreach().
		}// End if().

		return $data;
	}

	/**
	 * Get donor html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string Data shown in the User column.
	 */
	public function get_donor( $payment ) {

		$donor_id           = give_get_payment_donor_id( $payment['id'] );
		$donor_billing_name = give_get_donor_name_by( $payment['id'], 'donation' );
		$donor_name         = give_get_donor_name_by( $donor_id, 'donor' );

		$value = '';
		if ( ! empty( $donor_id ) ) {

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= $donor_billing_name . ' (';
			}

			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-donors&view=overview&id=$donor_id" ) ) . '">' . $donor_name . '</a>';

			// Check whether the donor name and WP_User name is same or not.
			if ( sanitize_title( $donor_billing_name ) !== sanitize_title( $donor_name ) ) {
				$value .= ')';
			}
		} else {
			$email = give_get_payment_user_email( $payment['id'] );
			$value .= '<a href="' . esc_url( admin_url( "edit.php?post_type=give_forms&page=give-payment-history&s=$email" ) ) . '">' . __( '(donor missing)', 'give-tributes' ) . '</a>';
		}

		return apply_filters( 'give_tributes_mail_card_donation_table_column', $value, $payment['id'], 'tributes' );
	}

	/**
	 * Get donor email html.
	 *
	 * @access public
	 * @since  1.0.0
	 *
	 * @param  Give_Payment $payment Contains all the data of the payment.
	 *
	 * @return string                Data shown in the Email column.
	 */
	public function get_donor_email( $payment ) {

		$email = give_get_payment_user_email( $payment['id'] );

		if ( empty( $email ) ) {
			$email = __( '(unknown)', 'give-tributes' );
		}

		$value = '<a href="mailto:' . $email . '" data-tooltip="' . esc_attr__( 'Email donor', 'give-tributes' ) . '">' . $email . '</a>';

		return apply_filters( 'give_payments_mail_card_table_column', $value, $payment['id'], 'email' );
	}
}
