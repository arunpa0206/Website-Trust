<?php
/**
 * Give Tributes eCards functions.
 *
 * @package    Give_Tributes
 * @subpackage Give_Tributes/includes
 * @author     GiveWP <https://givewp.com>
 */

/**
 * Get Give Tributes eCard Content for Donation.
 *
 * @since  1.0.0
 *
 * @param int $form_id Payment ID.
 *
 * @return string $ecard_content
 */
function give_tributes_get_ecard_content( $form_id = 0 ) {

	$form_customized      = give_get_meta( $form_id, '_give_tributes_per_form_enable_disable', true );
	$form_ecard_enabled   = give_get_meta( $form_id, '_give_tributes_per_form_ecards_enable_disable', true );
	$ecard_form_content   = give_get_meta( $form_id, '_give_tributes_per_form_ecards_content', true );
	$ecard_global_content = give_get_option( 'give_tributes_ecards_content', give_tributes_get_ecard_default_content() . "\n\n" );

	/**
	 * Conditions for per form override:
	 *
	 * a. Form has tributes customization enabled
	 * b. Form has eCards enabled
	 * c. Form has eCard content
	 *
	 * If none of the conditions above are met the plugin falls back to global settings.
	 */
	if ( 'enabled' === $form_customized && 'enabled' === $form_ecard_enabled && ! empty( $ecard_form_content ) ) {
		$ecard_content = $ecard_form_content;
	} else {
		$ecard_content = ! empty( $ecard_global_content ) ? $ecard_global_content : '';
	}

	return apply_filters( 'give_tributes_get_ecard_content', wpautop( $ecard_content ) );
}

/**
 *  Get default eCard Content.
 *
 * @return string $ecard_content
 */
function give_tributes_get_ecard_default_content() {

	$ecard_content = 'Dear {notify_name},' . "\n\n";
	$ecard_content .= 'A donation was made {tribute} {honoree_fullname} by {donor_fullname}. The {amount} donation that {donor_name} made to the "{form_title}" fund in your name will help our cause and be put to good use making a difference.' . "\n\n";
	$ecard_content .= '{donor_message}' . "\n\n";
	$ecard_content .= 'With our thanks,' . "\n";
	$ecard_content .= '{sitename}';

	return apply_filters( 'give_tributes_get_ecard_default_content', $ecard_content );
}

/**
 *  Get default eCard subject string.
 *
 * @return string $get_default_ecard_subject
 */
function give_tributes_get_default_ecard_subject() {

	$get_default_ecard_subject = '{donor_name} just gave {amount} {tribute} {honoree_fullname}!';

	return apply_filters( 'give_tributes_get_default_ecard_subject', $get_default_ecard_subject );
}

/**
 * Output eCard Template Preview Buttons.
 *
 * @since  1.0.0
 *
 * @param int $form_id Form ID.
 */
function give_tributes_ecard_preview_buttons_callback( $form_id = 0 ) {
	ob_start();
	?>
	<a href="<?php echo esc_url( add_query_arg( array(
		'give_action' => 'preview_ecard',
		'form_id'     => $form_id,
		'payment_id' => 0,
	), home_url() ) ); ?>" class="button-secondary"
	   target="_blank"><?php _e( 'Preview eCard', 'give-tributes' ); ?></a>
	<a href="<?php echo wp_nonce_url( add_query_arg( array(
		'give_action'  => 'tributes_send_test_email',
		'give-messages[]' => 'sent-tribute-test-email',
		'tag'          => 'tributes',
		'form_id'      => $form_id,
	) ), 'give-global-tributes-test-email' ); ?>" aria-label="<?php esc_attr_e( 'Send demo eCard to the emails listed below.', 'give-tributes' ); ?>"
	   class="button-secondary"><?php _e( 'Send Test Email', 'give-tributes' ); ?></a>
	<?php
	echo ob_get_clean();
}

/**
 * Get Give Tributes eCard honoree email address.
 *
 * @since  1.0.0
 *
 * @param int $payment_id Payment ID.
 *
 * @return string $email  Honoree email address.
 */
function give_tributes_ecard_honoree_email( $payment_id ) {
	$email = give_get_meta( $payment_id, '_give_tributes_honoree_ecard_email', true );

	return ! empty( $email ) ? $email : give_get_option( 'from_email', get_bloginfo( 'admin_email' ) );
}

/**
 * Give Tribute eCards Email Receipt.
 *
 * Email to the Honoree.
 *
 * @since 1.0.0
 *
 * @param int $payment_id Payment ID.
 * @param int $form_id    Form ID.
 * @param     array       List of emails to send.
 *
 * @return false|null
 */
function give_tributes_ecard_email_receipt( $payment_id = 0, $form_id = 0, $emails = array() ) {

	// Handle email receipt to donor.
	if ( isset( $_POST['give-action'] ) && 'create_manual_payment' === $_POST['give-action'] ) {
		if ( 'yes' !== $_POST['give-tribute-send-email'] ) {
			give_update_payment_meta( $payment_id, '_give_tribute_do_not_send_email', 1 );

			return false;
		}
	}

	// eCard from name.
	$from_name = give_get_option( 'from_name', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
	$from_name = apply_filters( 'give_tributes_ecard_from_name', $from_name );

	// eCard from email.
	$from_email = give_get_option( 'from_email', get_bloginfo( 'admin_email' ) );
	$from_email = apply_filters( 'give_tributes_ecard_from_address', $from_email );

	$form_id = ! empty( $form_id ) ? $form_id : give_get_payment_form_id( $payment_id );

	// The eCard email receipt subject.
	if ( give_tributes_is_per_form_customized( $form_id ) ) {
		$subject = give_get_meta( $form_id, '_give_tributes_per_form_ecards_email_subject', true );
	} else {
		$subject = give_get_option( 'give_tributes_ecards_email_subject', give_tributes_get_default_ecard_subject() );
	}

	// Strip all tags from subject.
	$subject = apply_filters( 'give_tributes_ecard_email_subject', wp_strip_all_tags( $subject ), $payment_id );

	// Replace subject tags.
	$subject = give_tribute_do_tags( $subject, $payment_id );

	// Convert in TEXT format.
	$subject = html_entity_decode( $subject, ENT_COMPAT, 'UTF-8' );

	if ( empty( $emails ) ) {

		// Get the emails.
		$to_emails = is_array( give_tributes_ecard_honoree_email( $payment_id ) ) ? give_tributes_ecard_honoree_email( $payment_id ) : array( give_tributes_ecard_honoree_email( $payment_id ) );
	} else {

		// If the emails were passed in function call.
		$to_emails = $emails;
	}

	/**
	 * Filters the Give Tributes eCard email receipt attachments.
	 * By default, there is no attachment but plugins can hook in to provide one more multiple for the donor.
	 *
	 * @since 1.0.0
	 */
	$attachments = apply_filters( 'give_tribute_ecard_receipt_attachments', array() );

	/**
	 * Filters the eCard receipt's email headers.
	 *
	 * @since 1.0.0
	 */
	$headers = "From: {$from_name} <{$from_email}>\r\n";
	$headers .= "Reply-To: {$from_email}\r\n";
	$headers .= "Content-Type: text/html; charset=utf-8\r\n";
	$headers = apply_filters( 'give_tribute_ecard_receipt_headers', $headers );

	// Go through each of the notification email.
	foreach ( $to_emails as $email_key => $email ) {

		// Generate and send eCards emails.
		$message =  give_tribute_ecard_build_email( $payment_id, $form_id, $email );

		// Send the eCard email receipt.
		wp_mail( $email, $subject, $message, $headers, $attachments );
	}

	$creation_date = get_post_field( 'post_date', $payment_id, 'raw' );
	give_update_payment_meta( $payment_id, '_give_tributes_ecard_email_sent_date', $creation_date );
}

/**
 * Give Tribute eCard Email template.
 *
 * @since 1.0.0
 *
 * @param int    $payment_id The Payment ID if provided.
 * @param int    $form_id    The form ID if provided.
 * @param string $email      Pass user's email address.
 *
 * @return string
 */
function give_tribute_ecard_build_email( $payment_id = 0, $form_id = 0, $email = '' ) {

	if ( empty( $form_id ) && ! empty( $payment_id ) ) {
		$form_id = give_get_payment_form_id( $payment_id );
	}

	ob_start();
	$message = give_tribute_do_tags( give_tributes_get_ecard_content( $form_id ), $payment_id, $email );

	/**
	 * Fires in the Give Tribute eCard email head.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_ecard_email_header', $payment_id, $form_id );

	/**
	 * Fires in the Give Tribute eCard email body.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_ecard_email_body', $payment_id, $form_id );

	/**
	 * Fires in the Give Tribute eCard email footer.
	 *
	 * @since 1.0.0
	 */
	do_action( 'give_tribute_ecard_email_footer', $payment_id, $form_id );

	$body    = ob_get_clean();
	$message = str_replace( '{ecard_email}', $message, $body );

	return apply_filters( 'give_tribute_ecard_email_message', $message );
}

/**
 * Give Tributes eCard Preview Email Header.
 *
 * Displays a header bar with the ability to change donations to preview actual data within the preview. Will not display if
 *
 * @since 1.0.0
 */
function give_tributes_preview_email_header() {

	// Payment receipt switcher.
	$payment_count = give_count_payments()->publish;
	$payment_id    = (int) isset( $_GET['preview_id'] ) ? $_GET['preview_id'] : '';

	if ( $payment_count <= 0 ) {
		return false;
	}

	// Get payments.
	$payments = new Give_Payments_Query( array(
		'number'     => 100,
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key'     => '_give_tributes_accept',
				'value'   => 'yes',
				'compare' => '=',
			),
			array(
				'key'     => '_give_tributes_would_to',
				'value'   => 'send_eCard',
				'compare' => '=',
			),
		),
	) );
	$payments = $payments->get_payments();
	$options  = array();

	// Provide nice human readable options..
	if ( $payments ) {
		$options[0] = __( '- Select a donation -', 'give-tributes' );
		foreach ( $payments as $payment ) {

			// If this payment has multiple receipts/notify.
			if ( give_tributes_is_multiple_receipts_enabled( $payment->ID ) && ! empty( $payment->ID ) ) {

				// Get the notify receipt lists.
				$notify_receipt_lists = give_tributes_get_notify_data_by_email( $payment->ID );

				// Go through each of the notification entry and add them into 'drop-down' for previewing the eCards.
				foreach ( $notify_receipt_lists as $notify_details ) {
					$options[ $payment->ID . '-' . $notify_details['email'] ] = esc_html( '#' . $payment->ID . ' - ' . $notify_details['email'] . ' - ' . $payment->form_title );
				}
			} else {
				$options[ $payment->ID ] = esc_html( '#' . $payment->ID . ' - ' . $payment->email . ' - ' . $payment->form_title );
			}

		}
	} else {
		$options[0] = __( 'No eCard donations found.', 'give-tributes' );
	}

	// Start constructing HTML output.
	$transaction_header = '<div style="margin:0;padding:10px 0;width:100%;background-color:#FFF;border-bottom:1px solid #eee; text-align:center;">';

	// Inline JS function for switching donations.
	$transaction_header .= '<script>
				 function change_preview(){
				  var transactions = document.getElementById("give_preview_ecard_email_payment_id");
			        var selected_trans = transactions.options[transactions.selectedIndex];
				        if (selected_trans){
				            var url_string = "' . get_bloginfo( 'url' ) . '?give_action=preview_ecard&preview_id=" + selected_trans.value;
				                window.location = url_string;
				        }
				    }
			    </script>';

	$transaction_header .= '<label for="give_preview_ecard_email_payment_id" style="font-size:12px;color:#333;margin:0 4px 0 0;">' . __( 'Preview eCard email with a donation:', 'give-tributes' ) . '</label>';

	// If payment id contains email inside it, then get it.
	$query_fragments = give_tributes_preview_ecard_fragments( $payment_id );

	// If the query string contains email.
	if ( ! empty( $query_fragments['email'] ) ) {

		// Generate the drop-down key for selected eCard.
		$selected_ecard = $query_fragments['payment_id'] . '-' . $query_fragments['email'];
	} else {
		$selected_ecard = $payment_id;
	}

	// The select field with 100 latest transactions.
	$transaction_header .= Give()->html->select( array(
		'name'             => 'preview_email_payment_id',
		'selected'         => $selected_ecard,
		'id'               => 'give_preview_ecard_email_payment_id',
		'class'            => 'give-preview-ecard-email-payment-id',
		'options'          => $options,
		'chosen'           => false,
		'select_atts'      => 'onchange="change_preview()">',
		'show_option_all'  => false,
		'show_option_none' => false,
	) );

	// Closing tag.
	$transaction_header .= '</div>';

	return apply_filters( 'give_tribute_preview_ecard_email_receipt_header', $transaction_header );

}

/**
 * This function will prepare eCard Actions i.e. Resend and Preview.
 *
 * @param int $donation_id Donation ID.
 *
 * @since 1.3.4
 *
 * @return bool|string
 */
function give_tributes_prepare_ecard_actions( $donation_id ) {

	// Bail out, if donation id doesn't exists.
	if ( empty( $donation_id ) ) {
		return false;
	}

	$is_multiple_receipts = give_get_meta( $donation_id, '_give_tributes_ecard_multiple_recipients', true );
	$user_email           = ! empty( $is_multiple_receipts ) && 'enabled' === $is_multiple_receipts ? '' : give_get_meta( $donation_id, '_give_tributes_honoree_ecard_email', true );

	// eCard Options.
	return sprintf(
		'<a id="%1$s" data-render="resend" data-email="%2$s" data-multiple_recipients="%3$s" class="give_tributes_ecard_resend" href="%4$s">%5$s</a> | <a target="_blank" id="%1$s" data-render="preview" class="give_tributes_ecard_preview" data-multiple_recipients="%3$s"  href="%6$s">%7$s</a>',
		$donation_id,
		sanitize_email( $user_email ),
		! empty( $is_multiple_receipts ) ? $is_multiple_receipts : 'disabled',
		give_tributes_get_ecards_action_url( $donation_id, 'resend' ),
		__( 'Resend', 'give-tributes' ),
		give_tributes_get_ecards_action_url( $donation_id, 'preview' ),
		__( 'Preview', 'give-tributes' )
	);
}