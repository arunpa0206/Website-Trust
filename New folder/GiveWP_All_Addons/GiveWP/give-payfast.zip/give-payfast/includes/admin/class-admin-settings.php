<?php
/**
 * Class Give_PayFast_Admin_Settings
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Give_Payfast_Admin_Settings' ) ) :

class Give_Payfast_Admin_Settings {
	/**
	 * Instance.
	 *
	 * @since  1.0
	 * @access static
	 *
	 * @var object $instance
	 */
	static private $instance;

	/**
	 * Payment gateways ID
	 *
	 * @since 1.0
	 *
	 * @var string $gateways_id
	 */
	private $gateways_id = '';

	/**
	 * Payment gateways label
	 *
	 * @since 1.0
	 *
	 * @var string $gateways_label
	 */
	private $gateways_label = '';

	/**
	 * Singleton pattern.
	 *
	 * @since  1.0
	 * @access private
	 *
	 * Give_Payfast_Admin_Settings constructor.
	 */
	private function __construct() {
	}

	/**
	 * Get instance.
	 *
	 * @since  1.0
	 * @access static
	 *
	 * @return static
	 */
	static function get_instance() {
		if ( null === static::$instance ) {
			self::$instance = new static();
		}

		return self::$instance;
	}

	/**
	 * Setup hooks
	 *
	 * @since  1.0
	 * @access public
	 */
	public function setup() {

		$this->gateways_id    = 'payfast';
		$this->gateways_label = __( 'PayFast', 'give-payfast' );

		add_filter( 'give_payment_gateways', array( $this, 'register_gateway' ) );
		add_filter( 'give_get_settings_gateways', array( $this, 'add_settings' ) );
		add_filter( 'give_get_sections_gateways', array( $this, 'add_gateways_section' ) );

	}

	/**
	 * Registers the PayFast Payment Gateway.
	 *
	 * @param array $gateways Payment Gateways List.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return mixed
	 */
	public function register_gateway( $gateways ) {
		$gateways[ $this->gateways_id ] = array(
			'admin_label'    => $this->gateways_label,
			'checkout_label' => give_payfast_get_payment_method_label(),
		);

		return $gateways;
	}

	/**
	 * Adds the PayFast Settings to the Payment Gateways.
	 *
	 * @param array $settings Payment Gateway Settings.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return array
	 */
	public function add_settings( $settings ) {

		if ( $this->gateways_id !== give_get_current_setting_section() ) {
			return $settings;
		}

		$payfast_settings = array(
			array(
				'id'   => $this->gateways_id,
				'type' => 'title',
			),
			array(
				'id'   => 'give_payfast_live_merchant_id',
				'name' => __( 'Live Merchant ID', 'give-payfast' ),
				'desc' => __( 'Live merchant id parameter provided by PayFast', 'give-payfast' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'give_payfast_live_merchant_access_key',
				'name' => __( 'Live Merchant Key', 'give-payfast' ),
				'desc' => __( 'Live secret key parameter provided by PayFast', 'give-payfast' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'give_payfast_live_passphrase',
				'name' => __( 'Live Passphrase', 'give-payfast' ),
				'desc' => __( 'Live Passphrase parameter provided by PayFast', 'give-payfast' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'id'   => 'give_payfast_sandbox_merchant_id',
				'name' => __( 'Sandbox Merchant ID', 'give-payfast' ),
				'desc' => __( 'Sandbox merchant id parameter provided by PayFast', 'give-payfast' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'give_payfast_sandbox_merchant_access_key',
				'name' => __( 'Sandbox Merchant Key', 'give-payfast' ),
				'desc' => __( 'Sandbox secret key parameter provided by PayFast', 'give-payfast' ),
				'type' => 'api_key',
				'size' => 'regular',
			),
			array(
				'id'   => 'give_payfast_sandbox_passphrase',
				'name' => __( 'Sandbox Passphrase', 'give-payfast' ),
				'desc' => __( 'Sandbox Passphrase parameter provided by PayFast', 'give-payfast' ),
				'type' => 'text',
				'size' => 'regular',
			),
			array(
				'title'       => __( 'Collect Billing Details', 'give-payfast' ),
				'id'          => 'give_payfast_billing_details',
				'type'        => 'radio_inline',
				'options'     => array(
					'enabled'  => __( 'Enabled', 'give-payfast' ),
					'disabled' => __( 'Disabled', 'give-payfast' ),
				),
				'default'     => 'disabled',
				'description' => __( 'This option will enable the billing details section for PayFast which requires the donor\'s address to complete the donation. These fields are not required by PayFast to process the transaction, but you may have the need to collect the data.', 'give-payfast' ),
			),
			array(
				'id'   => $this->gateways_id,
				'type' => 'sectionend',
			),
		);

		return $payfast_settings;
	}

	/**
	 * Add PayFast to payment gateway section
	 *
	 * @param array $section Payment Gateway Sections.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return mixed
	 */
	public function add_gateways_section( $section ) {
		$section[ $this->gateways_id ] = __( 'PayFast', 'give-payfast' );
		return $section;
	}
}

endif;

// Initialize settings.
Give_Payfast_Admin_Settings::get_instance()->setup();
