<?php
/**
 * Plugin Name: Give - CCAvenue Gateway
 * Plugin URI: https://github.com/impress-org/give-ccavenue
 * Description: Process online donations via the CCAvenue gateway.
 * Author: GiveWP
 * Author URI: https://givewp.com
 * Version: 1.0.4
 * Text Domain: give-ccavenue
 * Domain Path: /languages
 * GitHub Plugin URI: https://github.com/impress-org/give-ccavenue
 */

// Exit if access directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Give_CCAvenue_Payment' ) ) {
	/**
	 * Class Give_CCAvenue_Payment
	 *
	 * @since 1.0
	 */
	class Give_CCAvenue_Payment {

		/**
		 * @since  1.0
		 * @access static
		 * @var Give_CCAvenue_Payment $instance
		 */
		static private $instance;

		/**
		 * Notices (array)
		 *
		 * @since 1.0.3
		 *
		 * @var array
		 */
		public $notices = array();

		/**
		 * Singleton pattern.
		 *
		 * @since  1.0
		 * @access static
		 * @return Give_CCAvenue_Payment
		 */
		static function get_instance() {
			if ( null === self::$instance ) {
				static::$instance = new static();
				self::$instance->setup();
			}

			return self::$instance;
		}

		/**
		 * Setup Give CCAvenue.
		 *
		 * @since 1.0.3
		 * @access private
		 */
		private function setup() {

			// Setup constants.
			$this->set_constants();

			// Give init hook.
			add_action( 'give_init', array( $this, 'init' ), 10 );
			add_action( 'admin_init', array( $this, 'check_environment' ), 999 );
			add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );
		}

		/**
		 * Load libraries.
		 *
		 * @since 1.0.3
		 * @access public
		 * @return void
		 */
		public function init() {

			if ( ! $this->get_environment_warning() ) {
				return;
			}


			$this->licensing();
			$this->load_textdomain();
			$this->give_ccavenue_activation_banner();

			// Load lib.
			require_once 'includes/lib/bootstrap.php';

			// Load general functions.
			require_once 'includes/functions.php';

			// Load filters.
			require_once 'includes/filters.php';

			// Load frontend actions.
			require_once 'includes/actions.php';

			// Process donation payment.
			require_once 'includes/donation-processing.php';

			if ( is_admin() ) {
				// Process plugin activation.
				require_once 'includes/admin/plugin-activation.php';

				// Load admin actions
				require_once 'includes/admin/actions.php';

				// Load upgrade routines.
				require_once 'includes/admin/upgrades/upgrade-functions.php';

			}

			// Load admin settings and register payment gateway.
			require_once 'includes/admin/class-admin-settings.php';
		}

		/**
		 * Setup constants.
		 *
		 * @since  1.0
		 * @access public
		 */
		public function set_constants() {
			define( 'GIVE_CCAVENUE_VERSION', '1.0.4' );
			define( 'GIVE_CCAVENUE_MIN_GIVE_VER', '2.3.0' );
			define( 'GIVE_CCAVENUE_BASENAME', plugin_basename( __FILE__ ) );
			define( 'GIVE_CCAVENUE_URL', plugins_url( '/', __FILE__ ) );
			define( 'GIVE_CCAVENUE_DIR', plugin_dir_path( __FILE__ ) );
		}

		/**
		 * Load the text domain.
		 *
		 * @access private
		 * @since  1.0
		 *
		 * @return void
		 */
		public function load_textdomain() {

			// Set filter for plugin's languages directory.
			$give_ccavenue_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
			$give_ccavenue_lang_dir = apply_filters( 'give_ccavenue_languages_directory', $give_ccavenue_lang_dir );

			// Traditional WordPress plugin locale filter
			$locale = apply_filters( 'plugin_locale', get_locale(), 'give-ccavenue' );
			$mofile = sprintf( '%1$s-%2$s.mo', 'give-ccavenue', $locale );

			// Setup paths to current locale file
			$mofile_local  = $give_ccavenue_lang_dir . $mofile;
			$mofile_global = WP_LANG_DIR . '/give-ccavenue/' . $mofile;

			if ( file_exists( $mofile_global ) ) {
				// Look in global /wp-content/languages/give-ccavenue folder
				load_textdomain( 'give-ccavenue', $mofile_global );
			} elseif ( file_exists( $mofile_local ) ) {
				// Look in local /wp-content/plugins/give-ccavenue/languages/ folder
				load_textdomain( 'give-ccavenue', $mofile_local );
			} else {
				// Load the default language files
				load_plugin_textdomain( 'give-ccavenue', false, $give_ccavenue_lang_dir );
			}

		}

		/**
		 * Enqueue scripts.
		 *
		 * @since  1.0
		 * @access public
		 *
		 * @param string $hook
		 *
		 * @return void
		 */
		function enqueue_scripts( $hook ) {
			if ( 'gateways' === give_get_current_setting_tab() && 'ccavenue' === give_get_current_setting_section() ) {
				wp_enqueue_script( 'give-ccavenue-admin-settings', plugins_url( '/assets/js/admin/admin-settings.js', __FILE__ ), array( 'jquery' ) );
			}
		}

		/**
		 * Check plugin environment.
		 *
		 * @since 1.0.3
		 * @access public
		 *
		 * @return bool
		 */
		public function check_environment() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Load plugin helper functions.
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . '/wp-admin/includes/plugin.php';
			}

			/* Check to see if Give is activated, if it isn't deactivate and show a banner. */
			// Check for if give plugin activate or not.
			$is_give_active = defined( 'GIVE_PLUGIN_BASENAME' ) ? is_plugin_active( GIVE_PLUGIN_BASENAME ) : false;

			if ( empty( $is_give_active ) ) {
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_activate', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> plugin installed and activated for Give - CCAvenue to activate.', 'give-ccavenue' ), 'https://givewp.com' ) );
				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Check plugin for Give environment.
		 *
		 * @since 1.0.3
		 * @access public
		 *
		 * @return bool
		 */
		public function get_environment_warning() {
			// Flag to check whether plugin file is loaded or not.
			$is_working = true;

			// Verify dependency cases.
			if (
				defined( 'GIVE_VERSION' )
				&& version_compare( GIVE_VERSION, GIVE_CCAVENUE_MIN_GIVE_VER, '<' )
			) {

				/* Min. Give. plugin version. */
				// Show admin notice.
				$this->add_admin_notice( 'prompt_give_incompatible', 'error', sprintf( __( '<strong>Activation Error:</strong> You must have the <a href="%s" target="_blank">Give</a> core version %s for the Give - CCAvenue add-on to activate.', 'give-ccavenue' ), 'https://givewp.com', GIVE_CCAVENUE_MIN_GIVE_VER ) );

				$is_working = false;
			}

			return $is_working;
		}

		/**
		 * Show activation banner for this add-on.
		 *
		 * @since 1.0.3
		 */
		public function give_ccavenue_activation_banner() {
			// Check for activation banner inclusion.
			if (
				! class_exists( 'Give_Addon_Activation_Banner' )
				&& file_exists( GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php' )
			) {
				include GIVE_PLUGIN_DIR . 'includes/admin/class-addon-activation-banner.php';
			}

			// Initialize activation welcome banner.
			if ( class_exists( 'Give_Addon_Activation_Banner' ) ) {

				// Only runs on admin.
				$args = array(
					'file'              => __FILE__,
					'name'              => esc_html__( 'CCAvenue Gateway', 'give-ccavenue' ),
					'version'           => GIVE_CCAVENUE_VERSION,
					'settings_url'      => admin_url( 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=ccavenue' ),
					'documentation_url' => 'http://docs.givewp.com/addon-ccavenue',
					'support_url'       => 'https://givewp.com/support/',
					'testing'           => false, // Never leave true.
				);

				new Give_Addon_Activation_Banner( $args );
			}
		}

		/**
		 * Allow this class and other classes to add notices.
		 *
		 * @since 1.0.3
		 *
		 * @param $slug
		 * @param $class
		 * @param $message
		 */
		public function add_admin_notice( $slug, $class, $message ) {
			$this->notices[ $slug ] = array(
				'class'   => $class,
				'message' => $message,
			);
		}

		/**
		 * Display admin notices.
		 *
		 * @since 1.0.3
		 */
		public function admin_notices() {

			$allowed_tags = array(
				'a'      => array(
					'href'  => array(),
					'title' => array(),
					'class' => array(),
					'id'    => array(),
				),
				'br'     => array(),
				'em'     => array(),
				'span'   => array(
					'class' => array(),
				),
				'strong' => array(),
			);

			foreach ( (array) $this->notices as $notice_key => $notice ) {
				echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
				echo wp_kses( $notice['message'], $allowed_tags );
				echo '</p></div>';
			}

		}

		/**
		 * Implement Give Licensing for Give Mollie Add On.
		 *
		 * @since 1.0.3
		 * @access private
		 */
		private function licensing() {
			if ( class_exists( 'Give_License' ) ) {
				new Give_License( __FILE__, 'CCAvenue Gateway', GIVE_CCAVENUE_VERSION, 'WordImpress' );
			}
		}
	}

	/**
	 * Returns class object instance.
	 *
	 * @since 1.0.3
	 *
	 * @return Give_CCAvenue_Payment bool|object
	 */
	function Give_CCAvenue_Payment() {
		return Give_CCAvenue_Payment::get_instance();
	}

	Give_CCAvenue_Payment();
}
